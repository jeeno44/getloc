#!/bin/bash

ROOT_PATH=$(cd $(dirname $0) && pwd);

DIR=$ROOT_PATH"/../src/AnaliticsBundle/"

#
# Ищес список entity основываясь на список файлов
#
find $DIR"Entity/" -printf '%f\n' | grep '\.php' | cut -d '.' -f 1 | while read file
do
  # Выводи название entity без расширения ".php"
  echo $file


  sed -i -e 's/ORM\\Entity/ORM\\Entity(repositoryClass="AnaliticsBundle\\Entity\\'$file'Repository")/g' $DIR"Entity/"$file".php"
  sed -i -e 's/ORM\\Entity(repositoryClass="AnaliticsBundle\\Entity\\'$file'Repository")(repositoryClass="AnaliticsBundle\\Entity\\'$file'Repository")/ORM\\Entity(repositoryClass="AnaliticsBundle\\Entity\\'$file'Repository")/g' $DIR"Entity/"$file".php"
done

exit 0
