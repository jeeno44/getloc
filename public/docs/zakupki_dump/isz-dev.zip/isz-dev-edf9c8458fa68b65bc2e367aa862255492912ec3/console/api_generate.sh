#!/bin/bash

ROOT_PATH=$(cd $(dirname $0) && pwd);

DIR=$ROOT_PATH"/../src/AnaliticsBundle/"
CONFIG_ROUTING=$ROOT_PATH"/../app/config/routing.yml"

#
# В роутах возвращаем ссылки на AnaliticsBundle, что бы не создались новые/старые роуты
#
sed -i -e 's/@ApiBundle\/Controller\/\(.*\)RESTController.php/@AnaliticsBundle\/Controller\/\1RESTController.php/g' $CONFIG_ROUTING

#
# Ищес список entity основываясь на список файлов
#
find $DIR"Entity/" -printf '%f\n' | grep '\.php' | cut -d '.' -f 1 | while read file
do
  # Выводи название entity без расширения ".php"
  echo "$file"

  # Генерируем API для entity
  php app/console voryx:generate:rest --overwrite -n --route-prefix="/api" --entity=AnaliticsBundle:$file

  # Так как API изначально создаётся не в том bundle который необходимо, занимаемся перименовыванием ссылок на нужный bundle в controler-ах
  sed -i -e 's/namespace AnaliticsBundle/namespace\ ApiBundle/g' $DIR"Controller/"$file"RESTController.php"
  sed -i -e 's/use AnaliticsBundle\\Form\(.*\)Type/use ApiBundle\\Form\1Type/g' $DIR"Controller/"$file"RESTController.php"
  # Перемещаем controller в необходимый bundle
  mv $DIR"Controller/"$file"RESTController.php" "src/ApiBundle/Controller/"$file"RESTController.php"


  # Так как API изначально создаётся не в том bundle который необходимо, занимаемся перименовыванием ссылок на нужный bundle в form-ах
  sed -i -e 's/namespace AnaliticsBundle/namespace ApiBundle/g' $DIR"Form/"$file"Type.php"
  sed -i -e 's/analiticsbundle/apibundle/g' $DIR"Form/"$file"Type.php"
  # Перемещаем form в необходимый bundle
  mv $DIR"Form/"$file"Type.php" "src/ApiBundle/Form/"$file"Type.php"
done

#
# В роутах заменяем ссылки на нужный нам bundle
#
sed -i -e 's/@AnaliticsBundle\/Controller\/\(.*\)RESTController.php/@ApiBundle\/Controller\/\1RESTController.php/g' $CONFIG_ROUTING

exit 0
