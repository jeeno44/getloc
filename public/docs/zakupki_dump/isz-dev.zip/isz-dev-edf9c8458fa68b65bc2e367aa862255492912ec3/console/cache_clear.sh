#!/usr/bin/env bash

ROOT_PATH=$(cd $(dirname $0) && pwd)"/../";

$ROOT_PATH""app/console doctrine:cache:clear-result
$ROOT_PATH""app/console doctrine:cache:clear-result --env=prod
$ROOT_PATH""app/console doctrine:cache:clear-result --env=test
#$ROOT_PATH""app/console doctrine:cache:clear-result --env=admin
#ROOT_PATH""app/console doctrine:cache:clear-result --env=app
#$ROOT_PATH""app/console doctrine:cache:clear-result --env=expertise
$ROOT_PATH""app/console doctrine:cache:clear-query
$ROOT_PATH""app/console doctrine:cache:clear-query --env=prod
$ROOT_PATH""app/console doctrine:cache:clear-query --env=test
#$ROOT_PATH""app/console doctrine:cache:clear-query --env=admin
#$ROOT_PATH""app/console doctrine:cache:clear-query --env=app
#$ROOT_PATH""app/console doctrine:cache:clear-query --env=expertise
$ROOT_PATH""app/console doctrine:cache:clear-metadata
$ROOT_PATH""app/console doctrine:cache:clear-metadata --env=prod
$ROOT_PATH""app/console doctrine:cache:clear-metadata --env=test
#$ROOT_PATH""app/console doctrine:cache:clear-metadata --env=admin
#$ROOT_PATH""app/console doctrine:cache:clear-metadata --env=app
#$ROOT_PATH""app/console doctrine:cache:clear-metadata --env=expertise
$ROOT_PATH""app/console doctrine:cache:clear storage
$ROOT_PATH""app/console doctrine:cache:clear storage --env=prod
$ROOT_PATH""app/console doctrine:cache:clear storage --env=test
#$ROOT_PATH""app/console doctrine:cache:clear storage --env=admin
#$ROOT_PATH""app/console doctrine:cache:clear storage --env=app
#$ROOT_PATH""app/console doctrine:cache:clear storage --env=expertise
$ROOT_PATH""app/console cache:clear
$ROOT_PATH""app/console cache:clear --env=prod
$ROOT_PATH""app/console cache:clear --env=test
#$ROOT_PATH""app/console cache:clear --env=admin
#$ROOT_PATH""app/console cache:clear --env=app
#$ROOT_PATH""app/console cache:clear --env=expertise
