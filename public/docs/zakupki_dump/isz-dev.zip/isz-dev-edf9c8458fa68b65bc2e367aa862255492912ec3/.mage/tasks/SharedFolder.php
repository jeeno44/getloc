<?php
namespace Task;

use Mage\Task\AbstractTask;

class SharedFolder extends AbstractTask
{
    public function getName()
    {
        return 'Creating symbolic links';
    }

    public function run()
    {
        $deployToDirectory = $this->getConfig()->deployment('to');

        $sharedFiles = ['uploads', 'documents', 'postman'];
        foreach ($sharedFiles as $sf) {
            $command = "ln -s ".$deployToDirectory.'/'.$sf.' '.$deployToDirectory.'/releases/'.$this->getConfig()->getReleaseId().'/web/'.$sf;
            $this->runCommandRemote($command);
        }

        return true;
    }
}
