<?php
namespace Task;

use Mage\Task\AbstractTask;

class ConsumersRestart extends AbstractTask
{
    public function getName()
    {
        return 'Restart rabbitmq consumers';
    }

    public function run()
    {
        $command = 'cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.conf serialrestart storage:*';
        $result = $this->runCommandRemote($command);
        return $result;
    }
}