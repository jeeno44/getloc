<?php
namespace Task;

use Mage\Task\AbstractTask;

class CopyConfigFiles extends AbstractTask
{
    /**
     * @return string
     */
    public function getName()
    {
        return 'Copy config files';
    }

    /**
     * @return bool
     */
    public function run()
    {
        $deployToDirectory = $this->getConfig()->deployment('to');

        $sharedFiles = $this->getParameter('files', false);
        if ($sharedFiles) {
            foreach (explode(",", $sharedFiles) as $sf) {
                $command = "cp ".$deployToDirectory.'/'.$sf.' '.$deployToDirectory.'/releases/'.$this->getConfig()->getReleaseId().'/app/config/'.$sf;
                $this->runCommandRemote($command);
            }
        }

        return true;
    }
}
