<?php
namespace Task;

use Mage\Task\AbstractTask;

class Composer extends AbstractTask
{
    public function getName()
    {
        return 'Composer install';
    }

    public function run()
    {
        $command = 'composer install';
        $result = $this->runCommandRemote($command);

        return $result;
    }
}