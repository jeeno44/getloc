Запуск schema RPC
==================================

Используется модифицированный `videlalvaro/RabbitMqBundle`

## Настройка RPC сервера

``` yml
    rpc_servers:
        isz:
            connection: default
            callback: storage.consumer
            qos_options:
                prefetch_size: 0
                prefetch_count: 1
                global: false
            queue_options:
                name: 'storage'
                durable: true
                auto_delete: true
```

## Запуск RPC сервера

В консоли вводим команду

``` bash
php app/console rabbitmq:rpc-server isz -r storage.#.#
```

## Клиент

Для взаимодействия с сервером выполняем

   ```php
           $client = $this->get('old_sound_rabbit_mq.schema_rpc');
           $client->addRequest(null, 'isz', $messageId, "storage.$entity.schema");
           $replies = $client->getReplies();
   ```

где `$messageId` - уникальный ключ (подойдет `time()`) а `$entity` - название сущности с большой буквы