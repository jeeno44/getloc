<?php

use Symfony\Component\HttpKernel\Kernel;
use Symfony\Component\Config\Loader\LoaderInterface;

class AppKernel extends Kernel
{
    public function registerBundles()
    {
        $bundles = array(
            new Symfony\Bundle\FrameworkBundle\FrameworkBundle(),
            new Symfony\Bundle\SecurityBundle\SecurityBundle(),
            new Symfony\Bundle\MonologBundle\MonologBundle(),
            new Symfony\Bundle\AsseticBundle\AsseticBundle(),
            new Doctrine\Bundle\DoctrineBundle\DoctrineBundle(),
            new Sensio\Bundle\FrameworkExtraBundle\SensioFrameworkExtraBundle(),

            // Redis
            new Snc\RedisBundle\SncRedisBundle(),

            // REST
            new FOS\RestBundle\FOSRestBundle(),
            new JMS\SerializerBundle\JMSSerializerBundle($this),
            new Nelmio\CorsBundle\NelmioCorsBundle(),
            new Voryx\RESTGeneratorBundle\VoryxRESTGeneratorBundle(),

            new Doctrine\Bundle\DoctrineCacheBundle\DoctrineCacheBundle(),

            new OldSound\RabbitMqBundle\OldSoundRabbitMqBundle(),
            new Knp\JsonSchemaBundle\KnpJsonSchemaBundle(),
            new HWI\Bundle\OAuthBundle\HWIOAuthBundle(),

            new Liuggio\ExcelBundle\LiuggioExcelBundle(),

            new AnalyticsBundle\AnalyticsBundle(),
            new AppBundle\AppBundle(),
            new ExcelBundle\ExcelBundle(),
            new ExpertiseBundle\ExpertiseBundle(),
            new FormBundle\FormBundle(),
            new FreshdocBundle\FreshdocBundle(),
            new PostmanBundle\PostmanBundle(),

            new JMS\AopBundle\JMSAopBundle(),
            new JMS\SecurityExtraBundle\JMSSecurityExtraBundle(),
            new delelo\KladrBundle\KladrBundle(),
            new Stof\DoctrineExtensionsBundle\StofDoctrineExtensionsBundle(),
            new ApiBundle\ApiBundle()
        );

        if (in_array($this->getEnvironment(), array('dev', 'test'))) {
            // Only dev now
            $bundles[] = new Nelmio\ApiDocBundle\NelmioApiDocBundle();

            // Sonata bundles
            $bundles[] = new Symfony\Bundle\TwigBundle\TwigBundle();
            $bundles[] = new Knp\Bundle\MenuBundle\KnpMenuBundle();
            $bundles[] = new Sonata\CoreBundle\SonataCoreBundle();
            $bundles[] = new Sonata\BlockBundle\SonataBlockBundle();
            $bundles[] = new Sonata\CacheBundle\SonataCacheBundle();
            $bundles[] = new Sonata\EasyExtendsBundle\SonataEasyExtendsBundle();
            $bundles[] = new Sonata\DoctrineORMAdminBundle\SonataDoctrineORMAdminBundle();
            $bundles[] = new Sonata\AdminBundle\SonataAdminBundle();
            $bundles[] = new Symfony\Bundle\SwiftmailerBundle\SwiftmailerBundle();

            // Admin
            $bundles[] = new AdminBundle\AdminBundle();
            $bundles[] = new OAuthBundle\OAuthBundle();
            $bundles[] = new Ivory\CKEditorBundle\IvoryCKEditorBundle();

            $bundles[] = new Symfony\Bundle\DebugBundle\DebugBundle();
            $bundles[] = new Symfony\Bundle\WebProfilerBundle\WebProfilerBundle();
            $bundles[] = new Sensio\Bundle\DistributionBundle\SensioDistributionBundle();
            $bundles[] = new Sensio\Bundle\GeneratorBundle\SensioGeneratorBundle();
        }

        if (in_array($this->getEnvironment(), array('test'))) {
            $bundles[] = new Doctrine\Bundle\FixturesBundle\DoctrineFixturesBundle();
            //$bundles[] = new Liip\FunctionalTestBundle\LiipFunctionalTestBundle();
        }

        if (in_array($this->getEnvironment(), array('rabbit'))) {
            //$bundles[] = new ApiBundle\ApiBundle();  // Это должно работать только через rabbit, на ружу api не должно быть открыто!!!
        }

        return $bundles;
    }

    public function registerContainerConfiguration(LoaderInterface $loader)
    {
        $loader->load(__DIR__.'/config/config_'.$this->getEnvironment().'.yml');
    }


}
