<?php

namespace AnalyticsBundle\Services;

use AnalyticsBundle\Entity\Common,
    AnalyticsBundle\Repository\PlanRepository,
    AnalyticsBundle\Entity\Users,

    Doctrine\ORM\EntityManager;
use AnalyticsBundle\Entity\Plan;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage;

use \OldSound\RabbitMqBundle\RabbitMq\RpcClient;
use \Predis\Client;

/**
 * @todo: Каким-то магическим классом стал этот сервис, я уже сам не понимаю как он должен был работать, но попорядку...
 * @todo: давайтека расставим комментарии
 *
 * @package AnalyticsBundle\Services
 */
class SystemService
{
    /**
     * @var EntityManager
     */
    protected $_em;

    /**
     * @var \ApiBundle\User\OAuthUser
     */
    protected $_token_user;

    /**
     * @var Users
     */
    protected $_user;

    /**
     * @var Users[]
     */
    protected $_users = [];

    /**
     * @var Common
     */
    protected $_common;

    /**
     * @var TokenStorage
     */
    protected $_token_storage;

    /**
     * @var \Predis\Client
     */
    protected $_redis;

    /**
     * @var RpcClient
     */
    protected $_auth_rpc;


    /**
     * @param EntityManager $em
     * @param TokenStorage  $token_storage
     * @param Client        $redis
     * @param RpcClient     $auth_rpc
     */
    public function __construct(
        EntityManager $em,
        TokenStorage $token_storage,
        \Predis\Client $redis,
        RpcClient $auth_rpc
    )
    {
        $this->_em            = $em;
        $this->_token_storage = $token_storage;
        $this->_redis         = $redis;
        $this->_auth_rpc      = $auth_rpc;
    }

    /**
     * @return \ApiBundle\User\OAuthUser
     */
    public function getTokenUser()
    {
        return $this->_token_storage->getToken()->getUser();
    }

    /**
     * Получение данных по пользователю
     *
     * @param null|uuid|string $userId
     *
     * @return null|Users
     * @throws \Exception
     */
    public function getUser($userId = null)
    {
        if (is_null($userId)) {
            $userId = $this->getTokenUser()->getId();
        }
        if (!array_key_exists($userId, $this->_users)) {
            $user = $this->_em->getRepository('AnalyticsBundle:Users')->find($userId);
            if (!($user instanceof Users)) {
                throw new \Exception('Пользователь не найден (' . $userId . ')');
            }

            /*if(count($user->getGroupRoles()) < 1) {
                throw new UnauthorizedHttpException('', 'User ' . $this->getTokenUser()->getId() . ' doesn`t have any group');
            @todo: Нужно разобраться, почему это не работает, может оно уже не нужно, хотя оно точно нужно, потому что нужно же как-то получать permissions-ы для пользователя
            }*/

            $this->_users[$userId] = $user; //$this->setterUserPermissions($user);  @todo: Нужно разобраться, почему это не работает, может оно уже не нужно, хотя оно точно нужно, потому что нужно же как-то получать permissions-ы для пользователя
        }

        return $this->_users[$userId];
    }

    /**
     * @todo: Изначально этот метод предназначался для того что бы установить права пользователя
     * @todo: Но теперь стало не понятно, а работает ли оно вообще
     *
     * 1. Запрашиваем роли пользователя
     * 2. Устанавливаем права в группах
     *
     * @param Users $user Пользователь для которого нужно запросить права и сохранить
     * @deprecated - эта хрень больше нигде неиспользуеться
     * @return Users
     * @throws \Exception
     */
    public function setterUserPermissions(Users $user)
    {
        try {
            /**
             * Получение данных по ролям пользователя, в случае если их нет в кеше, то запрашиваем с сервера авторизации
             */
            $json = $this->_redis->get('auth_users_roles:' . $user->getId());
            if(!$json || empty($json)){
                $id     = time();
                $this->_auth_rpc->addRequest('{}', 'isz', $id, "auth.roles.get", 10);
                $roles = $this->_auth_rpc->getReplies()[$id];

                if(!empty($roles)) {
                    $this->_redis->set('auth_users_roles:' . $user->getId(), json_encode($roles), 'ex', 120);
                }
            } else {
                $roles = json_decode($json);
            }

            if (is_object($roles)) {
                foreach ($user->getGroupRoles() as &$usersExpertGroup) {
                    foreach ($roles as $role) {
                        if ($role->code == $usersExpertGroup->getExpertRole()) {
                            $usersExpertGroup->permissions = array_map(
                                function ($permissions) {
                                    return (array) $permissions;
                                },
                                (array) $role->permissions
                            );
                            $usersExpertGroup->expertRoleName = $role->name;
                        }
                    }
                }
            }

        } catch (\Exception $e) {
            throw new \Exception('Ошибка получения прав (' . $user->getId() . ')');
        }

        return $user;
    }

    /**
     * @param string $type Тип плана (current, next)
     *
     * @return \AnalyticsBundle\Entity\Plan|null
     * @throws \Exception
     */
    public function getPlan($type = Plan::TYPE_CURRENT)
    {
        $user = $this->getTokenUser();
        if ($this->getUser() && $user->getCommonId()) {
            /** @var PlanRepository $rPlan */
            $rPlan = $this->_em->getRepository('AnalyticsBundle:Plan');

            switch ($type) {
                case Plan::TYPE_CURRENT:
                    return $rPlan->findCurrent($user->getCommonId());

                case Plan::TYPE_NEXT:
                    return $rPlan->findNext($user->getCommonId());

                case Plan::TYPE_ARCHIVE:
                    return $rPlan->findArchives($user->getCommonId());
            }
            throw new \Exception('Не корректный запрос');
        } else {
            throw new \Exception('Не указана организация');
        }
    }

    /**
     * @todo: Сейчас комментируем проверку на то что common ранее уже был запрошен, иначе из-за этого появляется
     * @todo: проблема в том что лот сохраняется не под тем пользователем и департаментом
     *
     * @return Common|null|object
     */
    public function getCommon()
    {
        //if (!isset($this->_common)) {
            $this->_common = $this->_em
                ->getRepository('AnalyticsBundle:Common')
                ->find(
                    $this->getTokenUser()->getCommonId()  // @todo: А что будет если getTokenUser вернёт что-то ге то???
                );
        //}

        return $this->_common;
    }

    /**
     * @param $user
     * @deprecated
     */
    public function setUser($user)
    {
        $this->_user = $user;
    }

    /**
     * @param $common
     * @deprecated
     */
    public function setCommon($common)
    {
        $this->_common = $common;
    }
}
