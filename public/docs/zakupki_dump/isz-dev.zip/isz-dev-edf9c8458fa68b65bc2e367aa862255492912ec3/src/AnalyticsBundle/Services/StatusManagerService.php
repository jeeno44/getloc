<?php

namespace AnalyticsBundle\Services;

use Doctrine\ORM\EntityManager;

class StatusManagerService
{
    /**
     * @var \Doctrine\ORM\EntityRepository
     */
    private $em;

    /**
     * @param EntityManager $em
     */
    public function __construct(EntityManager $em)
    {
        $this->em = $em;
    }

    /**
     * Get list type objects
     * @return array of type object
     */
    public function getAllStatusType()
    {
        $types =  $this->em->getRepository('AnalyticsBundle\Entity\Status')->getAllStatusType();

        $result = array_map(
            function($item) {
                return $item['typeObject'];
            },
            $types
        );

        return $result;
    }

    /**
     * Check exist status
     * @param string $status
     * @param string $type
     * @return null|\AnalyticsBundle\Entity\Status
     */
    public function checkExistStatus($status, $type)
    {
        return $this->em->getRepository('AnalyticsBundle\Entity\Status')
            ->findOneBy([
                'id' => $status,
                'typeObject' => $type
            ]);
    }

    /**
     * Check all ready used status
     * @param string $status
     * @param string $type
     * @return null|\AnalyticsBundle\Entity\EventManagement
     */
    public function checkUsedStatus($status, $type)
    {
        return $this->em->getRepository('AnalyticsBundle\Entity\EventManagement')
            ->findOneBy([
                'statusStart' => $status,
                'statusTypeObject' => $type
            ]);
    }
}
