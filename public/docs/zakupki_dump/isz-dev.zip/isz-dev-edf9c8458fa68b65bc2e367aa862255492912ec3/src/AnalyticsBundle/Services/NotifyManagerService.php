<?php

namespace AnalyticsBundle\Services;

use OldSound\RabbitMqBundle\RabbitMq\Producer;
use Symfony\Component\Security\Acl\Exception\Exception;

class NotifyManagerService
{
    /**
     * @var Producer
     */
    private $producer;

    public function __construct(Producer $producer)
    {
        $this->producer = $producer;
    }

    /**
     * @param string $sendFrom
     * @param string $sendTo
     * @param string $subject
     * @param text $body
     * @return bool
     * @throws Exception
     */
    public function sendNotify($sendFrom, $sendTo, $subject, $body)
    {
        $message = json_encode([
            'from' => $sendFrom,
            'to' => $sendTo,
            'subject'=> $subject,
            'html' => $body
        ]);

        try {
            $this->producer->publish($message, 'async.mail.procedures');
        } catch (\Exception $exp) {
            throw new Exception($exp->getMessage());
        }

        return false;
    }

    /**
     * @param string $to
     * @param text $text
     * @return bool
     * @throws Exception
     */
    public function sendSms($to, $text)
    {
        $message = json_encode([
            'to' => $to,
            'text' => $text
        ]);

        try {
            $this->producer->publish($message, 'async.sms.procedures');
        } catch (\Exception $exp) {
            throw new Exception($exp->getMessage());
        }

        return false;
    }
}
