<?php
namespace AnalyticsBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputOption;

/**
 * Class CronYearCommand
 * @package AnalyticsBundle\Command
 */
class CronYearCommand extends ContainerAwareCommand
{
    /**
     *
     */
    public function configure()
    {
        $this
            ->setName('analytics:cron:year')
            ->setDescription('Задачи которые должны выполняться раз в год в yyyy-01-01 00:00:00')
            ->addOption('year', 'y', InputOption::VALUE_OPTIONAL, 'Год')
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        /**
         * Добавление планов
         */
        $this
            ->getContainer()
            ->get('doctrine')
            ->getManager('analytics')
            ->getRepository('AnalyticsBundle:Plan')
            ->addNewYear($input->getOption('year') ?: date('Y'));
    }
}
