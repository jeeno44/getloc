<?php
namespace AnalyticsBundle\Command;

use AnalyticsBundle\Entity\Lot;
use AnalyticsBundle\Entity\Okei;
use AnalyticsBundle\Entity\Okpd;
use AnalyticsBundle\Entity\Okved;
use AnalyticsBundle\Entity\Plan;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Validator\Constraints\DateTime;

use FOS\RestBundle\View\View as FOSView;
use JMS\Serializer\SerializationContext;

/**
 * Class TestCommand
 * @package AnalyticsBundle\Command
 */
class TestCommand extends ContainerAwareCommand
{
    public function configure()
    {
        $this
            ->setName('storage:test')
            ->setDescription('Testing storage')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {

        $em = $this->getContainer()->get('doctrine')->getManager('analytics');
        $govProgramm = $em->getRepository('AnalyticsBundle:GovProgram')->findOneBy(['id' => '26c60bae-2735-42aa-8435-a493c2ac314d']);
        if (!empty($govProgramm)) {
            $kbkItems = $em->getRepository('AnalyticsBundle:Kbk')->findBy(['govProgram' => $govProgramm]);
            $iDs = [];
            if (!empty($kbkItems)) {
                foreach ($kbkItems as $item) {
                    $kbkSection = $item->getKbkSection();
                    if (!empty($kbkSection)) {
                        $id = $kbkSection->getId();
                        $iDs[$id] = $id;
                    }
                }
            }
            $iDs = array_values($iDs);


        }



//        $em = $this->getContainer()->get('doctrine')->getManager('analytics');
//        $commonRep =  $em->getRepository('AnalyticsBundle:Common');
//
//        $common = $commonRep->findOneBy(["id" => "7724e85a-8156-4155-9d5e-f3fbfe00e702"]);
//
//        $serializationContext = SerializationContext::create()->enableMaxDepthChecks();
//
//        $serializationContext->setGroups(['common']);
//
//        $result = \FOS\RestBundle\View\View::create($common)
//            ->setSerializationContext($serializationContext);

//        dump($result);

//        $lotRep =  $em->getRepository('AnalyticsBundle:Lot');
//        $year = date("Y");
//        $years = [];
//
//        $lotId = "eed42895-4270-43bd-ac2e-88bb9230dd81";
//
//        $lot = $lotRep->findOneBy(['id' => $lotId]);
//
//        $common = $lot->getCommon();
//        $financing = $lot->getFinancings();
//
//        if (!empty($common) && !empty($financing)) {
//
//            for ($i = 0; $i < $financing->count(); $i++) {
//                $years[] = $year + $i;
//            }
//
//            /** @var Plan[] $plans */
//            $plans = $common->getPlans()->filter(function(Plan $entity) use($years){
//                return in_array($entity->getYear(), $years);
//            });
//
//            if (!empty($plans)) {
//                foreach ($plans as $plan) {
//                    $plan->addLot($lot);
//                    $em->persist($plan);
//                }
//            } else {
//                throw new \Exception("В департаменте нет планов", 504);
//            }
//
//            $lot->setStatusId(Lot::STATUS_IN_PLAN);
//            $em->persist($lot);
//
//            $em->flush();
//
//        } else {
//            throw new \Exception("Финансирование или Департамент не задан", 504);
//        }
//
//        return;



//            $em = $this->getContainer()->get('doctrine')->getManager('analytics');
//            $planRep = $em->getRepository('AnalyticsBundle:Plan');
//            $lotRep = $em->getRepository('AnalyticsBundle:Lot');

            /** @var Lot $activeLot */
//        $consolidatePlan = $planRep->findOneBy(['id' => "3c70684d-896f-44c3-9192-f87c825e9a58"]);
//            $activePlan = $planRep->findOneBy(['id' => "dd15beca-b980-470b-9b1e-d73dee7df87d"]);

//        $activePlan->setParent($consolidatePlan);
//        $activePlan->setComment(microtime());
//        $em->persist($activePlan);
//        $em->flush();


            /** @var Lot $activeLot */
//        $activeLot = $lotRep->findOneBy(['id' => "daea07c7-12bb-4dd5-baac-4f16b2198bf1"]);
//        $p = $activeLot->getPlan();
//        $activeLot->setTitle(microtime());
//        $em->persist($activeLot);
//        $em->flush();
    }
}
