<?php
namespace AnalyticsBundle\Command;

use AnalyticsBundle\Entity\Common;
use AnalyticsBundle\Entity\Plan;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputOption;

/**
 * Class CronYearCommand
 * @package AnalyticsBundle\Command
 */
class CronPlanCommand extends ContainerAwareCommand
{
    /**
     *
     */
    public function configure()
    {
        $this
            ->setName('analytics:cron:year')
            ->setDescription('Запуск экспертизы консолидированных планов ФОИВ-ов')
            ->addOption('year', 'y', InputOption::VALUE_OPTIONAL, 'Год')
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        /**
         * Добавление планов
         */
        /** @var Common[] $foivs */
        $foivs = $this
            ->getContainer()
            ->get('doctrine')
            ->getManager('analytics')
            ->getRepository('AnalyticsBundle:Common')
            ->findBy([
                'type' => Common::TYPE_FOIV,
            ]);

        $plans = $this
            ->getContainer()
            ->get('doctrine')
            ->getManager('analytics')
            ->getRepository('AnalyticsBundle:Plan')
            ->findBy([
                'common' => $foivs,
                'year'   => $input->getOption('year') ?: date('Y'),
            ]);
        foreach ($plans as $plan) {
            if ($plan->getStatusId() == Plan::STATUS_DRAFT) {
                /**
                 * Здесь нужно дописать код, но вообще лучше это всё делать в APP, написать там консольный скрипт,
                 * по примеру кода из: PlanController->startConsolidatedAction
                 */
            }
        }
    }
}
