<?php
namespace AnalyticsBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class UpdateDictionaryCommand
 *
 * Набор команд импорта и обновления данных с сервиса ftp.zakupki.gov.ru
 * Принцип работы при условии что схема сущности описанна
 * app/console dictionary:update NAME, где NAME это имя папки словаря из ftp.zakupki.gov.ru
 *
 * @package AnalyticsBundle\Command
 */
class UpdateDictionaryCommand extends ContainerAwareCommand
{

    const ZAKUPI_FTP_SERVER = "ftp.zakupki.gov.ru";
    const ZAKUPI_FTP_PATH = "/fcs_nsi";


    /**
     * Configuration task
     */
    public function configure()
    {
        $this
            ->setName('dictionary:update')
            ->setDescription('Обновление словарей с zakupki.gov.ru')
            ->addArgument('type', InputArgument::REQUIRED, 'Машинное имя справочника')
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return bool
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        if (!empty($input->getArgument('type')) && $input->getArgument('type') != 'help') {
            $connection = ftp_connect(self::ZAKUPI_FTP_SERVER);
            $dictionaryName = $input->getArgument('type');
            if (!ftp_login($connection, 'free', 'free')) {
                $output->writeln("Error login ftp");
                ftp_close($connection);
                return;
            }

            ftp_pasv($connection, true);

            $files = ftp_nlist($connection, self::ZAKUPI_FTP_PATH . "/" . $dictionaryName);
            $schema = $this->getSchemaFields($dictionaryName);
            $values = [];

            foreach ($files as $file) {
                $filePath = explode('/', $file);
                $fileName = $filePath[count($filePath) - 1];
                $tmpZipName = tempnam(sys_get_temp_dir(), $fileName);
                $handleZip = fopen($tmpZipName, 'w');

                if (ftp_fget($connection, $handleZip, $file, FTP_BINARY, 0)) {
                    try {

                        $zip = new \ZipArchive();
                        $zip->open($tmpZipName);
                        $xmlContent = $zip->getFromName(str_replace('.zip', '', $fileName));
                        $dictionaryItems = new \SimpleXMLElement($xmlContent);
                        $dictionaryItems->registerXPathNamespace('e', 'http://zakupki.gov.ru/oos/export/1');

                        $zip->close();

                        $items = $dictionaryItems->xpath('//e:' . $dictionaryName);

                        foreach($items as $key => $child) {
                            foreach ($schema as $fieldXML => $fieldDB) {
                                $val = (!empty($child->xpath('oos:' . $fieldXML))) ? (string) $child->xpath('oos:' . $fieldXML)[0] : null;
                                $values[$key][$fieldDB] = $val;
                            }
                        }

                    } catch (Exception $e) {
                        $output->writeln($e->getMessage());
                    }
                } else {

                }
            }

            $transducerFunc = 'transducer' . $dictionaryName;
            if (method_exists($this, $transducerFunc)) {
                $values = $this->$transducerFunc($values);
            }

            /** @var \Doctrine\ORM\EntityManager $em */
            $em = $this->getContainer()->get('doctrine')->getManager('analytics');
            $entityData = $this->getEntity($dictionaryName);
            $entityClass = key($entityData);
            $entityUniq = reset($entityData)['uniq'];

            if (!empty($entityClass)) {
                $repoName = 'AnalyticsBundle:' . $entityClass;
                $repo = $em->getRepository($repoName);

                foreach ($values as $value) {
                    $item = $repo->findOneBy([
                            $entityUniq => $value[$entityUniq],
                        ]
                    );
                    if (empty($item)) {
                        $class = "\\AnalyticsBundle\\Entity\\" . $entityClass;
                        $item = new $class();
                    }
                    foreach ($schema as $fieldXML => $fieldDB) {
                        $method = "set" . ucwords(str_replace('_', ' ', $fieldDB));
                        if (method_exists($item, $method)) {
                            $item->$method($value[$fieldDB]);
                        }
                    }

                    $em->persist($item);
                }
            }

            $em->flush();

            ftp_close($connection);

            $output->writeln("Import complete");
        }
        else {
            if ($input->getArgument('type') == 'help') {
                $output->writeln("Доступный набор словарей: nsiOKEI, nsiKOSGU, nsiOKOPF, nsiOKPD2, nsiOKVED2");
            } else {
                $output->writeln("Argument `type` is required");
            }
        }

        return true;
    }

    /**
     * Return mapped entity name
     *
     * @param $type
     * @return array|bool
     */
    public function getEntity($type)
    {
        switch ($type) {
            case 'nsiOKEI' :
                return ["Okei" => ['uniq' => 'code']];
            case 'nsiKOSGU' :
                return ["KbkKosgu" => ['uniq' => 'code']];
            case 'nsiOKOPF' :
                return ["Okopf" => ['uniq' => 'description']];
            case 'nsiOKPD2' :
                return ["Okpd" => ['uniq' => 'codeOkpd']];
            case 'nsiOKVED2' :
                return ["Okved" => ['uniq' => 'code']];
        }

        throw new Exception('Сущность не описанна в маппинге уникальности');
    }

    /**
     * Return mapped field schema for entity
     *
     * @param $type
     * @return array|bool
     */
    public function getSchemaFields($type)
    {
        switch ($type) {
            case 'nsiOKEI' :
                    return [
                        'code' => 'code',
                        'fullName' => 'description',
                        'localName' => 'symbol',
                    ];
            case 'nsiKOSGU' :
                    return [
                        'code' => 'code',
                        'name' => 'title',
                    ];
                break;
            case 'nsiOKOPF' :
                    return [
                        //'code' => 'code',
                        'fullName' => 'description',
                    ];
            case 'nsiOKPD2' :
                    return [
                        'code' => 'codeOkpd',
                        'name' => 'description',
                    ];
                break;
            case 'nsiOKVED2' :
                    return [
                        'code' => 'code',
                        'name' => 'title',
                    ];
        }

        throw new Exception('Сущность не описанна в маппинге полей');
    }

}
