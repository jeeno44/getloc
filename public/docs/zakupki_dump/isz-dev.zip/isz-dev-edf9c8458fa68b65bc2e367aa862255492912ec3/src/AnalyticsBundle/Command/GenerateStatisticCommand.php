<?php

namespace AnalyticsBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;

class GenerateStatisticCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('stimulsoft:generate:statistic')
            ->setDescription('Generate file json for view statistic');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln('==> Start work script');
        $fs = new Filesystem();
        $em = $this->getContainer()->get('doctrine')->getManager('analytics');
        $total = $em->getRepository('AnalyticsBundle:Lot')->countLots();
        $path = $this->getContainer()->getParameter('graph_path');

        $step = 10;
        $graf1 = [];
        $start = 0;
        $pages = ceil($total/$step);
        for ($i = 1; $i < $pages; $i++) {
            $lots = $em->getRepository('AnalyticsBundle:Lot')->getMinPlanGraphic($start, $step);
            $data = $this->formedFirstTable($lots);
            $graf1 = array_merge($data, $graf1);
            $start += $step;
        }

        $answer['data'][] = $graf1;
        $json = json_encode($answer, JSON_UNESCAPED_UNICODE);
        $file = $path . 'table.json';

        if ($fs->exists([$file])){
            $fs->remove(array('symlink', $path, 'table.json'));
        }
        $fs->dumpFile($file, $json);

        $output->writeln('==> Finish script');

    }

    /**
     * Сведения о плане-графике Минобрнауки
     * @param array $result
     * @return array
     */
    private function formedFirstTable($result)
    {
        $answer = [];
        foreach ($result as $item) {

            $okvedCode = [];
            $codeOkpd = [];
            $userFullName = null;
            $minStartDate = null;
            $minEndDate = null;
            $stagesPeriod = [];
            $qualitativeChars = [];
            $quantativeChars = [];
            $planPrice = [];
            $okei = null;
            $totalPrice = 0;
            $curPrice = '-';
            $grounds = 'Внепрограммное мероприятие';
            if ($okvedAr = $item->getOkved()) {
                foreach ($okvedAr as $okvedItem) {
                    $okvedCode[] = $okvedItem->getCode();
                }
            }
            if ($okpdAr = $item->getOkpd()) {
                foreach ($okpdAr as $okpdItem) {
                    $codeOkpd[] = $okpdItem->getCodeOkpd();
                }
            }
            /**Author of lot**/
            if ($user = $item->getProcResp()) {
                $userFullName = $user->getUsername();
            }
            if ($stages = $item->getStages()) {
                foreach ($stages as $stage) {
                    if ($wkTypes = $stage->getWorkTypes()) {
                        foreach ($wkTypes as $wkType) {
                            $qualitativeChars[] = $wkType->getQualitativeChar();
                            $quantativeChars[] = $wkType->getQuantativeChar();
                        }
                    }
                    $stringStage = '';
                    if ($minStartDate) {
                        if ($stage->getStartDate() < $minStartDate) {
                            $minStartDate = $stage->getStartDate();
                        }
                    } else {
                        $minStartDate = $stage->getStartDate();
                    }
                    if ($minEndDate) {
                        if ($stage->getExecutionDate() < $minEndDate) {
                            $minEndDate = $stage->getExecutionDate();
                        }
                    } else {
                        $minEndDate = $stage->getExecutionDate();
                    }
                    if ($stage->getExecutionDate() || $stage->getStartDate()) {
                        if ($stage->getStartDate()) {
                            $stringStage .= $stage->getStartDate()->format('m.Y') . ' - ';
                        } else {
                            $stringStage .= 'null - ';
                        }
                        if ($stage->getExecutionDate()) {
                            $stringStage .= $stage->getExecutionDate()->format('m.Y');
                        } else {
                            $stringStage .= 'null';
                        }
                        $stagesPeriod[] = $stringStage;
                    }
                }
            }
            if ($finansings = $item->getFinancings()) {
                foreach ($finansings as $finansing) {
                    if ($finansing->getPlanPrice()) {
                        $planPrice[$finansing->getYear()] = $finansing->getPlanPrice()/1000;
                        $totalPrice += $finansing->getPlanPrice()/1000;
                    } else {
                        if ($finansing->getYear()) {
                            $planPrice[$finansing->getYear()] = '-';
                        }
                    }
                }
            }
            if ($okeiItem = $item->getOkei()) {
                $okei = $okeiItem->getDescription() .' / '.$okeiItem->getCode();
            }
            /**Grounds**/
            if ($item->getGovProgram()) {
                if ($item->getFcpAction()) {
                    $grounds = $item->getGovProgram()->getTitle() . ' / ' . $item->getFcpAction()->getTitle();
                } else {
                    $grounds = $item->getGovProgram()->getTitle();
                }
            } elseif ($item->getSubProgramAction()) {
                if ($item->getFcpAction()) {
                    $grounds = $item->getSubProgramAction()->getTitle() . ' / ' . $item->getFcpAction()->getTitle();
                } else {
                    $grounds = $item->getSubProgramAction()->getTitle();
                }
            } elseif ($item->getFcp()) {
                if ($item->getFcpAction()) {
                    $grounds = $item->getFcp()->getTitle() . ' / ' . $item->getFcpAction()->getTitle();
                } else {
                    $grounds = $item->getFcp()->getTitle();
                }
            }
            $kbk = [
                $item->getKbkSection()?$item->getKbkSection()->getCode(): '-',
                $item->getKbkCsr()?$item->getKbkCsr()->getCode():'-',
                $item->getKbkExpenseType()?$item->getKbkExpenseType()->getCode():'-',
                $item->getKbkKosgu()?$item->getKbkKosgu()->getCode(): '-',
                $item->getKbkFlowDirection()?$item->getKbkFlowDirection()->getTitle():'-',
            ];
            $now = new \DateTime();
            $year = (int)$now->format('Y');
            if (array_key_exists($year, $planPrice)) {
                $curPrice = $totalPrice . ' / ' . $planPrice[$year] . ' / '. implode(' / ', $planPrice);
            } else {
                $curPrice = $totalPrice . ' / - /' . implode(' / ', $planPrice);
            }
            if (array_key_exists($year+1, $planPrice)) {
                $sumYears = $planPrice[$year] + $planPrice[$year+1];
                $curPrice = $totalPrice . ' / ' . $sumYears . ' / '. implode(' / ', $planPrice);
            }
            $answer[] = [
                'common' => $item->getCommon()->getFullName(),
                'lot_title' => $item->getTitle(),
                'user' => $userFullName,
                'status' => $item->getStatusId(),
                'kbk' => implode (' / ', $kbk),
                'okved' => implode(' / ', $okvedCode),
                'codeOkpd' => implode(' / ', $codeOkpd),
                'minRequirements' => $item->getMinRequirements()?$item->getMinRequirements():'-',
                'okei' => $okei,
                'financingPlanPrice' => $totalPrice,
                'orderPublication' => $item->getOrderPublication()?$item->getOrderPublication()->format('m.Y'):'-',
                'contractExecution' => $item->getContractExecution()?$item->getContractExecution()->format('m.Y'):'-' ,
                'procurementType_description' => $item->getProcurementType()?$item->getProcurementType()
                    ->getDescription():null,
                'grounds' => $grounds,
                'qualitativeChars' => implode('. ', $qualitativeChars),
                'quantativeChars' => implode('. ', $quantativeChars),
                'lotCode' => $item->getLotCode()?$item->getLotCode():'-',
                'curPrice' => $curPrice,
                'quantityFollowingPeriod' => $item->getQuantityFollowingPeriod()?$item->getQuantityFollowingPeriod()
                    :'-',
                'lot_stages_date' => implode(' / ', $stagesPeriod),
                'prepaymentBidPercentage' => $item->getPrepaymentBidPercentage()?$item->getPrepaymentBidPercentage()
                    :'-',
                'prepaymentContractPercentage' => $item->getPrepaymentContractPercentage()
                    ?$item->getPrepaymentContractPercentage():'-',
                'min_lot_stages_start_date' => $minStartDate ? $minStartDate->format('m.Y'): '-',
                'min_lot_stages_execution_date' => $minEndDate ? $minEndDate->format('m.Y'): '-',
                'preferences282944' => $item->getPreferences282944(),
                'preferences282944' => $item->getRequirement3044()? $item->getRequirement3044(): '-',
                'addReqJustification' => $item->getAddReqJustification() ? $item->getAddReqJustification(): '-',
            ];
        }

        return $answer;
    }

}