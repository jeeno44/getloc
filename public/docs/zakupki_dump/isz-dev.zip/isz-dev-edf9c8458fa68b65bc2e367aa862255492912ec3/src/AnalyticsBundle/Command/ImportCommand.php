<?php
namespace AnalyticsBundle\Command;

use AnalyticsBundle\Entity\Okei;
use AnalyticsBundle\Entity\Okpd;
use AnalyticsBundle\Entity\Okved;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class ImportCommand
 * @package AnalyticsBundle\Command
 */
class ImportCommand extends ContainerAwareCommand
{
    /**
     *
     */
    public function configure()
    {
        $this
            ->setName('analytics:import')
            ->setDescription('Импорт данных справочников')
            ->addArgument('dic', InputArgument::REQUIRED, 'Справочник')
            ->addArgument('file', InputArgument::REQUIRED, 'Excel файл')
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        switch ($input->getArgument('dic')) {
            case 'okved':
                $this->dicOkved($input->getArgument('file'));
                break;
            case 'okpd':
                $this->dicOkpd($input->getArgument('file'));
                break;
            case 'okei':
                $this->dicOkei($input->getArgument('file'));
                break;
        }
    }

    /**
     * @param $file
     */
    protected function dicOkved($file)
    {
        $phpExcelObject = $this->getContainer()->get('phpexcel')->createPHPExcelObject($file);

        $sheet = $phpExcelObject->getActiveSheet();

        $highestRow = $sheet->getHighestRow();

        $em = $this->getContainer()->get('doctrine')->getManager('analytics');
        $rOkved = $em->getRepository('AnalyticsBundle:Okved');
        for ($i = 0; $i < $highestRow; $i++) {
            $cellA = $sheet->getCellByColumnAndRow(0, $i)->getValue();
            $cellB = $sheet->getCellByColumnAndRow(1, $i)->getValue();
            if (!empty($cellA) && !empty($cellB)) {
                $mOkved = $rOkved->findOneByCode($cellA);
                if (!($mOkved instanceof Okved)) {
                    $mOkved = new Okved();
                }
                $mOkved
                    ->setCode($cellA)
                    ->setTitle($cellB);
                $em->persist($mOkved);

                if ($i % 200 === 0) {
                    $em->flush();
                }
            }
        }

        $em->flush();
    }

    /**
     * @param $file
     */
    protected function dicOkpd($file)
    {
        $phpExcelObject = $this->getContainer()->get('phpexcel')->createPHPExcelObject($file);

        $sheet = $phpExcelObject->getActiveSheet();

        $highestRow = $sheet->getHighestRow();

        $em = $this->getContainer()->get('doctrine')->getManager('analytics');
        $rOkpd = $em->getRepository('AnalyticsBundle:Okpd');
        for ($i = 0; $i < $highestRow; $i++) {
            $cellA = $sheet->getCellByColumnAndRow(0, $i)->getValue();
            $cellB = $sheet->getCellByColumnAndRow(1, $i)->getValue();
            if (!empty($cellA) && !empty($cellB)) {
                $mOkpd = $rOkpd->findOneByCodeOkpd($cellA);
                if (!($mOkpd instanceof Okpd)) {
                    $mOkpd = new Okpd();
                }
                $mOkpd
                    ->setCodeOkpd($cellA)
                    ->setDescription($cellB);
                $em->persist($mOkpd);

                if ($i % 200 === 0) {
                    $em->flush();
                }
            }
        }

        $em->flush();
    }

    /**
     * @param $file
     */
    protected function dicOkei($file)
    {
        $phpExcelObject = $this->getContainer()->get('phpexcel')->createPHPExcelObject($file);

        $sheet = $phpExcelObject->getActiveSheet();

        $highestRow = $sheet->getHighestRow();

        $em = $this->getContainer()->get('doctrine')->getManager('analytics');
        $rOkei = $em->getRepository('AnalyticsBundle:Okei');
        for ($i = 0; $i < $highestRow; $i++) {
            $cellA = $sheet->getCellByColumnAndRow(0, $i)->getValue();
            $cellB = $sheet->getCellByColumnAndRow(1, $i)->getValue();
            $cellC = $sheet->getCellByColumnAndRow(2, $i)->getValue();
            if (!empty($cellA) && is_numeric($cellA) && !empty($cellB) && !empty($cellC)) {
                //echo $cellA . ' : ' . $cellB . ' : ' . $cellC . "\r\n";
                $mOkei = $rOkei->findOneByCode($cellA);
                if (!($mOkei instanceof Okei)) {
                    $mOkei = new Okei();
                }
                $mOkei
                    ->setCode($cellA)
                    ->setDescription($cellB)
                    ->setSymbol($cellC);
                $em->persist($mOkei);

                if ($i % 200 === 0) {
                    $em->flush();
                }
            }
        }

        $em->flush();
    }
}
