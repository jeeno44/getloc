<?php
namespace AnalyticsBundle\Versionable;

use JMS\Serializer\Annotation as JMS;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 */
trait VersionableTrait
{
    /**
     * @var \DateTime
     *
     * @ORM\Column(name="version_start_at", type="datetime", nullable=true)
     * @JMS\Groups({"all"})
     */
    private $versionStartAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="version_end_at", type="datetime", nullable=true)
     * @JMS\Groups({"all"})
     */
    private $versionEndAt;

    /**
     * @var integer
     *
     * @ORM\Column(name="version_owner_id", type="guid", nullable=true)
     * @JMS\Groups({"all"})
     */
    private $versionOwnerId;


    /**
     * Set versionStartAt
     *
     * @param \DateTime $versionStartAt
     * @return $this
     */
    public function setVersionStartAt(\DateTime $versionStartAt = null)
    {
        $this->versionStartAt = $versionStartAt;

        return $this;
    }

    /**
     * Get versionStartAt
     *
     * @return \DateTime
     */
    public function getVersionStartAt()
    {
        return $this->versionStartAt;
    }

    /**
     * Set versionEndAt
     *
     * @param \DateTime $versionEndAt
     * @return $this
     */
    public function setVersionEndAt(\DateTime $versionEndAt = null)
    {
        $this->versionEndAt = $versionEndAt;
    }

    /**
     * Get versionEndAt
     *
     * @return \DateTime
     */
    public function getVersionEndAt()
    {
        return $this->versionEndAt;
    }

    /**
     * Set versionOwnerId
     *
     * @param guid|string $versionOwnerId
     * @return $this
     */
    public function setVersionOwnerId($versionOwnerId)
    {
        $this->versionOwnerId = $versionOwnerId;

        return $this;
    }

    /**
     * Get versionOwnerId
     *
     * @return guid|string
     */
    public function getVersionOwnerId()
    {
        return $this->versionOwnerId;
    }
}
