<?php

namespace AnalyticsBundle\Versionable;

use AnalyticsBundle\Entity\Indicator;
use Doctrine\ORM\Event\LifecycleEventArgs;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\OnFlushEventArgs;
use Doctrine\ORM\Event\PostFlushEventArgs;

/**
 * Class VersionableListener
 * @package AnalyticsBundle\Versionable
 */
class VersionableListener
{
    /**
     * @param OnFlushEventArgs $args
     */
    public function onFlush(OnFlushEventArgs $args)
    {
        $em = $args->getEntityManager();
        $uow = $args->getEntityManager()->getUnitOfWork();
        $eventManager = $em->getEventManager();

        $eventManager->removeEventListener('onFlush', $this);

        foreach ($uow->getScheduledEntityUpdates() as $entity) {
            if (in_array('AnalyticsBundle\Versionable\VersionableTrait', class_uses($entity))) {
                $newEntity = clone $entity;

                $entity->setEndDate(time());
                $em->persist($entity);

                $newEntity->setStartDate(time());
                $newEntity->setOwnerId($entity->getOwnerId() ? $entity->getOwnerId() : $entity->getId());
                $em->persist($newEntity);
                $em->flush();
            }
        }
    }

    /**
     *
     */
    public function preDelete()
    {

    }
}
