<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * RateIndicator
 *
 * @ORM\Table(
 *   name="rate_indicator",
 *   indexes={
 *     @ORM\Index(name="rate_indicator_parent_id", columns={"parent_id"}),
 *     @ORM\Index(name="rate_indicator_fcp_id", columns={"fcp_id"}),
 *     @ORM\Index(name="rate_indicator_end_date", columns={"end_date"}),
 *     @ORM\Index(name="rate_indicator_gov_program_id", columns={"gov_program_id"}),
 *     @ORM\Index(name="rate_indicator_fcp_action_id", columns={"fcp_action_id"}),
 *     @ORM\Index(name="rate_indicator_okei_id", columns={"okei_id"}),
 *     @ORM\Index(name="rate_indicator_sub_program_action_id", columns={"sub_program_action_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\RateIndicatorRepository")
 * @Json\Schema("RateIndicator")
 */
class RateIndicator implements IEntity
{
    const TYPE_RATE      = 'rate';
    const TYPE_INDICATOR = 'indicator';

    public static $types_list = [
        self::TYPE_RATE      => 'Показатель',
        self::TYPE_INDICATOR => 'Индикатор',
    ];

    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"lot_detail"})
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="end_date", type="date", nullable=true)
     * @JMS\Groups({"lot_detail", "lot_list"})
     */
    private $endDate;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=255, nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $type;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="start_date", type="date", nullable=true)
     * @JMS\Groups({"lot_detail", "lot_list"})
     */
    private $startDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="ref_value", type="float", precision=10, scale=2, nullable=true)
     */
    private $refValue;

    /**
     * @var integer
     *
     * @ORM\Column(name="min_value", type="float", precision=10, scale=2, nullable=true)
     */
    private $minValue;

    /**
     * @var integer
     *
     * @ORM\Column(name="max_value", type="float", precision=10, scale=2, nullable=true)
     */
    private $maxValue;

    /**
     * @var GovProgram
     *
     * @ORM\ManyToOne(targetEntity="GovProgram")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="gov_program_id", referencedColumnName="id")
     * })
     */
    private $govProgram;

    /**
     * @var SubProgramAction
     *
     * @ORM\ManyToOne(targetEntity="SubProgramAction")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="sub_program_action_id", referencedColumnName="id")
     * })
     */
    private $subProgramAction;

    /**
     * @var Fcp
     *
     * @ORM\ManyToOne(targetEntity="Fcp")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_id", referencedColumnName="id")
     * })
     */
    private $fcp;

    /**
     * @var FcpAction
     *
     * @ORM\ManyToOne(targetEntity="FcpAction")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_action_id", referencedColumnName="id")
     * })
     */
    private $fcpAction;

    /**
     * @var Okei
     *
     * @ORM\ManyToOne(targetEntity="Okei")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="okei_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail"})
     */
    private $okei;

    /**
     * @var RateIndicator
     *
     * @ORM\ManyToOne(targetEntity="RateIndicator")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     * })
     */
    private $parent;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Lot", mappedBy="rateIndicator")
     */
    private $lot;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->lot = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set endDate
     *
     * @param \DateTime $endDate
     * @return RateIndicator
     */
    public function setEndDate($endDate)
    {
        $this->endDate = $endDate;

        return $this;
    }

    /**
     * Get endDate
     *
     * @return \DateTime 
     */
    public function getEndDate()
    {
        return $this->endDate;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return RateIndicator
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return RateIndicator
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set startDate
     *
     * @param \DateTime $startDate
     * @return RateIndicator
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;

        return $this;
    }

    /**
     * Get startDate
     *
     * @return \DateTime 
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Set refValue
     *
     * @param integer $refValue
     * @return RateIndicator
     */
    public function setRefValue($refValue)
    {
        $this->refValue = $refValue;

        return $this;
    }

    /**
     * Get refValue
     *
     * @return integer 
     */
    public function getRefValue()
    {
        return $this->refValue;
    }

    /**
     * Set minValue
     *
     * @param integer $minValue
     * @return RateIndicator
     */
    public function setMinValue($minValue)
    {
        $this->minValue = $minValue;

        return $this;
    }

    /**
     * Get minValue
     *
     * @return integer 
     */
    public function getMinValue()
    {
        return $this->minValue;
    }

    /**
     * Set maxValue
     *
     * @param integer $maxValue
     * @return RateIndicator
     */
    public function setMaxValue($maxValue)
    {
        $this->maxValue = $maxValue;

        return $this;
    }

    /**
     * Get maxValue
     *
     * @return integer 
     */
    public function getMaxValue()
    {
        return $this->maxValue;
    }

    /**
     * Set govProgram
     *
     * @param \AnalyticsBundle\Entity\GovProgram $govProgram
     * @return RateIndicator
     */
    public function setGovProgram(\AnalyticsBundle\Entity\GovProgram $govProgram = null)
    {
        $this->govProgram = $govProgram;

        return $this;
    }

    /**
     * Get govProgram
     *
     * @return \AnalyticsBundle\Entity\GovProgram
     */
    public function getGovProgram()
    {
        return $this->govProgram;
    }

    /**
     * Set subProgramAction
     *
     * @param \AnalyticsBundle\Entity\SubProgramAction $subProgramAction
     * @return RateIndicator
     */
    public function setSubProgramAction(\AnalyticsBundle\Entity\SubProgramAction $subProgramAction = null)
    {
        $this->subProgramAction = $subProgramAction;

        return $this;
    }

    /**
     * Get subProgramAction
     *
     * @return \AnalyticsBundle\Entity\SubProgramAction
     */
    public function getSubProgramAction()
    {
        return $this->subProgramAction;
    }

    /**
     * Set fcp
     *
     * @param \AnalyticsBundle\Entity\Fcp $fcp
     * @return RateIndicator
     */
    public function setFcp(\AnalyticsBundle\Entity\Fcp $fcp = null)
    {
        $this->fcp = $fcp;

        return $this;
    }

    /**
     * Get fcp
     *
     * @return \AnalyticsBundle\Entity\Fcp
     */
    public function getFcp()
    {
        return $this->fcp;
    }

    /**
     * Set fcpAction
     *
     * @param \AnalyticsBundle\Entity\FcpAction $fcpAction
     * @return RateIndicator
     */
    public function setFcpAction(\AnalyticsBundle\Entity\FcpAction $fcpAction = null)
    {
        $this->fcpAction = $fcpAction;

        return $this;
    }

    /**
     * Get fcpAction
     *
     * @return \AnalyticsBundle\Entity\FcpAction
     */
    public function getFcpAction()
    {
        return $this->fcpAction;
    }

    /**
     * Set okei
     *
     * @param \AnalyticsBundle\Entity\Okei $okei
     * @return RateIndicator
     */
    public function setOkei(\AnalyticsBundle\Entity\Okei $okei = null)
    {
        $this->okei = $okei;

        return $this;
    }

    /**
     * Get okei
     *
     * @return \AnalyticsBundle\Entity\Okei
     */
    public function getOkei()
    {
        return $this->okei;
    }

    /**
     * Set parent
     *
     * @param \AnalyticsBundle\Entity\RateIndicator $parent
     * @return RateIndicator
     */
    public function setParent(\AnalyticsBundle\Entity\RateIndicator $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \AnalyticsBundle\Entity\RateIndicator
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Add lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     * @return RateIndicator
     */
    public function addLot(\AnalyticsBundle\Entity\Lot $lot)
    {
        if (!$this->lot->contains($lot)) {
            //$this->lot->add($lot);
            $this->lot[] = $lot;
        }

        return $this;
    }

    /**
     * Remove lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     */
    public function removeLot(\AnalyticsBundle\Entity\Lot $lot)
    {
        $this->lot->removeElement($lot);
    }

    /**
     * Get lot
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * @JMS\VirtualProperty
     * @JMS\Type("string")
     * @JMS\SerializedName("typeName")
     * @JMS\Groups({"lot_detail"})
     */
    public function typeName()
    {
        return static::$types_list[$this->getType()];
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
