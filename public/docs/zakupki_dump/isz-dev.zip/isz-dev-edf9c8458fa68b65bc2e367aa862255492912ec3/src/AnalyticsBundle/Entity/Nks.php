<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * Nks
 *
 * @ORM\Table(name="nks", indexes={@ORM\Index(name="nks_gov_program_id", columns={"gov_program_id"})})
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\NksRepository")
 * @Json\Schema("Nks")
 */
class Nks implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     */
    private $title;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="date", nullable=true)
     */
    private $date;

    /**
     * @var string
     *
     * @ORM\Column(name="protocol_number", type="string", length=255, nullable=true)
     */
    private $protocolNumber;

    /**
     * @var \GovProgram
     *
     * @ORM\ManyToOne(targetEntity="GovProgram")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="gov_program_id", referencedColumnName="id")
     * })
     */
    private $govProgram;


    /**
     * @var string
     *
     * @ORM\Column(name="file", type="string", length=255, nullable=true)
     */
    private $file;

    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Nks
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     * @return Nks
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set protocolNumber
     *
     * @param string $protocolNumber
     * @return Nks
     */
    public function setProtocolNumber($protocolNumber)
    {
        $this->protocolNumber = $protocolNumber;

        return $this;
    }

    /**
     * Get protocolNumber
     *
     * @return string
     */
    public function getProtocolNumber()
    {
        return $this->protocolNumber;
    }

    /**
     * Set govProgram
     *
     * @param \AnalyticsBundle\Entity\GovProgram $govProgram
     * @return Nks
     */
    public function setGovProgram(\AnalyticsBundle\Entity\GovProgram $govProgram = null)
    {
        $this->govProgram = $govProgram;

        return $this;
    }

    /**
     * Get govProgram
     *
     * @return \AnalyticsBundle\Entity\GovProgram
     */
    public function getGovProgram()
    {
        return $this->govProgram;
    }

    /**
     * Set file
     *
     * @param string $file
     * @return Nks
     */
    public function setFile($file)
    {
        $this->file = $file;

        return $this;
    }

    /**
     * Get file
     *
     * @return string 
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
