<?php
namespace AnalyticsBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * KbkExpenseType
 *
 * @ORM\Table(
 *   name="kbk_expense_type"
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\KbkExpenseTypeRepository")
 * @Json\Schema("KbkExpenseType")
 */
class KbkExpenseType implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"kbkexpensetype_detail", "kbkexpensetype_list", "lot_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     * @JMS\Groups({"kbkexpensetype_detail", "kbkexpensetype_list", "lot_detail"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=255, nullable=true)
     * @JMS\Groups({"kbkexpensetype_detail", "kbkexpensetype_list", "lot_detail"})
     */
    private $code;

    /**
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param guid $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param string $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @param string $code
     */
    public function setCode($code)
    {
        $this->code = $code;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getCode() . ' - ' . $this->getTitle();
    }
}