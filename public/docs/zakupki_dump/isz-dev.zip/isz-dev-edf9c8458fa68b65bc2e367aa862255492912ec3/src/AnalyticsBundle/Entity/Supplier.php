<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * Supplier
 *
 * @ORM\Table(
 *   name="supplier",
 *   indexes={
 *     @ORM\Index(name="supplier_head_id", columns={"head_id"}),
 *     @ORM\Index(name="supplier_bank_gaurantee_id", columns={"bank_gaurantee_id"}),
 *     @ORM\Index(name="supplier_okved_id", columns={"okved_id"}),
 *     @ORM\Index(name="supplier_okopf_id", columns={"okopf_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\SupplierRepository")
 * @Json\Schema("Supplier")
 */
class Supplier implements IEntity
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="full_name", type="text", nullable=true)
     */
    private $fullName;

    /**
     * @var string
     *
     * @ORM\Column(name="short_name", type="text", nullable=true)
     */
    private $shortName;

    /**
     * @var string
     *
     * @ORM\Column(name="federal_district", type="text", nullable=true)
     */
    private $federalDistrict;

    /**
     * @var string
     *
     * @ORM\Column(name="fact_address", type="text", nullable=true)
     */
    private $factAddress;

    /**
     * @var string
     *
     * @ORM\Column(name="post_address", type="text", nullable=true)
     */
    private $postAddress;

    /**
     * @var string
     *
     * @ORM\Column(name="inn", type="string", length=32, nullable=true)
     */
    private $inn;

    /**
     * @var string
     *
     * @ORM\Column(name="kpp", type="string", length=32, nullable=true)
     */
    private $kpp;

    /**
     * @var string
     *
     * @ORM\Column(name="ogrn", type="string", length=32, nullable=true)
     */
    private $ogrn;

    /**
     * @var string
     *
     * @ORM\Column(name="ogrnip", type="string", length=32, nullable=true)
     */
    private $ogrnip;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date_ogrn", type="date", nullable=true)
     */
    private $dateOgrn;

    /**
     * @var string
     *
     * @ORM\Column(name="bik", type="string", length=32, nullable=true)
     */
    private $bik;

    /**
     * @var string
     *
     * @ORM\Column(name="bank_name", type="text", nullable=true)
     */
    private $bankName;

    /**
     * @var string
     *
     * @ORM\Column(name="bank_account", type="string", length=32, nullable=true)
     */
    private $bankAccount;

    /**
     * @var string
     *
     * @ORM\Column(name="corr_account", type="string", length=32, nullable=true)
     */
    private $corrAccount;

    /**
     * @var string
     *
     * @ORM\Column(name="okpo", type="string", length=32, nullable=true)
     */
    private $okpo;

    /**
     * @var string
     *
     * @ORM\Column(name="oktmo", type="string", length=32, nullable=true)
     */
    private $oktmo;

    /**
     * @var string
     *
     * @ORM\Column(name="phone", type="text", nullable=true)
     */
    private $phone;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=255, nullable=true)
     */
    private $email;

    /**
     * @var boolean
     *
     * @ORM\Column(name="winner", type="boolean", nullable=true)
     */
    private $winner;

    /**
     * @var integer
     *
     * @ORM\Column(name="serial_number", type="smallint", nullable=true)
     */
    private $serialNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="authority", type="text", nullable=true)
     */
    private $authority;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=32, nullable=true)
     */
    private $type;

    /**
     * @var boolean
     *
     * @ORM\Column(name="foreign_comp", type="boolean", nullable=true)
     */
    private $foreignComp;

    /**
     * @var BankGuarantee
     *
     * @ORM\ManyToOne(targetEntity="BankGuarantee")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="bank_gaurantee_id", referencedColumnName="id")
     * })
     */
    private $bankGaurantee;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="head_id", referencedColumnName="id")
     * })
     */
    private $head;

    /**
     * @var Okopf
     *
     * @ORM\ManyToOne(targetEntity="Okopf")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="okopf_id", referencedColumnName="id")
     * })
     */
    private $okopf;

    /**
     * @var Okved
     *
     * @ORM\ManyToOne(targetEntity="Okved")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="okved_id", referencedColumnName="id")
     * })
     */
    private $okved;



    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set fullName
     *
     * @param string $fullName
     * @return Supplier
     */
    public function setFullName($fullName)
    {
        $this->fullName = $fullName;

        return $this;
    }

    /**
     * Get fullName
     *
     * @return string 
     */
    public function getFullName()
    {
        return $this->fullName;
    }

    /**
     * Set shortName
     *
     * @param string $shortName
     * @return Supplier
     */
    public function setShortName($shortName)
    {
        $this->shortName = $shortName;

        return $this;
    }

    /**
     * Get shortName
     *
     * @return string 
     */
    public function getShortName()
    {
        return $this->shortName;
    }

    /**
     * Set federalDistrict
     *
     * @param string $federalDistrict
     * @return Supplier
     */
    public function setFederalDistrict($federalDistrict)
    {
        $this->federalDistrict = $federalDistrict;

        return $this;
    }

    /**
     * Get federalDistrict
     *
     * @return string 
     */
    public function getFederalDistrict()
    {
        return $this->federalDistrict;
    }

    /**
     * Set factAddress
     *
     * @param string $factAddress
     * @return Supplier
     */
    public function setFactAddress($factAddress)
    {
        $this->factAddress = $factAddress;

        return $this;
    }

    /**
     * Get factAddress
     *
     * @return string 
     */
    public function getFactAddress()
    {
        return $this->factAddress;
    }

    /**
     * Set postAddress
     *
     * @param string $postAddress
     * @return Supplier
     */
    public function setPostAddress($postAddress)
    {
        $this->postAddress = $postAddress;

        return $this;
    }

    /**
     * Get postAddress
     *
     * @return string 
     */
    public function getPostAddress()
    {
        return $this->postAddress;
    }

    /**
     * Set inn
     *
     * @param string $inn
     * @return Supplier
     */
    public function setInn($inn)
    {
        $this->inn = $inn;

        return $this;
    }

    /**
     * Get inn
     *
     * @return string 
     */
    public function getInn()
    {
        return $this->inn;
    }

    /**
     * Set kpp
     *
     * @param string $kpp
     * @return Supplier
     */
    public function setKpp($kpp)
    {
        $this->kpp = $kpp;

        return $this;
    }

    /**
     * Get kpp
     *
     * @return string 
     */
    public function getKpp()
    {
        return $this->kpp;
    }

    /**
     * Set ogrn
     *
     * @param string $ogrn
     * @return Supplier
     */
    public function setOgrn($ogrn)
    {
        $this->ogrn = $ogrn;

        return $this;
    }

    /**
     * Get ogrn
     *
     * @return string 
     */
    public function getOgrn()
    {
        return $this->ogrn;
    }

    /**
     * Set ogrnip
     *
     * @param string $ogrnip
     * @return Supplier
     */
    public function setOgrnip($ogrnip)
    {
        $this->ogrnip = $ogrnip;

        return $this;
    }

    /**
     * Get ogrnip
     *
     * @return string
     */
    public function getOgrnip()
    {
        return $this->ogrnip;
    }

    /**
     * Set dateOgrn
     *
     * @param \DateTime $dateOgrn
     * @return Supplier
     */
    public function setDateOgrn($dateOgrn)
    {
        $this->dateOgrn = $dateOgrn;

        return $this;
    }

    /**
     * Get dateOgrn
     *
     * @return \DateTime 
     */
    public function getDateOgrn()
    {
        return $this->dateOgrn;
    }

    /**
     * Set bik
     *
     * @param string $bik
     * @return Supplier
     */
    public function setBik($bik)
    {
        $this->bik = $bik;

        return $this;
    }

    /**
     * Get bik
     *
     * @return string 
     */
    public function getBik()
    {
        return $this->bik;
    }

    /**
     * Set bankName
     *
     * @param string $bankName
     * @return Supplier
     */
    public function setBankName($bankName)
    {
        $this->bankName = $bankName;

        return $this;
    }

    /**
     * Get bankName
     *
     * @return string 
     */
    public function getBankName()
    {
        return $this->bankName;
    }

    /**
     * Set bankAccount
     *
     * @param string $bankAccount
     * @return Supplier
     */
    public function setBankAccount($bankAccount)
    {
        $this->bankAccount = $bankAccount;

        return $this;
    }

    /**
     * Get bankAccount
     *
     * @return string 
     */
    public function getBankAccount()
    {
        return $this->bankAccount;
    }

    /**
     * Set corrAccount
     *
     * @param string $corrAccount
     * @return Supplier
     */
    public function setCorrAccount($corrAccount)
    {
        $this->corrAccount = $corrAccount;

        return $this;
    }

    /**
     * Get corrAccount
     *
     * @return string 
     */
    public function getCorrAccount()
    {
        return $this->corrAccount;
    }

    /**
     * Set okpo
     *
     * @param string $okpo
     * @return Supplier
     */
    public function setOkpo($okpo)
    {
        $this->okpo = $okpo;

        return $this;
    }

    /**
     * Get okpo
     *
     * @return string 
     */
    public function getOkpo()
    {
        return $this->okpo;
    }

    /**
     * Set oktmo
     *
     * @param string $oktmo
     * @return Supplier
     */
    public function setOktmo($oktmo)
    {
        $this->oktmo = $oktmo;

        return $this;
    }

    /**
     * Get oktmo
     *
     * @return string 
     */
    public function getOktmo()
    {
        return $this->oktmo;
    }

    /**
     * Set phone
     *
     * @param string $phone
     * @return Supplier
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string 
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return Supplier
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string 
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set winner
     *
     * @param boolean $winner
     * @return Supplier
     */
    public function setWinner($winner)
    {
        $this->winner = $winner;

        return $this;
    }

    /**
     * Get winner
     *
     * @return boolean
     */
    public function getWinner()
    {
        return $this->winner;
    }

    /**
     * Set serialNumber
     *
     * @param integer $serialNumber
     * @return Supplier
     */
    public function setSerialNumber($serialNumber)
    {
        $this->serialNumber = $serialNumber;

        return $this;
    }

    /**
     * Get serialNumber
     *
     * @return integer
     */
    public function getSerialNumber()
    {
        return $this->serialNumber;
    }

    /**
     * Set authority
     *
     * @param string $authority
     * @return Supplier
     */
    public function setAuthority($authority)
    {
        $this->authority = $authority;

        return $this;
    }

    /**
     * Get authority
     *
     * @return string
     */
    public function getAuthority()
    {
        return $this->authority;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return Supplier
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set foreignComp
     *
     * @param boolean $foreignComp
     * @return Supplier
     */
    public function setForeignComp($foreignComp)
    {
        $this->foreignComp = $foreignComp;

        return $this;
    }

    /**
     * Get foreignComp
     *
     * @return boolean
     */
    public function getForeignComp()
    {
        return $this->foreignComp;
    }

    /**
     * Set bankGaurantee
     *
     * @param \AnalyticsBundle\Entity\BankGuarantee $bankGaurantee
     * @return Supplier
     */
    public function setBankGaurantee(\AnalyticsBundle\Entity\BankGuarantee $bankGaurantee = null)
    {
        $this->bankGaurantee = $bankGaurantee;

        return $this;
    }

    /**
     * Get bankGaurantee
     *
     * @return \AnalyticsBundle\Entity\BankGuarantee
     */
    public function getBankGaurantee()
    {
        return $this->bankGaurantee;
    }

    /**
     * Set head
     *
     * @param \AnalyticsBundle\Entity\Users $head
     * @return Supplier
     */
    public function setHead(\AnalyticsBundle\Entity\Users $head = null)
    {
        $this->head = $head;

        return $this;
    }

    /**
     * Get head
     *
     * @return \AnalyticsBundle\Entity\Users
     */
    public function getHead()
    {
        return $this->head;
    }

    /**
     * Set okopf
     *
     * @param \AnalyticsBundle\Entity\Okopf $okopf
     * @return Supplier
     */
    public function setOkopf(\AnalyticsBundle\Entity\Okopf $okopf = null)
    {
        $this->okopf = $okopf;

        return $this;
    }

    /**
     * Get okopf
     *
     * @return \AnalyticsBundle\Entity\Okopf
     */
    public function getOkopf()
    {
        return $this->okopf;
    }

    /**
     * Set okved
     *
     * @param \AnalyticsBundle\Entity\Okved $okved
     * @return Supplier
     */
    public function setOkved(\AnalyticsBundle\Entity\Okved $okved = null)
    {
        $this->okved = $okved;

        return $this;
    }

    /**
     * Get okved
     *
     * @return \AnalyticsBundle\Entity\Okved
     */
    public function getOkved()
    {
        return $this->okved;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getFullName();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
