<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * Marketplace
 *
 * @ORM\Table(name="marketplace")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\MarketplaceRepository")
 * @Json\Schema("Marketplace")
 */
class Marketplace implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="http", type="text", nullable=true)
     */
    private $http;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="text", nullable=true)
     */
    private $code;


    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Marketplace
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set http
     *
     * @param string $http
     * @return Marketplace
     */
    public function setHttp($http)
    {
        $this->http = $http;

        return $this;
    }

    /**
     * Get http
     *
     * @return string 
     */
    public function getHttp()
    {
        return $this->http;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @param string $code
     */
    public function setCode($code)
    {
        $this->code = $code;
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
