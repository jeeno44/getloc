<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * Protocol2Criteria
 *
 * @ORM\Table(
 *   name="protocol2_criteria",
 *   uniqueConstraints={
 *     @ORM\UniqueConstraint(name="uniquepair_id2", columns={"application_id", "criteria_indicator_id"})
 *   },
 *   indexes={
 *     @ORM\Index(name="protocol2_criteria_application_id", columns={"application_id"}),
 *     @ORM\Index(name="protocol2_criteria_criteria_indicator_id", columns={"criteria_indicator_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\Protocol2CriteriaRepository")
 * @Json\Schema("Protocol2Criteria")
 */
class Protocol2Criteria implements IEntity
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="value", type="decimal", precision=3, scale=2, nullable=true)
     */
    private $value;

    /**
     * @var Application
     *
     * @ORM\ManyToOne(targetEntity="Application")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="application_id", referencedColumnName="id")
     * })
     */
    private $application;

    /**
     * @var \AnalyticsBundle\Entity\CriteriaIndicator
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\CriteriaIndicator")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="criteria_indicator_id", referencedColumnName="id")
     * })
     */
    private $criteriaIndicator;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="FactCommissionCommissionMember", mappedBy="protocol2Criteria")
     */
    private $factCommissionCommissionMember;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->factCommissionCommissionMember = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set value
     *
     * @param string $value
     * @return Protocol2Criteria
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return string 
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set application
     *
     * @param \AnalyticsBundle\Entity\Application $application
     * @return Protocol2Criteria
     */
    public function setApplication(\AnalyticsBundle\Entity\Application $application = null)
    {
        $this->application = $application;

        return $this;
    }

    /**
     * Get application
     *
     * @return \AnalyticsBundle\Entity\Application
     */
    public function getApplication()
    {
        return $this->application;
    }

    /**
     * Set criteriaIndicator
     *
     * @param \AnalyticsBundle\Entity\CriteriaIndicator $criteriaIndicator
     * @return Protocol2Criteria
     */
    public function setCriteriaIndicator(\AnalyticsBundle\Entity\CriteriaIndicator $criteriaIndicator = null)
    {
        $this->criteriaIndicator = $criteriaIndicator;

        return $this;
    }

    /**
     * Get criteriaIndicator
     *
     * @return \AnalyticsBundle\Entity\CriteriaIndicator
     */
    public function getCriteriaIndicator()
    {
        return $this->criteriaIndicator;
    }

    /**
     * Add factCommissionCommissionMember
     *
     * @param \AnalyticsBundle\Entity\FactCommissionCommissionMember $factCommissionCommissionMember
     * @return Protocol2Criteria
     */
    public function addFactCommissionCommissionMember(\AnalyticsBundle\Entity\FactCommissionCommissionMember $factCommissionCommissionMember)
    {
        $this->factCommissionCommissionMember[] = $factCommissionCommissionMember;

        return $this;
    }

    /**
     * Remove factCommissionCommissionMember
     *
     * @param \AnalyticsBundle\Entity\FactCommissionCommissionMember $factCommissionCommissionMember
     */
    public function removeFactCommissionCommissionMember(\AnalyticsBundle\Entity\FactCommissionCommissionMember $factCommissionCommissionMember)
    {
        $this->factCommissionCommissionMember->removeElement($factCommissionCommissionMember);
    }

    /**
     * Get factCommissionCommissionMember
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFactCommissionCommissionMember()
    {
        return $this->factCommissionCommissionMember;
    }
}
