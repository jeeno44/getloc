<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Financing
 *
 * @ORM\Table(
 *     name="financing",
 *     uniqueConstraints={
 *          @ORM\UniqueConstraint(name="lot_year", columns={"year", "lot_id"}),
 *          @ORM\UniqueConstraint(name="lot_rel_year", columns={"rel_year", "lot_id"}),
 *          @ORM\UniqueConstraint(name="financing_lot_year", columns={"lot_id", "year"}),
 *          @ORM\UniqueConstraint(name="plan_lot_rel_year", columns={"rel_year", "plan_id", "lot_id"}),
 *          @ORM\UniqueConstraint(name="plan_lot_year", columns={"year", "plan_id", "lot_id"})
 *     },
 *     indexes={
 *          @ORM\Index(name="financing_year", columns={"year"}),
 *          @ORM\Index(name="idx_7eca6feba8cba5f7", columns={"lot_id"}),
 *          @ORM\Index(name="idx_7eca6febe899029b", columns={"plan_id"})
 *     }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\FinancingRepository")
 * @Json\Schema("Financing")
 */
class Financing implements IEntity
{
    const MAX_YEARS = 3;

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="SEQUENCE")
     * @ORM\SequenceGenerator(sequenceName="financing_id_seq", allocationSize=1, initialValue=1)
     * @JMS\Groups({"financing", "financing_detail", "lot_detail"})
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="year", type="smallint", nullable=true)
     * @JMS\Groups({"financing", "financing_list", "financing_detail", "lot_detail", "lot_list", "plan_current", "plan_next"})
     */
    private $year;

    /**
     * @var integer
     *
     * @ORM\Column(name="rel_year", type="smallint", nullable=false)
     * @Assert\Range(min=1, max=3)
     * @Json\Minimum(1)
     * @Json\Maximum(3)
     * @JMS\Groups({"financing", "financing_list", "financing_detail", "lot_detail", "lot_list", "plan_current", "plan_next"})
     */
    private $relYear;

    /**
     * @var float
     *
     * @ORM\Column(name="plan_price", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"financing", "financing_list", "financing_detail", "lot_detail", "lot_list", "plan_current", "plan_next"})
     */
    private $planPrice;

    /**
     * @var integer
     *
     * @ORM\Column(name="plan_quantity", type="integer", nullable=true)
     * @JMS\Groups({"financing", "financing_detail", "lot_detail", "lot_list"})
     */
    private $planQuantity;

    /**
     * @var float
     *
     * @ORM\Column(name="publication_price", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"financing", "financing_detail", "lot_detail"})
     */
    private $publicationPrice;

    /**
     * @var integer
     *
     * @ORM\Column(name="publication_quantity", type="integer", nullable=true)
     * @JMS\Groups({"financing", "financing_detail", "lot_detail"})
     */
    private $publicationQuantity;

    /**
     * @var float
     *
     * @ORM\Column(name="contract_price", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"financing", "financing_detail", "lot_detail"})
     */
    private $contractPrice;

    /**
     * @var integer
     *
     * @ORM\Column(name="contract_quantity", type="integer", nullable=true)
     * @JMS\Groups({"financing", "financing_detail", "lot_detail"})
     */
    private $contractQuantity;

    /**
     * @var float
     *
     * @ORM\Column(name="fact_price", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"financing", "financing_detail", "lot_detail"})
     */
    private $factPrice;

    /**
     * @var integer
     *
     * @ORM\Column(name="fact_quantity", type="integer", nullable=true)
     * @JMS\Groups({"financing", "financing_detail", "lot_detail"})
     */
    private $factQuantity;

    /**
     * @var float
     *
     * @ORM\Column(name="advance_payment_percentage", type="float", precision=5, scale=2, nullable=true)
     * @JMS\Groups({"financing", "financing_list", "financing_detail", "lot_detail"})
     */
    private $advancePaymentPercentage;

    /**
     * @var Plan
     *
     * @ORM\ManyToOne(targetEntity="Plan", inversedBy="financing")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="plan_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"financing_detail"})
     */
    private $plan;

    /**
     * @var Lot
     *
     * @ORM\ManyToOne(targetEntity="Lot", inversedBy="financing")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"financing_detail"})
     */
    private $lot;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set year
     *
     * @param integer $year
     * @return Financing
     */
    public function setYear($year)
    {
        $this->year = $year;

        return $this;
    }

    /**
     * Get year
     *
     * @return integer 
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * Set relYear
     *
     * @param integer $relYear
     * @return Financing
     */
    public function setRelYear($relYear)
    {
        $this->relYear = $relYear;

        return $this;
    }

    /**
     * Get relYear
     *
     * @return integer 
     */
    public function getRelYear()
    {
        return $this->relYear;
    }

    /**
     * Set planPrice
     *
     * @param float $planPrice
     * @return Financing
     */
    public function setPlanPrice($planPrice)
    {
        $this->planPrice = $planPrice;

        return $this;
    }

    /**
     * Get planPrice
     *
     * @return float 
     */
    public function getPlanPrice()
    {
        return $this->planPrice;
    }

    /**
     * Set planQuantity
     *
     * @param integer $planQuantity
     * @return Financing
     */
    public function setPlanQuantity($planQuantity)
    {
        $this->planQuantity = $planQuantity;

        return $this;
    }

    /**
     * Get planQuantity
     *
     * @return integer 
     */
    public function getPlanQuantity()
    {
        return $this->planQuantity;
    }

    /**
     * Set publicationPrice
     *
     * @param float $publicationPrice
     * @return Financing
     */
    public function setPublicationPrice($publicationPrice)
    {
        $this->publicationPrice = $publicationPrice;

        return $this;
    }

    /**
     * Get publicationPrice
     *
     * @return float 
     */
    public function getPublicationPrice()
    {
        return $this->publicationPrice;
    }

    /**
     * Set publicationQuantity
     *
     * @param integer $publicationQuantity
     * @return Financing
     */
    public function setPublicationQuantity($publicationQuantity)
    {
        $this->publicationQuantity = $publicationQuantity;

        return $this;
    }

    /**
     * Get publicationQuantity
     *
     * @return integer 
     */
    public function getPublicationQuantity()
    {
        return $this->publicationQuantity;
    }

    /**
     * Set contractPrice
     *
     * @param float $contractPrice
     * @return Financing
     */
    public function setContractPrice($contractPrice)
    {
        $this->contractPrice = $contractPrice;

        return $this;
    }

    /**
     * Get contractPrice
     *
     * @return float 
     */
    public function getContractPrice()
    {
        return $this->contractPrice;
    }

    /**
     * Set contractQuantity
     *
     * @param integer $contractQuantity
     * @return Financing
     */
    public function setContractQuantity($contractQuantity)
    {
        $this->contractQuantity = $contractQuantity;

        return $this;
    }

    /**
     * Get contractQuantity
     *
     * @return integer 
     */
    public function getContractQuantity()
    {
        return $this->contractQuantity;
    }

    /**
     * Set factPrice
     *
     * @param float $factPrice
     * @return Financing
     */
    public function setFactPrice($factPrice)
    {
        $this->factPrice = $factPrice;

        return $this;
    }

    /**
     * Get factPrice
     *
     * @return float 
     */
    public function getFactPrice()
    {
        return $this->factPrice;
    }

    /**
     * Set factQuantity
     *
     * @param integer $factQuantity
     * @return Financing
     */
    public function setFactQuantity($factQuantity)
    {
        $this->factQuantity = $factQuantity;

        return $this;
    }

    /**
     * Get factQuantity
     *
     * @return integer 
     */
    public function getFactQuantity()
    {
        return $this->factQuantity;
    }

    /**
     * Set plan
     *
     * @param \AnalyticsBundle\Entity\Plan $plan
     * @return Financing
     */
    public function setPlan(\AnalyticsBundle\Entity\Plan $plan = null)
    {
        $this->plan = $plan;

        return $this;
    }

    /**
     * Get plan
     *
     * @return \AnalyticsBundle\Entity\Plan
     */
    public function getPlan()
    {
        return $this->plan;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     * @return Financing
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * Set advancePaymentPercentage
     *
     * @param float $advancePaymentPercentage
     * @return Financing
     */
    public function setAdvancePaymentPercentage($advancePaymentPercentage)
    {
        $this->advancePaymentPercentage = $advancePaymentPercentage;

        return $this;
    }

    /**
     * Get advancePaymentPercentage
     *
     * @return float 
     */
    public function getAdvancePaymentPercentage()
    {
        return $this->advancePaymentPercentage;
    }
}
