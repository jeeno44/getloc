<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * FcpPhases
 *
 * @ORM\Table(name="fcp_phases", indexes={@ORM\Index(name="fcp_phases_execution_date", columns={"execution_date"}), @ORM\Index(name="IDX_859B61A843C2FCC7", columns={"fcp_id"})})
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\FcpPhasesRepository")
 * @Json\Schema("FcpPhases")
 */
class FcpPhases implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="execution_phase", type="text", nullable=true)
     */
    private $executionPhase;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="execution_date", type="date", nullable=true)
     */
    private $executionDate;

    /**
     * @var \Fcp
     *
     * @ORM\ManyToOne(targetEntity="Fcp")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_id", referencedColumnName="id")
     * })
     */
    private $fcp;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set executionPhase
     *
     * @param string $executionPhase
     * @return FcpPhases
     */
    public function setExecutionPhase($executionPhase)
    {
        $this->executionPhase = $executionPhase;

        return $this;
    }

    /**
     * Get executionPhase
     *
     * @return string 
     */
    public function getExecutionPhase()
    {
        return $this->executionPhase;
    }

    /**
     * Set executionDate
     *
     * @param \DateTime $executionDate
     * @return FcpPhases
     */
    public function setExecutionDate($executionDate)
    {
        $this->executionDate = $executionDate;

        return $this;
    }

    /**
     * Get executionDate
     *
     * @return \DateTime 
     */
    public function getExecutionDate()
    {
        return $this->executionDate;
    }

    /**
     * Set fcp
     *
     * @param \AnalyticsBundle\Entity\Fcp $fcp
     * @return FcpPhases
     */
    public function setFcp(\AnalyticsBundle\Entity\Fcp $fcp = null)
    {
        $this->fcp = $fcp;

        return $this;
    }

    /**
     * Get fcp
     *
     * @return \AnalyticsBundle\Entity\Fcp
     */
    public function getFcp()
    {
        return $this->fcp;
    }
}
