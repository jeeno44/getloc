<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * ApplicationDocumentsAvailability
 *
 * @ORM\Table(
 *     name="application_documents_availability",
 *     uniqueConstraints={
 *         @ORM\UniqueConstraint(name="application_documents_availability_documents_id", columns={"documents_id"}),
 *         @ORM\UniqueConstraint(name="application_documents_availability_application_id", columns={"application_id"}),
 *         @ORM\UniqueConstraint(name="uniquepair_id1", columns={"application_id", "documents_id"})
 *     }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\ApplicationDocumentsAvailabilityRepository")
 * @Json\Schema("ApplicationDocumentsAvailability")
 */
class ApplicationDocumentsAvailability implements IEntity
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var boolean
     *
     * @ORM\Column(name="availability", type="boolean", nullable=true)
     */
    private $availability;

    /**
     * @var Application
     *
     * @ORM\ManyToOne(targetEntity="Application")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="application_id", referencedColumnName="id")
     * })
     */
    private $application;

    /**
     * @var Documents
     *
     * @ORM\ManyToOne(targetEntity="Documents")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="documents_id", referencedColumnName="id")
     * })
     */
    private $documents;



    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set availability
     *
     * @param boolean $availability
     * @return ApplicationDocumentsAvailability
     */
    public function setAvailability($availability)
    {
        $this->availability = $availability;

        return $this;
    }

    /**
     * Get availability
     *
     * @return boolean 
     */
    public function getAvailability()
    {
        return $this->availability;
    }

    /**
     * Set application
     *
     * @param \AnalyticsBundle\Entity\Application $application
     * @return ApplicationDocumentsAvailability
     */
    public function setApplication(\AnalyticsBundle\Entity\Application $application = null)
    {
        $this->application = $application;

        return $this;
    }

    /**
     * Get application
     *
     * @return \AnalyticsBundle\Entity\Application
     */
    public function getApplication()
    {
        return $this->application;
    }

    /**
     * Set documents
     *
     * @param \AnalyticsBundle\Entity\Documents $documents
     * @return ApplicationDocumentsAvailability
     */
    public function setDocuments(\AnalyticsBundle\Entity\Documents $documents = null)
    {
        $this->documents = $documents;

        return $this;
    }

    /**
     * Get documents
     *
     * @return \AnalyticsBundle\Entity\Documents
     */
    public function getDocuments()
    {
        return $this->documents;
    }
}
