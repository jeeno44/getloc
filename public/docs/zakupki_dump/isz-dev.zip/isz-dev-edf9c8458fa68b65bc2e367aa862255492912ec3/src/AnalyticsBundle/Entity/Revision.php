<?php

namespace AnalyticsBundle\Entity;

abstract class Revision
{
}