<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Okpd
 *
 * @ORM\Table(name="okpd")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\OkpdRepository")
 * @Json\Schema("Okpd")
 */
class Okpd implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"okpd", "details", "lot_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="code_okpd", type="string", length=255, nullable=true)
     * @JMS\Groups({"okpd", "details", "lot_detail", "notice_ea", "common_detail"})
     */
    private $codeOkpd;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=1024, nullable=true)
     * @JMS\Groups({"okpd", "details", "lot_detail", "notice_ea", "common_detail"})
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="value", type="decimal", precision=17, scale=2, nullable=true)
     * @JMS\Groups({"details"})
     */
    private $value;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set codeOkpd
     *
     * @param string $codeOkpd
     * @return Okpd
     */
    public function setCodeOkpd($codeOkpd)
    {
        $this->codeOkpd = $codeOkpd;

        return $this;
    }

    /**
     * Get codeOkpd
     *
     * @return string 
     */
    public function getCodeOkpd()
    {
        return $this->codeOkpd;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Okpd
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set value
     *
     * @param string $value
     * @return Okpd
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return string 
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return sprintf("%s - %s", $this->getCodeOkpd(), $this->getDescription());
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
