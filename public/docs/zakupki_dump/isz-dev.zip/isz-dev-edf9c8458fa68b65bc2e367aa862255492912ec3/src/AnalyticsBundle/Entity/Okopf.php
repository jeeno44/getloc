<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Okopf
 *
 * @ORM\Table(name="okopf")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\OkopfRepository")
 * @Json\Schema("Okopf")
 */
class Okopf implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"list", "details"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     * @JMS\Groups({"list", "details"})
     */
    private $description;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Okopf
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Возвращает автоматическое название
     *
     * @return string
     */
    public function __toString()
    {
        return $this->getDescription();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
