<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * NmckMarketPriceMethod
 *
 * @ORM\Table(name="nmck_market_price_method", indexes={@ORM\Index(name="nmck_market_price_method_coef_value", columns={"coef_value"}), @ORM\Index(name="nmck_market_price_method_correspondance_id", columns={"correspondance_id"}), @ORM\Index(name="nmck_market_price_method_info_source_id", columns={"info_source_id"}), @ORM\Index(name="nmck_market_price_method_nmck_variant_id", columns={"nmck_variant_id"}), @ORM\Index(name="nmck_market_price_method_procurement_type_id", columns={"procurement_type_id"})})
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\NmckMarketPriceMethodRepository")
 * @Json\Schema("NmckMarketPriceMethod")
 */
class NmckMarketPriceMethod implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="coef_value", type="integer", nullable=true)
     */
    private $coefValue;

    /**
     * @var float
     *
     * @ORM\Column(name="price", type="float", precision=10, scale=0, nullable=true)
     */
    private $price;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="date", nullable=true)
     */
    private $date;

    /**
     * @var string
     *
     * @ORM\Column(name="information", type="text", nullable=true)
     */
    private $information;

    /**
     * @var integer
     *
     * @ORM\Column(name="quantity", type="integer", nullable=true)
     */
    private $quantity;

    /**
     * @var \NmckVariant
     *
     * @ORM\ManyToOne(targetEntity="NmckVariant")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="nmck_variant_id", referencedColumnName="id")
     * })
     */
    private $nmckVariant;

    /**
     * @var \Correspondance
     *
     * @ORM\ManyToOne(targetEntity="Correspondance")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="correspondance_id", referencedColumnName="id")
     * })
     */
    private $correspondance;

    /**
     * @var \ProcurementType
     *
     * @ORM\ManyToOne(targetEntity="ProcurementType")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="procurement_type_id", referencedColumnName="id")
     * })
     */
    private $procurementType;

    /**
     * @var \InfoSource
     *
     * @ORM\ManyToOne(targetEntity="InfoSource")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="info_source_id", referencedColumnName="id")
     * })
     */
    private $infoSource;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set coefValue
     *
     * @param integer $coefValue
     * @return NmckMarketPriceMethod
     */
    public function setCoefValue($coefValue)
    {
        $this->coefValue = $coefValue;

        return $this;
    }

    /**
     * Get coefValue
     *
     * @return integer
     */
    public function getCoefValue()
    {
        return $this->coefValue;
    }

    /**
     * Set price
     *
     * @param float $price
     * @return NmckMarketPriceMethod
     */
    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    /**
     * Get price
     *
     * @return float 
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     * @return NmckMarketPriceMethod
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime 
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set information
     *
     * @param string $information
     * @return NmckMarketPriceMethod
     */
    public function setInformation($information)
    {
        $this->information = $information;

        return $this;
    }

    /**
     * Get information
     *
     * @return string 
     */
    public function getInformation()
    {
        return $this->information;
    }

    /**
     * Set quantity
     *
     * @param integer $quantity
     * @return NmckMarketPriceMethod
     */
    public function setQuantity($quantity)
    {
        $this->quantity = $quantity;

        return $this;
    }

    /**
     * Get quantity
     *
     * @return integer 
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     * Set nmckVariant
     *
     * @param \AnalyticsBundle\Entity\NmckVariant $nmckVariant
     * @return NmckMarketPriceMethod
     */
    public function setNmckVariant(\AnalyticsBundle\Entity\NmckVariant $nmckVariant = null)
    {
        $this->nmckVariant = $nmckVariant;

        return $this;
    }

    /**
     * Get nmckVariant
     *
     * @return \AnalyticsBundle\Entity\NmckVariant
     */
    public function getNmckVariant()
    {
        return $this->nmckVariant;
    }

    /**
     * Set correspondance
     *
     * @param \AnalyticsBundle\Entity\Correspondance $correspondance
     * @return NmckMarketPriceMethod
     */
    public function setCorrespondance(\AnalyticsBundle\Entity\Correspondance $correspondance = null)
    {
        $this->correspondance = $correspondance;

        return $this;
    }

    /**
     * Get correspondance
     *
     * @return \AnalyticsBundle\Entity\Correspondance
     */
    public function getCorrespondance()
    {
        return $this->correspondance;
    }

    /**
     * Set procurementType
     *
     * @param \AnalyticsBundle\Entity\ProcurementType $procurementType
     * @return NmckMarketPriceMethod
     */
    public function setProcurementType(\AnalyticsBundle\Entity\ProcurementType $procurementType = null)
    {
        $this->procurementType = $procurementType;

        return $this;
    }

    /**
     * Get procurementType
     *
     * @return \AnalyticsBundle\Entity\ProcurementType
     */
    public function getProcurementType()
    {
        return $this->procurementType;
    }

    /**
     * Set infoSource
     *
     * @param \AnalyticsBundle\Entity\InfoSource $infoSource
     * @return NmckMarketPriceMethod
     */
    public function setInfoSource(\AnalyticsBundle\Entity\InfoSource $infoSource = null)
    {
        $this->infoSource = $infoSource;

        return $this;
    }

    /**
     * Get infoSource
     *
     * @return \AnalyticsBundle\Entity\InfoSource
     */
    public function getInfoSource()
    {
        return $this->infoSource;
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
