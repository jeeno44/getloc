<?php
namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * KbkSection
 *
 * @ORM\Table(
 *   name="kbk_section"
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\KbkSectionRepository")
 * @Json\Schema("KbkSection")
 */
class KbkSection implements IEntity
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"kbksection_detail", "kbksection_list", "lot_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     * @JMS\Groups({"kbksection_detail", "kbksection_list", "lot_detail"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=255, nullable=true)
     * @JMS\Groups({"kbksection_detail", "kbksection_list", "lot_detail"})
     */
    private $code;


    /**
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param string $title
     *
     * @return KbkSection
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @param string $code
     *
     * @return KbkSection
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getCode() . ' - ' . $this->getTitle();
    }
}