<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * BankGuarantee
 *
 * @ORM\Table(name="bank_guarantee")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\BankGuaranteeRepository")
 * @Json\Schema("BankGuarantee")
 */
class BankGuarantee implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     */
    private $title;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="date", nullable=true)
     */
    private $date;

    /**
     * @var string
     *
     * @ORM\Column(name="issuer", type="text", nullable=true)
     */
    private $issuer;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="valid_until", type="date", nullable=true)
     */
    private $validUntil;

    /**
     * @var float
     *
     * @ORM\Column(name="financing", type="float", precision=10, scale=0, nullable=true)
     */
    private $financing;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return BankGuarantee
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     * @return BankGuarantee
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime 
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set issuer
     *
     * @param string $issuer
     * @return BankGuarantee
     */
    public function setIssuer($issuer)
    {
        $this->issuer = $issuer;

        return $this;
    }

    /**
     * Get issuer
     *
     * @return string 
     */
    public function getIssuer()
    {
        return $this->issuer;
    }

    /**
     * Set validUntil
     *
     * @param \DateTime $validUntil
     * @return BankGuarantee
     */
    public function setValidUntil($validUntil)
    {
        $this->validUntil = $validUntil;

        return $this;
    }

    /**
     * Get validUntil
     *
     * @return \DateTime 
     */
    public function getValidUntil()
    {
        return $this->validUntil;
    }

    /**
     * Set financing
     *
     * @param float $financing
     * @return BankGuarantee
     */
    public function setFinancing($financing)
    {
        $this->financing = $financing;

        return $this;
    }

    /**
     * Get financing
     *
     * @return float 
     */
    public function getFinancing()
    {
        return $this->financing;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
