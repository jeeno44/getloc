<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * ProcurementType
 *
 * @ORM\Table(name="procurement_type")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\ProcurementTypeRepository")
 * @Json\Schema("ProcurementType")
 */
class ProcurementType implements IEntity
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"lot_list", "lot_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     * @JMS\Groups({"lot_list", "lot_detail", "notice_ea", "lot_item_plans"})
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=255, nullable=true)
     * @JMS\Groups({"lot_detail", "notice_ea"})
     */
    private $code;

    /**
     * @var string
     *
     * @ORM\Column(name="coef_max_value", type="decimal", precision=5, scale=2, nullable=true)
     */
    private $coefMaxValue;



    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return ProcurementType
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return ProcurementType
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string 
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set coefMaxValue
     *
     * @param string $coefMaxValue
     * @return ProcurementType
     */
    public function setCoefMaxValue($coefMaxValue)
    {
        $this->coefMaxValue = $coefMaxValue;

        return $this;
    }

    /**
     * Get coefMaxValue
     *
     * @return string
     */
    public function getCoefMaxValue()
    {
        return $this->coefMaxValue;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getDescription();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
