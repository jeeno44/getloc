<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * DocumentsFreshDoc
 *
 * @ORM\Table(name="documents_fresh_doc")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\DocumentsFreshDocRepository")
 * @Json\Schema("DocumentsFreshDoc")
 * @ORM\HasLifecycleCallbacks
 */
class DocumentsFreshDoc implements IEntity
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"lot", "lot_detail", "DocumentsFreshDoc_detail", "DocumentsFreshDoc_list"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="uri", type="string", length=255, nullable=false)
     * @JMS\Groups({"lot", "lot_detail", "DocumentsFreshDoc_detail", "DocumentsFreshDoc_list"})
     */
    private $uri;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=255, nullable=false)
     * @JMS\Groups({"lot", "lot_detail", "DocumentsFreshDoc_detail", "DocumentsFreshDoc_list"})
     */
    private $type;

    /**
     * @var integer
     *
     * @ORM\Column(name="status", type="integer", nullable=false)
     * @JMS\Groups({"lot", "lot_detail", "DocumentsFreshDoc_detail", "DocumentsFreshDoc_list"})
     */
    private $status;

    /**
     * @var
     *
     * @ORM\Column(name="doc_number", type="string", length=255, nullable=false)
     * @JMS\Groups({"lot", "lot_detail", "DocumentsFreshDoc_detail", "DocumentsFreshDoc_list"})
     */
    private $docNumber;

    /**
     * @var
     *
     * @ORM\Column(name="doc_type", type="string", length=255, nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "DocumentsFreshDoc_detail", "DocumentsFreshDoc_list"})
     */
    private $docType;

    /**
     * @var \AnalyticsBundle\Entity\Lot
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\Lot", inversedBy="documentFreshDoc")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="entity_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot", "lot_detail", "DocumentsFreshDoc_detail", "DocumentsFreshDoc_list"})
     */
    private $entityId;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created", type="datetime", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "DocumentsFreshDoc_detail", "DocumentsFreshDoc_list"})
     */
    private $created;

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getId();
    }

    /**
     *
     * @ORM\PrePersist
     */
    public function updatedCreated()
    {
        if ($this->getCreated() == null) {
            $this->setCreated(new \DateTime('now'));
        }
    }

    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set uri
     *
     * @param string $uri
     * @return DocumentsFreshDoc
     */
    public function setUri($uri)
    {
        $this->uri = $uri;

        return $this;
    }

    /**
     * Get uri
     *
     * @return string 
     */
    public function getUri()
    {
        return $this->uri;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return DocumentsFreshDoc
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set status
     *
     * @param integer $status
     * @return DocumentsFreshDoc
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return integer 
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set docNumber
     *
     * @param string $docNumber
     * @return DocumentsFreshDoc
     */
    public function setDocNumber($docNumber)
    {
        $this->docNumber = $docNumber;

        return $this;
    }

    /**
     * Get docNumber
     *
     * @return string 
     */
    public function getDocNumber()
    {
        return $this->docNumber;
    }

    /**
     * Set docType
     *
     * @param string $docType
     * @return DocumentsFreshDoc
     */
    public function setDocType($docType)
    {
        $this->docType = $docType;

        return $this;
    }

    /**
     * Get docType
     *
     * @return string
     */
    public function getDocType()
    {
        return $this->docType;
    }

    /**
     * Set created
     *
     * @param \DateTime $created
     *
     * @return DocumentsFreshDoc
     */
    public function setCreated($created)
    {
        $this->created = $created;

        return $this;
    }

    /**
     * Get created
     *
     * @return \DateTime 
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     *
     * @return Gz
     */
    public function setEntityId(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->entityId = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getEntityId()
    {
        return $this->entityId;
    }
}
