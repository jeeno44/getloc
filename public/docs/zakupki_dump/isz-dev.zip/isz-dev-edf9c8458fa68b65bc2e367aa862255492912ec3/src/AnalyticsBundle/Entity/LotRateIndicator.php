<?php

namespace AnalyticsBundle\Entity;

use AnalyticsBundle\Entity\IEntity;
use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * LotRateIndicator
 *
 * @ORM\Table(name="lot_rate_indicator")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\LotRateIndicatorRepository")
 * @Json\Schema("LotRateIndicator")
 */
class LotRateIndicator implements IEntity
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="SEQUENCE")
     * @ORM\SequenceGenerator(sequenceName="lot_rate_indicator_id_seq", allocationSize=1, initialValue=1)
     * @JMS\Groups({"LotRateIndicator", "lot_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="value", type="float", precision=10, scale=2, nullable=true)
     * @JMS\Groups({"LotRateIndicator", "lot_detail"})
     */
    private $weight;

    /**
     * @var \AnalyticsBundle\Entity\RateIndicator
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\RateIndicator")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="rate_indicator_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"LotRateIndicator", "lot_detail"})
     */
    private $rateIndicator;

    /**
     * @var \AnalyticsBundle\Entity\Lot
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\Lot", inversedBy="criteria")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     */
    private $lot;

    /**
     * @var \AnalyticsBundle\Entity\LotRateIndicatorValue[]
     *
     * @ORM\OneToMany(targetEntity="AnalyticsBundle\Entity\LotRateIndicatorValue", mappedBy="lotRateIndicator", cascade={"persist", "remove"})
     * @JMS\Groups({"lot_detail"})
     */
    private $value;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->value = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     * @return RateIndicator
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * Set rateIndicator
     *
     * @param \AnalyticsBundle\Entity\RateIndicator $rateIndicator
     * @return RateIndicator
     */
    public function setRateIndicator(\AnalyticsBundle\Entity\RateIndicator $rateIndicator = null)
    {
        $this->rateIndicator = $rateIndicator;

        return $this;
    }

    /**
     * Get rateIndicator
     *
     * @return \AnalyticsBundle\Entity\RateIndicator 
     */
    public function getRateIndicator()
    {
        return $this->rateIndicator;
    }

    /**
     * Add value
     *
     * @param \AnalyticsBundle\Entity\LotRateIndicatorValue $value
     * @return RateIndicator
     */
    public function addValue(\AnalyticsBundle\Entity\LotRateIndicatorValue $value)
    {
        if (!$this->value->contains($value)) {
            $value->setLotRateIndicator($this);

            $this->value->add($value);
        }

        return $this;
    }

    /**
     * Remove value
     *
     * @param \AnalyticsBundle\Entity\LotRateIndicatorValue $value
     */
    public function removeValue(\AnalyticsBundle\Entity\LotRateIndicatorValue $value)
    {
        $this->value->removeElement($value);
    }

    /**
     * Get value
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set weight
     *
     * @param float $weight
     * @return RateIndicator
     */
    public function setWeight($weight)
    {
        $this->weight = $weight;

        return $this;
    }

    /**
     * Get weight
     *
     * @return float 
     */
    public function getWeight()
    {
        return $this->weight;
    }
}
