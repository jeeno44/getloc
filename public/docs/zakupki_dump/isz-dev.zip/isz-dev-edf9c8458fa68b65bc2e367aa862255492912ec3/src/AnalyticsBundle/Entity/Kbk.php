<?php

namespace AnalyticsBundle\Entity;

use AnalyticsBundle\Entity\Views\BaseImplementation;
use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Kbk
 *
 * @ORM\Table(
 *   name="kbk",
 *   indexes={
 *     @ORM\Index(name="kbk_fcp", columns={"kbk_section_id", "gov_program_id", "fcp_id", "fcp_action_id", "kbk_flow_direction_id"}),
 *     @ORM\Index(name="kbk_subprogram", columns={"kbk_section_id", "gov_program_id", "sub_program_action_id", "kbk_flow_direction_id"}),
 *   },
 *   uniqueConstraints={
 *     @ORM\UniqueConstraint(name="kbk_unique", columns={"kbk_section_id", "gov_program_id", "fcp_id", "fcp_action_id", "sub_program_action_id", "kbk_flow_direction_id"}),
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\KbkRepository")
 * @Json\Schema("Kbk")
 */
class Kbk implements IEntity
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"kbk"})
     */
    private $id;

    /**
     * @var \AnalyticsBundle\Entity\KbkSection
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\KbkSection")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_section_id", referencedColumnName="id", nullable=false)
     * })
     * @JMS\Groups({"kbk"})
     */
    private $kbkSection;

    /**
     * @var Fcp
     *
     * @ORM\ManyToOne(targetEntity="GovProgram")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="gov_program_id", referencedColumnName="id", nullable=true)
     * })
     * @JMS\Groups({"kbk"})
     */
    private $govProgram;

    /**
     * @var Fcp
     *
     * @ORM\ManyToOne(targetEntity="Fcp")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_id", referencedColumnName="id", nullable=true)
     * })
     * @JMS\Groups({"kbk"})
     */
    private $fcp;

    /**
     * @var FcpAction
     *
     * @ORM\ManyToOne(targetEntity="FcpAction")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_action_id", referencedColumnName="id", nullable=true)
     * })
     * @JMS\Groups({"kbk"})
     */
    private $fcpAction;

    /**
     * @var SubProgramAction
     *
     * @ORM\ManyToOne(targetEntity="SubProgramAction")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="sub_program_action_id", referencedColumnName="id", nullable=true)
     * })
     * @JMS\Groups({"kbk"})
     */
    private $subProgramAction;

    /**
     * @var SubProgramAction
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\KbkFlowDirection")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_flow_direction_id", referencedColumnName="id", nullable=true)
     * })
     * @JMS\Groups({"kbk"})
     */
    private $kbkFlowDirection;

    /**
     * @var SubProgramAction
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\KbkExpenseType")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_expense_type_id", referencedColumnName="id", nullable=true)
     * })
     * @JMS\Groups({"kbk"})
     */
    private $kbkExpenseType;


    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set kbkSection
     *
     * @param \AnalyticsBundle\Entity\KbkSection $kbkSection
     *
     * @return Kbk
     */
    public function setKbkSection(\AnalyticsBundle\Entity\KbkSection $kbkSection)
    {
        $this->kbkSection = $kbkSection;

        return $this;
    }

    /**
     * Get kbkSection
     *
     * @return \AnalyticsBundle\Entity\KbkSection 
     */
    public function getKbkSection()
    {
        return $this->kbkSection;
    }

    /**
     * Set fcp
     *
     * @param \AnalyticsBundle\Entity\Fcp $fcp
     *
     * @return Kbk
     */
    public function setFcp(\AnalyticsBundle\Entity\Fcp $fcp = null)
    {
        $this->fcp = $fcp;

        return $this;
    }

    /**
     * Get fcp
     *
     * @return \AnalyticsBundle\Entity\Fcp 
     */
    public function getFcp()
    {
        return $this->fcp;
    }

    /**
     * Set fcpAction
     *
     * @param \AnalyticsBundle\Entity\FcpAction $fcpAction
     *
     * @return Kbk
     */
    public function setFcpAction(\AnalyticsBundle\Entity\FcpAction $fcpAction = null)
    {
        $this->fcpAction = $fcpAction;

        return $this;
    }

    /**
     * Get fcpAction
     *
     * @return \AnalyticsBundle\Entity\FcpAction 
     */
    public function getFcpAction()
    {
        return $this->fcpAction;
    }

    /**
     * Set subProgramAction
     *
     * @param \AnalyticsBundle\Entity\SubProgramAction $subProgramAction
     *
     * @return Kbk
     */
    public function setSubProgramAction(\AnalyticsBundle\Entity\SubProgramAction $subProgramAction = null)
    {
        $this->subProgramAction = $subProgramAction;

        return $this;
    }

    /**
     * Get subProgramAction
     *
     * @return \AnalyticsBundle\Entity\SubProgramAction 
     */
    public function getSubProgramAction()
    {
        return $this->subProgramAction;
    }

    /**
     * Set govProgram
     *
     * @param \AnalyticsBundle\Entity\govProgram $govProgram
     *
     * @return Kbk
     */
    public function setGovProgram(\AnalyticsBundle\Entity\govProgram $govProgram = null)
    {
        $this->govProgram = $govProgram;

        return $this;
    }

    /**
     * Get govProgram
     *
     * @return \AnalyticsBundle\Entity\govProgram 
     */
    public function getGovProgram()
    {
        return $this->govProgram;
    }

    /**
     * Set kbkFlowDirection
     *
     * @param \AnalyticsBundle\Entity\KbkFlowDirection $kbkFlowDirection
     *
     * @return Kbk
     */
    public function setKbkFlowDirection(\AnalyticsBundle\Entity\KbkFlowDirection $kbkFlowDirection = null)
    {
        $this->kbkFlowDirection = $kbkFlowDirection;

        return $this;
    }

    /**
     * Get kbkFlowDirection
     *
     * @return \AnalyticsBundle\Entity\KbkFlowDirection
     */
    public function getKbkFlowDirection()
    {
        return $this->kbkFlowDirection;
    }

    /**
     * Set kbkExpenseType
     *
     * @param \AnalyticsBundle\Entity\KbkExpenseType $kbkExpenseType
     *
     * @return Kbk
     */
    public function setKbkExpenseType(\AnalyticsBundle\Entity\KbkExpenseType $kbkExpenseType = null)
    {
        $this->kbkExpenseType = $kbkExpenseType;

        return $this;
    }

    /**
     * Get kbkExpenseType
     *
     * @return \AnalyticsBundle\Entity\KbkExpenseType 
     */
    public function getKbkExpenseType()
    {
        return $this->kbkExpenseType;
    }
}
