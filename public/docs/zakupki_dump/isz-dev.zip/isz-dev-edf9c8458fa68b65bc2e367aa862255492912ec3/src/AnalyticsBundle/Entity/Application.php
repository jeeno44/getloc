<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * Application
 *
 * @ORM\Table(
 *   name="application",
 *   indexes={
 *     @ORM\Index(name="application_protocol2_id", columns={"protocol2_id"}),
 *     @ORM\Index(name="application_protocol1_id", columns={"protocol1_id"}),
 *     @ORM\Index(name="application_commission_id", columns={"commission_id"}),
 *     @ORM\Index(name="application_supplier_id", columns={"supplier_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\ApplicationRepository")
 * @Json\Schema("Application")
 */
class Application implements IEntity
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="reg_number", type="text", nullable=true)
     */
    private $regNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     */
    private $title;

    /**
     * @var float
     *
     * @ORM\Column(name="total_financing", type="float", precision=10, scale=0, nullable=true)
     */
    private $totalFinancing;

    /**
     * @var string
     *
     * @ORM\Column(name="proposed_char", type="text", nullable=true)
     */
    private $proposedChar;

    /**
     * @var string
     *
     * @ORM\Column(name="supplier_qualification", type="text", nullable=true)
     */
    private $supplierQualification;

    /**
     * @var Protocol1
     *
     * @ORM\ManyToOne(targetEntity="Protocol1")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="protocol1_id", referencedColumnName="id")
     * })
     */
    private $protocol1;

    /**
     * @var Protocol2
     *
     * @ORM\ManyToOne(targetEntity="Protocol2")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="protocol2_id", referencedColumnName="id")
     * })
     */
    private $protocol2;

    /**
     * @var Commission
     *
     * @ORM\ManyToOne(targetEntity="Commission")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="commission_id", referencedColumnName="id")
     * })
     */
    private $commission;

    /**
     * @var Supplier
     *
     * @ORM\ManyToOne(targetEntity="Supplier")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="supplier_id", referencedColumnName="id")
     * })
     */
    private $supplier;



    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set regNumber
     *
     * @param string $regNumber
     * @return Application
     */
    public function setRegNumber($regNumber)
    {
        $this->regNumber = $regNumber;

        return $this;
    }

    /**
     * Get regNumber
     *
     * @return string 
     */
    public function getRegNumber()
    {
        return $this->regNumber;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Application
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set totalFinancing
     *
     * @param float $totalFinancing
     * @return Application
     */
    public function setTotalFinancing($totalFinancing)
    {
        $this->totalFinancing = $totalFinancing;

        return $this;
    }

    /**
     * Get totalFinancing
     *
     * @return float
     */
    public function getTotalFinancing()
    {
        return $this->totalFinancing;
    }

    /**
     * Set proposedChar
     *
     * @param string $proposedChar
     * @return Application
     */
    public function setProposedChar($proposedChar)
    {
        $this->proposedChar = $proposedChar;

        return $this;
    }

    /**
     * Get proposedChar
     *
     * @return string
     */
    public function getProposedChar()
    {
        return $this->proposedChar;
    }

    /**
     * Set supplierQualification
     *
     * @param string $supplierQualification
     * @return Application
     */
    public function setSupplierQualification($supplierQualification)
    {
        $this->supplierQualification = $supplierQualification;

        return $this;
    }

    /**
     * Get supplierQualification
     *
     * @return string
     */
    public function getSupplierQualification()
    {
        return $this->supplierQualification;
    }

    /**
     * Set protocol1
     *
     * @param \AnalyticsBundle\Entity\Protocol1 $protocol1
     * @return Application
     */
    public function setProtocol1(\AnalyticsBundle\Entity\Protocol1 $protocol1 = null)
    {
        $this->protocol1 = $protocol1;

        return $this;
    }

    /**
     * Get protocol1
     *
     * @return \AnalyticsBundle\Entity\Protocol1
     */
    public function getProtocol1()
    {
        return $this->protocol1;
    }

    /**
     * Set protocol2
     *
     * @param \AnalyticsBundle\Entity\Protocol2 $protocol2
     * @return Application
     */
    public function setProtocol2(\AnalyticsBundle\Entity\Protocol2 $protocol2 = null)
    {
        $this->protocol2 = $protocol2;

        return $this;
    }

    /**
     * Get protocol2
     *
     * @return \AnalyticsBundle\Entity\Protocol2
     */
    public function getProtocol2()
    {
        return $this->protocol2;
    }

    /**
     * Set commission
     *
     * @param \AnalyticsBundle\Entity\Commission $commission
     * @return Application
     */
    public function setCommission(\AnalyticsBundle\Entity\Commission $commission = null)
    {
        $this->commission = $commission;

        return $this;
    }

    /**
     * Get commission
     *
     * @return \AnalyticsBundle\Entity\Commission
     */
    public function getCommission()
    {
        return $this->commission;
    }

    /**
     * Set supplier
     *
     * @param \AnalyticsBundle\Entity\Supplier $supplier
     * @return Application
     */
    public function setSupplier(\AnalyticsBundle\Entity\Supplier $supplier = null)
    {
        $this->supplier = $supplier;

        return $this;
    }

    /**
     * Get supplier
     *
     * @return \AnalyticsBundle\Entity\Supplier
     */
    public function getSupplier()
    {
        return $this->supplier;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
