<?php

namespace AnalyticsBundle\Entity;

use Doctrine\Common\Collections\Criteria;
use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;
use Symfony\Component\Validator\Constraints as Assert;

define('PLAN_YEAR_CURRENT', date('Y'));
define('PLAN_YEAR_NEXT', PLAN_YEAR_CURRENT + 1);

/**
 * Plan
 *
 * @ORM\Table(
 *   name="plan",
 *   uniqueConstraints={
 *     @ORM\UniqueConstraint(name="common_year", columns={"common_id", "year"}),
 *   },
 *   indexes={
 *     @ORM\Index(name="plan_common_id", columns={"common_id"}),
 *     @ORM\Index(name="plan_parent_id", columns={"parent_id"}),
 *     @ORM\Index(name="plan_status_id", columns={"status_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\PlanRepository")
 * @Json\Schema("Plan")
 */
class Plan extends Revision
{
    const STATUS_DRAFT    = 'draft';
    const STATUS_REWORK   = 'rework';
    const STATUS_APPROVED = 'approved';
    const STATUS_PLANING  = 'planning';
    const STATUS_PLANNED  = 'planned';

    const TYPE_CURRENT = 'current';
    const TYPE_NEXT    = 'next';
    const TYPE_ARCHIVE = 'archive';

    const YEAR_CURRENT = PLAN_YEAR_CURRENT;
    const YEAR_NEXT    = PLAN_YEAR_NEXT;

    /**
     * @JMS\Groups({"all_all"})
     */
    static $year_list = [
        self::TYPE_CURRENT => self::YEAR_CURRENT,
        self::TYPE_NEXT    => self::YEAR_NEXT,
    ];

    /**
     * @JMS\Groups({"all_all"})
     */
    static $type_year_list = [
        self::YEAR_CURRENT => self::TYPE_CURRENT,
        self::YEAR_NEXT    => self::TYPE_NEXT,
    ];

    /**
     * @JMS\Groups({"all_all"})
     */
    static $types = [
        self::TYPE_CURRENT => 'Текущий',
        self::TYPE_NEXT    => 'Следующий',
        self::TYPE_ARCHIVE => 'Архивный',
    ];

    /**
     * Полный список статусов системы
     *
     * @var array
     *
     * @Json\Ignore()
     */
    static public $listStatus = [
        self::STATUS_DRAFT    => 'Формируется',
        self::STATUS_REWORK   => 'На доработке',
        self::STATUS_APPROVED => 'Согласован',
        self::STATUS_PLANING  => 'Планируется',
        self::STATUS_PLANNED  => 'Запланирован',
    ];

    /**
     * Получаем тип плана
     *
     * @JMS\VirtualProperty
     * @JMS\SerializedName("type")
     * @JMS\Groups({"plan_detail"})
     * @return string
     */
    public function getType()
    {
        $type = Plan::TYPE_ARCHIVE;
        if ($this->getYear() == date("Y")) {
            $type = Plan::TYPE_CURRENT;
        } elseif ($this->getYear() > date("Y")) {
            $type = Plan::TYPE_NEXT;
        }

        return $type . "_" . $this->getCommon()->getType();
    }

    /**
     * @JMS\Groups({"plan_list", "plan_detail", "lot_detail", "lot_list", "plan_common"})
     */
    public $financing;

    /**
     * @JMS\Groups({"plan_list", "plan_detail", "lot_detail", "lot_list", "plan_common"})
     */
    public $financing1;

    /**
     * @JMS\Groups({"plan_list", "plan_detail", "lot_detail", "lot_list", "plan_common"})
     */
    public $financing2;

    /**
     * @var FinancingPlan
     *
     * @ORM\OneToMany(targetEntity="FinancingPlan", mappedBy="plan", cascade={"remove"})
     * @ORM\OrderBy({"year"="ASC"})
     * @JMS\Groups({"lot", "plan_detail", "lot_detail", "lot_item_plans", "lot_list", "lot_detail", "plan_common_lots", "plan_current", "plan_next", "lots_consolidated",
     *      "lot_item_plans"})
     */
    private $financingsPlan;

    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false, options={"comment":"Уникальный идентификатор"})
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"plan", "lot_detail", "lot_list", "plan_common", "expert_group_list", "expert_group_detail", "common_detail",
     *     "plan_consolidated"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="status_id", type="string", length=32, nullable=false, options={"comment":"Статус"})
     * @JMS\Groups({"plan", "lot_list", "plan_common", "expert_group_list", "expert_group_detail", "plan_consolidated"})
     */
    private $statusId;

    /**
     * @var string
     *
     * @ORM\Column(name="comment", type="text", nullable=true, options={"comment":"Комментарий к плану"})
     * @JMS\Groups({"plan_list", "plan_detail", "Plan_zakupki", "common_detail"})
     */
    private $comment;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="comment_date", type="date", nullable=true, options={"comment":"Дата комментария"})
     * @JMS\Groups({"plan_list", "plan_detail", "plan_common"})
     */
    private $commentDate;

    /**
     * @var LotDoc
     * состояние плана: текущий/проектируемый
     *
     * @ORM\OneToMany(targetEntity="PlanDoc", mappedBy="plan")
     * @JMS\Groups({"plan_list", "plan_detail", "lot_detail", "lot_list", "plan_common", "plan_current", "plan_next", "Plan_zakupki", "common_detail"})
     */
    private $planDocs;

    /**
     * @var \DateTime
     * год в плане
     *
     * @ORM\Column(name="year", type="integer", nullable=false)
     * @JMS\Groups({"plan", "lot_list", "plan_common", "lot_detail", "expert_group_list", "expert_group_detail", "common_detail"})
     */
    private $year;

    /**
     * @var Common
     * Департамент
     *
     * @ORM\ManyToOne(targetEntity="Common", inversedBy="plans", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="common_id", referencedColumnName="id", nullable=false)
     * })
     * @JMS\Groups({"plan_detail", "plan_current", "plan_next", "plan_common"})
     */
    private $common;

    /**
     * @var  \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Lot", inversedBy="plan", cascade={"persist", "remove", "refresh"})
     * @ORM\JoinTable(name="lot_plan",
     *   joinColumns={
     *     @ORM\JoinColumn(name="plan_id", referencedColumnName="id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     *   }
     * )
     *
     */
    private $lots;


    /**
     * Получаем список прикрепленных лотов
     *
     * @JMS\VirtualProperty
     * @JMS\SerializedName("lots")
     * @JMS\Groups({"plan_detail"})
     * @return string
     */
    public function getLotsMini()
    {
        $lots = [];
        $items = $this->getLots();
        foreach ($items as $item) {
            if (!$item->getIsRevision()) {
                $lots[$item->getId()] = [
                    'id' => $item->getId(),
                ];
            }
        }
        return array_values($lots);
    }

//    /**
//     * @var \Doctrine\Common\Collections\Collection
//     *
//     * @ORM\ManyToMany(targetEntity="Lot", inversedBy="plan")
//     * @ORM\JoinTable(name="lot_plan_consolidated",
//     *   joinColumns={
//     *     @ORM\JoinColumn(name="plan_id", referencedColumnName="id")
//     *   },
//     *   inverseJoinColumns={
//     *     @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
//     *   }
//     * )
//     * @JMS\Groups({"plan_detail"})
//     */
//    private $consolidatedLots;


    /******************************************************************************************************************/
    // Подчиненные планы
    /******************************************************************************************************************/

    /**
     * @var Plan[]
     *
     * @ORM\OneToMany(targetEntity="Plan", mappedBy="parent")
     *
     */
    protected $children;

    /**
     * Получаем список прикрепленных лотов
     *
     * @JMS\VirtualProperty
     * @JMS\SerializedName("childrenMini")
     * @JMS\Groups({"plan_detail"})
     * @return string
     */
    public function getChildrenMini()
    {
        $children = [];
        $items = $this->getChildren();
        foreach ($items as $item) {
            if (!$item->getIsRevision() && $item->getId() != $this->getId()) {

                // убираем из списка ненужный план фоива
                if ($item->getCommon()->getType() == Common::TYPE_FOIV) {
                    continue;
                }

                $children[] = [
                    'id' => $item->getId(),
                ];
            }
        }
        return $children;
    }


    /******************************************************************************************************************/
    // Подительский план
    /******************************************************************************************************************/

    /**
     * @var Plan[]
     *
     * @ORM\ManyToOne(targetEntity="Plan", inversedBy="children")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     * })
     */
    private $parent;

    /******************************************************************************************************************/
    // Ревизии плана
    /******************************************************************************************************************/

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Plan", inversedBy="revision", cascade={"persist"}, fetch="EXTRA_LAZY")
     * @ORM\JoinTable(name="plan_revision",
     *   joinColumns={
     *     @ORM\JoinColumn(name="plan_id", referencedColumnName="id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="revision_id", referencedColumnName="id")
     *   }
     * )
     */
    private $revision;

    /**
     * Получаем список ревизий сущности
     *
     * @JMS\VirtualProperty
     * @JMS\SerializedName("revisions")
     * @JMS\Groups({"plan_detail"})
     * @return string
     */
    public function getRevisionsMini()
    {
        $revisions = [];
        $items = $this->getRevision();
        foreach ($items as $item) {
            $revisions[] = [
                'id' => $item->getId(),
                'created' => $item->getRevisionDate()
            ];
        }
        return $revisions;
    }

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\ManyToMany(targetEntity="Plan", mappedBy="revision", cascade={"persist", "remove", "refresh"})
     *
     * @JMS\Groups({"plan_detail", "plan"})
     */
    private $revisionOrigin;


    /**
     * Add plan
     *
     * @param \AnalyticsBundle\Entity\Plan $plan
     * @return Lot
     */
    public function addRevisionOrigin(\AnalyticsBundle\Entity\Plan $plan)
    {
        $this->revisionOrigin[] = $plan;
        return $this;
    }

    /**
     * Remove plan
     *
     * @param \AnalyticsBundle\Entity\Plan $plan
     */
    public function removeRevisionOrigin(\AnalyticsBundle\Entity\Plan $plan)
    {
        $this->revisionOrigin->removeElement($plan);
    }

    /**
     * Get plan
     *
     * @return \Doctrine\Common\Collections\Collection|Plan[]
     */
    public function getRevisionOrigin()
    {
        return $this->revisionOrigin;
    }


    /**
     * @var \DateTime
     *
     * @ORM\Column(name="revision_date", type="datetime")
     * @JMS\Groups({"plan_detail", "plan_current", "plan_next", "common_detail", "plan"})
     */
    private $revisionDate;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     * @JMS\Groups({"plan_detail", "plan_current", "plan_next", "common_detail", "plan"})
     */
    private $isRevision = false;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_date", type="datetime", nullable=true)
     */
    private $updatedDate;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->lots = new \Doctrine\Common\Collections\ArrayCollection();
        $this->consolidatedLots = new \Doctrine\Common\Collections\ArrayCollection();
        $this->children = new \Doctrine\Common\Collections\ArrayCollection();
        $this->financingsPlan = new \Doctrine\Common\Collections\ArrayCollection();

        /** @var Lot revision
         *  Revisions list
         */
        $this->revision = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add financingsPlan
     *
     * @param \AnalyticsBundle\Entity\FinancingPlan $financingsPlan
     * @return Lot
     */
    public function addFinancingPlan(\AnalyticsBundle\Entity\FinancingPlan $financingsPlan)
    {
        if (!$this->financingsPlan->contains($financingsPlan)) {
            $financingsPlan->setLot($this);
            $this->financingsPlan->add($financingsPlan);
        }

        return $this;
    }

    /**
     * @param Financing $financingsPlan
     * @return $this
     */
    public function removeFinancingPlan(\AnalyticsBundle\Entity\Financing $financingsPlan)
    {
        $this->financingsPlan->removeElement($financingsPlan);

        return $this;
    }

    /**
     * Get FinancingPlan
     *
     * @return Financing[]|\Doctrine\Common\Collections\Collection
     */
    public function getFinancingsPlan()
    {
        return $this->financingsPlan;
    }

    /**
     * Set updatedDate
     *
     * @param \DateTime $updatedDate
     * @return Lot
     */
    public function setUpdatedDate($updatedDate)
    {
        $this->updatedDate = $updatedDate;

        return $this;
    }

    /**
     * Get updatedDate
     *
     * @return \DateTime
     */
    public function getUpdatedDate()
    {
        return $this->updatedDate;
    }


    /**
     * Clone implementetion
     */
    public function __clone() {
        $this->id = null;
        unset($this->_entityPersister, $this->_identifier);
    }

    /**
     * @param $revisionDate
     * @return $this
     */
    public function setRevisionDate($revisionDate)
    {
        $this->revisionDate = $revisionDate;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getRevisionDate()
    {
        return $this->revisionDate;
    }

    /**
     * Add revision
     *
     * @param \AnalyticsBundle\Entity\Plan $plan
     * @return Plan
     */
    public function addRevision(\AnalyticsBundle\Entity\Plan $plan)
    {
        $this->revision[] = $plan;

        return $this;
    }

    /**
     * Remove Revision
     *
     * @param \AnalyticsBundle\Entity\Plan $plan
     */
    public function removeRevision(\AnalyticsBundle\Entity\Plan $plan)
    {
        $this->revision->removeElement($plan);
    }

    /**
     * Get Revisions
     *
     * @return \Doctrine\Common\Collections\Collection|Plan[]
     */
    public function getRevision()
    {
        return $this->revision;
    }

    /**
     * @param null $plans
     * @return $this
     */
    public function setRevision($plans = null)
    {
        $this->revision = $plans;
        return $this;
    }



    /**
     * Set $isRevision
     *
     * @param string $isRevision
     * @return Lot
     */
    public function setIsRevision($isRevision)
    {
        $this->isRevision = $isRevision;

        return $this;
    }

    /**
     * Get $isRevision
     *
     * @return string
     */
    public function getIsRevision()
    {
        return $this->isRevision;
    }

    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set statusId
     *
     * @param string $statusId
     * @return Plan
     */
    public function setStatusId($statusId)
    {
        $this->statusId = $statusId;

        return $this;
    }

    /**
     * Get statusId
     *
     * @return string
     */
    public function getStatusId()
    {
        return $this->statusId;
    }

    /**
     * Set comment
     *
     * @param string $comment
     * @return Plan
     */
    public function setComment($comment)
    {
        $this->comment = $comment;

        return $this;
    }

    /**
     * Get comment
     *
     * @return string
     */
    public function getComment()
    {
        return $this->comment;
    }

    /**
     * Set commentDate
     *
     * @param \DateTime $commentDate
     * @return Plan
     */
    public function setCommentDate($commentDate)
    {
        $this->commentDate = $commentDate;

        return $this;
    }

    /**
     * Get commentDate
     *
     * @return \DateTime
     */
    public function getCommentDate()
    {
        return $this->commentDate;
    }

    /**
     * Set year
     *
     * @param integer $year
     * @return Plan
     */
    public function setYear($year)
    {
        $this->year = $year;

        return $this;
    }

    /**
     * Get year
     *
     * @return integer
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * Set lotDoc
     *
     * @param \AnalyticsBundle\Entity\PlanDoc $planDoc
     * @return Plan
     */
    public function setPlanDocs(\AnalyticsBundle\Entity\PlanDoc $planDoc = null)
    {
        $this->planDocs[] = $planDoc;

        return $this;
    }

    public function addPlanDoc(\AnalyticsBundle\Entity\PlanDoc $planDoc = null)
    {
        $this->planDocs[] = $planDoc;

        return $this;
    }

    /**
     * Get lotDoc
     *
     * @return \AnalyticsBundle\Entity\PlanDoc
     */
    public function getPlanDocs()
    {
        return $this->planDocs;
    }

    /**
     * @return Plan[]
     */
    public function getParent() {
        return $this->parent;
    }

    /**
     * @return Plan[]|\Doctrine\Common\Collections\ArrayCollection
     */
    public function getChildren() {
        return $this->children;
    }

    /**
     * @param Plan $child
     */
    public function addChild(Plan $child) {
        $this->children[] = $child;
        $child->setParent($this);
    }

    /**
     * @param Plan $parent
     */
    public function setParent(Plan $parent) {
        $this->parent = $parent;
    }

    /**
     * Set common
     *
     * @param \AnalyticsBundle\Entity\Common $common
     * @return Plan
     */
    public function setCommon(\AnalyticsBundle\Entity\Common $common = null)
    {
        $this->common = $common;

        return $this;
    }

    /**
     * Get common
     *
     * @return \AnalyticsBundle\Entity\Common
     */
    public function getCommon()
    {
        return $this->common;
    }

    /**
     * Add lots
     *
     * @param \AnalyticsBundle\Entity\Lot $lots
     * @return Plan
     */
    public function addLot(\AnalyticsBundle\Entity\Lot $lots)
    {
        if (!$this->getLots()->contains($lots)) {
            $lots->addPlan($this);
            $this->lots->add($lots);
        }

        //$this->lots[] = $lots;

        return $this;
    }

    /**
     * Remove lots
     *
     * @param \AnalyticsBundle\Entity\Lot $lots
     */
    public function removeLot(\AnalyticsBundle\Entity\Lot $lots)
    {
        $this->lots->removeElement($lots);
    }

    /**
     * Get lots
     *
     * @return \Doctrine\Common\Collections\Collection|Lot[]
     */
    public function getLots()
    {
        return $this->lots->filter(function($el){
            return $el->getIsRevision() != true;
        });
    }

    /**
     * Get consolidatedLots
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getConsolidatedLots()
    {
        return $this->consolidatedLots;
    }

//    use \AnalyticsBundle\Versionable\Versionable;

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getCommon()->getFullName() . ' - ' . $this->getYear();
    }
}