<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * FinancingPlan
 *
 * @ORM\Table(name="financing_plan")
 * @ORM\Entity()
 * @Json\Schema("FinancingPlan")
 */
class FinancingPlan implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="year", type="smallint", nullable=true)
     * @JMS\Groups({"plan_detail", "plan_common", "plan_current", "plan_next"})
     */
    private $year;

    /**
     * @var Plan
     *
     * @ORM\ManyToOne(targetEntity="Plan", inversedBy="financingsPlan")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="plan_id", referencedColumnName="id")
     * })
     */
    private $plan;

    /**
     * @var Lot
     *
     * @ORM\ManyToOne(targetEntity="Lot", inversedBy="financingsPlan")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     * 
     */
    private $lot;


    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set year
     *
     * @param int $year
     *
     * @return FinancingPlan
     */
    public function setYear($year)
    {
        $this->year = $year;

        return $this;
    }

    /**
     * Get year
     *
     * @return int
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * Set plan
     *
     * @param \AnalyticsBundle\Entity\Plan $plan
     *
     * @return FinancingPlan
     */
    public function setPlan(\AnalyticsBundle\Entity\Plan $plan = null)
    {
        $this->plan = $plan;

        return $this;
    }

    /**
     * Get plan
     *
     * @return \AnalyticsBundle\Entity\Plan
     */
    public function getPlan()
    {
        return $this->plan;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     *
     * @return FinancingPlan
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }
}
