<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * FactCommission
 *
 * @ORM\Table(name="fact_commission", uniqueConstraints={@ORM\UniqueConstraint(name="user_commission", columns={"commission_id"})}, indexes={@ORM\Index(name="fact_commission_lot_id", columns={"lot_id"})})
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\FactCommissionRepository")
 * @Json\Schema("FactCommission")
 */
class FactCommission implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var \Lot
     *
     * @ORM\ManyToOne(targetEntity="Lot")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     */
    private $lot;

    /**
     * @var \Commission
     *
     * @ORM\ManyToOne(targetEntity="Commission")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="commission_id", referencedColumnName="id")
     * })
     */
    private $commission;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     * @return FactCommission
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * Set commission
     *
     * @param \AnalyticsBundle\Entity\Commission $commission
     * @return FactCommission
     */
    public function setCommission(\AnalyticsBundle\Entity\Commission $commission = null)
    {
        $this->commission = $commission;

        return $this;
    }

    /**
     * Get commission
     *
     * @return \AnalyticsBundle\Entity\Commission
     */
    public function getCommission()
    {
        return $this->commission;
    }
}
