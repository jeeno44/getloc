<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use AnalyticsBundle\Entity\IEntity;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * CriteriaIndicator
 *
 * @ORM\Table(
 *     name="criteria_indicator",
 *     indexes={@ORM\Index(name="criteria_indicator_criteria_rating_id", columns={"criteria_rating_id"})}
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\CriteriaIndicatorRepository")
 * @Json\Schema("CriteriaIndicator")
 */
class CriteriaIndicator implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="SEQUENCE")
     * @ORM\SequenceGenerator(sequenceName="criteria_indicator_id_seq", allocationSize=1, initialValue=1)
     * @JMS\Groups({"CriteriaIndicator"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"CriteriaIndicator"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="content", type="text", nullable=true)
     * @JMS\Groups({"CriteriaIndicator"})
     */
    private $content;

    /**
     * @var \CriteriaRating
     *
     * @ORM\ManyToOne(targetEntity="CriteriaRating")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="criteria_rating_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"CriteriaIndicator"})
     * @Json\Ignore
     */
    private $criteriaRating;

    use \AnalyticsBundle\Versionable\VersionableTrait;

    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return CriteriaIndicator
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set content
     *
     * @param string $content
     *
     * @return CriteriaIndicator
     */
    public function setContent($content)
    {
        $this->content = $content;

        return $this;
    }

    /**
     * Get content
     *
     * @return string
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Set criteriaRating
     *
     * @param \AnalyticsBundle\Entity\CriteriaRating $criteriaRating
     *
     * @return CriteriaIndicator
     */
    public function setCriteriaRating(\AnalyticsBundle\Entity\CriteriaRating $criteriaRating = null)
    {
        $this->criteriaRating = $criteriaRating;

        return $this;
    }

    /**
     * Get criteriaRating
     *
     * @return \AnalyticsBundle\Entity\CriteriaRating
     */
    public function getCriteriaRating()
    {
        return $this->criteriaRating;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }
}
