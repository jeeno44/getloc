<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;
use Symfony\Component\Validator\Constraints as Assert;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Stage
 *
 * @ORM\Table(
 *   name="stage",
 *   indexes={
 *     @ORM\Index(name="stage_lot_id", columns={"lot_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\StageRepository")
 * @Json\Schema("Stage")
 */
class Stage implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="number", type="integer", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $number;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="reporting_docs_requirement", type="text", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $reportingDocsRequirement;

    /**
     * @var string
     *
     * @ORM\Column(name="place", type="text", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $place;

    /**
     * @var string
     *
     * @ORM\Column(name="place_kladr_id", type="text", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $placeKladrId;

    /**
     * @var float
     *
     * @ORM\Column(name="financing", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $financing;

    /**
     * @var string
     *
     * @ORM\Column(name="reporting_docs_date", type="text", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $reportingDocsDate;

    /**
     * @var string
     *
     * @ORM\Column(name="stage_results", type="text", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $stageResults;

    /**
     * @var boolean
     *
     * @ORM\Column(name="start_year", type="integer", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $startYear;

    /**
     * @var boolean
     *
     * @ORM\Column(name="starting_date", type="integer", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $startingDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="start_date", type="date", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $startDate;

    /**
     * @var boolean
     *
     * @ORM\Column(name="execution_type", type="integer", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $executionType;

    /**
     * @var boolean
     *
     * @ORM\Column(name="execution_date_term", type="boolean", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "notice_ea", "common_detail"})
     */
    private $executionDateTerm;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="execution_date", type="date", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "notice_ea", "common_detail"})
     */
    private $executionDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="execution_term", type="smallint", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "notice_ea", "common_detail"})
     */
    private $executionTerm;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="acceptance_date", type="date", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $acceptanceDate;

    /**
     * @var string
     *
     * @ORM\Column(name="nmck_justification", type="text", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail"})
     */
    private $nmckJustification;

    /**
     * @var Lot
     *
     * @ORM\ManyToOne(targetEntity="Lot", inversedBy="stages",  cascade={"persist", "remove"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"exclude"})
     */
    private $lot;

    /**
     * @var Stage
     *
     * @ORM\OneToMany(targetEntity="WorkType", mappedBy="stage", cascade={"persist", "remove"})
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "notice_ea", "common_detail"})
     * @ORM\OrderBy({"versionStartAt"="ASC"})
     */
    private $workTypes;

    /**
     * @var \DateTime
     *
     * @Assert\Type("\DateTime")
     * @ORM\Column(name="act_date", type="date", nullable=true)
     * @JMS\Groups({"stage", "stage_detail", "lot_detail", "lots_consolidated", "common_detail", "lot_list"})
     */
    private $actDate;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->workTypes = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Stage
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set reportingDocsRequirement
     *
     * @param string $reportingDocsRequirement
     * @return Stage
     */
    public function setReportingDocsRequirement($reportingDocsRequirement)
    {
        $this->reportingDocsRequirement = $reportingDocsRequirement;

        return $this;
    }

    /**
     * Get reportingDocsRequirement
     *
     * @return string 
     */
    public function getReportingDocsRequirement()
    {
        return $this->reportingDocsRequirement;
    }

    /**
     * Set place
     *
     * @param string $place
     * @return Stage
     */
    public function setPlace($place)
    {
        $this->place = $place;

        return $this;
    }

    /**
     * Get place
     *
     * @return string
     */
    public function getPlace()
    {
        return $this->place;
    }

    /**
     * Set financing
     *
     * @param float $financing
     * @return Stage
     */
    public function setFinancing($financing)
    {
        $this->financing = $financing;

        return $this;
    }

    /**
     * Get financing
     *
     * @return float
     */
    public function getFinancing()
    {
        return $this->financing;
    }

    /**
     * Set reportingDocsDate
     *
     * @param string $reportingDocsDate
     * @return Stage
     */
    public function setReportingDocsDate($reportingDocsDate)
    {
        $this->reportingDocsDate = $reportingDocsDate;

        return $this;
    }

    /**
     * Get reportingDocsDate
     *
     * @return string
     */
    public function getReportingDocsDate()
    {
        return $this->reportingDocsDate;
    }

    /**
     * Set stageResults
     *
     * @param string $stageResults
     * @return Stage
     */
    public function setStageResults($stageResults)
    {
        $this->stageResults = $stageResults;

        return $this;
    }

    /**
     * Get stageResults
     *
     * @return string
     */
    public function getStageResults()
    {
        return $this->stageResults;
    }

    /**
     * Set startYear
     *
     * @param boolean $startYear
     * @return Stage
     */
    public function setStartYear($startYear)
    {
        $this->startYear = $startYear;

        return $this;
    }

    /**
     * Get startYear
     *
     * @return boolean
     */
    public function getStartYear()
    {
        return $this->startYear;
    }

    /**
     * Set startingDate
     *
     * @param boolean $startingDate
     * @return Stage
     */
    public function setStartingDate($startingDate)
    {
        $this->startingDate = $startingDate;

        return $this;
    }

    /**
     * Get startingDate
     *
     * @return boolean
     */
    public function getStartingDate()
    {
        return $this->startingDate;
    }

    /**
     * Set startDate
     *
     * @param \DateTime $startDate
     * @return Stage
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;

        return $this;
    }

    /**
     * Get startDate
     *
     * @return \DateTime
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Set executionDateTerm
     *
     * @param boolean $executionDateTerm
     * @return Stage
     */
    public function setExecutionDateTerm($executionDateTerm)
    {
        $this->executionDateTerm = $executionDateTerm;

        return $this;
    }

    /**
     * Get executionDateTerm
     *
     * @return boolean
     */
    public function getExecutionDateTerm()
    {
        return $this->executionDateTerm;
    }

    /**
     * Set executionDate
     *
     * @param \DateTime $executionDate
     * @return Stage
     */
    public function setExecutionDate($executionDate)
    {
        $this->executionDate = $executionDate;

        return $this;
    }

    /**
     * Get executionDate
     *
     * @return \DateTime
     */
    public function getExecutionDate()
    {
        return $this->executionDate;
    }

    /**
     * Set executionTerm
     *
     * @param integer $executionTerm
     * @return Stage
     */
    public function setExecutionTerm($executionTerm)
    {
        $this->executionTerm = $executionTerm;

        return $this;
    }

    /**
     * Get executionTerm
     *
     * @return integer
     */
    public function getExecutionTerm()
    {
        return $this->executionTerm;
    }

    /**
     * Set acceptanceDate
     *
     * @param \DateTime $acceptanceDate
     * @return Stage
     */
    public function setAcceptanceDate($acceptanceDate)
    {
        $this->acceptanceDate = $acceptanceDate;

        return $this;
    }

    /**
     * Get acceptanceDate
     *
     * @return \DateTime
     */
    public function getAcceptanceDate()
    {
        return $this->acceptanceDate;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     * @return Stage
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * Add workTypes
     *
     * @param \AnalyticsBundle\Entity\WorkType $workTypes
     * @return Stage
     */
    public function addWorkType(\AnalyticsBundle\Entity\WorkType $workTypes)
    {
        if (!$this->workTypes->contains($workTypes)) {
            $workTypes->setStage($this);
            $this->workTypes->add($workTypes);
        }

        return $this;
    }

    /**
     * Remove workTypes
     *
     * @param \AnalyticsBundle\Entity\WorkType $workTypes
     */
    public function removeWorkType(\AnalyticsBundle\Entity\WorkType $workTypes)
    {
        $this->workTypes->removeElement($workTypes);
    }

    /**
     * Get workTypes
     *
     * @return \Doctrine\Common\Collections\Collection|WorkType[]
     */
    public function getWorkTypes()
    {
        return $this->workTypes;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getTitle();
    }

    /**
     * @return boolean
     */
    public function isExecutionType()
    {
        return $this->executionType;
    }

    /**
     * @param boolean $executionType
     */
    public function setExecutionType($executionType)
    {
        $this->executionType = $executionType;
    }

    /**
     * @return string
     */
    public function getNumber()
    {
        return $this->number;
    }

    /**
     * @param string $number
     */
    public function setNumber($number)
    {
        $this->number = $number;
    }

    /**
     * @return string
     */
    public function getPlaceKladrId()
    {
        return $this->placeKladrId;
    }

    /**
     * @param string $placeKladrId
     */
    public function setPlaceKladrId($placeKladrId)
    {
        $this->placeKladrId = $placeKladrId;
    }


    /**
     * Set actDate
     *
     * @param \DateTime $actDate
     * @return Stage
     */
    public function setActDate($actDate)
    {
        $this->actDate = $actDate;

        return $this;
    }

    /**
     * Get actDate
     *
     * @return \DateTime
     */
    public function getActDate()
    {
        return $this->actDate;
    }

    /**
     * Set nmckJustification
     *
     * @param string $nmckJustification
     * @return Stage
     */
    public function setNmckJustification($nmckJustification)
    {
        $this->nmckJustification = $nmckJustification;

        return $this;
    }

    /**
     * Get nmckJustification
     *
     * @return string
     */
    public function getNmckJustification()
    {
        return $this->nmckJustification;
    }
}
