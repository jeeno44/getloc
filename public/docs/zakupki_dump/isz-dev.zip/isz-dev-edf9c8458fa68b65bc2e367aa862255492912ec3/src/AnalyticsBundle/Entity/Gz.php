<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Gz
 *
 * @ORM\Table(name="gz")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\GzRepository")
 * @Json\Schema("gz")
 */
class Gz
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="gz_user", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $gzUser;

    /**
     * @var string
     *
     * @ORM\Column(name="gz_phone_nuber_resp", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $gzPhoneNuberResp;

    /**
     * @var string
     *
     * @ORM\Column(name="gz_mail_resp", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $gzMailResp;

    /**
     * @var string
     *
     * @ORM\Column(name="gz_resp", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $gzResp;

    /**
     * @var string
     *
     * @ORM\Column(name="pass_phone_number", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $passPhoneNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="pass_adress", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $passAdress;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="kd_explanation_data_start", type="datetime", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $kdExplanationDataStart;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="kd_explanation_data_end", type="datetime", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $kdExplanationDataEnd;

    /**
     * @var string
     *
     * @ORM\Column(name="gz_agreement_name", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $gzAgreementName;

    /**
     * @var string
     *
     * @ORM\Column(name="gz_agreement_position", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $gzAgreementPosition;

    /**
     * @var string
     *
     * @ORM\Column(name="gz_agreement_extra_name", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $gzAgreementExtraName;

    /**
     * @var string
     *
     * @ORM\Column(name="gz_agreement_extra_position", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $gzAgreementExtraPosition;

    /**
     * @var string
     *
     * @ORM\Column(name="gz_approv_name", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $gzApprovName;

    /**
     * @var string
     *
     * @ORM\Column(name="gz_approv_position", type="text", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $gzApprovPosition;

    /**
     * @var string
     *
     * @ORM\Column(name="gz_smp_sonk", type="float", nullable=true)
     * @JMS\Groups({"lot", "lot_detail", "lot_detail"})
     */
    private $gzSmpSonk;

    /**
     * @var \AnalyticsBundle\Entity\Lot
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\Lot", inversedBy="gz")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     */
    private $lot;


    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set gzUser
     *
     * @param string $gzUser
     *
     * @return Gz
     */
    public function setGzUser($gzUser)
    {
        $this->gzUser = $gzUser;

        return $this;
    }

    /**
     * Get gzUser
     *
     * @return string
     */
    public function getGzUser()
    {
        return $this->gzUser;
    }

    /**
     * Set gzPhoneNuberResp
     *
     * @param string $gzPhoneNuberResp
     *
     * @return Gz
     */
    public function setGzPhoneNuberResp($gzPhoneNuberResp)
    {
        $this->gzPhoneNuberResp = $gzPhoneNuberResp;

        return $this;
    }

    /**
     * Get gzPhoneNuberResp
     *
     * @return string
     */
    public function getGzPhoneNuberResp()
    {
        return $this->gzPhoneNuberResp;
    }

    /**
     * Set gzMailResp
     *
     * @param string $gzMailResp
     *
     * @return Gz
     */
    public function setGzMailResp($gzMailResp)
    {
        $this->gzMailResp = $gzMailResp;

        return $this;
    }

    /**
     * Get gzMailResp
     *
     * @return string
     */
    public function getGzMailResp()
    {
        return $this->gzMailResp;
    }

    /**
     * Set gzResp
     *
     * @param \DateTime $gzResp
     *
     * @return Gz
     */
    public function setGzResp($gzResp)
    {
        $this->gzResp = $gzResp;

        return $this;
    }

    /**
     * Get gzResp
     *
     * @return \DateTime
     */
    public function getGzResp()
    {
        return $this->gzResp;
    }

    /**
     * Set passPhoneNumber
     *
     * @param \DateTime $passPhoneNumber
     *
     * @return Gz
     */
    public function setPassPhoneNumber($passPhoneNumber)
    {
        $this->passPhoneNumber = $passPhoneNumber;

        return $this;
    }

    /**
     * Get passPhoneNumber
     *
     * @return \DateTime
     */
    public function getPassPhoneNumber()
    {
        return $this->passPhoneNumber;
    }

    /**
     * Set passAdress
     *
     * @param string $passAdress
     *
     * @return Gz
     */
    public function setPassAdress($passAdress)
    {
        $this->passAdress = $passAdress;

        return $this;
    }

    /**
     * Get passAdress
     *
     * @return string
     */
    public function getPassAdress()
    {
        return $this->passAdress;
    }

    /**
     * Set kdExplanationDataStart
     *
     * @param \DateTime $kdExplanationDataStart
     *
     * @return Gz
     */
    public function setKdExplanationDataStart($kdExplanationDataStart)
    {
        $this->kdExplanationDataStart = $kdExplanationDataStart;

        return $this;
    }

    /**
     * Get kdExplanationDataStart
     *
     * @return \DateTime
     */
    public function getKdExplanationDataStart()
    {
        return $this->kdExplanationDataStart;
    }

    /**
     * Set kdExplanationDataEnd
     *
     * @param \DateTime $kdExplanationDataEnd
     *
     * @return Gz
     */
    public function setKdExplanationDataEnd($kdExplanationDataEnd)
    {
        $this->kdExplanationDataEnd = $kdExplanationDataEnd;

        return $this;
    }

    /**
     * Get kdExplanationDataEnd
     *
     * @return \DateTime
     */
    public function getKdExplanationDataEnd()
    {
        return $this->kdExplanationDataEnd;
    }

    /**
     * Set gzAgreementName
     *
     * @param string $gzAgreementName
     *
     * @return Gz
     */
    public function setGzAgreementName($gzAgreementName)
    {
        $this->gzAgreementName = $gzAgreementName;

        return $this;
    }

    /**
     * Get gzAgreementName
     *
     * @return string
     */
    public function getGzAgreementName()
    {
        return $this->gzAgreementName;
    }

    /**
     * Set gzAgreementPosition
     *
     * @param string $gzAgreementPosition
     *
     * @return Gz
     */
    public function setGzAgreementPosition($gzAgreementPosition)
    {
        $this->gzAgreementPosition = $gzAgreementPosition;

        return $this;
    }

    /**
     * Get gzAgreementPosition
     *
     * @return string
     */
    public function getGzAgreementPosition()
    {
        return $this->gzAgreementPosition;
    }

    /**
     * Set gzAgreementExtraPosition
     *
     * @param string $gzAgreementExtraPosition
     *
     * @return Gz
     */
    public function setGzAgreementExtraPosition($gzAgreementExtraPosition)
    {
        $this->gzAgreementExtraPosition = $gzAgreementExtraPosition;

        return $this;
    }

    /**
     * Get gzAgreementExtraPosition
     *
     * @return string
     */
    public function getGzAgreementExtraPosition()
    {
        return $this->gzAgreementExtraPosition;
    }

    /**
     * Set $gzAgreementExtraName
     *
     * @param string $gzAgreementExtraName
     *
     * @return Gz
     */
    public function setGzAgreementExtraName($gzAgreementExtraName)
    {
        $this->gzAgreementExtraName = $gzAgreementExtraName;

        return $this;
    }

    /**
     * Get $gzAgreementExtraName
     *
     * @return string
     */
    public function getGzAgreementExtraName()
    {
        return $this->gzAgreementExtraName;
    }

    /**
     * Set gzApprovName
     *
     * @param string $gzApprovName
     *
     * @return Gz
     */
    public function setGzApprovName($gzApprovName)
    {
        $this->gzApprovName = $gzApprovName;

        return $this;
    }

    /**
     * Get gzApprovName
     *
     * @return string
     */
    public function getGzApprovName()
    {
        return $this->gzApprovName;
    }

    /**
     * Set gzApprovPosition
     *
     * @param string $gzApprovPosition
     *
     * @return Gz
     */
    public function setGzApprovPosition($gzApprovPosition)
    {
        $this->gzApprovPosition = $gzApprovPosition;

        return $this;
    }

    /**
     * Get gzApprovPosition
     *
     * @return string
     */
    public function getGzApprovPosition()
    {
        return $this->gzApprovPosition;
    }

    /**
     * Set gzSmpSonk
     *
     * @param float $gzSmpSonk
     *
     * @return Gz
     */
    public function setGzSmpSonk($gzSmpSonk)
    {
        $this->gzSmpSonk = $gzSmpSonk;

        return $this;
    }

    /**
     * Get gzSmpSonk
     *
     * @return float
     */
    public function getGzSmpSonk()
    {
        return $this->gzSmpSonk;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     *
     * @return Gz
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }
}
