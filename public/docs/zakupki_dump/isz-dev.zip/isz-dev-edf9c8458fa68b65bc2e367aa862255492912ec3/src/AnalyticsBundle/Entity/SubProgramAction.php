<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * SubProgramAction
 *
 * @ORM\Table(
 *   name="sub_program_action",
 *   indexes={
 *     @ORM\Index(name="sub_program_action_gov_program_id", columns={"gov_program_id"}),
 *     @ORM\Index(name="sub_program_action_parent_id", columns={"parent_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\SubProgramActionRepository")
 * @Json\Schema("SubProgramAction")
 */
class SubProgramAction implements IEntity
{
    const TYPE_SUBPROGRAM = 'subprogram';
    const TYPE_MAINACTION = 'mainaction';
    const TYPE_ACTION     = 'action';
    const TYPE_OTHER      = 'other';

    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"sub_program_action", "lot_detail", "financing_limits"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"sub_program_action", "lot_detail", "financing_limits"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="short_title", type="text", nullable=true)
     *
     * @JMS\Groups({"sub_program_action", "lot_detail", "financing_limits"})
     */
    private $shortTitle;

    /**
     * @var string
     *
     * @ORM\Column(name="number", type="string", length=255, nullable=true)
     *
     * @JMS\Groups({"sub_program_action", "lot_detail", "financing_limits", "lot_list"})
     */
    private $number;

    /**
     * @var integer
     *
     * @ORM\Column(name="financing_type_num", type="integer", nullable=true)
     * @JMS\Groups({"sub_program_action", "lot_list", "lot_detail", "financing_limits"})
     */
    private $financingTypeNum;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=32, nullable=true)
     * @JMS\Groups({"lot_detail", "financing_limits"})
     */
    private $type;

    /**
     * @var GovProgram
     *
     * @ORM\ManyToOne(targetEntity="GovProgram")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="gov_program_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_list", "lot_detail", "financing_limits"})
     */
    private $govProgram;

    /**
     * @var SubProgramAction
     *
     * @ORM\ManyToOne(targetEntity="SubProgramAction")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_list", "lot_detail", "financing_limits"})
     */
    private $parent;

    /**
     * @var string
     *
     * @ORM\Column(name="ksuf_id", type="string", length=64, nullable=true)
     */
    private $ksufId;


    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return SubProgramAction
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set number
     *
     * @param string $number
     * @return SubProgramAction
     */
    public function setNumber($number)
    {
        $this->number = $number;

        return $this;
    }

    /**
     * Get number
     *
     * @return string 
     */
    public function getNumber()
    {
        return $this->number;
    }

    /**
     * Set financingTypeNum
     *
     * @param integer $financingTypeNum
     * @return SubProgramAction
     */
    public function setFinancingTypeNum($financingTypeNum)
    {
        $this->financingTypeNum = $financingTypeNum;

        return $this;
    }

    /**
     * Get financingTypeNum
     *
     * @return integer
     */
    public function getFinancingTypeNum()
    {
        return $this->financingTypeNum;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return SubProgramAction
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set govProgram
     *
     * @param \AnalyticsBundle\Entity\GovProgram $govProgram
     * @return SubProgramAction
     */
    public function setGovProgram(\AnalyticsBundle\Entity\GovProgram $govProgram = null)
    {
        $this->govProgram = $govProgram;

        return $this;
    }

    /**
     * Get govProgram
     *
     * @return \AnalyticsBundle\Entity\GovProgram
     */
    public function getGovProgram()
    {
        return $this->govProgram;
    }

    /**
     * Set parent
     *
     * @param \AnalyticsBundle\Entity\SubProgramAction $parent
     * @return SubProgramAction
     */
    public function setParent(\AnalyticsBundle\Entity\SubProgramAction $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \AnalyticsBundle\Entity\SubProgramAction
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    /**
     * @return string
     */
    public function getShortTitle()
    {
        return $this->shortTitle;
    }

    /**
     * @param string $shortTitle
     */
    public function setShortTitle($shortTitle)
    {
        $this->shortTitle = $shortTitle;
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;

    /**
     * Set ksufId
     *
     * @param string $ksufId
     * @return SubProgramAction
     */
    public function setKsufId($ksufId)
    {
        $this->ksufId = $ksufId;

        return $this;
    }

    /**
     * Get ksufId
     *
     * @return string 
     */
    public function getKsufId()
    {
        return $this->ksufId;
    }
}
