<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * NmckCostMethod
 *
 * @ORM\Table(name="nmck_cost_method", indexes={@ORM\Index(name="nmck_cost_method_nmck_variant_id", columns={"nmck_variant_id"})})
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\NmckCostMethodRepository")
 * @Json\Schema("NmckCostMethod")
 */
class NmckCostMethod implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="cost_item_name", type="text", nullable=true)
     */
    private $costItemName;

    /**
     * @var string
     *
     * @ORM\Column(name="cost_distribution", type="decimal", precision=5, scale=2, nullable=true)
     */
    private $costDistribution;

    /**
     * @var float
     *
     * @ORM\Column(name="price", type="float", precision=10, scale=0, nullable=true)
     */
    private $price;

    /**
     * @var string
     *
     * @ORM\Column(name="esn", type="decimal", precision=5, scale=2, nullable=true)
     */
    private $esn;

    /**
     * @var string
     *
     * @ORM\Column(name="expenses", type="decimal", precision=5, scale=2, nullable=true)
     */
    private $expenses;

    /**
     * @var string
     *
     * @ORM\Column(name="profit", type="decimal", precision=5, scale=2, nullable=true)
     */
    private $profit;

    /**
     * @var string
     *
     * @ORM\Column(name="nds", type="decimal", precision=5, scale=2, nullable=true)
     */
    private $nds;

    /**
     * @var \NmckVariant
     *
     * @ORM\ManyToOne(targetEntity="NmckVariant")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="nmck_variant_id", referencedColumnName="id")
     * })
     */
    private $nmckVariant;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return NmckCostMethod
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set costItemName
     *
     * @param string $costItemName
     * @return NmckCostMethod
     */
    public function setCostItemName($costItemName)
    {
        $this->costItemName = $costItemName;

        return $this;
    }

    /**
     * Get costItemName
     *
     * @return string 
     */
    public function getCostItemName()
    {
        return $this->costItemName;
    }

    /**
     * Set costDistribution
     *
     * @param string $costDistribution
     * @return NmckCostMethod
     */
    public function setCostDistribution($costDistribution)
    {
        $this->costDistribution = $costDistribution;

        return $this;
    }

    /**
     * Get costDistribution
     *
     * @return string 
     */
    public function getCostDistribution()
    {
        return $this->costDistribution;
    }

    /**
     * Set price
     *
     * @param float $price
     * @return NmckCostMethod
     */
    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    /**
     * Get price
     *
     * @return float
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set esn
     *
     * @param string $esn
     * @return NmckCostMethod
     */
    public function setEsn($esn)
    {
        $this->esn = $esn;

        return $this;
    }

    /**
     * Get esn
     *
     * @return string
     */
    public function getEsn()
    {
        return $this->esn;
    }

    /**
     * Set expenses
     *
     * @param string $expenses
     * @return NmckCostMethod
     */
    public function setExpenses($expenses)
    {
        $this->expenses = $expenses;

        return $this;
    }

    /**
     * Get expenses
     *
     * @return string
     */
    public function getExpenses()
    {
        return $this->expenses;
    }

    /**
     * Set profit
     *
     * @param string $profit
     * @return NmckCostMethod
     */
    public function setProfit($profit)
    {
        $this->profit = $profit;

        return $this;
    }

    /**
     * Get profit
     *
     * @return string
     */
    public function getProfit()
    {
        return $this->profit;
    }

    /**
     * Set nds
     *
     * @param string $nds
     * @return NmckCostMethod
     */
    public function setNds($nds)
    {
        $this->nds = $nds;

        return $this;
    }

    /**
     * Get nds
     *
     * @return string
     */
    public function getNds()
    {
        return $this->nds;
    }

    /**
     * Set nmckVariant
     *
     * @param \AnalyticsBundle\Entity\NmckVariant $nmckVariant
     * @return NmckCostMethod
     */
    public function setNmckVariant(\AnalyticsBundle\Entity\NmckVariant $nmckVariant = null)
    {
        $this->nmckVariant = $nmckVariant;

        return $this;
    }

    /**
     * Get nmckVariant
     *
     * @return \AnalyticsBundle\Entity\NmckVariant
     */
    public function getNmckVariant()
    {
        return $this->nmckVariant;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getDescription();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
