<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use AnalyticsBundle\Entity\MailList;
use AnalyticsBundle\Entity\ExpertRole;
use AnalyticsBundle\Entity\Rules;
use AnalyticsBundle\Entity\NotifyPeriod;
use Doctrine\Common\Collections\ArrayCollection;
use AnalyticsBundle\Entity\Common;

/**
 * Notify
 *
 * @ORM\Table("notify")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\NotifyRepository")
 */
class Notify
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @ORM\SequenceGenerator(sequenceName="notify_id_seq", allocationSize=1, initialValue=1)
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255)
     */
    private $description;

    /**
     * @var MailList
     *
     * @ORM\OneToOne(targetEntity="MailList", cascade={"persist", "remove"})
     * @ORM\JoinColumn(name="email_id", referencedColumnName="id", nullable=true)
     */
    private $email;

    /**
     * @var MailList
     *
     * @ORM\OneToOne(targetEntity="MailList", cascade={"persist", "remove"})
     * @ORM\JoinColumn(name="sms_id", referencedColumnName="id", nullable=true)
     */
    private $sms;

    /**
     * @ORM\ManyToMany(targetEntity="ExpertRole", cascade={"persist"})
     * @ORM\JoinTable(name="notify_roles",
     * joinColumns={@ORM\JoinColumn(name="notify__id", referencedColumnName="id")},
     * inverseJoinColumns={@ORM\JoinColumn(name="roles__id", referencedColumnName="id")}
     * )
     */
    private $roles;

    /**
     * @ORM\ManyToMany(targetEntity="Rules", cascade={"persist"})
     * @ORM\JoinTable(name="notify_rules",
     * joinColumns={@ORM\JoinColumn(name="notify__id", referencedColumnName="id")},
     * inverseJoinColumns={@ORM\JoinColumn(name="rules__id", referencedColumnName="id")}
     * )
     */
    private $rules;

    /**
     * @ORM\ManyToMany(targetEntity="NotifyPeriod", cascade={"persist"})
     * @ORM\JoinTable(name="notify_period_value",
     * joinColumns={@ORM\JoinColumn(name="notify__id", referencedColumnName="id")},
     * inverseJoinColumns={@ORM\JoinColumn(name="period__id", referencedColumnName="id")}
     * )
     */
    private $periods;

    /**
     * @var string
     * @ORM\Column(name="code", type="string", length=64, unique=true, nullable=false)
     */
    private $code;

    /**
     * @var Common
     *
     * @ORM\OneToOne(targetEntity="Common")
     * @ORM\JoinColumn(name="common_id", referencedColumnName="id", nullable=true)
     */
    private $common;

    public function __construct()
    {
        $this->roles = new ArrayCollection();
        $this->rules = new ArrayCollection();
        $this->periods = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Notify
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Notify
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set email
     *
     * @param MailList $email
     *
     * @return Notify
     */
    public function setEmail(MailList $email = null)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return MailList
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set sms
     *
     * @param MailList $sms
     *
     * @return Notify
     */
    public function setSms(MailList $sms = null)
    {
        $this->sms = $sms;

        return $this;
    }

    /**
     * Get sms
     *
     * @return MailList
     */
    public function getSms()
    {
        return $this->sms;
    }

    /**
     * Add role
     *
     * @param ExpertRole $role
     * @return Notify
     */
    public function addRole(ExpertRole $role)
    {
        $this->roles[] = $role;

        return $this;
    }

    /**
     * Remove role
     *
     * @param ExpertRole $role
     */
    public function removeRole(ExpertRole $role)
    {
        $this->roles->removeElement($role);
    }

    /**
     * Get roles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getRoles()
    {
        return $this->roles;
    }

    /**
     * Add rule
     *
     * @param Rules $rule
     * @return Notify
     */
    public function addRule(Rules $rule)
    {
        $this->rules[] = $rule;

        return $this;
    }

    /**
     * Remove rule
     *
     * @param Rules $rule
     */
    public function removeRule(Rules $rule)
    {
        $this->rules->removeElement($rule);
    }

    /**
     * Get rules
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getRules()
    {
        return $this->rules;
    }

    /**
     * Add period
     *
     * @param NotifyPeriod $period
     * @return Notify
     */
    public function addPeriod(NotifyPeriod $period)
    {
        $this->periods[] = $period;

        return $this;
    }

    /**
     * Remove period
     *
     * @param NotifyPeriod $period
     */
    public function removePeriod(NotifyPeriod $period)
    {
        $this->periods->removeElement($period);
    }

    /**
     * Get periods
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPeriods()
    {
        return $this->periods;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return Notify
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set common
     *
     * @param Common $common
     *
     * @return Notify
     */
    public function setCommon(Common $common = null)
    {
        $this->common = $common;

        return $this;
    }

    /**
     * Get common
     *
     * @return Common
     */
    public function getCommon()
    {
        return $this->common;
    }
}
