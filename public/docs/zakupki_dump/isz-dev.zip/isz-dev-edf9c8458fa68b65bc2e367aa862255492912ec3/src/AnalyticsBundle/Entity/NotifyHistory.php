<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use AnalyticsBundle\Entity\Notify;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * NotifyHistory
 *
 * @ORM\Table(name="notify_history")
 * @ORM\Entity()
 */
class NotifyHistory
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @ORM\SequenceGenerator(sequenceName="notify_history_id_seq", allocationSize=1, initialValue=1)
     */
    private $id;

    /**
     * @var Common
     *
     * @ORM\ManyToOne(targetEntity="Notify")
     * @ORM\JoinColumn(name="notify_id", referencedColumnName="id", nullable=true)
     */
    private $notify;

    /**
     * @var string
     * @ORM\Column(name="entity", type="string", length=64)
     */
    private $entity;

    /**
     * @var string
     * @ORM\Column(name="type", type="string", length=64)
     */
    private $type;

    /**
     * @var date
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="created_at", type="date")
     */
    private $createdAt;

    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set notify
     *
     * @param Notify $notify
     *
     * @return NotifyHistory
     */
    public function setNotify(Notify $notify = null)
    {
        $this->notify = $notify;

        return $this;
    }

    /**
     * Get notify
     *
     * @return Notify
     */
    public function getNotify()
    {
        return $this->notify;
    }

    /**
     * Set createdAt
     *
     * @param date $createdAt
     * @return NotifyHistory
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     * @return date
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set entity
     *
     * @param string $entity
     * @return NotifyHistory
     */
    public function setEntity($entity)
    {
        $this->entity = $entity;

        return $this;
    }

    /**
     * Get entity
     * @return string
     */
    public function getEntity()
    {
        return $this->entity;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return NotifyHistory
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }
}
