<?php

namespace AnalyticsBundle\Entity;

interface IEntity
{
}