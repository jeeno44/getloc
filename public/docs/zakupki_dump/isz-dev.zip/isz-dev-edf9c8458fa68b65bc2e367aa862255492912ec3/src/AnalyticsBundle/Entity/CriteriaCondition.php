<?php

namespace AnalyticsBundle\Entity;

use AnalyticsBundle\Entity\IEntity;
use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * CriteriaCondition
 *
 * @ORM\Table(name="criteria_condition")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\CriteriaConditionRepository")
 * @Json\Schema("CriteriaCondition")
 */
class CriteriaCondition implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="SEQUENCE")
     * @ORM\SequenceGenerator(sequenceName="criteria_condition_id_seq", allocationSize=1, initialValue=1)
     * @JMS\Groups({"CriteriaCondition"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"CriteriaCondition"})
     */
    private $title;

    /**
     * @var \AnalyticsBundle\Entity\CriteriaMaxValues
     *
     * @ORM\OneToMany(targetEntity="AnalyticsBundle\Entity\CriteriaMaxValues", mappedBy="criteriaCondition", cascade={"remove"})
     * @JMS\Groups({"CriteriaCondition_list"})
     * @Json\Ignore
     */
    private $criteriaMaxValues;

    /**
     * @var \AnalyticsBundle\Entity\Lot
     *
     * @ORM\OneToMany(targetEntity="AnalyticsBundle\Entity\Lot", mappedBy="criteriaCondition", cascade={"remove"})
     * @Json\Ignore
     */
    private $lot;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->criteriaMaxValues = new \Doctrine\Common\Collections\ArrayCollection();
        $this->lot = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return CriteriaCondition
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Add criteriaMaxValue
     *
     * @param \AnalyticsBundle\Entity\CriteriaMaxValues $criteriaMaxValue
     *
     * @return CriteriaCondition
     */
    public function addCriteriaMaxValue(\AnalyticsBundle\Entity\CriteriaMaxValues $criteriaMaxValue)
    {
        $this->criteriaMaxValues[] = $criteriaMaxValue;

        return $this;
    }

    /**
     * Remove criteriaMaxValue
     *
     * @param \AnalyticsBundle\Entity\CriteriaMaxValues $criteriaMaxValue
     *
     * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
     */
    public function removeCriteriaMaxValue(\AnalyticsBundle\Entity\CriteriaMaxValues $criteriaMaxValue)
    {
        return $this->criteriaMaxValues->removeElement($criteriaMaxValue);
    }

    /**
     * Get criteriaMaxValues
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCriteriaMaxValues()
    {
        return $this->criteriaMaxValues;
    }

    /**
     * Add lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     *
     * @return CriteriaCondition
     */
    public function addLot(\AnalyticsBundle\Entity\Lot $lot)
    {
        $this->lot[] = $lot;

        return $this;
    }

    /**
     * Remove lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     *
     * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
     */
    public function removeLot(\AnalyticsBundle\Entity\Lot $lot)
    {
        return $this->lot->removeElement($lot);
    }

    /**
     * Get lot
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }
}
