<?php

namespace AnalyticsBundle\Entity\Views;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * BaseImplementation
 *
 * @ORM\Table(name="base_implementation")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\Views\BaseImplementationRepository", readOnly=true)
 * @Json\Schema("BaseImplementation")
 */
class BaseImplementation
{
    const TYPE_GOVPROGRAM = 'govprogram';
    const TYPE_FCP        = 'fcp';
    const TYPE_SUBPROGRAM = 'subprogram';
    const TYPE_TASK       = 'task';
    const TYPE_MAINACTION = 'mainaction';
    const TYPE_ACTION     = 'action';
    const TYPE_SUBACTION  = 'subaction';

    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="number", type="string", length=255, nullable=true)
     */
    private $number;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=32, nullable=true)
     */
    private $type;

    /**
     * @var BaseImplementation
     *
     * @ORM\ManyToOne(targetEntity="BaseImplementation")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     * })
     */
    private $parent;


    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getTitle();
    }

    /**
     * Set title
     *
     * @param string $title
     * @return BaseImplementation
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set number
     *
     * @param string $number
     * @return BaseImplementation
     */
    public function setNumber($number)
    {
        $this->number = $number;

        return $this;
    }

    /**
     * Get number
     *
     * @return string 
     */
    public function getNumber()
    {
        return $this->number;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return BaseImplementation
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set parent
     *
     * @param \AnalyticsBundle\Entity\Views\BaseImplementation $parent
     * @return BaseImplementation
     */
    public function setParent(\AnalyticsBundle\Entity\Views\BaseImplementation $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \AnalyticsBundle\Entity\Views\BaseImplementation 
     */
    public function getParent()
    {
        return $this->parent;
    }
}
