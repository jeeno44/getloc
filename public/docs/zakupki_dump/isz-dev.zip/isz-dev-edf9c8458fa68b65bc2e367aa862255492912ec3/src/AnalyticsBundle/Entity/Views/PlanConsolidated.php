<?php

namespace AnalyticsBundle\Entity\Views;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * PlanFinancing
 *
 * @ORM\Table(name="plan_consolidated")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\Views\PlanConsolidatedRepository", readOnly=true)
 * @Json\Schema("ViewPlanConsolidated")
 */
class PlanConsolidated
{
    /**
     * @var uuid
     *
     * @ORM\Column(name="plan_id", type="guid", nullable=false)
     * @ORM\Id
     * @JMS\Groups({"plan_detail", "plan_common"})
     */
    private $planId;

    /**
     * @var integer
     *
     * @ORM\Column(name="year", type="smallint", nullable=true)
     * @ORM\Id
     * @JMS\Groups({"plan_detail", "plan_common"})
     */
    private $year;

    /**
     * @var float
     *
     * @ORM\Column(name="plan_price", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"plan_detail", "plan_common"})
     */
    private $planPrice;

    /**
     * @var float
     *
     * @ORM\Column(name="publication_price", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"plan_detail", "plan_common"})
     */
    private $publicationPrice;

    /**
     * @var float
     *
     * @ORM\Column(name="contract_price", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"plan_detail", "plan_common"})
     */
    private $contractPrice;

    /**
     * @var float
     *
     * @ORM\Column(name="fact_price", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"plan_detail", "plan_common"})
     */
    private $factPrice;

    /**
     * @var Common
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\Common")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="common_id", referencedColumnName="id", nullable=false)
     * })
     * @JMS\Groups({"lot", "lot_detail"})
     */
    private $common;


    /**
     * Set planId
     *
     * @param integer $planId
     * @return PlanFinancing
     */
    public function setPlanId($planId)
    {
        $this->planId = $planId;

        return $this;
    }

    /**
     * Get planId
     *
     * @return integer
     */
    public function getPlanId()
    {
        return $this->planId;
    }

    /**
     * Set year
     *
     * @param integer $year
     * @return PlanFinancing
     */
    public function setYear($year)
    {
        $this->year = $year;

        return $this;
    }

    /**
     * Get year
     *
     * @return integer 
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * Set planPrice
     *
     * @param float $planPrice
     * @return PlanFinancing
     */
    public function setPlanPrice($planPrice)
    {
        $this->planPrice = $planPrice;

        return $this;
    }

    /**
     * Get planPrice
     *
     * @return float 
     */
    public function getPlanPrice()
    {
        return $this->planPrice;
    }

    /**
     * Set publicationPrice
     *
     * @param float $publicationPrice
     * @return PlanFinancing
     */
    public function setPublicationPrice($publicationPrice)
    {
        $this->publicationPrice = $publicationPrice;

        return $this;
    }

    /**
     * Get publicationPrice
     *
     * @return float 
     */
    public function getPublicationPrice()
    {
        return $this->publicationPrice;
    }

    /**
     * Set contractPrice
     *
     * @param float $contractPrice
     * @return PlanFinancing
     */
    public function setContractPrice($contractPrice)
    {
        $this->contractPrice = $contractPrice;

        return $this;
    }

    /**
     * Get contractPrice
     *
     * @return float 
     */
    public function getContractPrice()
    {
        return $this->contractPrice;
    }

    /**
     * Set factPrice
     *
     * @param float $factPrice
     * @return PlanFinancing
     */
    public function setFactPrice($factPrice)
    {
        $this->factPrice = $factPrice;

        return $this;
    }

    /**
     * Get factPrice
     *
     * @return float 
     */
    public function getFactPrice()
    {
        return $this->factPrice;
    }

    /**
     * Set common
     *
     * @param \AnalyticsBundle\Entity\Common $common
     * @return PlanConsolidated
     */
    public function setCommon(\AnalyticsBundle\Entity\Common $common)
    {
        $this->common = $common;

        return $this;
    }

    /**
     * Get common
     *
     * @return \AnalyticsBundle\Entity\Common
     */
    public function getCommon()
    {
        return $this->common;
    }
}
