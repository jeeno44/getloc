<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * CommissionMember
 *
 * @ORM\Table(name="commission_member")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\CommissionMemberRepository")
 * @Json\Schema("CommissionMember")
 */
class CommissionMember implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="last_name", type="string", length=32, nullable=true)
     */
    private $lastName;

    /**
     * @var string
     *
     * @ORM\Column(name="fisrt_name", type="string", length=32, nullable=true)
     */
    private $fisrtName;

    /**
     * @var string
     *
     * @ORM\Column(name="middle_name", type="string", length=32, nullable=true)
     */
    private $middleName;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set lastName
     *
     * @param string $lastName
     * @return CommissionMember
     */
    public function setLastName($lastName)
    {
        $this->lastName = $lastName;

        return $this;
    }

    /**
     * Get lastName
     *
     * @return string 
     */
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * Set fisrtName
     *
     * @param string $fisrtName
     * @return CommissionMember
     */
    public function setFisrtName($fisrtName)
    {
        $this->fisrtName = $fisrtName;

        return $this;
    }

    /**
     * Get fisrtName
     *
     * @return string 
     */
    public function getFisrtName()
    {
        return $this->fisrtName;
    }

    /**
     * Set middleName
     *
     * @param string $middleName
     * @return CommissionMember
     */
    public function setMiddleName($middleName)
    {
        $this->middleName = $middleName;

        return $this;
    }

    /**
     * Get middleName
     *
     * @return string 
     */
    public function getMiddleName()
    {
        return $this->middleName;
    }
}
