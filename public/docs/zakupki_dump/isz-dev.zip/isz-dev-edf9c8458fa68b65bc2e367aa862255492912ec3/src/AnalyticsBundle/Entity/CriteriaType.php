<?php

namespace AnalyticsBundle\Entity;

use AnalyticsBundle\Entity\IEntity;
use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * CriteriaType
 *
 * @ORM\Table(name="criteria_type")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\CriteriaTypeRepository")
 * @Json\Schema("CriteriaType")
 */
class CriteriaType implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="SEQUENCE")
     * @ORM\SequenceGenerator(sequenceName="criteria_type_id_seq", allocationSize=1, initialValue=1)
     * @JMS\Groups({"CriteriaType"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"CriteriaType"})
     */
    private $title;

    /**
     * @var \AnalyticsBundle\Entity\CriteriaMaxValues
     *
     * @ORM\OneToMany(targetEntity="AnalyticsBundle\Entity\CriteriaMaxValues", mappedBy="criteriaType", cascade={"remove"})
     * @JMS\Groups({"CriteriaType_detail"})
     */
    private $criteriaMaxValues;

    /**
     * @var \AnalyticsBundle\Entity\CriteriaRating
     *
     * @ORM\OneToMany(targetEntity="AnalyticsBundle\Entity\CriteriaRating", mappedBy="criteriaType", cascade={"remove"})
     * @JMS\Groups({"CriteriaType_detail"})
     * @Json\Ignore
     */
    private $criteriaRatings;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->criteriaMaxValues = new \Doctrine\Common\Collections\ArrayCollection();
        $this->criteriaRatings = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return CriteriaType
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Add criteriaMaxValue
     *
     * @param \AnalyticsBundle\Entity\CriteriaMaxValues $criteriaMaxValue
     *
     * @return CriteriaType
     */
    public function addCriteriaMaxValue(\AnalyticsBundle\Entity\CriteriaMaxValues $criteriaMaxValue)
    {
        $this->criteriaMaxValues[] = $criteriaMaxValue;

        return $this;
    }

    /**
     * Remove criteriaMaxValue
     *
     * @param \AnalyticsBundle\Entity\CriteriaMaxValues $criteriaMaxValue
     *
     * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
     */
    public function removeCriteriaMaxValue(\AnalyticsBundle\Entity\CriteriaMaxValues $criteriaMaxValue)
    {
        return $this->criteriaMaxValues->removeElement($criteriaMaxValue);
    }

    /**
     * Get criteriaMaxValues
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCriteriaMaxValues()
    {
        return $this->criteriaMaxValues;
    }

    /**
     * Add criteriaRating
     *
     * @param \AnalyticsBundle\Entity\CriteriaRating $criteriaRating
     *
     * @return CriteriaType
     */
    public function addCriteriaRating(\AnalyticsBundle\Entity\CriteriaRating $criteriaRating)
    {
        $this->criteriaRatings[] = $criteriaRating;

        return $this;
    }

    /**
     * Remove criteriaRating
     *
     * @param \AnalyticsBundle\Entity\CriteriaRating $criteriaRating
     *
     * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
     */
    public function removeCriteriaRating(\AnalyticsBundle\Entity\CriteriaRating $criteriaRating)
    {
        return $this->criteriaRatings->removeElement($criteriaRating);
    }

    /**
     * Get criteriaRatings
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCriteriaRatings()
    {
        return $this->criteriaRatings;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }
}
