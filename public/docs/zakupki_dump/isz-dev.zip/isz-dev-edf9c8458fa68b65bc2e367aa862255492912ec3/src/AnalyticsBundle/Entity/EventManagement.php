<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use AnalyticsBundle\Validator\Constraints as EventManagementAssert;

/**
 * EventManagement
 *
 * @ORM\Table(name="event_management")
 * @ORM\Entity()
 * @Json\Schema("EventManagement")
 * @EventManagementAssert\StatusType
 */
class EventManagement implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="status_type_object", type="string", length=32, nullable=false)
     */
    private $statusTypeObject;

    /**
     * @var string
     *
     * @ORM\Column(name="status_start", type="string", length=32, nullable=false)
     */
    private $statusStart;

    /**
     * @var string
     *
     * @ORM\Column(name="status_end", type="string", length=32, nullable=false)
     */
    private $statusEnd;

    /**
     * @var int
     * @ORM\Column(name="days", type="integer")
     */
    private $days;

    /**
     * @var boolean
     *
     * @ORM\Column(name="type_days", type="boolean")
     */
    private $typeDays;

    /**
     * @var string
     *
     * @ORM\Column(name="comment", type="string", length=255)
     */
    private $comment;

    /**
     * @var string
     *
     * @ORM\Column(name="options", type="text")
     */
    private $options;

    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set statusTypeObject
     *
     * @param string $statusTypeObject
     * @return EventManagement
     */
    public function setStatusTypeObject($statusTypeObject)
    {
        $this->statusTypeObject = $statusTypeObject;

        return $this;
    }

    /**
     * Get statusTypeObject
     *
     * @return string
     */
    public function getStatusTypeObject()
    {
        return $this->statusTypeObject;
    }

    /**
     * Set statusStart
     *
     * @param string $statusStart
     * @return EventManagement
     */
    public function setStatusStart($statusStart)
    {
        $this->statusStart = $statusStart;

        return $this;
    }

    /**
     * Get statusStart
     *
     * @return string
     */
    public function getStatusStart()
    {
        return $this->statusStart;
    }

    /**
     * Set statusEnd
     *
     * @param string $statusEnd
     * @return EventManagement
     */
    public function setStatusEnd($statusEnd)
    {
        $this->statusEnd = $statusEnd;

        return $this;
    }

    /**
     * Get statusEnd
     *
     * @return string
     */
    public function getStatusEnd()
    {
        return $this->statusEnd;
    }

    /**
     * Set days
     *
     * @param integer $days
     * @return EventManagement
     */
    public function setDays($days)
    {
        $this->days = $days;

        return $this;
    }

    /**
     * Get days
     *
     * @return boolean
     */
    public function getDays()
    {
        return $this->days;
    }

    /**
     * Set typeDays
     *
     * @param boolean $typeDays
     * @return EventManagement
     */
    public function setTypeDays($typeDays)
    {
        $this->typeDays = $typeDays;

        return $this;
    }

    /**
     * Get typeDays
     *
     * @return boolean
     */
    public function getTypeDays()
    {
        return $this->typeDays;
    }

    /**
     * Set comment
     *
     * @param string $comment
     * @return EventManagement
     */
    public function setComment($comment)
    {
        $this->comment = $comment;

        return $this;
    }

    /**
     * Get comment
     *
     * @return string
     */
    public function getComment()
    {
        return $this->comment;
    }

    /**
     * Set options
     *
     * @param text $options
     * @return EventManagement
     */
    public function setOptions($options)
    {
        $this->options = $options;

        return $this;
    }

    /**
     * Get options
     *
     * @return text
     */
    public function getOptions()
    {
        return $this->options;
    }
}
