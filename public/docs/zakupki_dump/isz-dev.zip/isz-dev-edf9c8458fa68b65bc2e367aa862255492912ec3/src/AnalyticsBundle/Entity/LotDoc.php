<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

use JMS\Serializer\Annotation as JMS;

/**
 * LotDoc
 *
 * @ORM\Table(name="lot_doc")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\LotDocRepository")
 * @Json\Schema("LotDoc")
 */
class LotDoc implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"lot_doc_detail", "lot_doc_list", "lot_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     * @JMS\Groups({"lot_doc_detail", "lot_doc_list", "lot_detail"})
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     * @JMS\Groups({"lot_doc_detail", "lot_doc_list", "lot_detail"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     * @JMS\Groups({"lot_doc_detail", "lot_doc_list", "lot_detail"})
     */
    private $decs;

    /**
     * @var string
     *
     * @ORM\Column(name="file", type="string", length=255, nullable=true)
     * @JMS\Groups({"lot_doc_detail", "lot_doc_list", "lot_detail"})
     */
    private $file;

    /**
     * @var Lot
     *
     * @ORM\ManyToOne(targetEntity="Lot", inversedBy="lotDoc")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     */
    private $lot;


    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return LotDoc
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        if (!$this->name) {
            return basename($this->getFile());
        }

        return $this->name;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return LotDoc
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set decs
     *
     * @param string $decs
     * @return LotDoc
     */
    public function setDecs($decs)
    {
        $this->decs = $decs;

        return $this;
    }

    /**
     * Get decs
     *
     * @return string
     */
    public function getDecs()
    {
        return $this->decs;
    }

    /**
     * Set file
     *
     * @param string $file
     * @return LotDoc
     */
    public function setFile($file)
    {
        $this->file = $file;

        return $this;
    }

    /**
     * Get file
     *
     * @return string
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     * @return LotDoc
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getTitle();
    }
}
