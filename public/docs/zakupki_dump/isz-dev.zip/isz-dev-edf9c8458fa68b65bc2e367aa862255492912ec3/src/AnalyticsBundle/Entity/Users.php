<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;
use Swagger\Annotations as SWG;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Security\Core\User\EquatableInterface;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\Role\Role;

/**
 * Users
 *
 * @ORM\Table(name="users")
 * @Gedmo\SoftDeleteable(fieldName="deleted")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\UsersRepository")
 * @Json\Schema("Users")
 * @SWG\Definition(definition="UsersList",
 *   @SWG\Property(property="id", type="string", description="ID пользователя"),
 *   @SWG\Property(property="name", type="string", description="Имя и отчество (если есть)"),
 *   @SWG\Property(property="lastName", type="string", description="Фамилия"),
 *   @SWG\Property(property="patronymic", type="string", description="Отчество"),
 *   @SWG\Property(property="jobTitle", type="string", description="Должность"),
 *   @SWG\Property(property="phone", type="string", description="Телефон"),
 *   @SWG\Property(property="email", type="string", description="Почта"),
 *   @SWG\Property(property="avatar", type="string", description="Ссылка на аватар")
 * )
 * @SWG\Definition(definition="User",
 *   @SWG\Property(property="id", type="string", description="ID пользователя"),
 *   @SWG\Property(property="name", type="string", description="Имя и отчество (если есть)"),
 *   @SWG\Property(property="lastName", type="string", description="Фамилия"),
 *   @SWG\Property(property="patronymic", type="string", description="Отчество"),
 *   @SWG\Property(property="jobTitle", type="string", description="Должность"),
 *   @SWG\Property(property="phone", type="string", description="Телефон"),
 *   @SWG\Property(property="email", type="string", description="Почта"),
 *   @SWG\Property(property="avatar", type="string", description="Ссылка на аватар"),
 *   @SWG\Property(property="expertGroup", ref="#/definitions/ExpertGroup", description="Экспертная группа")
 *
 * )
 *
 */
class Users implements IEntity, UserInterface, EquatableInterface
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @JMS\Groups({"users", "users_list", "users_detail", "lot_list", "lot_detail", "users_expert_group_detail", "expert_group_list", "expert_group_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     * @JMS\Groups({"users", "users_list", "users_detail", "lot_list", "lot_detail", "users_expert_group_detail",
     *      "expert_group_list", "expert_group_detail", "notice_ea"})
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="last_name", type="string", length=255, nullable=true)
     * @JMS\Groups({"users", "users_list", "users_detail", "lot_list", "lot_detail", "users_expert_group_detail",
     *      "expert_group_list", "expert_group_detail", "notice_ea"})
     */
    private $lastName;

    /**
     * @var string
     *
     * @ORM\Column(name="patronymic", type="string", length=255, nullable=true)
     * @JMS\Groups({"users", "users_list", "users_detail", "lot_list", "lot_detail", "users_expert_group_detail",
     *      "expert_group_list", "expert_group_detail", "notice_ea"})
     */
    private $patronymic;

    /**
     * @var string
     *
     * @ORM\Column(name="job_title", type="string", length=255, nullable=true)
     * @JMS\Groups({"users", "users_list", "users_detail", "users_expert_group_detail", "expert_group_list", "expert_group_detail"})
     */
    private $jobTitle;

    /**
     * @var string
     *
     * @ORM\Column(name="phone", type="string", length=255, nullable=true)
     * @JMS\Groups({"users", "users_list", "users_detail"})
     */
    private $phone;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=255, nullable=true)
     * @JMS\Groups({"users", "users_list", "users_detail", "Common_zakupki", "notice_ea"})
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(name="avatar", type="string", length=255, nullable=true)
     * @JMS\Groups({"users", "users_list", "users_detail"})
     */
    private $avatar;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="ExpertGroup", mappedBy="users")
     * @JMS\Groups({"users_detail"})
     * @Json\Ignore
     */
    private $expertGroup;

    /**
     * @var Stage
     *
     * @ORM\OneToMany(targetEntity="UsersExpertGroup", mappedBy="users", cascade={"persist", "remove"})
     * @JMS\Groups({"users_detail"})
     * @Json\Ignore
     */
    private $groupRoles;

    /**
     * @var \Datetime
     *
     * @ORM\Column(name="deleted", type="datetime", nullable=true)
     */
    protected $deleted;

    /**
     * @return \Datetime
     */
    public function getDeleted()
    {
        return $this->deleted;
    }
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->expertGroup = new \Doctrine\Common\Collections\ArrayCollection();
        $this->groupRoles = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Set id
     *
     * @param guid|string $id
     * @return Users
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Users
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set lastName
     *
     * @param string $lastName
     * @return Users
     */
    public function setLastName($lastName)
    {
        $this->lastName = $lastName;

        return $this;
    }

    /**
     * Get lastName
     *
     * @return string 
     */
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * Set patronymic
     *
     * @param string $patronymic
     * @return Users
     */
    public function setPatronymic($patronymic)
    {
        $this->patronymic = $patronymic;

        return $this;
    }

    /**
     * Get patronymic
     *
     * @return string
     */
    public function getPatronymic()
    {
        return $this->patronymic;
    }

    /**
     * Set jobTitle
     *
     * @param string $jobTitle
     * @return Users
     */
    public function setJobTitle($jobTitle)
    {
        $this->jobTitle = $jobTitle;

        return $this;
    }

    /**
     * Get jobTitle
     *
     * @return string 
     */
    public function getJobTitle()
    {
        return $this->jobTitle;
    }

    /**
     * Set phone
     *
     * @param string $phone
     * @return Users
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string 
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return Users
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set avatar
     *
     * @param string $avatar
     * @return Users
     */
    public function setAvatar($avatar)
    {
        $this->avatar = $avatar;

        return $this;
    }

    /**
     * Get avatar
     *
     * @return string
     */
    public function getAvatar()
    {
        return $this->avatar;
    }

    /**
     * Add expertGroup
     *
     * @param \AnalyticsBundle\Entity\ExpertGroup $expertGroup
     * @return Users
     */
    public function addExpertGroup(\AnalyticsBundle\Entity\ExpertGroup $expertGroup)
    {
        $expertGroup->addUser($this);

        $this->expertGroup[] = $expertGroup;

        return $this;
    }

    /**
     * Remove expertGroup
     *
     * @param \AnalyticsBundle\Entity\ExpertGroup $expertGroup
     */
    public function removeExpertGroup(\AnalyticsBundle\Entity\ExpertGroup $expertGroup)
    {
        $this->expertGroup->removeElement($expertGroup);

        $expertGroup->removeUser($this);
    }

    /**
     * Get expertGroup
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getExpertGroup()
    {
        return $this->expertGroup;
    }

    /**
     * Add groupRoles
     *
     * @param \AnalyticsBundle\Entity\UsersExpertGroup $groupRoles
     * @return Users
     */
    public function addGroupRole(\AnalyticsBundle\Entity\UsersExpertGroup $groupRoles)
    {
        $groupRoles->setUsers($this);

        $this->groupRoles[] = $groupRoles;

        return $this;
    }

    /**
     * Remove groupRoles
     *
     * @param \AnalyticsBundle\Entity\UsersExpertGroup $groupRoles
     */
    public function removeGroupRole(\AnalyticsBundle\Entity\UsersExpertGroup $groupRoles)
    {
        $this->groupRoles->removeElement($groupRoles);
    }

    /**
     * Get groupRoles
     *
     * @return \Doctrine\Common\Collections\Collection|UsersExpertGroup[]
     */
    public function getGroupRoles()
    {
        return $this->groupRoles;
    }

    /**
     * Возвращает автоматическое название
     *
     * @return string
     */
    public function __toString()
    {
        $name = "";
        $lastName = "";
        try {
            if ($this->getLastName()) {
                $lastName = (string) $this->getLastName();
            }


            if ($this->getName()) {
                $name = (string) $this->getName();
            }
            return $lastName . ' ' . $name;
        } catch (\Exception $e) {
            return 'Ошибка в ';
        }
    }

    public function isEqualTo(UserInterface $user)
    {
        if (!$user instanceof Users) {
            return false;
        }

        return true;
    }









    /**
     * Returns the roles granted to the user.
     *
     * <code>
     * public function getRoles()
     * {
     *     return array('ROLE_USER');
     * }
     * </code>
     *
     * Alternatively, the roles might be stored on a ``roles`` property,
     * and populated in any number of different ways when the user object
     * is created.
     *
     * @return Role[] The user roles
     */
    public function getRoles()
    {
        return array('ROLE_USER');
    }

    /**
     * Returns the salt that was originally used to encode the password.
     *
     * This can return null if the password was not encoded using a salt.
     *
     * @return string|null The salt
     */
    public function getSalt()
    {
        return '';
        /**
         * A random numeric string (digits only) used to encrypt/decrypt strings.
         */
        //Configure::write('Security.cipherSeed', '7693096535424967464')
    }

    /**
     * Returns the username used to authenticate the user.
     *
     * @return string The username
     */
    public function getUsername()
    {
        return $this->getLastName() . ' ' . $this->getName();
    }

    /**
     * Removes sensitive data from the user.
     *
     * This is important if, at any given point, sensitive information like
     * the plain-text password is stored on this object.
     */
    public function eraseCredentials()
    {

    }


    /**
     * Get password
     *
     * @return string
     */
    public function getPassword()
    {
        return '';
    }











    /**
     * @var array
     */
    protected $roles;

    /**
     * @var integer
     */
    protected $commonId;

    /**
     * @var integer
     */
    protected $expertGroupId;

    /**
     * @var array
     */
    protected $permissions;

    /**
     * @var string
     */
    protected $subSystem;



    /**
     * @return guid|string
     */
    public function getCommonId()
    {
        return $this->commonId;
    }

    /**
     * @param guid|string $commonId
     *
     * @return Users
     */
    public function setCommonId($commonId)
    {
        $this->commonId = $commonId;

        return $this;
    }



    /**
     * @return guid
     */
    public function getExpertGroupId()
    {
        return $this->expertGroupId;
    }

    /**
     * @param guid|string $expertGroupId
     *
     * @return Users
     */
    public function setExpertGroupId($expertGroupId)
    {
        $this->expertGroupId = $expertGroupId;

        return $this;
    }

    /**
     * @return array
     */
    public function getPermissions()
    {
        return $this->permissions;
    }

    /**
     * @param array $permissions
     *
     * @return $this
     */
    public function setPermissions($permissions)
    {
        $this->permissions = $permissions;
        return $this;
    }

    /**
     * @param $permission
     * @param null $group
     * @return bool
     */
    public function hasPermission($permission, $group = null)
    {
        $permission = (array) $permission;
        /** @var \AnalyticsBundle\Entity\UsersExpertGroup $permissions */
        foreach ($this->getPermissions() as $permissions) {
            foreach ((array) $permissions->permissions as $p) {
                if (in_array($p['code'], $permission) && in_array($p['subSystem'], ['All_subsystems', $this->getSubSystem()])) {
                    return true;
                }
            }
        }

        // @todo Temporary always has permissions
        return true; // false;
    }

    /**
     * @return string
     */
    public function getSubSystem()
    {
        return $this->subSystem;
    }

    /**
     * @param string $subSystem
     *
     * @return Users
     */
    public function setSubSystem($subSystem = null)
    {
        $this->subSystem = $subSystem;

        return $this;
    }

    /**
     * Set deleted
     *
     * @param \DateTime $deleted
     * @return Users
     */
    public function setDeleted($deleted)
    {
        $this->deleted = $deleted;

        return $this;
    }
}
