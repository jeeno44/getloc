<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * WorkType
 *
 * @ORM\Table(
 *   name="work_type",
 *   uniqueConstraints={
 *     @ORM\UniqueConstraint(name="work_type_num_employee_key", columns={"num_employee"})
 *   },
 *   indexes={
 *     @ORM\Index(name="work_type_stage_id", columns={"stage_id"}),
 *     @ORM\Index(name="work_type_okved_id", columns={"okved_id"}),
 *     @ORM\Index(name="work_type_okei_id", columns={"okei_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\WorkTypeRepository")
 * @Json\Schema("WorkType")
 */
class WorkType implements IEntity
{
    const TYPE_LABOUR = 'labour';
    const TYPE_GOOD   = 'good';

    public static $type_list = [
        self::TYPE_LABOUR => 'Работа/Услуга',
        self::TYPE_GOOD   => 'Товар',
    ];

    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=32, nullable=false)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $type;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail", "notice_ea", "common_detail"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="qualitative_char", type="text", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $qualitativeChar;

    /**
     * @var string
     *
     * @ORM\Column(name="quantative_char", type="text", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $quantativeChar;

    /**
     * @var string
     *
     * @ORM\Column(name="result", type="text", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $result;

    /**
     * @var float
     *
     * @ORM\Column(name="price_per_unit", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "lots_consolidated", "work_kinds_detail", "common_detail"})
     */
    private $pricePerUnit;

    /**
     * @var string
     *
     * @ORM\Column(name="volume", type="decimal", precision=5, scale=2, nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $volume;

    /**
     * @var float
     *
     * @ORM\Column(name="financing", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $financing;

    /**
     * @var boolean
     *
     * @ORM\Column(name="starting_date", type="integer", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $startingDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="start_date", type="date", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $startDate;

    /**
     * @var boolean
     *
     * @ORM\Column(name="execution_date_term", type="boolean", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $executionDateTerm;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="execution_date", type="date", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $executionDate;

    /**
     * @var boolean
     *
     * @ORM\Column(name="execution_type", type="integer", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail"})
     */
    private $executionType;

    /**
     * @var integer
     *
     * @ORM\Column(name="execution_term", type="smallint", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $executionTerm;

    /**
     * @var integer
     *
     * @ORM\Column(name="num_employee", type="smallint", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $numEmployee;

    /**
     * @var integer
     *
     * @ORM\Column(name="duration", type="smallint", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail"})
     */
    private $duration;

    /**
     * @var string
     *
     * @ORM\Column(name="nmck_justification", type="text", nullable=true)
     * @JMS\Groups({"work_type", "work_type_detail", "lot_detail", "work_kinds_detail", "notice_ea", "common_detail"})
     */
    private $nmckJustification;

    /**
     * @var Okved
     *
     * @ORM\ManyToOne(targetEntity="Okved")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="okved_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"work_type_detail", "lot_detail"})
     */
    private $okved;

    /**
     * @var Stage
     *
     * @ORM\ManyToOne(targetEntity="Stage", inversedBy="workTypes")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="stage_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"work_type_detail", "lot_detail"})
     */
    private $stage;

    /**
     * @var Okei
     *
     * @ORM\ManyToOne(targetEntity="Okei")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="okei_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"work_type_detail", "lots_consolidated", "lot_detail", "common_detail"})
     */
    private $okei;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="NmckVariant", mappedBy="workType")
     * @JMS\Groups({"work_type_detail", "lot_detail"})
     */
    private $nmckVariant;

    /**
     * @var \Doctrine\Common\Collections\Collection|WorkKind[]
     *
     * @ORM\OneToMany(targetEntity="WorkKind", mappedBy="workType", cascade={"persist", "remove"})
     * @JMS\Groups({"lot_detail", "work_type_detail"})
     */
    private $workKinds;

    /**
     * @var string
     *
     * @ORM\Column(name="warranty", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "work_kinds_detail", "work_kinds_list"})
     */
    private $warranty;

    /**
     * @var string
     *
     * @ORM\Column(name="spec_requirements", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "work_kinds_detail", "work_kinds_list"})
     */
    private $specRequirements;

    /**
     * @var string
     *
     * @ORM\Column(name="gos_accred", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "work_kinds_detail", "work_kinds_list"})
     */
    private $gosAccred;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->nmckVariant = new \Doctrine\Common\Collections\ArrayCollection();
        $this->workKinds = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return WorkType
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return WorkType
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set qualitativeChar
     *
     * @param string $qualitativeChar
     * @return WorkType
     */
    public function setQualitativeChar($qualitativeChar)
    {
        $this->qualitativeChar = $qualitativeChar;

        return $this;
    }

    /**
     * Get qualitativeChar
     *
     * @return string 
     */
    public function getQualitativeChar()
    {
        return $this->qualitativeChar;
    }

    /**
     * Set quantativeChar
     *
     * @param string $quantativeChar
     * @return WorkType
     */
    public function setQuantativeChar($quantativeChar)
    {
        $this->quantativeChar = $quantativeChar;

        return $this;
    }

    /**
     * Get quantativeChar
     *
     * @return string 
     */
    public function getQuantativeChar()
    {
        return $this->quantativeChar;
    }

    /**
     * Set result
     *
     * @param string $result
     * @return WorkType
     */
    public function setResult($result)
    {
        $this->result = $result;

        return $this;
    }

    /**
     * Get result
     *
     * @return string
     */
    public function getResult()
    {
        return $this->result;
    }

    /**
     * Set pricePerUnit
     *
     * @param float $pricePerUnit
     * @return WorkType
     */
    public function setPricePerUnit($pricePerUnit)
    {
        $this->pricePerUnit = $pricePerUnit;

        return $this;
    }

    /**
     * Get pricePerUnit
     *
     * @return float 
     */
    public function getPricePerUnit()
    {
        return $this->pricePerUnit;
    }

    /**
     * Set volume
     *
     * @param float $volume
     * @return WorkType
     */
    public function setVolume($volume)
    {
        $this->volume = $volume;

        return $this;
    }

    /**
     * Get volume
     *
     * @return float
     */
    public function getVolume()
    {
        return $this->volume;
    }

    /**
     * Set financing
     *
     * @param float $financing
     * @return WorkType
     */
    public function setFinancing($financing)
    {
        $this->financing = $financing;

        return $this;
    }

    /**
     * Get financing
     *
     * @return float 
     */
    public function getFinancing()
    {
        return $this->financing;
    }

    /**
     * Set startingDate
     *
     * @param boolean $startingDate
     * @return WorkType
     */
    public function setStartingDate($startingDate)
    {
        $this->startingDate = $startingDate;

        return $this;
    }

    /**
     * Get startingDate
     *
     * @return boolean
     */
    public function getStartingDate()
    {
        return $this->startingDate;
    }

    /**
     * Set startDate
     *
     * @param \DateTime $startDate
     * @return WorkType
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;

        return $this;
    }

    /**
     * Get startDate
     *
     * @return \DateTime
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Set executionDateTerm
     *
     * @param boolean $executionDateTerm
     * @return WorkType
     */
    public function setExecutionDateTerm($executionDateTerm)
    {
        $this->executionDateTerm = $executionDateTerm;

        return $this;
    }

    /**
     * Get executionDateTerm
     *
     * @return boolean
     */
    public function getExecutionDateTerm()
    {
        return $this->executionDateTerm;
    }

    /**
     * Set executionDate
     *
     * @param \DateTime $executionDate
     * @return WorkType
     */
    public function setExecutionDate($executionDate)
    {
        $this->executionDate = $executionDate;

        return $this;
    }

    /**
     * Get executionDate
     *
     * @return \DateTime
     */
    public function getExecutionDate()
    {
        return $this->executionDate;
    }

    /**
     * Set executionTerm
     *
     * @param integer $executionTerm
     * @return WorkType
     */
    public function setExecutionTerm($executionTerm)
    {
        $this->executionTerm = $executionTerm;

        return $this;
    }

    /**
     * Get executionTerm
     *
     * @return integer
     */
    public function getExecutionTerm()
    {
        return $this->executionTerm;
    }

    /**
     * Set numEmployee
     *
     * @param integer $numEmployee
     * @return WorkType
     */
    public function setNumEmployee($numEmployee)
    {
        $this->numEmployee = $numEmployee;

        return $this;
    }

    /**
     * Get numEmployee
     *
     * @return integer
     */
    public function getNumEmployee()
    {
        return $this->numEmployee;
    }

    /**
     * Set duration
     *
     * @param integer $duration
     * @return WorkType
     */
    public function setDuration($duration)
    {
        $this->duration = $duration;

        return $this;
    }

    /**
     * Get duration
     *
     * @return integer
     */
    public function getDuration()
    {
        return $this->duration;
    }

    /**
     * Set okved
     *
     * @param \AnalyticsBundle\Entity\Okved $okved
     * @return WorkType
     */
    public function setOkved(\AnalyticsBundle\Entity\Okved $okved = null)
    {
        $this->okved = $okved;

        return $this;
    }

    /**
     * Get okved
     *
     * @return \AnalyticsBundle\Entity\Okved
     */
    public function getOkved()
    {
        return $this->okved;
    }

    /**
     * Set stage
     *
     * @param \AnalyticsBundle\Entity\Stage $stage
     * @return WorkType
     */
    public function setStage(\AnalyticsBundle\Entity\Stage $stage = null)
    {
        $this->stage = $stage;

        return $this;
    }

    /**
     * Get stage
     *
     * @return \AnalyticsBundle\Entity\Stage
     */
    public function getStage()
    {
        return $this->stage;
    }

    /**
     * Set okei
     *
     * @param \AnalyticsBundle\Entity\Okei $okei
     * @return WorkType
     */
    public function setOkei(\AnalyticsBundle\Entity\Okei $okei = null)
    {
        $this->okei = $okei;

        return $this;
    }

    /**
     * Get okei
     *
     * @return \AnalyticsBundle\Entity\Okei
     */
    public function getOkei()
    {
        return $this->okei;
    }

    /**
     * Add nmckVariant
     *
     * @param \AnalyticsBundle\Entity\NmckVariant $nmckVariant
     * @return WorkType
     */
    public function addNmckVariant(\AnalyticsBundle\Entity\NmckVariant $nmckVariant)
    {
        $this->nmckVariant[] = $nmckVariant;

        return $this;
    }

    /**
     * Remove nmckVariant
     *
     * @param \AnalyticsBundle\Entity\NmckVariant $nmckVariant
     */
    public function removeNmckVariant(\AnalyticsBundle\Entity\NmckVariant $nmckVariant)
    {
        $this->nmckVariant->removeElement($nmckVariant);
    }

    /**
     * Get nmckVariant
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getNmckVariant()
    {
        return $this->nmckVariant;
    }

    /**
     * @param \AnalyticsBundle\Entity\WorkKind $workKinds
     * @return WorkType
     */
    public function addWorkKind(\AnalyticsBundle\Entity\WorkKind $workKinds)
    {
        if (!$this->workKinds->contains($workKinds)) {
            $workKinds->setWorkType($this);

            $this->workKinds->add($workKinds);
        }

        return $this;
    }

    /**
     * @param \AnalyticsBundle\Entity\WorkKind $workKinds
     */
    public function removeWorkKind(\AnalyticsBundle\Entity\WorkKind $workKinds)
    {
        $this->workKinds->removeElement($workKinds);
    }

    /**
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getWorkKinds()
    {
        return $this->workKinds;
    }

    /**
     * @return boolean
     */
    public function isExecutionType()
    {
        return $this->executionType;
    }

    /**
     * @param boolean $executionType
     */
    public function setExecutionType($executionType)
    {
        $this->executionType = $executionType;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;

    /**
     * Get executionType
     *
     * @return integer 
     */
    public function getExecutionType()
    {
        return $this->executionType;
    }

    /**
     * Set warranty
     *
     * @param string $warranty
     * @return WorkType
     */
    public function setWarranty($warranty)
    {
        $this->warranty = $warranty;

        return $this;
    }

    /**
     * Get warranty
     *
     * @return string 
     */
    public function getWarranty()
    {
        return $this->warranty;
    }

    /**
     * Set specRequirements
     *
     * @param string $specRequirements
     * @return WorkType
     */
    public function setSpecRequirements($specRequirements)
    {
        $this->specRequirements = $specRequirements;

        return $this;
    }

    /**
     * Get specRequirements
     *
     * @return string 
     */
    public function getSpecRequirements()
    {
        return $this->specRequirements;
    }

    /**
     * Set gosAccred
     *
     * @param string $gosAccred
     * @return WorkType
     */
    public function setGosAccred($gosAccred)
    {
        $this->gosAccred = $gosAccred;

        return $this;
    }

    /**
     * Get gosAccred
     *
     * @return string 
     */
    public function getGosAccred()
    {
        return $this->gosAccred;
    }

    /**
     * Set nmckJustification
     *
     * @param string $nmckJustification
     * @return WorkType
     */
    public function setNmckJustification($nmckJustification)
    {
        $this->nmckJustification = $nmckJustification;

        return $this;
    }

    /**
     * Get nmckJustification
     *
     * @return string
     */
    public function getNmckJustification()
    {
        return $this->nmckJustification;
    }
}
