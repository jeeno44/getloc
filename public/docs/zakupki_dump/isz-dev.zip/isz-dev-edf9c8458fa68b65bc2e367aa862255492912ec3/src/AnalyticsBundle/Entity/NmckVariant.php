<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * NmckVariant
 *
 * @ORM\Table(name="nmck_variant", indexes={@ORM\Index(name="nmck_variant_nmck_type_id", columns={"nmck_type_id"})})
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\NmckVariantRepository")
 * @Json\Schema("NmckVariant")
 */
class NmckVariant implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var float
     *
     * @ORM\Column(name="value", type="float", precision=10, scale=0, nullable=true)
     */
    private $value;

    /**
     * @var string
     *
     * @ORM\Column(name="comment", type="text", nullable=true)
     */
    private $comment;

    /**
     * @var \NmckType
     *
     * @ORM\ManyToOne(targetEntity="NmckType")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="nmck_type_id", referencedColumnName="id")
     * })
     */
    private $nmckType;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="WorkType", inversedBy="nmckVariant")
     * @ORM\JoinTable(name="nmck_variant_work_type",
     *   joinColumns={
     *     @ORM\JoinColumn(name="nmck_variant_id", referencedColumnName="id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="work_type_id", referencedColumnName="id")
     *   }
     * )
     */
    private $workType;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->workType = new \Doctrine\Common\Collections\ArrayCollection();
        $this->nmckDocs = new \Doctrine\Common\Collections\ArrayCollection();
    }


    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set value
     *
     * @param float $value
     * @return NmckVariant
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return float 
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set comment
     *
     * @param string $comment
     * @return NmckVariant
     */
    public function setComment($comment)
    {
        $this->comment = $comment;

        return $this;
    }

    /**
     * Get comment
     *
     * @return string 
     */
    public function getComment()
    {
        return $this->comment;
    }

    /**
     * Set nmckType
     *
     * @param \AnalyticsBundle\Entity\NmckType $nmckType
     * @return NmckVariant
     */
    public function setNmckType(\AnalyticsBundle\Entity\NmckType $nmckType = null)
    {
        $this->nmckType = $nmckType;

        return $this;
    }

    /**
     * Get nmckType
     *
     * @return \AnalyticsBundle\Entity\NmckType
     */
    public function getNmckType()
    {
        return $this->nmckType;
    }

    /**
     * Add workType
     *
     * @param \AnalyticsBundle\Entity\WorkType $workType
     * @return NmckVariant
     */
    public function addWorkType(\AnalyticsBundle\Entity\WorkType $workType)
    {
        $this->workType[] = $workType;

        return $this;
    }

    /**
     * Remove workType
     *
     * @param \AnalyticsBundle\Entity\WorkType $workType
     */
    public function removeWorkType(\AnalyticsBundle\Entity\WorkType $workType)
    {
        $this->workType->removeElement($workType);
    }

    /**
     * Get workType
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getWorkType()
    {
        return $this->workType;
    }
}
