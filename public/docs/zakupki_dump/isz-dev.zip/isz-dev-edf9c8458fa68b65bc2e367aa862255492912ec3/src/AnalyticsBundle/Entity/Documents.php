<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * Documents
 *
 * @ORM\Table(name="documents")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\DocumentsRepository")
 * @Json\Schema("Documents")
 */
class Documents implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="desc", type="text", nullable=true)
     */
    private $desc;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Protocol1", mappedBy="documents")
     */
    private $protocol1;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->protocol1 = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Documents
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set desc
     *
     * @param string $desc
     * @return Documents
     */
    public function setDesc($desc)
    {
        $this->desc = $desc;

        return $this;
    }

    /**
     * Get desc
     *
     * @return string 
     */
    public function getDesc()
    {
        return $this->desc;
    }

    /**
     * Add protocol1
     *
     * @param \AnalyticsBundle\Entity\Protocol1 $protocol1
     * @return Documents
     */
    public function addProtocol1(\AnalyticsBundle\Entity\Protocol1 $protocol1)
    {
        $this->protocol1[] = $protocol1;

        return $this;
    }

    /**
     * Remove protocol1
     *
     * @param \AnalyticsBundle\Entity\Protocol1 $protocol1
     */
    public function removeProtocol1(\AnalyticsBundle\Entity\Protocol1 $protocol1)
    {
        $this->protocol1->removeElement($protocol1);
    }

    /**
     * Get protocol1
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getProtocol1()
    {
        return $this->protocol1;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
