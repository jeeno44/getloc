<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * NmckJustification
 *
 * @ORM\Table(name="nmck_justification")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\NmckJustificationRepository")
 * @Json\Schema("NmckJustification")
 */
class NmckJustification implements IEntity
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"nmck_justification_detail", "lot_detail"})
     */
    private $id;

    /**
     * @var float
     *
     * @ORM\Column(name="price", type="float", nullable=true)
     * @JMS\Groups({"nmck_justification_detail", "lot_detail", "notice_ea"})
     */
    private $price;

    /**
     * @var string
     *
     * @ORM\Column(name="comment", type="text", nullable=true)
     * @JMS\Groups({"nmck_justification_detail", "lot_detail"})
     */
    private $comment;

    /**
     * @var string
     *
     * @ORM\Column(name="justification", type="text", nullable=true)
     * @JMS\Groups({"nmck_justification_detail", "lot_detail"})
     */
    private $justification;

    /**
     * @var string
     *
     * @ORM\Column(name="url", type="text", nullable=true)
     * @JMS\Groups({"nmck_justification_detail", "lot_detail"})
     */
    private $url;

    /**
     * @var string
     *
     * @ORM\Column(name="file", type="string", length=255, nullable=true)
     * @JMS\Groups({"nmck_justification_detail", "lot_detail"})
     */
    private $file;

    /**
     * @var Lot
     *
     * @ORM\ManyToOne(targetEntity="Lot", inversedBy="nmckJustification")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     */
    private $lot;


    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set price
     *
     * @param float $price
     * @return NmckJustification
     */
    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    /**
     * Get price
     *
     * @return float
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set comment
     *
     * @param string $comment
     * @return NmckJustification
     */
    public function setComment($comment)
    {
        $this->comment = $comment;

        return $this;
    }

    /**
     * Get comment
     *
     * @return string
     */
    public function getComment()
    {
        return $this->comment;
    }

    /**
     * Set justification
     *
     * @param string $justification
     * @return NmckJustification
     */
    public function setJustification($justification)
    {
        $this->justification = $justification;

        return $this;
    }

    /**
     * Get justification
     *
     * @return string
     */
    public function getJustification()
    {
        return $this->justification;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     * @return NmckJustification
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * Set url
     *
     * @param string $url
     * @return NmckJustification
     */
    public function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    /**
     * Get url
     *
     * @return string 
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * Set file
     *
     * @param string $file
     * @return NmckJustification
     */
    public function setFile($file)
    {
        $this->file = $file;

        return $this;
    }

    /**
     * Get file
     *
     * @return string
     */
    public function getFile()
    {
        return $this->file;
    }
}
