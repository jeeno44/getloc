<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;
use Swagger\Annotations as SWG;

/**
 * Экспертные группы нужны для того что бы во первых в них добавить всех работников организаций (type=common) и одна из
 * главных причин появления экспертных групп, это создания групп для экспертиз лотов/планов, других объектов системы
 *
 * @ORM\Table(
 *   name="expert_group",
 *   indexes={
 *     @ORM\Index(name="expert_group_parent_id", columns={"parent_id"}),
 *     @ORM\Index(name="expert_group_common_id", columns={"common_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\ExpertGroupRepository")
 * @Json\Schema("ExpertGroup")
 *
 * @SWG\Definition(definition="ExpertGroup",
 *   @SWG\Property(property="id", type="string", description="ID экспертной группы"),
 *   @SWG\Property(property="title", type="string", description="Название"),
 *   @SWG\Property(property="type", type="string", description="Тип (common|expert)"),
 *   @SWG\Property(property="parent", ref="#/definitions/ExpertGroup", description="Родительский элемент"),
 *   @SWG\Property(
 *     property="children",
 *     type="array",
 *     @SWG\Items(ref="#/definitions/ExpertGroup"),
 *     description="Дочерние элементы"
 *   ),
 *   @SWG\Property(property="common", ref="#/definitions/Common", description="???")
 * )
 */
class ExpertGroup implements IEntity
{
    const TYPE_COMMON = 'common';  // Группа организации - в неё должны включаться все пользователи системы которые
                                   // работают в этой организации, она должна быть одна в пределах одной организации
    const TYPE_EXPERT = 'expert';  // Группа экспетов - создаются для проведения экспертиз, их может быть множество

    const TYPE_MONITOR = 'monitor';  // Группа экспетов - создаются для проведения экспертиз, их может быть множество

    public static $type_lists = [
        self::TYPE_COMMON => 'Организация',
        self::TYPE_EXPERT => 'Эксперты',
        self::TYPE_MONITOR => 'Организация монитор',
    ];

    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"expert_group", "expert_group_list", "expert_group_detail", "users_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     * @JMS\Groups({"expert_group", "expert_group_list", "expert_group_detail", "users_detail"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=32, nullable=true)
     * @JMS\Groups({"expert_group", "expert_group_list", "expert_group_detail", "users_detail"})
     */
    private $type;

    /**
     * @var ExpertGroup
     *
     * @ORM\ManyToOne(targetEntity="ExpertGroup")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"expert_group_detail"})
     */

    private $parent;

    /**
     * @var ExpertGroup
     *
     * @ORM\ManyToOne(targetEntity="ExpertGroup")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"expert_group_detail"})
     */
    private $parentHiden;

    /**
     * @var ExpertGroup[]
     *
     * @ORM\OneToMany(targetEntity="ExpertGroup",  mappedBy="parentHiden")
     * @JMS\Groups({"expert_group", "expert_group_list", "expert_group_detail", "users_detail", "users_expert_group_detail"})
     */
    private $children;

    /**
     * @var Common
     *
     * @ORM\ManyToOne(targetEntity="Common", inversedBy="expertGroups")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="common_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"users_detail"})
     */
    private $common;

    /**
     * @var UsersExpertGroup
     *
     * @ORM\OneToMany(targetEntity="UsersExpertGroup", mappedBy="expertGroup", cascade={"remove"})
     * @JMS\Groups({"expert_group", "expert_group_list", "expert_group_list", "expert_group_detail"})
     */
    private $usersExpertGroups;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="AnalyticsBundle\Entity\Users", inversedBy="expertGroup")
     * @ORM\JoinTable(name="users_expert_group",
     *   joinColumns={
     *     @ORM\JoinColumn(name="expert_group_id", referencedColumnName="id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="users_id", referencedColumnName="id")
     *   }
     * )
     * @JMS\Groups({"expert_group_detail"})
     */
    private $users;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->users = new \Doctrine\Common\Collections\ArrayCollection();
        $this->usersExpertGroups = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return ExpertGroup
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return ExpertGroup
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set parent
     *
     * @param \AnalyticsBundle\Entity\ExpertGroup $parent
     * @return ExpertGroup
     */
    public function setParent(\AnalyticsBundle\Entity\ExpertGroup $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \AnalyticsBundle\Entity\ExpertGroup
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Set common
     *
     * @param \AnalyticsBundle\Entity\Common $common
     * @return ExpertGroup
     */
    public function setCommon(\AnalyticsBundle\Entity\Common $common = null)
    {
        $this->common = $common;

        return $this;
    }

    /**
     * Get common
     *
     * @return \AnalyticsBundle\Entity\Common
     */
    public function getCommon()
    {
        return $this->common;
    }

    /**
     * Add users
     *
     * @param \AnalyticsBundle\Entity\Users $users
     * @return Common
     */
    public function addUser(\AnalyticsBundle\Entity\Users $users)
    {
        if (!$this->users->contains($users)) {
            $this->users[] = $users;
        }

        return $this;
    }

    /**
     * Remove users
     *
     * @param \AnalyticsBundle\Entity\Users $users
     */
    public function removeUser(\AnalyticsBundle\Entity\Users $users)
    {
        $this->users->removeElement($users);
    }

    /**
     * Get users
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUsers()
    {
        return $this->users;
    }

    /**
     * Add usersExpertGroups
     *
     * @param \AnalyticsBundle\Entity\UsersExpertGroup $usersExpertGroups
     * @return ExpertGroup
     */
    public function addUsersExpertGroup(\AnalyticsBundle\Entity\UsersExpertGroup $usersExpertGroups)
    {
        $this->usersExpertGroups[] = $usersExpertGroups;

        return $this;
    }

    /**
     * Remove usersExpertGroups
     *
     * @param \AnalyticsBundle\Entity\UsersExpertGroup $usersExpertGroups
     */
    public function removeUsersExpertGroup(\AnalyticsBundle\Entity\UsersExpertGroup $usersExpertGroups)
    {
        $this->usersExpertGroups->removeElement($usersExpertGroups);
    }

    /**
     * Get usersExpertGroups
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUsersExpertGroups()
    {
        return $this->usersExpertGroups;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
