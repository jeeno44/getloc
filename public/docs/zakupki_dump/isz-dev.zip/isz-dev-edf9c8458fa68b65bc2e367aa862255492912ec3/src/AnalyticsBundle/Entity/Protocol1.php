<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * Protocol1
 *
 * @ORM\Table(name="protocol1", indexes={@ORM\Index(name="protocol1_commission_id", columns={"commission_id"}), @ORM\Index(name="protocol1_lot_id", columns={"lot_id"})})
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\Protocol1Repository")
 * @Json\Schema("Protocol1")
 */
class Protocol1 implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     */
    private $title;

    /**
     * @var float
     *
     * @ORM\Column(name="total_financing", type="float", precision=10, scale=0, nullable=true)
     */
    private $totalFinancing;

    /**
     * @var string
     *
     * @ORM\Column(name="supp_qualification", type="text", nullable=true)
     */
    private $suppQualification;

    /**
     * @var string
     *
     * @ORM\Column(name="char_description", type="text", nullable=true)
     */
    private $charDescription;

    /**
     * @var \Commission
     *
     * @ORM\ManyToOne(targetEntity="Commission")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="commission_id", referencedColumnName="id")
     * })
     */
    private $commission;

    /**
     * @var \Lot
     *
     * @ORM\ManyToOne(targetEntity="Lot")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     */
    private $lot;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Documents", inversedBy="protocol1")
     * @ORM\JoinTable(name="protocol1_documents",
     *   joinColumns={
     *     @ORM\JoinColumn(name="protocol1_id", referencedColumnName="id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="documents_id", referencedColumnName="id")
     *   }
     * )
     */
    private $documents;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->documents = new \Doctrine\Common\Collections\ArrayCollection();
    }


    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Protocol1
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set totalFinancing
     *
     * @param float $totalFinancing
     * @return Protocol1
     */
    public function setTotalFinancing($totalFinancing)
    {
        $this->totalFinancing = $totalFinancing;

        return $this;
    }

    /**
     * Get totalFinancing
     *
     * @return float 
     */
    public function getTotalFinancing()
    {
        return $this->totalFinancing;
    }

    /**
     * Set suppQualification
     *
     * @param string $suppQualification
     * @return Protocol1
     */
    public function setSuppQualification($suppQualification)
    {
        $this->suppQualification = $suppQualification;

        return $this;
    }

    /**
     * Get suppQualification
     *
     * @return string 
     */
    public function getSuppQualification()
    {
        return $this->suppQualification;
    }

    /**
     * Set charDescription
     *
     * @param string $charDescription
     * @return Protocol1
     */
    public function setCharDescription($charDescription)
    {
        $this->charDescription = $charDescription;

        return $this;
    }

    /**
     * Get charDescription
     *
     * @return string 
     */
    public function getCharDescription()
    {
        return $this->charDescription;
    }

    /**
     * Set commission
     *
     * @param \AnalyticsBundle\Entity\Commission $commission
     * @return Protocol1
     */
    public function setCommission(\AnalyticsBundle\Entity\Commission $commission = null)
    {
        $this->commission = $commission;

        return $this;
    }

    /**
     * Get commission
     *
     * @return \AnalyticsBundle\Entity\Commission
     */
    public function getCommission()
    {
        return $this->commission;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     * @return Protocol1
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * Add documents
     *
     * @param \AnalyticsBundle\Entity\Documents $documents
     * @return Protocol1
     */
    public function addDocument(\AnalyticsBundle\Entity\Documents $documents)
    {
        $this->documents[] = $documents;

        return $this;
    }

    /**
     * Remove documents
     *
     * @param \AnalyticsBundle\Entity\Documents $documents
     */
    public function removeDocument(\AnalyticsBundle\Entity\Documents $documents)
    {
        $this->documents->removeElement($documents);
    }

    /**
     * Get documents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getDocuments()
    {
        return $this->documents;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
