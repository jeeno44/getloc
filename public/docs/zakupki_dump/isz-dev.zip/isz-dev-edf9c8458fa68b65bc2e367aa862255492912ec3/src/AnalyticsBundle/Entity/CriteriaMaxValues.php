<?php

namespace AnalyticsBundle\Entity;

use AnalyticsBundle\Entity\IEntity;
use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * CriteriaMaxValues
 *
 * @ORM\Table(
 *     name="criteria_max_values",
 *     indexes={
 *      @ORM\Index(name="criteria_max_values_criteria_condition_id", columns={"criteria_condition_id"}),
 *      @ORM\Index(name="criteria_max_values_criteria_type_id", columns={"criteria_type_id"})
 *     }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\CriteriaMaxValuesRepository")
 * @Json\Schema("CriteriaMaxValues")
 */
class CriteriaMaxValues implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="SEQUENCE")
     * @ORM\SequenceGenerator(sequenceName="criteria_max_values_id_seq", allocationSize=1, initialValue=1)
     * @JMS\Groups({"CriteriaMaxValues"})
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="min_value", type="smallint", nullable=true)
     * @JMS\Groups({"CriteriaMaxValues"})
     */
    private $minValue;

    /**
     * @var int
     *
     * @ORM\Column(name="max_value", type="smallint", nullable=true)
     * @JMS\Groups({"CriteriaMaxValues"})
     */
    private $maxValue;

    /**
     * @var \CriteriaCondition
     *
     * @ORM\ManyToOne(targetEntity="CriteriaCondition")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="criteria_condition_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"CriteriaMaxValues_detail", "CriteriaCondition"})
     */
    private $criteriaCondition;

    /**
     * @var \CriteriaType
     *
     * @ORM\ManyToOne(targetEntity="CriteriaType")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="criteria_type_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"CriteriaMaxValues_detail", "CriteriaCondition"})
     * @Json\Ignore
     */
    private $criteriaType;

    use \AnalyticsBundle\Versionable\VersionableTrait;


    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set minValue
     *
     * @param int $minValue
     *
     * @return CriteriaMaxValues
     */
    public function setMinValue($minValue)
    {
        $this->minValue = $minValue;

        return $this;
    }

    /**
     * Get minValue
     *
     * @return int
     */
    public function getMinValue()
    {
        return $this->minValue;
    }

    /**
     * Set maxValue
     *
     * @param int $maxValue
     *
     * @return CriteriaMaxValues
     */
    public function setMaxValue($maxValue)
    {
        $this->maxValue = $maxValue;

        return $this;
    }

    /**
     * Get maxValue
     *
     * @return int
     */
    public function getMaxValue()
    {
        return $this->maxValue;
    }

    /**
     * Set criteriaCondition
     *
     * @param \AnalyticsBundle\Entity\CriteriaCondition $criteriaCondition
     *
     * @return CriteriaMaxValues
     */
    public function setCriteriaCondition(\AnalyticsBundle\Entity\CriteriaCondition $criteriaCondition = null)
    {
        $this->criteriaCondition = $criteriaCondition;

        return $this;
    }

    /**
     * Get criteriaCondition
     *
     * @return \AnalyticsBundle\Entity\CriteriaCondition
     */
    public function getCriteriaCondition()
    {
        return $this->criteriaCondition;
    }

    /**
     * Set criteriaType
     *
     * @param \AnalyticsBundle\Entity\CriteriaType $criteriaType
     *
     * @return CriteriaMaxValues
     */
    public function setCriteriaType(\AnalyticsBundle\Entity\CriteriaType $criteriaType = null)
    {
        $this->criteriaType = $criteriaType;

        return $this;
    }

    /**
     * Get criteriaType
     *
     * @return \AnalyticsBundle\Entity\CriteriaType
     */
    public function getCriteriaType()
    {
        return $this->criteriaType;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getId();
    }
}
