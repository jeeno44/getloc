<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * FcpAction
 *
 * @ORM\Table(
 *   name="fcp_action",
 *   indexes={
 *     @ORM\Index(name="fcp_action_fcp_id", columns={"fcp_id"}),
 *     @ORM\Index(name="fcp_action_parent_id", columns={"parent_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\FcpActionRepository")
 * @Json\Schema("FcpAction")
 */
class FcpAction implements IEntity
{
    const TYPE_TASK = 'task';
    const TYPE_ACTION = 'action';
    const TYPE_SUBACTION = 'subaction';

    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"fcp_action", "lot_detail", "financing_limits"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"fcp_action", "lot_detail", "lot_list", "financing_limits", "lot_item_plans"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="number", type="string", length=255, nullable=true)
     * @JMS\Groups({"fcp_action", "lot_detail", "financing_limits", "lot_list"})
     */
    private $number;

    /**
     * @var integer
     *
     * @ORM\Column(name="financing_type_num", type="integer", nullable=true)
     * @JMS\Groups({"lot_list", "lot_detail", "fcp_action_detail", "financing_limits"})
     */
    private $financingTypeNum;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=32, nullable=true)
     * @JMS\Groups({"fcp_action", "financing_limits", "lot_item_plans"})
     */
    private $type;

    /**
     * @var FcpAction
     *
     * @ORM\ManyToOne(targetEntity="FcpAction")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_list", "lot_detail", "fcp_action_detail", "financing_limits", "lot_item_plans"})
     */
    private $parent;

    /**
     * @var Fcp
     *
     * @ORM\ManyToOne(targetEntity="Fcp")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_list", "fcp_action_detail", "lot_detail", "financing_limits"})
     */
    private $fcp;

    /**
     * @var string
     *
     * @ORM\Column(name="ksuf_id", type="string", length=64, nullable=true)
     */
    private $ksufId;


    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return FcpAction
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set number
     *
     * @param string $number
     * @return FcpAction
     */
    public function setNumber($number)
    {
        $this->number = $number;

        return $this;
    }

    /**
     * Get number
     *
     * @return string
     */
    public function getNumber()
    {
        return $this->number;
    }

    /**
     * Set financingTypeNum
     *
     * @param integer $financingTypeNum
     * @return FcpAction
     */
    public function setFinancingTypeNum($financingTypeNum)
    {
        $this->financingTypeNum = $financingTypeNum;

        return $this;
    }

    /**
     * Get financingTypeNum
     *
     * @return integer
     */
    public function getFinancingTypeNum()
    {
        return $this->financingTypeNum;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return FcpAction
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set parent
     *
     * @param \AnalyticsBundle\Entity\FcpAction $parent
     * @return FcpAction
     */
    public function setParent(\AnalyticsBundle\Entity\FcpAction $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \AnalyticsBundle\Entity\FcpAction
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Set fcp
     *
     * @param \AnalyticsBundle\Entity\Fcp $fcp
     * @return FcpAction
     */
    public function setFcp(\AnalyticsBundle\Entity\Fcp $fcp = null)
    {
        $this->fcp = $fcp;

        return $this;
    }

    /**
     * Get fcp
     *
     * @return \AnalyticsBundle\Entity\Fcp
     */
    public function getFcp()
    {
        return $this->fcp;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;

    /**
     * Set ksufId
     *
     * @param string $ksufId
     * @return FcpAction
     */
    public function setKsufId($ksufId)
    {
        $this->ksufId = $ksufId;

        return $this;
    }

    /**
     * Get ksufId
     *
     * @return string 
     */
    public function getKsufId()
    {
        return $this->ksufId;
    }
}
