<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * GovProgram
 *
 * @ORM\Table(
 *   name="gov_program",
 *   indexes={
 *     @ORM\Index(name="gov_program_execution_enddate", columns={"execution_enddate"}),
 *     @ORM\Index(name="gov_program_executor_id", columns={"executor_id"}),
 *     @ORM\Index(name="gov_program_co_executor_id", columns={"co_executor_id"}),
 *     @ORM\Index(name="gov_program_parent_id", columns={"parent_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\GovProgramRepository")
 * @Json\Schema("GovProgram")
 */
class GovProgram implements IEntity
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"gov_program", "lot_detail", "expert_light"})
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="execution_enddate", type="date", nullable=true)
     */
    private $executionEnddate;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"gov_program", "lot_detail", "expert_light"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="number", type="string", length=255, nullable=true)
     * @JMS\Groups({"gov_program", "lot_detail", "lot_list", "expert_light"})
     */
    private $number;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="exectuion_startdate", type="date", nullable=true)
     */
    private $exectuionStartdate;

    /**
     * @var string
     *
     * @ORM\Column(name="goals", type="text", nullable=true)
     */
    private $goals;

    /**
     * @var string
     *
     * @ORM\Column(name="tasks", type="text", nullable=true)
     */
    private $tasks;

    /**
     * @var GovProgram
     *
     * @ORM\ManyToOne(targetEntity="GovProgram")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     * })
     */
    private $parent;

    /**
     * @var Common
     *
     * @ORM\ManyToOne(targetEntity="Common")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="executor_id", referencedColumnName="id")
     * })
     */
    private $executor;

    /**
     * @var Common
     *
     * @ORM\ManyToOne(targetEntity="Common")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="co_executor_id", referencedColumnName="id")
     * })
     */
    private $coExecutor;

    /**
     * @var string
     *
     * @ORM\Column(name="ksuf_id", type="string", length=64, nullable=true)
     */
    private $ksufId;


    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set executionEnddate
     *
     * @param \DateTime $executionEnddate
     * @return GovProgram
     */
    public function setExecutionEnddate($executionEnddate)
    {
        $this->executionEnddate = $executionEnddate;

        return $this;
    }

    /**
     * Get executionEnddate
     *
     * @return \DateTime
     */
    public function getExecutionEnddate()
    {
        return $this->executionEnddate;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return GovProgram
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set number
     *
     * @param string $number
     * @return GovProgram
     */
    public function setNumber($number)
    {
        $this->number = $number;

        return $this;
    }

    /**
     * Get number
     *
     * @return string
     */
    public function getNumber()
    {
        return $this->number;
    }

    /**
     * Set exectuionStartdate
     *
     * @param \DateTime $exectuionStartdate
     * @return GovProgram
     */
    public function setExectuionStartdate($exectuionStartdate)
    {
        $this->exectuionStartdate = $exectuionStartdate;

        return $this;
    }

    /**
     * Get exectuionStartdate
     *
     * @return \DateTime 
     */
    public function getExectuionStartdate()
    {
        return $this->exectuionStartdate;
    }

    /**
     * Set goals
     *
     * @param string $goals
     * @return GovProgram
     */
    public function setGoals($goals)
    {
        $this->goals = $goals;

        return $this;
    }

    /**
     * Get goals
     *
     * @return string 
     */
    public function getGoals()
    {
        return $this->goals;
    }

    /**
     * Set tasks
     *
     * @param string $tasks
     * @return GovProgram
     */
    public function setTasks($tasks)
    {
        $this->tasks = $tasks;

        return $this;
    }

    /**
     * Get tasks
     *
     * @return string 
     */
    public function getTasks()
    {
        return $this->tasks;
    }

    /**
     * Set parent
     *
     * @param \AnalyticsBundle\Entity\GovProgram $parent
     * @return GovProgram
     */
    public function setParent(\AnalyticsBundle\Entity\GovProgram $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \AnalyticsBundle\Entity\GovProgram
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Set executor
     *
     * @param \AnalyticsBundle\Entity\Common $executor
     * @return GovProgram
     */
    public function setExecutor(\AnalyticsBundle\Entity\Common $executor = null)
    {
        $this->executor = $executor;

        return $this;
    }

    /**
     * Get executor
     *
     * @return \AnalyticsBundle\Entity\Common
     */
    public function getExecutor()
    {
        return $this->executor;
    }

    /**
     * Set coExecutor
     *
     * @param \AnalyticsBundle\Entity\Common $coExecutor
     * @return GovProgram
     */
    public function setCoExecutor(\AnalyticsBundle\Entity\Common $coExecutor = null)
    {
        $this->coExecutor = $coExecutor;

        return $this;
    }

    /**
     * Get coExecutor
     *
     * @return \AnalyticsBundle\Entity\Common
     */
    public function getCoExecutor()
    {
        return $this->coExecutor;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;

    /**
     * Set ksufId
     *
     * @param string $ksufId
     * @return GovProgram
     */
    public function setKsufId($ksufId)
    {
        $this->ksufId = $ksufId;

        return $this;
    }

    /**
     * Get ksufId
     *
     * @return string
     */
    public function getKsufId()
    {
        return $this->ksufId;
    }
}
