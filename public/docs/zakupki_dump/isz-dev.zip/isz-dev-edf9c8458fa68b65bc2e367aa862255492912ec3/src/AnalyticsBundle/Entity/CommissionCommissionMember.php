<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * CommissionCommissionMember
 *
 * @ORM\Table(
 *   name="commission_commission_member",
 *   uniqueConstraints={
 *     @ORM\UniqueConstraint(
 *       name="commission_id_member_role",
 *       columns={"commission_id", "commission_member_id", "commission_role_id"}
 *     )
 *   },
 *   indexes={
 *     @ORM\Index(name="commission_commission_member_commission_role_id", columns={"commission_role_id"}),
 *     @ORM\Index(name="commission_commission_member_commission_id", columns={"commission_id"}),
 *     @ORM\Index(name="commission_commission_member_commission_member_id", columns={"commission_member_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\CommissionCommissionMemberRepository")
 * @Json\Schema("CommissionCommissionMember")
 */
class CommissionCommissionMember implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var Commission
     *
     * @ORM\ManyToOne(targetEntity="Commission")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="commission_id", referencedColumnName="id")
     * })
     */
    private $commission;

    /**
     * @var CommissionMember
     *
     * @ORM\ManyToOne(targetEntity="CommissionMember")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="commission_member_id", referencedColumnName="id")
     * })
     */
    private $commissionMember;

    /**
     * @var CommissionRole
     *
     * @ORM\ManyToOne(targetEntity="CommissionRole")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="commission_role_id", referencedColumnName="id")
     * })
     */
    private $commissionRole;


    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set commission
     *
     * @param \AnalyticsBundle\Entity\Commission $commission
     * @return CommissionCommissionMember
     */
    public function setCommission(\AnalyticsBundle\Entity\Commission $commission = null)
    {
        $this->commission = $commission;

        return $this;
    }

    /**
     * Get commission
     *
     * @return \AnalyticsBundle\Entity\Commission
     */
    public function getCommission()
    {
        return $this->commission;
    }

    /**
     * Set commissionMember
     *
     * @param \AnalyticsBundle\Entity\CommissionMember $commissionMember
     * @return CommissionCommissionMember
     */
    public function setCommissionMember(\AnalyticsBundle\Entity\CommissionMember $commissionMember = null)
    {
        $this->commissionMember = $commissionMember;

        return $this;
    }

    /**
     * Get commissionMember
     *
     * @return \AnalyticsBundle\Entity\CommissionMember
     */
    public function getCommissionMember()
    {
        return $this->commissionMember;
    }

    /**
     * Set commissionRole
     *
     * @param \AnalyticsBundle\Entity\CommissionRole $commissionRole
     * @return CommissionCommissionMember
     */
    public function setCommissionRole(\AnalyticsBundle\Entity\CommissionRole $commissionRole = null)
    {
        $this->commissionRole = $commissionRole;

        return $this;
    }

    /**
     * Get commissionRole
     *
     * @return \AnalyticsBundle\Entity\CommissionRole
     */
    public function getCommissionRole()
    {
        return $this->commissionRole;
    }
}
