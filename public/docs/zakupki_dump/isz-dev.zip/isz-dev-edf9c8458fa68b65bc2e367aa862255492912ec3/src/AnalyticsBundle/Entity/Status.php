<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Status
 *
 * @ORM\Table(
 *     name="status",
 *     indexes={
 *         @ORM\Index(name="status_id", columns={"id"})
 *     }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\StatusRepository")
 * @Json\Schema("Status")
 */
class Status
{
    const OBJECT_TYPE_PLAN = 'plan';
    const OBJECT_TYPE_CPZ  = 'cpz';
    const OBJECT_TYPE_LOT  = 'lot';

    const SUB_SYSTEM_FP_PLANIROVANIE = 'fp_planirovanie';
    const SUB_SYSTEM_FP_DOCUMENTS    = 'fp_documents';
    const SUB_SYSTEM_FP_PROCEDURES   = 'fp_procedures';
    const SUB_SYSTEM_FP_PRIEMKA      = 'fp_priemka';

    /**
     * Список типов
     *
     * @var array
     */
    public static $objectTypeList = [
        self::OBJECT_TYPE_PLAN  => 'План',
        self::OBJECT_TYPE_CPZ   => 'ЧПЗ',
        self::OBJECT_TYPE_LOT   => 'Лот',
    ];

    /**
     * Список подсистем
     *
     * @var array
     */
    public static $subSystemList = [
        self::SUB_SYSTEM_FP_PLANIROVANIE => 'Планирование',
        self::SUB_SYSTEM_FP_DOCUMENTS    => 'Документы',
        self::SUB_SYSTEM_FP_PROCEDURES   => 'Процедуры',
        self::SUB_SYSTEM_FP_PRIEMKA      => 'Приёмка',
    ];

    /**
     * @var string
     *
     * @ORM\Column(name="type_object", type="string", length=32, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $typeObject;

    /**
     * @var string
     *
     * @ORM\Column(name="sub_system", type="string", length=64, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $subSystem;

    /**
     * @var string
     *
     * @ORM\Column(name="id", type="string", length=32, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=64, nullable=false)
     */
    private $title;

    /**
     * Set typeObject
     *
     * @param string $typeObject
     * @return Status
     */
    public function setTypeObject($typeObject)
    {
        $this->typeObject = $typeObject;

        return $this;
    }

    /**
     * Get typeObject
     *
     * @return string 
     */
    public function getTypeObject()
    {
        return $this->typeObject;
    }

    /**
     * Set id
     *
     * @param string $id
     * @return Status
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get id
     *
     * @return string 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Status
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    /**
     * Set subSystem
     *
     * @param string $subSystem
     * @return Status
     */
    public function setSubSystem($subSystem)
    {
        $this->subSystem = $subSystem;

        return $this;
    }

    /**
     * Get subSystem
     *
     * @return string 
     */
    public function getSubSystem()
    {
        return $this->subSystem;
    }
}
