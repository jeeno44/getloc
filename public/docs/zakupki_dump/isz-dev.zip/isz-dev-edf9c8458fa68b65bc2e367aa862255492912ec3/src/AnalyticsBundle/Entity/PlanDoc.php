<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * PlanDoc
 *
 * @ORM\Table(name="plan_doc")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\PlanDocRepository")
 * @Json\Schema("PlanDoc")
 */
class PlanDoc implements IEntity
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"plan_list", "plan_detail", "lot_detail", "lot_list", "plan_common", "plan_current", "plan_next", "plan_doc_detail", "plan_doc_list", "common_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     * @JMS\Groups({"plan_list", "plan_detail", "lot_detail", "lot_list", "plan_common", "plan_current", "plan_next", "plan_doc_detail", "plan_doc_list", "Plan_zakupki", "common_detail"})
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     * @JMS\Groups({"plan_list", "plan_detail", "lot_detail", "lot_list", "plan_common", "plan_current", "plan_next", "plan_doc_detail", "plan_doc_list", "Plan_zakupki", "common_detail"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     * @JMS\Groups({"plan_list", "plan_detail", "lot_detail", "lot_list", "plan_common", "common_detail"})
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="file", type="string", length=255, nullable=true)
     * @JMS\Groups({"plan_list", "plan_detail", "lot_detail", "lot_list", "plan_common", "plan_current", "plan_next", "plan_doc_detail", "plan_doc_list", "Plan_zakupki", "common_detail"})
     */
    private $file;

    /**
     * @var Plan
     *
     * @ORM\ManyToOne(targetEntity="Plan")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="plan_id", referencedColumnName="id", nullable=true)
     * })
     */
    private $plan;

    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return PlanDoc
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        if (!$this->name) {
            return basename($this->getFile());
        }

        return $this->name;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return PlanDoc
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set decs
     *
     * @param string $decs
     * @return PlanDoc
     */
    public function setDescription($decs)
    {
        $this->description = $decs;

        return $this;
    }

    /**
     * Get decs
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set file
     *
     * @param string $file
     * @return PlanDoc
     */
    public function setFile($file)
    {
        $this->file = $file;

        return $this;
    }

    /**
     * Get file
     *
     * @return string
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * @return mixed
     */
    public function getPlan()
    {
        return $this->plan;
    }

    /**
     * @param \AnalyticsBundle\Entity\Plan $plan
     */
    public function setPlan(\AnalyticsBundle\Entity\Plan $plan)
    {
        $this->plan = $plan;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getTitle();
    }
}
