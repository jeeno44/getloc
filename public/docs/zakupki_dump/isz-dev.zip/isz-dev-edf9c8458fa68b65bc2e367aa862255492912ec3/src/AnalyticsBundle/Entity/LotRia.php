<?php

namespace AnalyticsBundle\Entity;

use AnalyticsBundle\Entity\IEntity;
use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Ria
 *
 * @ORM\Table(name="lot_ria")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\LotRiaRepository")
 * @Json\Schema("LotRia")
 */
class LotRia implements IEntity
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"LotRia"})
     */
    private $id;

    /**
     * @var \AnalyticsBundle\Entity\Lot
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\Lot", inversedBy="ria")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     */
    private $lot;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text", nullable=true)
     * @JMS\Groups({"LotRia"})
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="volume", type="text", nullable=true)
     * @JMS\Groups({"LotRia"})
     */
    private $volume;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     * @return Criteria
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Ria
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set volume
     *
     * @param string $volume
     * @return Ria
     */
    public function setVolume($volume)
    {
        $this->volume = $volume;

        return $this;
    }

    /**
     * Get volume
     *
     * @return string 
     */
    public function getVolume()
    {
        return $this->volume;
    }
}
