<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use AnalyticsBundle\Entity\IEntity;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * LotCriteria
 *
 * @ORM\Table(
 *     name="lot_criteria",
 *     indexes={
 *      @ORM\Index(name="lot_criteria_lot", columns={"lot_id"}),
 *      @ORM\Index(name="lot_criteria_criteria_indicator", columns={"criteria_indicator_id"}),
 *      @ORM\Index(name="lot_criteria_criteria_rating", columns={"criteria_rating_id"})
 *     }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\LotCriteriaRepository")
 * @Json\Schema("LotCriteria")
 */
class LotCriteria implements IEntity
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="SEQUENCE")
     * @ORM\SequenceGenerator(sequenceName="lot_criteria_id_seq", allocationSize=1, initialValue=1)
     * @JMS\Groups({"LotCriteria"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="value", type="decimal", precision=3, scale=0, nullable=true)
     * @JMS\Groups({"LotCriteria"})
     */
    private $value;

    /**
     * @var string
     *
     * @ORM\Column(name="content", type="text", nullable=true)
     * @JMS\Groups({"LotCriteria"})
     */
    private $content;

    /**
     * @var \CriteriaIndicator
     *
     * @ORM\ManyToOne(targetEntity="CriteriaIndicator")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="criteria_indicator_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"LotCriteria_detail"})
     */
    private $criteriaIndicator;

    /**
     * @var \CriteriaRating
     *
     * @ORM\ManyToOne(targetEntity="CriteriaRating")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="criteria_rating_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"LotCriteria_detail"})
     */
    private $criteriaRating;

    /**
     * @var \Lot
     *
     * @ORM\ManyToOne(targetEntity="Lot")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     * @Json\Ignore
     */
    private $lot;



    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set value
     *
     * @param string $value
     *
     * @return LotCriteria
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return string
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set content
     *
     * @param string $content
     *
     * @return LotCriteria
     */
    public function setContent($content)
    {
        $this->content = $content;

        return $this;
    }

    /**
     * Get content
     *
     * @return string
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Set criteriaIndicator
     *
     * @param \AnalyticsBundle\Entity\CriteriaIndicator $criteriaIndicator
     *
     * @return LotCriteria
     */
    public function setCriteriaIndicator(\AnalyticsBundle\Entity\CriteriaIndicator $criteriaIndicator = null)
    {
        $this->criteriaIndicator = $criteriaIndicator;

        return $this;
    }

    /**
     * Get criteriaIndicator
     *
     * @return \AnalyticsBundle\Entity\CriteriaIndicator
     */
    public function getCriteriaIndicator()
    {
        return $this->criteriaIndicator;
    }

    /**
     * Set criteriaRating
     *
     * @param \AnalyticsBundle\Entity\CriteriaRating $criteriaRating
     *
     * @return LotCriteria
     */
    public function setCriteriaRating(\AnalyticsBundle\Entity\CriteriaRating $criteriaRating = null)
    {
        $this->criteriaRating = $criteriaRating;

        return $this;
    }

    /**
     * Get criteriaRating
     *
     * @return \AnalyticsBundle\Entity\CriteriaRating
     */
    public function getCriteriaRating()
    {
        return $this->criteriaRating;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     *
     * @return LotCriteria
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string)$this->getId();
    }
}
