<?php

namespace AnalyticsBundle\Entity;

use AnalyticsBundle\Entity\IEntity;
use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Value
 *
 * @ORM\Table(name="lot_rate_indicator_value")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\LotRateIndicatorValue")
 * @Json\Schema("LotRateIndicatorValue")
 */
class LotRateIndicatorValue implements IEntity
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="SEQUENCE")
     * @ORM\SequenceGenerator(sequenceName="lot_rate_indicator_value_id_seq", allocationSize=1, initialValue=1)
     * @JMS\Groups({"LotRateIndicator"})
     */
    private $id;

    /**
     * @var \AnalyticsBundle\Entity\LotRateIndicator
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\LotRateIndicator", inversedBy="value")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_rate_indicator_id", referencedColumnName="id", nullable=false)
     * })
     * @JMS\Groups({"LotRateIndicatorValue"})
     */
    private $lotRateIndicator;

    /**
     * @var string
     *
     * @ORM\Column(name="year", type="integer", nullable=false)
     * @JMS\Groups({"lot_detail"})
     */
    private $year;

    /**
     * @var string
     *
     * @ORM\Column(name="weight", type="float", precision=10, scale=2, nullable=false)
     * @JMS\Groups({"lot_detail"})
     */
    private $weight;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set year
     *
     * @param integer $year
     * @return Value
     */
    public function setYear($year)
    {
        $this->year = $year;

        return $this;
    }

    /**
     * Get year
     *
     * @return integer 
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * Set weight
     *
     * @param float $weight
     * @return Value
     */
    public function setWeight($weight)
    {
        $this->weight = $weight;

        return $this;
    }

    /**
     * Get weight
     *
     * @return float 
     */
    public function getWeight()
    {
        return $this->weight;
    }

    /**
     * Set lotRateIndicator
     *
     * @param \AnalyticsBundle\Entity\LotRateIndicator $lotRateIndicator
     * @return Value
     */
    public function setLotRateIndicator(\AnalyticsBundle\Entity\LotRateIndicator $lotRateIndicator)
    {
        $this->lotRateIndicator = $lotRateIndicator;

        return $this;
    }

    /**
     * Get lotRateIndicator
     *
     * @return \AnalyticsBundle\Entity\LotRateIndicator
     */
    public function getLotRateIndicator()
    {
        return $this->lotRateIndicator;
    }
}
