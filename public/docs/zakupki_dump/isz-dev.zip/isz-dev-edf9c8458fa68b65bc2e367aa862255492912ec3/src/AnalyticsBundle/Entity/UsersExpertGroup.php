<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * UsersExpertGroup
 *
 * @ORM\Table(
 *   name="users_expert_group",
 *   uniqueConstraints={
 *     @ORM\UniqueConstraint(name="users_expert_group_unique", columns={"users_id", "expert_group_id"})
 *   },
 *   indexes={
 *     @ORM\Index(name="users_expert_group_expert_group_id", columns={"expert_group_id"}),
 *     @ORM\Index(name="users_expert_group_users_id", columns={"users_id"}),
 *     @ORM\Index(name="users_expert_group_expert_role_id", columns={"expert_role_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\UsersExpertGroupRepository")
 * @Json\Schema("UsersExpertGroup")
 */
class UsersExpertGroup implements IEntity
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="SEQUENCE")
     * @ORM\SequenceGenerator(sequenceName="seq_users_expert_group", allocationSize=1, initialValue=1)
     * @JMS\Groups({"users_expert_group", "users_expert_group_list", "users_expert_group_detail", "expert_group_list",
     *     "expert_group_detail"})
     */
    private $id;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="users_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"users_expert_group", "users_expert_group_list", "users_expert_group_detail", "expert_group_list",
     *     "expert_group_detail"})
     */
    private $users;

    /**
     * @var ExpertGroup
     *
     * @ORM\ManyToOne(targetEntity="ExpertGroup", inversedBy="expertGroup")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="expert_group_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"users_expert_group", "users_expert_group_list", "users_expert_group_detail", "users_detail"})
     */
    private $expertGroup;

    /**
     * @var ExpertRole
     *
     * @ORM\ManyToOne(targetEntity="ExpertRole")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="expert_role_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"users_expert_group", "expert_group", "expert_group_list", "users_expert_group_list",
     *     "users_expert_group_detail", "expert_group_detail", "users_detail", "expert_group_list",
     *     "expert_group_detail"})
     */
    private $expertRole;

    /**
     * @var array[]
     *
     * @JMS\Groups({"users_expert_group", "users_expert_group_list", "users_expert_group_detail", "expert_group_detail",
     *     "users_detail"})
     */
    public $permissions;

    /**
     * @var string
     *
     * @JMS\Groups({"users_expert_group", "users_expert_group_list", "users_expert_group_detail", "expert_group_detail",
     *     "users_detail"})
     */
    public $expertRoleName;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set users
     *
     * @param \AnalyticsBundle\Entity\Users $users
     * @return UsersExpertGroup
     */
    public function setUsers(\AnalyticsBundle\Entity\Users $users = null)
    {
        $this->users = $users;

        return $this;
    }

    /**
     * Get users
     *
     * @return \AnalyticsBundle\Entity\Users
     */
    public function getUsers()
    {
        return $this->users;
    }

    /**
     * Set expertGroup
     *
     * @param \AnalyticsBundle\Entity\ExpertGroup $expertGroup
     * @return UsersExpertGroup
     */
    public function setExpertGroup(\AnalyticsBundle\Entity\ExpertGroup $expertGroup = null)
    {
        $this->expertGroup = $expertGroup;

        return $this;
    }

    /**
     * Get expertGroup
     *
     * @return \AnalyticsBundle\Entity\ExpertGroup
     */
    public function getExpertGroup()
    {
        return $this->expertGroup;
    }

    /**
     * Set expertRole
     *
     * @param ExpertRole|null $expertRole
     * @return UsersExpertGroup
     */
    public function setExpertRole(\AnalyticsBundle\Entity\ExpertRole $expertRole = null)
    {
        $this->expertRole = $expertRole;

        return $this;
    }

    /**
     * Get expertRole
     *
     * @return ExpertRole
     */
    public function getExpertRole()
    {
        return $this->expertRole;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        if ($user = $this->getUsers()) {
            if ($eg = $this->getExpertGroup()) {
                if ($er = $this->getExpertRole()) {
                    return $user->__toString() . ' - ' . $eg->__toString() . ' - ' . $er->__toString();
                }
                return $user->__toString() . ' - ' . $eg->__toString() . ' - NONE';
            }
            return $user->__toString() . ' - NONE - NONE';
        }
    }
}
