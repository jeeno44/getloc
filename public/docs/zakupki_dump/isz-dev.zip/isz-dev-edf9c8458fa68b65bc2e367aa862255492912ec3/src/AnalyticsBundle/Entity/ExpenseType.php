<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * ExpenseType
 *
 * @ORM\Table(name="expense_type", indexes={@ORM\Index(name="expense_type_dfcp_id", columns={"dfcp_id"}), @ORM\Index(name="expense_type_sstp_id", columns={"sstp_id"})})
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\ExpenseTypeRepository")
 * @Json\Schema("ExpenseType")
 */
class ExpenseType implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"lot_list", "lot_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="dfcp_id", type="string", length=32, nullable=true)
     * @Json\Ignore()
     */
    private $dfcpId;

    /**
     * @var string
     *
     * @ORM\Column(name="sstp_id", type="string", length=32, nullable=true)
     * @Json\Ignore()
     */
    private $sstpId;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     * @JMS\Groups({"lot_list", "lot_detail", "lot_item_plans"})
     * @JMS\SerializedName("")
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=255, nullable=true)
     */
    private $code;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set dfcpId
     *
     * @param string $dfcpId
     * @return ExpenseType
     */
    public function setDfcpId($dfcpId)
    {
        $this->dfcpId = $dfcpId;

        return $this;
    }

    /**
     * Get dfcpId
     *
     * @return string
     */
    public function getDfcpId()
    {
        return $this->dfcpId;
    }

    /**
     * Set sstpId
     *
     * @param string $sstpId
     * @return ExpenseType
     */
    public function setSstpId($sstpId)
    {
        $this->sstpId = $sstpId;

        return $this;
    }

    /**
     * Get sstpId
     *
     * @return string
     */
    public function getSstpId()
    {
        return $this->sstpId;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return ExpenseType
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return ExpenseType
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getDescription();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
