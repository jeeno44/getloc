<?php

namespace AnalyticsBundle\Entity\Views;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Common
 *
 * @ORM\Table(name="common_root")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\Views\CommonRootRepository", readOnly=true)
 * @Json\Schema("ViewCommonRoot")
 */
class CommonRoot
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @JMS\Groups({"common", "common_list", "common_detail", "all", "users_detail", "plan_common", "lot_detail"})
     */
    private $id;

    /**
     * @var CommonRoot
     *
     * @ORM\ManyToOne(targetEntity="CommonRoot")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"common", "common_list", "common_detail", "all", "users_detail"})
     */
    private $parent;

    /**
     * @var CommonRoot
     *
     * @ORM\ManyToOne(targetEntity="CommonRoot")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="root", referencedColumnName="id")
     * })
     * @JMS\Groups({"common", "common_list", "common_detail", "all", "users_detail"})
     */
    private $root;


    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set parent
     *
     * @param \AnalyticsBundle\Entity\Views\CommonRoot $parent
     * @return CommonRoot
     */
    public function setParent(\AnalyticsBundle\Entity\Views\CommonRoot $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \AnalyticsBundle\Entity\Views\CommonRoot
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Set root
     *
     * @param \AnalyticsBundle\Entity\Views\CommonRoot $root
     * @return CommonRoot
     */
    public function setRoot(\AnalyticsBundle\Entity\Views\CommonRoot $root = null)
    {
        $this->root = $root;

        return $this;
    }

    /**
     * Get root
     *
     * @return \AnalyticsBundle\Entity\Views\CommonRoot
     */
    public function getRoot()
    {
        return $this->root;
    }
}
