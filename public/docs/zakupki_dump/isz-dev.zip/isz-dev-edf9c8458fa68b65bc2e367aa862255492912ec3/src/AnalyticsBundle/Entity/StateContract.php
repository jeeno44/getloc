<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use AnalyticsBundle\Entity\Lot;
use AnalyticsBundle\Entity\Surety;
use AnalyticsBundle\Entity\BankGuarantee;
use AnalyticsBundle\Entity\Supplier;
use JMS\Serializer\Annotation as JMS;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * StateContract
 *
 * @ORM\Table(name="state_contract")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\StateContractRepository")
 */
class StateContract
{
    const CONTRACT_PROCURING_TYPE_BANK_GUARANTEE = 'bank_guarantee';
    const CONTRACT_PROCURING_TYPE_SURETY = 'surety';

    const CONTRACT_PROCURING_MADE = 'made';
    const CONTRACT_PROCURING_NO_MADE = 'no_made';
    const CONTRACT_PROCURING_RETURNED = 'returned';

    const CONTRACT_STATUS_GENERATE = 'generate_print_gk';
    const CONTRACT_STATUS_EXIST_FILE = 'exist_print_gk';
    const CONTRACT_STATUS_NO_START_GENERATE = 'no_generate_print_gk';

    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @ORM\SequenceGenerator(sequenceName="state_contract_id_seq", allocationSize=1, initialValue=1)
     * @JMS\Groups({"contract"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="full_name", type="string", length=255)
     * @JMS\Groups({"contract"})
     */
    private $fullName;

    /**
     * @var string
     *
     * @ORM\Column(name="statute", type="string", length=255)
     * @JMS\Groups({"contract"})
     */
    private $statute;

    /**
     * @var string
     *
     * @ORM\Column(name="approved_by", type="string", length=255)
     * @JMS\Groups({"contract"})
     */
    private $approvedBy;

    /**
     * @var \Supplier
     *
     * @ORM\ManyToOne(targetEntity="Supplier", cascade={"persist"})
     * @ORM\JoinColumn(name="supplier_id", referencedColumnName="id")
     * @JMS\Groups({"contract"})
     */
    private $supplier;

    /**
     * @ORM\ManyToOne(targetEntity="Lot", inversedBy="stateContract")
     * @ORM\JoinColumn(name="lot_id", referencedColumnName="id", nullable=FALSE)
     * @JMS\Groups({"contract"})
     */
    private $lot;

    /**
     * @var boolean
     *
     * @ORM\Column(name="nds", type="boolean")
     * @JMS\Groups({"contract"})
     */
    private $nds = true;

    /**
     * @var int
     *
     * @ORM\Column(name="nds_amount", type="integer", nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $ndsAmount;

    /**
     * @var float
     *
     * @ORM\Column(name="nds_summ", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $ndsSumm;

    /**
     * @var string
     *
     * @ORM\Column(name="grounds_with_out_nds", type="string", length=255)
     * @JMS\Groups({"contract"})
     */
    private $groundsWithOutNds;

    /**
     * @var float
     *
     * @ORM\Column(name="penalty_charge_customer", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $penaltyChargeCustomer;

    /**
     * @var float
     *
     * @ORM\Column(name="penalty_charge_provider", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $penaltyChargeProvider;

    /**
     * @var \BankGuarantee
     *
     * @ORM\ManyToOne(targetEntity="BankGuarantee", cascade={"persist", "remove"})
     * @ORM\JoinColumn(name="bank_guarantee_id", referencedColumnName="id", nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $bankGuarantee;

    /**
     * @var \Surety
     *
     * @ORM\ManyToOne(targetEntity="Surety", cascade={"persist", "remove"})
     * @ORM\JoinColumn(name="surety_id", referencedColumnName="id", nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $surety;

    /**
     * @var \Surety
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\Application", cascade={"persist"})
     * @ORM\JoinColumn(name="application_id", referencedColumnName="id", nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $application;

    /**
     * @var string
     *
     * @ORM\Column(name="contract_procuring_type", type="string", length=255, nullable=false)
     * @JMS\Groups({"contract"})
     */
    private $contractProcuringType;

    /**
     * @var string
     *
     * @ORM\Column(name="contract_procuring", type="string", length=255, nullable=false)
     * @JMS\Groups({"contract"})
     */
    private $contractProcuring;

    /**
     * @var string
     *
     * @ORM\Column(name="supplier_first_name", type="string", length=255, nullable=false)
     * @JMS\Groups({"contract"})
     * @Assert\NotBlank(message="not.blank.contract.supplier_first_name")
     */
    private $supplierFirstName;
    /**
     * @var string
     *
     * @ORM\Column(name="supplier_last_name", type="string", length=255, nullable=false)
     * @JMS\Groups({"contract"})
     * @Assert\NotBlank(message="not.blank.contract.supplier_last_name")
     */
    private $supplierLastName;
    /**
     * @var string
     *
     * @ORM\Column(name="supplier_authority", type="string", length=255, nullable=false)
     * @JMS\Groups({"contract"})
     * @Assert\NotBlank(message="not.blank.contract.supplier_authority")
     */
    private $supplierAuthority;

    /**
     * @var boolean
     *
     * @ORM\Column(name="print_variant", type="boolean")
     * @JMS\Groups({"contract"})
     */
    private $printVariant = false;

    /**
     * @var string
     *
     * @ORM\Column(name="attachment_file1", type="string", length=255, nullable=false)
     * @JMS\Groups({"contract"})
     */
    private $attachmentFile1;

    /**
     * @var string
     *
     * @ORM\Column(name="attachment_file2", type="string", length=255, nullable=false)
     * @JMS\Groups({"contract"})
     */
    private $attachmentFile2;

    /**
     * @var string
     *
     * @ORM\Column(name="attachment_file3", type="string", length=255, nullable=false)
     * @JMS\Groups({"contract"})
     */
    private $attachmentFile3;

    /**
     * @var string
     *
     * @ORM\Column(name="singned_by_provider_file", type="string", length=255, nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $singnedByProviderFile;

    /**
     * @var string
     *
     * @ORM\Column(name="singned_by_customer_file", type="string", length=255, nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $singnedByCustomerFile;

    /**
     * @var string
     *
     * @ORM\Column(name="print_state_contract", type="string", length=255, nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $printStateContract;

    /**
     * @var string
     *
     * @ORM\Column(name="generate_status", type="string", length=255, nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $generateStatus;

    /**
     * @var bool
     *
     * @ORM\Column(name="blocked", type="boolean", nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $blocked;

    /**
     * @var string
     *
     * @ORM\Column(name="comments", type="string", length=255, nullable=true)
     * @JMS\Groups({"contract"})
     */
    private $comments;

    /**
     * @var string
     * @ORM\Column(name="comments_file", type="string", length=255, nullable=true)
     */
    private $commentsFile;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set fullName
     *
     * @param string $fullName
     *
     * @return StateContract
     */
    public function setFullName($fullName)
    {
        $this->fullName = $fullName;

        return $this;
    }

    /**
     * Get fullName
     *
     * @return string
     */
    public function getFullName()
    {
        return $this->fullName;
    }

    /**
     * Set statute
     *
     * @param string $statute
     *
     * @return StateContract
     */
    public function setStatute($statute)
    {
        $this->statute = $statute;

        return $this;
    }

    /**
     * Get statute
     *
     * @return string
     */
    public function getStatute()
    {
        return $this->statute;
    }

    /**
     * Set approvedBy
     *
     * @param string $approvedBy
     *
     * @return StateContract
     */
    public function setApprovedBy($approvedBy)
    {
        $this->approvedBy = $approvedBy;

        return $this;
    }

    /**
     * Get approvedBy
     *
     * @return string
     */
    public function getApprovedBy()
    {
        return $this->approvedBy;
    }

    /**
     * Set supplier
     *
     * @param \AnalyticsBundle\Entity\Supplier $supplier
     *
     * @return StateContract
     */
    public function setSupplier(\AnalyticsBundle\Entity\Supplier $supplier = null)
    {
        $this->supplier = $supplier;

        return $this;
    }

    /**
     * Get supplier
     *
     * @return \AnalyticsBundle\Entity\Supplier
     */
    public function getSupplier()
    {
        return $this->supplier;
    }

    /**
     * Set lot
     *
     * @param Lot $lot
     * @return StateContract
     */
    public function setLot(Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return Lot
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * Set nds
     *
     * @param string $nds
     *
     * @return StateContract
     */
    public function setNds($nds)
    {
        $this->nds = $nds;

        return $this;
    }

    /**
     * Get nds
     *
     * @return string
     */
    public function getNds()
    {
        return $this->nds;
    }

    /**
     * Set ndsAmount
     *
     * @param integer $ndsAmount
     *
     * @return StateContract
     */
    public function setNdsAmount($ndsAmount)
    {
        $this->ndsAmount = $ndsAmount;

        return $this;
    }

    /**
     * Get ndsAmount
     *
     * @return int
     */
    public function getNdsAmount()
    {
        return $this->ndsAmount;
    }

    /**
     * Set ndsSumm
     *
     * @param float $ndsSumm
     *
     * @return StateContract
     */
    public function setNdsSumm($ndsSumm)
    {
        $this->ndsSumm = $ndsSumm;

        return $this;
    }

    /**
     * Get ndsSumm
     *
     * @return float
     */
    public function getNdsSumm()
    {
        return $this->ndsSumm;
    }

    /**
     * Set groundsWithOutNds
     *
     * @param string $groundsWithOutNds
     *
     * @return StateContract
     */
    public function setGroundsWithOutNds($groundsWithOutNds)
    {
        $this->groundsWithOutNds = $groundsWithOutNds;

        return $this;
    }

    /**
     * Get groundsWithOutNds
     *
     * @return string
     */
    public function getGroundsWithOutNds()
    {
        return $this->groundsWithOutNds;
    }

    /**
     * Set penaltyChargeCustomer
     *
     * @param float $penaltyChargeCustomer
     *
     * @return StateContract
     */
    public function setPenaltyChargeCustomer($penaltyChargeCustomer)
    {
        $this->penaltyChargeCustomer = $penaltyChargeCustomer;

        return $this;
    }

    /**
     * Get penaltyChargeCustomer
     *
     * @return float
     */
    public function getPenaltyChargeCustomer()
    {
        return $this->penaltyChargeCustomer;
    }

    /**
     * Set penaltyChargeProvider
     *
     * @param float $penaltyChargeProvider
     *
     * @return StateContract
     */
    public function setPenaltyChargeProvider($penaltyChargeProvider)
    {
        $this->penaltyChargeProvider = $penaltyChargeProvider;

        return $this;
    }

    /**
     * Get penaltyChargeProvider
     *
     * @return float
     */
    public function getPenaltyChargeProvider()
    {
        return $this->penaltyChargeProvider;
    }

    /**
     * Set bankGuarantee
     *
     * @param BankGuarantee $bankGuarantee
     *
     * @return StateContract
     */
    public function setBankGuarantee(BankGuarantee $bankGuarantee = null)
    {
        $this->bankGuarantee = $bankGuarantee;

        return $this;
    }

    /**
     * Get bankGuarantee
     *
     * @return BankGuarantee
     */
    public function getBankGuarantee()
    {
        return $this->bankGuarantee;
    }

    /**
     * Set surety
     *
     * @param Surety $surety
     * @return StateContract
     */
    public function setSurety(Surety $surety = null)
    {
        $this->surety = $surety;

        return $this;
    }

    /**
     * Get surety
     *
     * @return Surety
     */
    public function getSurety()
    {
        return $this->surety;
    }

    /**
     * Set application
     *
     * @param Application $application
     * @return StateContract
     */
    public function setApplication(Application $application = null)
    {
        $this->application = $application;

        return $this;
    }

    /**
     * Get surety
     *
     * @return Application
     */
    public function getApplication()
    {
        return $this->application;
    }

    /**
     * Set contractProcuringType
     *
     * @param $contractProcuringType
     * @return StateContract
     */
    public function setContractProcuringType($contractProcuringType)
    {
        $this->contractProcuringType = $contractProcuringType;

        return $this;
    }

    /**
     * Get contractProcuringType
     *
     * @return string
     */
    public function getContractProcuringType()
    {
        return $this->contractProcuringType;
    }

    /**
     * Set contractProcuring
     *
     * @param $contractProcuring
     * @return StateContract
     */
    public function setContractProcuring($contractProcuring)
    {
        $this->contractProcuring = $contractProcuring;

        return $this;
    }

    /**
     * Get contractProcuring
     *
     * @return string
     */
    public function getContractProcuring()
    {
        return $this->contractProcuring;
    }

    /**
     * Set printVariant
     *
     * @param $printVariant
     * @return StateContract
     */
    public function setPrintVariant($printVariant)
    {
        $this->printVariant = $printVariant;

        return $this;
    }

    /**
     * Get printVariant
     *
     * @return boolean
     */
    public function getPrintVariant()
    {
        return $this->printVariant;
    }

    /**
     * Set supplierFirstName
     *
     * @param $supplierFirstName
     * @return StateContract
     */
    public function setSupplierFirstName($supplierFirstName)
    {
        $this->supplierFirstName = $supplierFirstName;

        return $this;
    }

    /**
     * Get supplierFirstName
     *
     * @return string
     */
    public function getSupplierFirstName()
    {
        return $this->supplierFirstName;
    }

    /**
     * Set supplierLastName
     *
     * @param $supplierLastName
     * @return StateContract
     */
    public function setSupplierLastName($supplierLastName)
    {
        $this->supplierLastName = $supplierLastName;

        return $this;
    }

    /**
     * Get supplierLastName
     *
     * @return string
     */
    public function getSupplierLastName()
    {
        return $this->supplierLastName;
    }

    /**
     * Set supplierAuthority
     *
     * @param $supplierAuthority
     * @return StateContract
     */
    public function setSupplierAuthority($supplierAuthority)
    {
        $this->supplierAuthority = $supplierAuthority;

        return $this;
    }

    /**
     * Get supplierAuthority
     *
     * @return string
     */
    public function getSupplierAuthority()
    {
        return $this->supplierAuthority;
    }

    /**
     * Set attachmentFile1
     *
     * @param $attachmentFile1
     * @return StateContract
     */
    public function setAttachmentFile1($attachmentFile1)
    {
        $this->attachmentFile1 = $attachmentFile1;

        return $this;
    }

    /**
     * Get attachmentFile1
     *
     * @return string
     */
    public function getAttachmentFile1()
    {
        return $this->attachmentFile1;
    }

    /**
     * Set attachmentFile2
     *
     * @param $attachmentFile2
     * @return StateContract
     */
    public function setAttachmentFile2($attachmentFile2)
    {
        $this->attachmentFile2 = $attachmentFile2;

        return $this;
    }

    /**
     * Get attachmentFile2
     *
     * @return string
     */
    public function getAttachmentFile2()
    {
        return $this->attachmentFile2;
    }

    /**
     * Set attachmentFile3
     *
     * @param $attachmentFile3
     * @return StateContract
     */
    public function setAttachmentFile3($attachmentFile3)
    {
        $this->attachmentFile3 = $attachmentFile3;

        return $this;
    }

    /**
     * Get attachmentFile3
     *
     * @return string
     */
    public function getAttachmentFile3()
    {
        return $this->attachmentFile3;
    }

    /**
     * Set singnedByProviderFile
     *
     * @param $singnedByProviderFile
     * @return StateContract
     */
    public function setSingnedByProviderFile($singnedByProviderFile)
    {
        $this->singnedByProviderFile = $singnedByProviderFile;

        return $this;
    }

    /**
     * Get singnedByProviderFile
     *
     * @return string
     */
    public function getSingnedByProviderFile()
    {
        return $this->singnedByProviderFile;
    }

    /**
     * Set singnedByCustomerFile
     *
     * @param $singnedByCustomerFile
     * @return StateContract
     */
    public function setSingnedByCustomerFile($singnedByCustomerFile)
    {
        $this->singnedByCustomerFile = $singnedByCustomerFile;

        return $this;
    }

    /**
     * Get singnedByCustomerFile
     *
     * @return string
     */
    public function getSingnedByCustomerFile()
    {
        return $this->singnedByCustomerFile;
    }

    /**
     * Set printStateContract
     *
     * @param $printStateContract
     * @return StateContract
     */
    public function setPrintStateContract($printStateContract)
    {
        $this->printStateContract = $printStateContract;

        return $this;
    }

    /**
     * Get printStateContract
     *
     * @return string
     */
    public function getPrintStateContract()
    {
        return $this->printStateContract;
    }

    /**
     * Set generateStatus
     *
     * @param $generateStatus
     * @return StateContract
     */
    public function setGenerateStatus($generateStatus)
    {
        $this->generateStatus = $generateStatus;

        return $this;
    }

    /**
     * Get generateStatus
     *
     * @return string
     */
    public function getGenerateStatus()
    {
        return $this->generateStatus;
    }

    /**
     * Set blocked
     *
     * @param bool $blocked
     * @return StateContract
     */
    public function setBlocked($blocked)
    {
        $this->blocked = $blocked;

        return $this;
    }

    /**
     * Get blocked
     *
     * @return bool
     */
    public function getBlocked()
    {
        return $this->blocked;
    }

    /**
     * Set comments
     *
     * @param string $comments
     * @return StateContract
     */
    public function setComments($comments)
    {
        $this->comments = $comments;

        return $this;
    }

    /**
     * Get comments
     *
     * @return string
     */
    public function getComments()
    {
        return $this->comments;
    }

    /**
     * Set commentsFile
     *
     * @param string $commentsFile
     * @return StateContract
     */
    public function setCommentsFile($commentsFile)
    {
        $this->commentsFile = $commentsFile;

        return $this;
    }

    /**
     * Get commentsFile
     *
     * @return string
     */
    public function getCommentsFile()
    {
        return $this->commentsFile;
    }
}

