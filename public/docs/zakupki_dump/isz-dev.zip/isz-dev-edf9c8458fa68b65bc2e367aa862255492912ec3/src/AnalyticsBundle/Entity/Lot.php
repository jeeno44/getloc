<?php

namespace AnalyticsBundle\Entity;

use Doctrine\Common\Collections\Criteria;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use Gedmo\Mapping\Annotation as Gedmo;
use JMS\Serializer\Annotation as JMS;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

/**
 * Lot
 *
 * @ORM\Table(
 *     name="lot",
 *     uniqueConstraints={
 *          @ORM\UniqueConstraint(name="lot_number_unique", columns={"number"})
 *     },
 *     indexes={
 *          @ORM\Index(name="lot_kbk_csr_id", columns={"kbk_csr_id"}),
 *          @ORM\Index(name="lot_fcp_id", columns={"fcp_id"}),
 *          @ORM\Index(name="lot_marketplace_id", columns={"marketplace_id"}),
 *          @ORM\Index(name="lot_dfcp_id", columns={"dfcp_id"}),
 *          @ORM\Index(name="lot_fcp_action_subaction_id", columns={"fcp_action_subaction_id"}),
 *          @ORM\Index(name="lot_nmck_justification_id", columns={"nmck_type_id"}),
 *          @ORM\Index(name="lot_fcp_action_task_id", columns={"fcp_action_task_id"}),
 *          @ORM\Index(name="lot_nks_id", columns={"nks_id"}),
 *          @ORM\Index(name="lot_expense_type_id", columns={"expense_type_id"}),
 *          @ORM\Index(name="lot_kbk_section_id", columns={"kbk_section_id"}),
 *          @ORM\Index(name="lot_sstp_id", columns={"sstp_id"}),
 *          @ORM\Index(name="lot_gov_program_id", columns={"gov_program_id"}),
 *          @ORM\Index(name="lot_fcp_action_id", columns={"fcp_action_id"}),
 *          @ORM\Index(name="lot_procurement_type_id", columns={"procurement_type_id"}),
 *          @ORM\Index(name="lot_kbk_flow_direction_id", columns={"kbk_flow_direction_id"}),
 *          @ORM\Index(name="lot_supplier_id", columns={"supplier_id"}),
 *          @ORM\Index(name="lot_kbk_kosgu_id", columns={"kbk_kosgu_id"}),
 *          @ORM\Index(name="lot_proc_resp_id", columns={"proc_resp_id"}),
 *          @ORM\Index(name="lot_kbk_expense_type_id", columns={"kbk_expense_type_id"}),
 *          @ORM\Index(name="lot_okei_id", columns={"okei_id"}),
 *          @ORM\Index(name="lot_project_id", columns={"project_id"}),
 *          @ORM\Index(name="lot_sub_program_main_action_id", columns={"sub_program_main_action_id"}),
 *          @ORM\Index(name="lot_procurement_cause_id", columns={"procurement_cause_id"}),
 *          @ORM\Index(name="lot_sub_program_action_id", columns={"sub_program_action_id"}),
 *          @ORM\Index(name="lot_sub_program_id", columns={"sub_program_id"}),
 *          @ORM\Index(name="lot_common_id", columns={"common_id"})
 *      }
 * )
 * @UniqueEntity(fields={"number"}, message="Поле 'Номер лота' должно быть уникальным")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\LotRepository")
 * @Json\Schema("Lot")
 */
class Lot extends Revision
{
    const STATUS_DRAFT    = 'draft';    // 1  порядок следования статусов в системе
    const STATUS_REWORK   = 'rework';   // 2
    const STATUS_APPROVED = 'approved'; // 3
    const STATUS_PLANING  = 'planning'; // 4
    const STATUS_PLANNED  = 'planned';  // 5
    const STATUS_PLANING_PROPOSAL  = 'planning_proposal'; // 4

    /**
     * Статус который присваивается лоту когда он добавляется в ЧПЗ
     */
    const STATUS_IN_PLAN = self::STATUS_PLANING;

    /**
     * Список статусов с которыми лот может быть добавлен в ЧПЗ
     *
     * @var array
     *
     * @Json\Ignore()
     */
    static public $listStatusAllowedInPlan = [
        self::STATUS_DRAFT,
        self::STATUS_REWORK,
    ];

    /**
     * Статус который присваивается лоту когда он удаляется из ЧПЗ
     */
    const STATUS_OUT_PLAN = self::STATUS_APPROVED;

    /**
     * Полный список статусов системы
     *
     * @var array
     *
     * @Json\Ignore()
     */
    static public $listStatus = [
        self::STATUS_DRAFT    => 'Формируется',
        self::STATUS_REWORK   => 'На доработке',
        self::STATUS_APPROVED => 'Согласован',
        self::STATUS_PLANING  => 'Планируется',
        self::STATUS_PLANNED  => 'Запланирован',
    ];

    /**
     * Список статусов с которыми лот можно редактировать
     *
     * @var array
     *
     * @Json\Ignore()
     */
    static public $listStatusEdit = [
        self::STATUS_DRAFT,
        self::STATUS_REWORK,
        self::STATUS_APPROVED,
    ];


    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_detail", "plan_common_lots", "plan_current", "plan_next",
     *      "common_detail", "notice_ea", "lot_dfcp_export", "expert_light"})
     */
    private $id;

    /**
     * @var float
     *
     * @ORM\Column(name="advance_payment_percentage", type="float", precision=5, scale=2, nullable=true)
     * @JMS\Groups({"financing", "financing_list", "financing_detail", "lot_detail", "lot_list"})
     */
    private $advancePaymentPercentage;

    /**
     * @var string
     *
     * @ORM\Column(name="isz_number", type="string", length=255, nullable=true)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots"})
     */
    private $iszNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="status_id", type="string", length=32, nullable=false)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots", "lot_item_plans", "lot_dfcp_export", "expert_light"})
     */
    private $statusId;

    /**
     * @var string
     *
     * @ORM\Column(name="dfcp_id", type="string", length=32, nullable=true)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots", "lot_dfcp_export"})
     */
    private $dfcpId;

    /**
     * @var string
     *
     * @ORM\Column(name="sstp_id", type="string", length=32, nullable=true)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots"})
     */
    private $sstpId;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=1024, nullable=true)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_detail", "plan_common_lots", "plan_current", "plan_next",
     *      "common_detail", "notice_ea", "lot_item_plans"})
     * @Assert\NotBlank(groups={"apiForm"}, message="Это значение не должно быть пустым")
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="number", type="string", length=255, nullable=true, unique=true)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_detail", "lot_item_plans"})
     * @Assert\NotBlank(groups={"apiForm"}, message="Это значение не должно быть пустым")
     */
    private $number;

    /**
     * @var string
     *
     * @ORM\Column(name="goals", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $goals;

    /**
     * @var string
     *
     * @ORM\Column(name="tasks", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $tasks;

    /**
     * @var string
     *
     * @ORM\Column(name="actuality_justification", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $actualityJustification;

    /**
     * @var string
     *
     * @ORM\Column(name="practical_usage", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $practicalUsage;

    /**
     * @var string
     *
     * @ORM\Column(name="expected_results", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $expectedResults;

    /**
     * @var string
     *
     * @ORM\Column(name="nmck_method_other", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $nmckMethodOther;

    /**
     * @var string
     *
     * @ORM\Column(name="nmck_justification_other", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $nmckJustificationOther;

    /**
     * @var string
     *
     * @ORM\Column(name="nmck_justification", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $nmckJustification;

    /**
     * @var integer
     *
     * @ORM\Column(name="lot_code", type="integer", nullable=true)
     * @JMS\Groups({"lot_list", "lot_detail", "notice_ea"})
     */
    private $lotCode;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     * @JMS\Groups({"lot_list", "lot_detail"})
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="min_requirements", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "lots_consolidated", "common_detail"})
     */
    private $minRequirements;

    /**
     * @var float
     *
     * @ORM\Column(name="quantity_following_period", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $quantityFollowingPeriod;

    /**
     * @var string
     *
     * @ORM\Column(name="prepayment_bid_percentage", type="decimal", precision=5, scale=2, nullable=true)
     * @JMS\Groups({"lot_detail", "lots_consolidated", "common_detail"})
     */
    private $prepaymentBidPercentage;

    /**
     * @var string
     *
     * @ORM\Column(name="prepayment_contract_percentage", type="decimal", precision=5, scale=2, nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $prepaymentContractPercentage;

    /**
     * @var \DateTime
     *
     * @Assert\Type("\DateTime")
     * @ORM\Column(name="procurement_start_date", type="date", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $procurementStartDate;

    /**
     * @var \DateTime
     *
     * @Assert\Type("\DateTime")
     * @ORM\Column(name="procurement_end_date", type="date", nullable=true)
     * @JMS\Groups({"lot_list", "lot_detail"})
     */
    private $procurementEndDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="order_publication", type="date", nullable=true)
     * @JMS\Groups({"lot_detail", "lots_consolidated", "lot_list", "common_detail"})
     */
    private $orderPublication;

    /**
     * @var string
     *
     * @ORM\Column(name="order_title", type="string", length=255, nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $orderTitle;

    /**
     * @var string
     *
     * @ORM\Column(name="order_number", type="string", length=32, nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $orderNumber;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="order_date", type="date", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $orderDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="contract_execution", type="date", nullable=true)
     * @JMS\Groups({"lot_detail", "lots_consolidated", "common_detail"})
     */
    private $contractExecution;

    /**
     * @var string
     *
     * @ORM\Column(name="changes", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $changes;

    /**
     * @var string
     *
     * @ORM\Column(name="justification_item_tasks", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $justificationItemTasks;

    /**
     * @var string
     *
     * @ORM\Column(name="requirements_19_44", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "lots_consolidated"})
     */
    private $requirements1944;

    /**
     * @var string
     *
     * @ORM\Column(name="add_req_justification", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $addReqJustification;

    /**
     * @var boolean
     *
     * @ORM\Column(name="publ_discussion", type="boolean", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $publDiscussion;

    /**
     * @var string
     *
     * @ORM\Column(name="add_info_7_2_17_44", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $addInfo721744;

    /**
     * @var string
     *
     * @ORM\Column(name="contract_number", type="string", length=32, nullable=true)
     * @JMS\Groups({"lot_detail", "lot", "plan_detail", "lot_detail", "lot_item_plans"})
     */
    private $contractNumber;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="contract_date", type="date", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $contractDate;

    /**
     * @var boolean
     *
     * @ORM\Column(name="preferences_28_29_44", type="boolean", nullable=true)
     * @JMS\Groups({"lot_detail", "lots_consolidated", "common_detail", "lot_list"})
     */
    private $preferences282944;

    /**
     * @var boolean
     *
     * @ORM\Column(name="gov_requirements", type="boolean", nullable=true)
     * @JMS\Groups({"lot_detail", "lots_consolidated"})
     */
    private $govRequirements;

    /**
     * @var boolean
     *
     * @ORM\Column(name="doc_requirements_14_44", type="boolean", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $docRequirements1444;

    /**
     * @var string
     *
     * @ORM\Column(name="doc_requirements", type="string", nullable=true)
     * @JMS\Groups({"lot_detail", "lot_list"})
     */
    private $docRequirements;

    /**
     * @var boolean
     *
     * @ORM\Column(name="rid_requirements", type="boolean", nullable=true)
     * @JMS\Groups({"lot_detail", "lots_consolidated"})
     */
    private $ridRequirements;

    /**
     * @var string
     *
     * @ORM\Column(name="application_post_address", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "notice_ea"})
     */
    private $applicationPostAddress;

    /**
     * @var string
     *
     * @ORM\Column(name="application_courrier_address", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $applicationCourrierAddress;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="application_date_time_start", type="datetime", nullable=true)
     * @JMS\Groups({"lot_detail", "notice_ea"})
     */
    private $applicationDateTimeStart;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="application_date_time_end", type="datetime", nullable=true)
     * @JMS\Groups({"lot_detail", "notice_ea"})
     */
    private $applicationDateTimeEnd;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="application_vskr_address", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $applicationVskrAddress;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="application_vskr_date_time", type="datetime", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $applicationVskrDateTime;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="application_rassmotr_date_time", type="datetime", nullable=true)
     * @JMS\Groups({"lot_detail", "notice_ea"})
     */
    private $applicationRassmotrDateTime;

    /**
     * @var string
     *
     * @ORM\Column(name="application_rassmotr_address", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $applicationRassmotrAddress;

    /**
     * @var float
     *
     * @ORM\Column(name="nmck_price", type="float", nullable=true)
     * @JMS\Groups({"lot_detail", "notice_ea"})
     */
    private $nmckPrice;

    /**
     * @var string
     *
     * @ORM\Column(name="nmck_comment", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $nmckComment;

    /**
     * @var string
     *
     * @ORM\Column(name="specification_tasks", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $specificationTasks;

    /**
     * @var string
     *
     * @ORM\Column(name="specification_content", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $specificationContent;

    /**
     * @var string
     *
     * @ORM\Column(name="specification_doc_req", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $specificationDocReq;

    /**
     * @var string
     *
     * @ORM\Column(name="specification_stage_content", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $specificationStageContent;

    /**
     * @var string
     *
     * @ORM\Column(name="specification_accept_conditions", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $specificationAcceptConditions;

    /**
     * @var string
     *
     * @ORM\Column(name="nmck_url", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $nmckUrl;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="application_1stpart_review_date_end", type="date", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $application1stpartReviewDateEnd;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="auction_date", type="date", nullable=true)
     * @JMS\Groups({"lot_detail", "notice_ea"})
     */
    private $auctionDate;

    /**
     * @var boolean
     *
     * @ORM\Column(name="auction_price_reduction", type="boolean", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $auctionPriceReduction;

    /**
     * @var boolean
     *
     * @ORM\Column(name="auction_quantity_change", type="boolean", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $auctionQuantityChange;

    /**
     * @var boolean
     *
     * @ORM\Column(name="auction_quantity_increase", type="boolean", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $auctionQuantityIncrease;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="doc_clarification_start_date", type="date", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $docClarificationStartDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="doc_clarification_end_date", type="date", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $docClarificationEndDate;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="creation_date", type="datetime")
     * @JMS\Groups({"lot", "lot_list", "lot_detail"})
     * @Assert\DateTime(groups={"apiForm"})
     */
    private $creationDate;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(name="updated_date", type="datetime")
     * @JMS\Groups({"lot", "lot_list", "lot_detail"})
     * @Assert\DateTime(groups={"apiForm"})
     */
    private $updatedDate;

    /**
     * @var float
     *
     * @ORM\Column(name="plan_price_following_period", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $planPriceFollowingPeriod;

    /**
     * @var boolean
     *
     * @ORM\Column(name="requirement_30_44", type="boolean", nullable=true)
     * @JMS\Groups({"lot_detail", "lots_consolidated", "notice_ea", "common_detail"})
     */
    private $requirement3044;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_one_supplier", type="boolean", nullable=true)
     * @JMS\Groups({"lot_detail", "lots_consolidated"})
     */
    private $isOneSupplier;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_used_cultural_heritage", type="boolean", nullable=true)
     * @JMS\Groups({"lot_detail", "lots_consolidated"})
     */
    private $isUseCulturalHeritage;

    /**
     * @var float
     *
     * @ORM\Column(name="quantity", type="integer", nullable=true)
     * @JMS\Groups({"lot_detail"})
     * @Assert\GreaterThan(value=0, groups={"apiForm"})
     */
    private $quantity;

    /**
     * @var string
     *
     * @ORM\Column(name="kd_method_provision", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $kdMethodProvision;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="kd_date_time_start_provision", type="datetime", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $kdDateTimeStartProvision;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="kd_date_time_end_provision", type="datetime", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $kdDateTimeEndProvision;

    /**
     * @var string
     *
     * @ORM\Column(name="kd_place_provision", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $kdPlaceProvision;

    /**
     * @var string
     *
     * @ORM\Column(name="kd_order_provision", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $kdOrderProvision;

    /**
     * @var string
     *
     * @ORM\Column(name="placing_in_eis_department", type="string", length=255, nullable=false)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots", "lot_item_plans", "lot_dfcp_export", "expert_light"})
     */
    private $placingInEisDepartment;

    /**
     * @var string
     *
     * @ORM\Column(name="placing_in_eis_person", type="string", length=255, nullable=false)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots", "lot_item_plans", "lot_dfcp_export", "expert_light"})
     */
    private $placingInEisPerson;

    /**
     * @var string
     *
     * @ORM\Column(name="placing_in_eis_person_family", type="string", length=255, nullable=false)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots", "lot_item_plans", "lot_dfcp_export", "expert_light"})
     */
    private $placingInEisPersonFamily;

    /**
     * @var string
     *
     * @ORM\Column(name="placing_in_eis_person_name", type="string", length=255, nullable=false)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots", "lot_item_plans", "lot_dfcp_export", "expert_light"})
     */
    private $placingInEisPersonName;

    /**
     * @var string
     *
     * @ORM\Column(name="placing_in_eis_person_patronomic", type="string", length=255, nullable=false)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots", "lot_item_plans", "lot_dfcp_export", "expert_light"})
     */
    private $placingInEisPersonPatronomic;

    /**
     * @var string
     *
     * @ORM\Column(name="placing_in_eis_job_title", type="string", length=255, nullable=false)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots", "lot_item_plans", "lot_dfcp_export", "expert_light"})
     */
    private $placingInEisJobTitle;

    /**
     * @var string
     *
     * @ORM\Column(name="placing_in_eis_phone", type="string", length=255, nullable=false)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots", "lot_item_plans", "lot_dfcp_export", "expert_light"})
     */
    private $placingInEisPhone;

    /**
     * @var string
     *
     * @ORM\Column(name="placing_in_eis_email", type="string", length=255, nullable=false)
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_common_lots", "lot_item_plans", "lot_dfcp_export", "expert_light"})
     */
    private $placingInEisEmail;

    /**
     * @var Common
     *
     * @ORM\ManyToOne(targetEntity="Common")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="common_id", referencedColumnName="id", nullable=false)
     * })
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_detail", "plan_common_lots", "notice_ea", "lot_item_plans", "expert_light"})
     */
    private $common;

    /**
     * @var LotDoc
     *
     * @ORM\OneToMany(targetEntity="LotDoc", mappedBy="lot", cascade={"persist", "remove"})
     * @JMS\Groups({"lot_detail"})
     */
    private $lotDoc;

    /**
     * @var NmckDoc
     *
     * @ORM\OneToMany(targetEntity="NmckDoc", mappedBy="lot", cascade={"persist", "remove"})
     * @JMS\Groups({"lot_detail"})
     */
    private $nmckDoc;

    /**
     * @var Marketplace
     *
     * @ORM\ManyToOne(targetEntity="Marketplace", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="marketplace_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail"})
     */
    private $marketplace;

    /**
     * @var Supplier
     *
     * @ORM\ManyToOne(targetEntity="Supplier", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="supplier_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail"})
     */
    private $supplier;

    /**
     * @var KbkCsr
     *
     * @ORM\ManyToOne(targetEntity="KbkCsr", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_csr_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail", "lots_consolidated"})
     */
    private $kbkCsr;

    /**
     * @var KbkExpenseType
     *
     * @ORM\ManyToOne(targetEntity="KbkExpenseType", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_expense_type_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail", "lots_consolidated"})
     * @Assert\Valid
     */
    private $kbkExpenseType;

    /**
     * @var KbkFlowDirection
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\KbkFlowDirection", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_flow_direction_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail", "lots_consolidated"})
     * @Assert\Valid
     */
    private $kbkFlowDirection;

    /**
     * @var KbkKosgu
     *
     * @ORM\ManyToOne(targetEntity="KbkKosgu", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_kosgu_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail", "lots_consolidated"})
     */
    private $kbkKosgu;

    /**
     * @var Kbk
     *
     * @ORM\ManyToOne(targetEntity="KbkSection", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_section_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail", "lots_consolidated"})
     */
    private $kbkSection;

    /**
     * @var Nks
     *
     * @ORM\Column(name="nks", type="text", nullable=true)
     * @JMS\Groups({"lot_detail"})
     */
    private $nks;

    /**
     * @var SubProgramAction
     *
     * @ORM\ManyToOne(targetEntity="SubProgramAction", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="sub_program_action_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_detail", "plan_common_lots"})
     */
    private $subProgramAction;

    /**
     * @var SubProgramAction
     *
     * @ORM\ManyToOne(targetEntity="SubProgramAction", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="sub_program_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_detail", "plan_common_lots", "common_detail"})
     */
    private $subProgram;

    /**
     * @var SubProgramAction
     *
     * @ORM\ManyToOne(targetEntity="SubProgramAction", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="sub_program_main_action_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_detail", "plan_common_lots"})
     */
    private $subProgramMainAction;

    /**
     * @var GovProgram
     *
     * @ORM\ManyToOne(targetEntity="GovProgram", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="gov_program_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail", "common_detail", "expert_light"})
     */
    private $govProgram;

    /**
     * @var Users
     *
     * @ORM\ManyToOne(targetEntity="Users", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="proc_resp_id", referencedColumnName="id", nullable=false)
     * })
     * @JMS\Groups({"lot_list", "lot_detail", "common_detail", "notice_ea"})
     */
    private $procResp;

    /**
     * @var Stage
     *
     * @ORM\OneToMany(targetEntity="Stage", mappedBy="lot", cascade={"persist", "remove"})
     * @JMS\Groups({"lot_detail", "lots_consolidated", "common_detail", "notice_ea"})
     * @ORM\OrderBy({"startYear"="ASC","executionDate"="ASC"})
     */
    private $stages;

    /**
     * @var ExpenseType
     *
     * @ORM\ManyToOne(targetEntity="ExpenseType", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="expense_type_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot", "plan_detail", "lot_detail", "lot_item_plans", "lot_list", "lot_detail", "lot_item_plans"})
     * @Assert\NotBlank(groups={"apiForm"}, message="Это значение не должно быть пустым")
     */
    private $expenseType;

    /**
     * @var Project
     *
     * @ORM\ManyToOne(targetEntity="Project", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="project_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail"})
     */
    private $project;

    /**
     * @var Fcp
     *
     * @ORM\ManyToOne(targetEntity="Fcp", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail", "fcp_action", "lot", "lot_list", "plan_detail", "plan_common_lots"})
     */
    private $fcp;

    /**
     * @var FcpAction
     *
     * @ORM\ManyToOne(targetEntity="FcpAction", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_action_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail", "fcp_action", "lot", "lot_list", "plan_detail", "plan_common_lots"})
     */
    private $fcpAction;

    /**
     * @var FcpAction
     *
     * @ORM\ManyToOne(targetEntity="FcpAction", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_action_task_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_detail", "plan_common_lots", "lot_item_plans"})
     */
    private $fcpActionTask;

    /**
     * @var FcpAction
     *
     * @ORM\ManyToOne(targetEntity="FcpAction", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_action_subaction_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot", "lot_list", "lot_detail", "plan_detail", "plan_common_lots"})
     */
    private $fcpActionSubaction;

    /**
     * @var Okei
     *
     * @ORM\ManyToOne(targetEntity="Okei", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="okei_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail", "lots_consolidated", "notice_ea"})
     */
    private $okei;

    /**
     * @var ProcurementType
     *
     * @ORM\ManyToOne(targetEntity="ProcurementType", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="procurement_type_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_list", "lot_detail", "notice_ea", "lot_item_plans", "lot", "plan_detail", "lot_detail", "lot_item_plans"})
     */
    private $procurementType;

    /**
     * @var  \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Okved", inversedBy="okved", cascade={"remove", "persist"})
     * @ORM\JoinTable(name="lot_okved",
     *   joinColumns={
     *     @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="okved_id", referencedColumnName="id")
     *   }
     * )
     *
     * @JMS\Groups({"lot_detail", "lots_consolidated", "common_detail"})
     * @Assert\NotBlank(groups={"apiForm"}, message="Это значение не должно быть пустым")
     */
    private $okved;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Okpd", inversedBy="okpd", cascade={"remove", "persist"})
     * @ORM\JoinTable(name="lot_okpd",
     *   joinColumns={
     *     @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="okpd_id", referencedColumnName="id")
     *   }
     * )
     * @JMS\Groups({"lot_detail", "lots_consolidated", "notice_ea", "common_detail"})
     */
    private $okpd;

    /**
     * @var NmckType
     *
     * @ORM\ManyToOne(targetEntity="NmckType", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="nmck_type_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail"})
     * @Assert\NotBlank(groups={"apiForm"}, message="Это значение не должно быть пустым")
     */
    private $nmckType;

    /**
     * @var ProcurementCause
     *
     * @ORM\ManyToOne(targetEntity="ProcurementCause", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="procurement_cause_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail"})
     */
    private $procurementCause;

    /**
     * @var \AnalyticsBundle\Entity\LotRateIndicator[]
     *
     * @ORM\OneToMany(targetEntity="AnalyticsBundle\Entity\LotRateIndicator", mappedBy="lot", cascade={"persist", "remove"})
     * @JMS\Groups({"lot_detail"})
     */
    private $rateIndicator;

    /**
     * @var Financing
     *
     * @ORM\OneToMany(targetEntity="Financing", mappedBy="lot", cascade={"persist", "remove"})
     * @ORM\OrderBy({"year"="ASC"})
     * @JMS\Groups({"lot", "plan_detail", "lot_detail", "lot_item_plans", "lot_list", "lot_detail", "plan_common_lots", "plan_current", "plan_next", "lots_consolidated",
     *      "lot_item_plans"})
     */
    private $financings;

    /**
     * @var FinancingPlan
     *
     * @ORM\OneToMany(targetEntity="FinancingPlan", mappedBy="lot", cascade={"persist", "remove"})
     * @ORM\OrderBy({"year"="ASC"})
     * @JMS\Groups({"lot", "plan_detail", "lot_detail", "lot_item_plans", "lot_list", "lot_detail", "plan_common_lots", "plan_current", "plan_next", "lots_consolidated",
     *      "lot_item_plans"})
     */
    private $financingsPlan;
    
    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\ManyToMany(targetEntity="Plan", mappedBy="lots", cascade={"persist", "remove", "refresh"})
     *
     * @JMS\Groups({"lot_detail", "lot_list"})
     */
    private $plan;

    /**
     * @var NmckJustification[]
     *
     * @ORM\OneToMany(targetEntity="NmckJustification", mappedBy="lot", cascade={"persist", "remove"})
     * @JMS\Groups({"lot_detail"})
     */
    private $nmckJustifications;

    /**
     * @var \AnalyticsBundle\Entity\CriteriaCondition
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\CriteriaCondition", inversedBy="lot", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="criteria_condition_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail"})
     */
    private $criteriaCondition;

    /**
     * @var \AnalyticsBundle\Entity\LotCriteria[]
     *
     * @ORM\OneToMany(targetEntity="AnalyticsBundle\Entity\LotCriteria", mappedBy="lot", cascade={"persist", "remove"})
     * @JMS\Groups({"lot_detail"})
     */
    private $criteria;

    /**
     * @var \AnalyticsBundle\Entity\LotRia[]
     *
     * @ORM\OneToMany(targetEntity="AnalyticsBundle\Entity\LotRia", mappedBy="lot", cascade={"persist", "remove"})
     * @JMS\Groups({"lot_detail"})
     */
    private $ria;

    /**
     * @var \AnalyticsBundle\Entity\Gz[]
     *
     * @ORM\OneToMany(targetEntity="AnalyticsBundle\Entity\Gz", mappedBy="lot", cascade={"persist", "remove"})
     * @JMS\Groups({"lot_detail"})
     */
    private $gz;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Lot", inversedBy="revision", cascade={"persist", "remove"}, fetch="EXTRA_LAZY")
     * @ORM\JoinTable(name="lot_revision",
     *   joinColumns={
     *     @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="revision_id", referencedColumnName="id")
     *   }
     * )
     *
     */
    private $revision;

    /**
     * @var \AnalyticsBundle\Entity\DocumentsFreshDoc[]
     *
     * @ORM\OneToMany(targetEntity="AnalyticsBundle\Entity\DocumentsFreshDoc", mappedBy="entityId", cascade={"persist", "remove"})
     * @JMS\Groups({"lot_detail"})
     */
    private $documentFreshDoc;

    /**
     * Получаем список ревизий сущности
     * 
     * @JMS\VirtualProperty
     * @JMS\SerializedName("revisions")
     * @JMS\Groups({"lot_detail"})
     * @return string
     */
    public function getRevisions()
    {
        $revisions = [];
        $items = $this->getRevision();
        foreach ($items as $item) {
            $revisions[] = [
                'id' => $item->getId(),
                'created' => $item->getRevisionDate()
            ];
        }
        return $revisions;
    }


    /**
     * @var \DateTime
     *
     * @ORM\Column(name="revision_date", type="datetime")
     * @JMS\Groups({"lot", "plan_detail", "lot_detail", "lot_item_plans", "lot_detail"})
     */
    private $revisionDate;

    /**
     * @var Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="revision_owner", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail"})
     *
     */
    private $revisionOwner;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     * @JMS\Groups({"lot", "plan_detail", "lot_detail", "lot_item_plans", "lot_detail", "lot_list"})
     */
    private $isRevision = false;


    /*******************************************************************************************************************
     * NEED TO CHECK THIS FIELD REVERT FROM DB
     ******************************************************************************************************************/
    /**
     * @var \Nks
     *
     * @ORM\ManyToOne(targetEntity="Nks", cascade={"persist"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="nks_id", referencedColumnName="id")
     * })
     */
    private $nks2;

    /**
     * Set nks2
     *
     * @param \AnalyticsBundle\Entity\Nks $nks2
     * @return Lot
     */
    public function setNks2(\AnalyticsBundle\Entity\Nks $nks2 = null)
    {
        $this->nks2 = $nks2;

        return $this;
    }

    /**
     * Get nks2
     *
     * @return \AnalyticsBundle\Entity\Nks
     */
    public function getNks2()
    {
        return $this->nks2;
    }

    /*******************************************************************************************************************
     * /// END
     ******************************************************************************************************************/

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->rateIndicator = new \Doctrine\Common\Collections\ArrayCollection();
        $this->okpd = new \Doctrine\Common\Collections\ArrayCollection();
        $this->okved = new \Doctrine\Common\Collections\ArrayCollection();
        $this->stages = new \Doctrine\Common\Collections\ArrayCollection();
        $this->financings = new \Doctrine\Common\Collections\ArrayCollection();
        $this->financingsPlan = new \Doctrine\Common\Collections\ArrayCollection();
        $this->plan = new \Doctrine\Common\Collections\ArrayCollection();
        $this->lotDoc = new \Doctrine\Common\Collections\ArrayCollection();
        $this->nmckDoc = new \Doctrine\Common\Collections\ArrayCollection();
        $this->nmckJustifications = new \Doctrine\Common\Collections\ArrayCollection();
        $this->criteria = new \Doctrine\Common\Collections\ArrayCollection();
        $this->ria = new \Doctrine\Common\Collections\ArrayCollection();
        $this->gz = new \Doctrine\Common\Collections\ArrayCollection();
        $this->documentFreshDoc = new \Doctrine\Common\Collections\ArrayCollection();

        /** @var Lot revision
         *  Revisions list
         */
        $this->revision = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /*******************************************************************************************************************
     * Need to go to custom trait
     ******************************************************************************************************************/
    /**
     * Clone implementetion
     */
    public function __clone() {
        $this->id = null;
        unset($this->_entityPersister, $this->_identifier);
    }


    /**
     * @param $revisionDate
     * @return $this
     */
    public function setRevisionDate($revisionDate)
    {
        $this->revisionDate = $revisionDate;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getRevisionDate()
    {
        return $this->revisionDate;
    }

    /**
     * Add revision
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     * @return Lot
     */
    public function addRevision(\AnalyticsBundle\Entity\Lot $lot)
    {
        $this->revision[] = $lot;

        return $this;
    }

    /**
     * Remove Revision
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     */
    public function removeRevision(\AnalyticsBundle\Entity\Lot $lot)
    {
        $this->revision->removeElement($lot);
    }

    /**
     * Get Revisions
     *
     * @return \Doctrine\Common\Collections\Collection|Lot[]
     */
    public function getRevision()
    {
        return $this->revision;
    }

    /**
     * @param null $lots
     * @return $this
     */
    public function setRevision($lots = null)
    {
        $this->revision = $lots;
        return $this;
    }


    /**
     * Set $isRevision
     *
     * @param string $isRevision
     * @return Lot
     */
    public function setIsRevision($isRevision)
    {
        $this->isRevision = $isRevision;

        return $this;
    }

    /**
     * Set revisionOwner
     *
     * @param \AnalyticsBundle\Entity\Users $revisionOwner
     * @return Lot
     */
    public function setRevisionOwner(\AnalyticsBundle\Entity\Users $revisionOwner = null)
    {
        $this->revisionOwner = $revisionOwner;

        return $this;
    }

    /**
     * Get revisionOwner
     *
     * @return \AnalyticsBundle\Entity\Users
     */
    public function getRevisionOwner()
    {
        return $this->revisionOwner;
    }

    /**
     * Get $isRevision
     *
     * @return string
     */
    public function getIsRevision()
    {
        return $this->isRevision;
    }

    /*******************************************************************************************************************
     * /// END
     ******************************************************************************************************************/


    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set statusId
     *
     * @param string $statusId
     * @return Lot
     */
    public function setStatusId($statusId)
    {
        $this->statusId = $statusId;

        return $this;
    }

    /**
     * Get statusId
     *
     * @return string
     */
    public function getStatusId()
    {
        return $this->statusId;
    }

    /**
     * Set dfcpId
     *
     * @param string $dfcpId
     * @return Lot
     */
    public function setDfcpId($dfcpId)
    {
        $this->dfcpId = $dfcpId;

        return $this;
    }

    /**
     * Get dfcpId
     *
     * @return string
     */
    public function getDfcpId()
    {
        return $this->dfcpId;
    }

    /**
     * Set sstpId
     *
     * @param string $sstpId
     * @return Lot
     */
    public function setSstpId($sstpId)
    {
        $this->sstpId = $sstpId;

        return $this;
    }

    /**
     * Get sstpId
     *
     * @return string
     */
    public function getSstpId()
    {
        return $this->sstpId;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Lot
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set number
     *
     * @param string $number
     * @return Lot
     */
    public function setNumber($number)
    {
        $this->number = $number;

        return $this;
    }

    /**
     * Get number
     *
     * @return string
     */
    public function getNumber()
    {
        return $this->number;
    }

    /**
     * Set goals
     *
     * @param string $goals
     * @return Lot
     */
    public function setGoals($goals)
    {
        $this->goals = $goals;

        return $this;
    }

    /**
     * Get goals
     *
     * @return string
     */
    public function getGoals()
    {
        return $this->goals;
    }

    /**
     * Set tasks
     *
     * @param string $tasks
     * @return Lot
     */
    public function setTasks($tasks)
    {
        $this->tasks = $tasks;

        return $this;
    }

    /**
     * Get tasks
     *
     * @return string
     */
    public function getTasks()
    {
        return $this->tasks;
    }

    /**
     * Set actualityJustification
     *
     * @param string $actualityJustification
     * @return Lot
     */
    public function setActualityJustification($actualityJustification)
    {
        $this->actualityJustification = $actualityJustification;

        return $this;
    }

    /**
     * Get actualityJustification
     *
     * @return string
     */
    public function getActualityJustification()
    {
        return $this->actualityJustification;
    }

    /**
     * Set practicalUsage
     *
     * @param string $practicalUsage
     * @return Lot
     */
    public function setPracticalUsage($practicalUsage)
    {
        $this->practicalUsage = $practicalUsage;

        return $this;
    }

    /**
     * Get practicalUsage
     *
     * @return string
     */
    public function getPracticalUsage()
    {
        return $this->practicalUsage;
    }

    /**
     * Set expectedResults
     *
     * @param string $expectedResults
     * @return Lot
     */
    public function setExpectedResults($expectedResults)
    {
        $this->expectedResults = $expectedResults;

        return $this;
    }

    /**
     * Get expectedResults
     *
     * @return string
     */
    public function getExpectedResults()
    {
        return $this->expectedResults;
    }

    /**
     * Set nmckMethodOther
     *
     * @param string $nmckMethodOther
     * @return Lot
     */
    public function setNmckMethodOther($nmckMethodOther)
    {
        $this->nmckMethodOther = $nmckMethodOther;

        return $this;
    }

    /**
     * Get nmckMethodOther
     *
     * @return string
     */
    public function getNmckMethodOther()
    {
        return $this->nmckMethodOther;
    }

    /**
     * Set nmckJustificationOther
     *
     * @param string $nmckJustificationOther
     * @return Lot
     */
    public function setNmckJustificationOther($nmckJustificationOther)
    {
        $this->nmckJustificationOther = $nmckJustificationOther;

        return $this;
    }

    /**
     * Get nmckJustificationOther
     *
     * @return string
     */
    public function getNmckJustificationOther()
    {
        return $this->nmckJustificationOther;
    }

    /**
     * Set nmckJustification
     *
     * @param string $nmckJustification
     * @return Lot
     */
    public function setNmckJustification($nmckJustification)
    {
        $this->nmckJustification = $nmckJustification;

        return $this;
    }

    /**
     * Get nmckJustification
     *
     * @return string
     */
    public function getNmckJustification()
    {
        return $this->nmckJustification;
    }

    /**
     * Set lotCode
     *
     * @param integer $lotCode
     * @return Lot
     */
    public function setLotCode($lotCode)
    {
        $this->lotCode = $lotCode;

        return $this;
    }

    /**
     * Get lotCode
     *
     * @return integer
     */
    public function getLotCode()
    {
        return $this->lotCode;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Lot
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set minRequirements
     *
     * @param string $minRequirements
     * @return Lot
     */
    public function setMinRequirements($minRequirements)
    {
        $this->minRequirements = $minRequirements;

        return $this;
    }

    /**
     * Get minRequirements
     *
     * @return string
     */
    public function getMinRequirements()
    {
        return $this->minRequirements;
    }

    /**
     * Set quantityFollowingPeriod
     *
     * @param float $quantityFollowingPeriod
     * @return Lot
     */
    public function setQuantityFollowingPeriod($quantityFollowingPeriod)
    {
        $this->quantityFollowingPeriod = $quantityFollowingPeriod;

        return $this;
    }

    /**
     * Get quantityFollowingPeriod
     *
     * @return float
     */
    public function getQuantityFollowingPeriod()
    {
        return $this->quantityFollowingPeriod;
    }

    /**
     * Set prepaymentBidPercentage
     *
     * @param string $prepaymentBidPercentage
     * @return Lot
     */
    public function setPrepaymentBidPercentage($prepaymentBidPercentage)
    {
        $this->prepaymentBidPercentage = $prepaymentBidPercentage;

        return $this;
    }

    /**
     * Get prepaymentBidPercentage
     *
     * @return string
     */
    public function getPrepaymentBidPercentage()
    {
        return $this->prepaymentBidPercentage;
    }

    /**
     * Set prepaymentContractPercentage
     *
     * @param string $prepaymentContractPercentage
     * @return Lot
     */
    public function setPrepaymentContractPercentage($prepaymentContractPercentage)
    {
        $this->prepaymentContractPercentage = $prepaymentContractPercentage;

        return $this;
    }

    /**
     * Get prepaymentContractPercentage
     *
     * @return string
     */
    public function getPrepaymentContractPercentage()
    {
        return $this->prepaymentContractPercentage;
    }

    /**
     * Set procurementStartDate
     *
     * @param \DateTime $procurementStartDate
     * @return Lot
     */
    public function setProcurementStartDate($procurementStartDate)
    {
        $this->procurementStartDate = $procurementStartDate;

        return $this;
    }

    /**
     * Get procurementStartDate
     *
     * @return \DateTime
     */
    public function getProcurementStartDate()
    {
        return $this->procurementStartDate;
    }

    /**
     * Set procurementEndDate
     *
     * @param \DateTime $procurementEndDate
     * @return Lot
     */
    public function setProcurementEndDate($procurementEndDate)
    {
        $this->procurementEndDate = $procurementEndDate;

        return $this;
    }

    /**
     * Get procurementEndDate
     *
     * @return \DateTime
     */
    public function getProcurementEndDate()
    {
        return $this->procurementEndDate;
    }

    /**
     * Set orderPublication
     *
     * @param \DateTime $orderPublication
     * @return Lot
     */
    public function setOrderPublication($orderPublication)
    {
        $this->orderPublication = $orderPublication;

        return $this;
    }

    /**
     * Get orderPublication
     *
     * @return \DateTime 
     */
    public function getOrderPublication()
    {
        return $this->orderPublication;
    }

    /**
     * Set contractExecution
     *
     * @param \DateTime $contractExecution
     * @return Lot
     */
    public function setContractExecution($contractExecution)
    {
        $this->contractExecution = $contractExecution;

        return $this;
    }

    /**
     * Get contractExecution
     *
     * @return \DateTime
     */
    public function getContractExecution()
    {
        return $this->contractExecution;
    }

    /**
     * Set changes
     *
     * @param string $changes
     * @return Lot
     */
    public function setChanges($changes)
    {
        $this->changes = $changes;

        return $this;
    }

    /**
     * Get changes
     *
     * @return string
     */
    public function getChanges()
    {
        return $this->changes;
    }

    /**
     * Set justificationItemTasks
     *
     * @param string $justificationItemTasks
     * @return Lot
     */
    public function setJustificationItemTasks($justificationItemTasks)
    {
        $this->justificationItemTasks = $justificationItemTasks;

        return $this;
    }

    /**
     * Get justificationItemTasks
     *
     * @return string
     */
    public function getJustificationItemTasks()
    {
        return $this->justificationItemTasks;
    }

    /**
     * Set requirements1944
     *
     * @param string $requirements1944
     * @return Lot
     */
    public function setRequirements1944($requirements1944)
    {
        $this->requirements1944 = $requirements1944;

        return $this;
    }

    /**
     * Get requirements1944
     *
     * @return string
     */
    public function getRequirements1944()
    {
        return $this->requirements1944;
    }

    /**
     * Set addReqJustification
     *
     * @param string $addReqJustification
     * @return Lot
     */
    public function setAddReqJustification($addReqJustification)
    {
        $this->addReqJustification = $addReqJustification;

        return $this;
    }

    /**
     * Get addReqJustification
     *
     * @return string
     */
    public function getAddReqJustification()
    {
        return $this->addReqJustification;
    }

    /**
     * Set publDiscussion
     *
     * @param boolean $publDiscussion
     * @return Lot
     */
    public function setPublDiscussion($publDiscussion)
    {
        $this->publDiscussion = $publDiscussion;

        return $this;
    }

    /**
     * Get publDiscussion
     *
     * @return boolean
     */
    public function getPublDiscussion()
    {
        return $this->publDiscussion;
    }

    /**
     * Set addInfo721744
     *
     * @param string $addInfo721744
     * @return Lot
     */
    public function setAddInfo721744($addInfo721744)
    {
        $this->addInfo721744 = $addInfo721744;

        return $this;
    }

    /**
     * Get addInfo721744
     *
     * @return string
     */
    public function getAddInfo721744()
    {
        return $this->addInfo721744;
    }

    /**
     * Set contractNumber
     *
     * @param string $contractNumber
     * @return Lot
     */
    public function setContractNumber($contractNumber)
    {
        $this->contractNumber = $contractNumber;

        return $this;
    }

    /**
     * Get contractNumber
     *
     * @return string
     */
    public function getContractNumber()
    {
        return $this->contractNumber;
    }

    /**
     * Set contractDate
     *
     * @param \DateTime $contractDate
     * @return Lot
     */
    public function setContractDate($contractDate)
    {
        $this->contractDate = $contractDate;

        return $this;
    }

    /**
     * Get contractDate
     *
     * @return \DateTime
     */
    public function getContractDate()
    {
        return $this->contractDate;
    }

    /**
     * Set preferences282944
     *
     * @param boolean $preferences282944
     * @return Lot
     */
    public function setPreferences282944($preferences282944)
    {
        $this->preferences282944 = $preferences282944;

        return $this;
    }

    /**
     * Get preferences282944
     *
     * @return boolean
     */
    public function getPreferences282944()
    {
        return $this->preferences282944;
    }

    /**
     * Set govRequirements
     *
     * @param boolean $govRequirements
     * @return Lot
     */
    public function setGovRequirements($govRequirements)
    {
        $this->govRequirements = $govRequirements;

        return $this;
    }

    /**
     * Get govRequirements
     *
     * @return boolean
     */
    public function getGovRequirements()
    {
        return $this->govRequirements;
    }

    /**
     * Set docRequirements1444
     *
     * @param boolean $docRequirements1444
     * @return Lot
     */
    public function setDocRequirements1444($docRequirements1444)
    {
        $this->docRequirements1444 = $docRequirements1444;

        return $this;
    }

    /**
     * Get docRequirements1444
     *
     * @return boolean
     */
    public function getDocRequirements1444()
    {
        return $this->docRequirements1444;
    }

    /**
     * Set docRequirements
     *
     * @param string $docRequirements
     * @return Lot
     */
    public function setDocRequirements($docRequirements)
    {
        $this->docRequirements = $docRequirements;

        return $this;
    }

    /**
     * Get docRequirements
     *
     * @return string
     */
    public function getDocRequirements()
    {
        return $this->docRequirements;
    }

    /**
     * Set ridRequirements
     *
     * @param boolean $ridRequirements
     * @return Lot
     */
    public function setRidRequirements($ridRequirements)
    {
        $this->ridRequirements = $ridRequirements;

        return $this;
    }

    /**
     * Get ridRequirements
     *
     * @return boolean
     */
    public function getRidRequirements()
    {
        return $this->ridRequirements;
    }

    /**
     * Set applicationPostAddress
     *
     * @param string $applicationPostAddress
     * @return Lot
     */
    public function setApplicationPostAddress($applicationPostAddress)
    {
        $this->applicationPostAddress = $applicationPostAddress;

        return $this;
    }

    /**
     * Get applicationPostAddress
     *
     * @return string
     */
    public function getApplicationPostAddress()
    {
        return $this->applicationPostAddress;
    }

    /**
     * Set applicationCourrierAddress
     *
     * @param string $applicationCourrierAddress
     * @return Lot
     */
    public function setApplicationCourrierAddress($applicationCourrierAddress)
    {
        $this->applicationCourrierAddress = $applicationCourrierAddress;

        return $this;
    }

    /**
     * Get applicationCourrierAddress
     *
     * @return string
     */
    public function getApplicationCourrierAddress()
    {
        return $this->applicationCourrierAddress;
    }

    /**
     * Set applicationDateTimeStart
     *
     * @param \DateTime $applicationDateTimeStart
     * @return Lot
     */
    public function setApplicationDateTimeStart($applicationDateTimeStart)
    {
        $this->applicationDateTimeStart = $applicationDateTimeStart;

        return $this;
    }

    /**
     * Get applicationDateTimeStart
     *
     * @return \DateTime
     */
    public function getApplicationDateTimeStart()
    {
        return $this->applicationDateTimeStart;
    }

    /**
     * Set applicationDateTimeEnd
     *
     * @param \DateTime $applicationDateTimeEnd
     * @return Lot
     */
    public function setApplicationDateTimeEnd($applicationDateTimeEnd)
    {
        $this->applicationDateTimeEnd = $applicationDateTimeEnd;

        return $this;
    }

    /**
     * Get applicationDateTimeEnd
     *
     * @return \DateTime
     */
    public function getApplicationDateTimeEnd()
    {
        return $this->applicationDateTimeEnd;
    }

    /**
     * Set applicationVskrAddress
     *
     * @param string $applicationVskrAddress
     * @return Lot
     */
    public function setApplicationVskrAddress($applicationVskrAddress)
    {
        $this->applicationVskrAddress = $applicationVskrAddress;

        return $this;
    }

    /**
     * Get applicationVskrAddress
     *
     * @return string
     */
    public function getApplicationVskrAddress()
    {
        return $this->applicationVskrAddress;
    }

    /**
     * Set applicationVskrDateTime
     *
     * @param \DateTime $applicationVskrDateTime
     * @return Lot
     */
    public function setApplicationVskrDateTime($applicationVskrDateTime)
    {
        $this->applicationVskrDateTime = $applicationVskrDateTime;

        return $this;
    }

    /**
     * Get applicationVskrDateTime
     *
     * @return \DateTime
     */
    public function getApplicationVskrDateTime()
    {
        return $this->applicationVskrDateTime;
    }

    /**
     * Set applicationRassmotrDateTime
     *
     * @param \DateTime $applicationRassmotrDateTime
     * @return Lot
     */
    public function setApplicationRassmotrDateTime($applicationRassmotrDateTime)
    {
        $this->applicationRassmotrDateTime = $applicationRassmotrDateTime;

        return $this;
    }

    /**
     * Get applicationRassmotrDateTime
     *
     * @return \DateTime
     */
    public function getApplicationRassmotrDateTime()
    {
        return $this->applicationRassmotrDateTime;
    }

    /**
     * Set applicationRassmotrAddress
     *
     * @param string $applicationRassmotrAddress
     * @return Lot
     */
    public function setApplicationRassmotrAddress($applicationRassmotrAddress)
    {
        $this->applicationRassmotrAddress = $applicationRassmotrAddress;

        return $this;
    }

    /**
     * Get applicationRassmotrAddress
     *
     * @return string
     */
    public function getApplicationRassmotrAddress()
    {
        return $this->applicationRassmotrAddress;
    }

    /**
     * Set application1stpartReviewDateEnd
     *
     * @param \DateTime $application1stpartReviewDateEnd
     * @return Lot
     */
    public function setApplication1stpartReviewDateEnd($application1stpartReviewDateEnd)
    {
        $this->application1stpartReviewDateEnd = $application1stpartReviewDateEnd;

        return $this;
    }

    /**
     * Get application1stpartReviewDateEnd
     *
     * @return \DateTime
     */
    public function getApplication1stpartReviewDateEnd()
    {
        return $this->application1stpartReviewDateEnd;
    }

    /**
     * Set auctionDate
     *
     * @param \DateTime $auctionDate
     * @return Lot
     */
    public function setAuctionDate($auctionDate)
    {
        $this->auctionDate = $auctionDate;

        return $this;
    }

    /**
     * Get auctionDate
     *
     * @return \DateTime
     */
    public function getAuctionDate()
    {
        return $this->auctionDate;
    }

    /**
     * Set auctionPriceReduction
     *
     * @param boolean $auctionPriceReduction
     * @return Lot
     */
    public function setAuctionPriceReduction($auctionPriceReduction)
    {
        $this->auctionPriceReduction = $auctionPriceReduction;

        return $this;
    }

    /**
     * Get auctionPriceReduction
     *
     * @return boolean
     */
    public function getAuctionPriceReduction()
    {
        return $this->auctionPriceReduction;
    }

    /**
     * Set auctionQuantityChange
     *
     * @param boolean $auctionQuantityChange
     * @return Lot
     */
    public function setAuctionQuantityChange($auctionQuantityChange)
    {
        $this->auctionQuantityChange = $auctionQuantityChange;

        return $this;
    }

    /**
     * Get auctionQuantityChange
     *
     * @return boolean
     */
    public function getAuctionQuantityChange()
    {
        return $this->auctionQuantityChange;
    }

    /**
     * Set auctionQuantityIncrease
     *
     * @param boolean $auctionQuantityIncrease
     * @return Lot
     */
    public function setAuctionQuantityIncrease($auctionQuantityIncrease)
    {
        $this->auctionQuantityIncrease = $auctionQuantityIncrease;

        return $this;
    }

    /**
     * Get auctionQuantityIncrease
     *
     * @return boolean
     */
    public function getAuctionQuantityIncrease()
    {
        return $this->auctionQuantityIncrease;
    }

    /**
     * Set docClarificationStartDate
     *
     * @param \DateTime $docClarificationStartDate
     * @return Lot
     */
    public function setDocClarificationStartDate($docClarificationStartDate)
    {
        $this->docClarificationStartDate = $docClarificationStartDate;

        return $this;
    }

    /**
     * Get docClarificationStartDate
     *
     * @return \DateTime
     */
    public function getDocClarificationStartDate()
    {
        return $this->docClarificationStartDate;
    }

    /**
     * Set docClarificationEndDate
     *
     * @param \DateTime $docClarificationEndDate
     * @return Lot
     */
    public function setDocClarificationEndDate($docClarificationEndDate)
    {
        $this->docClarificationEndDate = $docClarificationEndDate;

        return $this;
    }

    /**
     * Get docClarificationEndDate
     *
     * @return \DateTime
     */
    public function getDocClarificationEndDate()
    {
        return $this->docClarificationEndDate;
    }

    /**
     * Set creationDate
     *
     * @param \DateTime $creationDate
     * @return Lot
     */
    public function setCreationDate($creationDate)
    {
        $this->creationDate = $creationDate;

        return $this;
    }

    /**
     * Get creationDate
     *
     * @return \DateTime
     */
    public function getCreationDate()
    {
        return $this->creationDate;
    }

    /**
     * Set updatedDate
     *
     * @param \DateTime $updatedDate
     * @return Lot
     */
    public function setUpdatedDate($updatedDate)
    {
        $this->updatedDate = $updatedDate;

        return $this;
    }

    /**
     * Get updatedDate
     *
     * @return \DateTime
     */
    public function getUpdatedDate()
    {
        return $this->updatedDate;
    }

    /**
     * Set planPriceFollowingPeriod
     *
     * @param float $planPriceFollowingPeriod
     * @return Lot
     */
    public function setPlanPriceFollowingPeriod($planPriceFollowingPeriod)
    {
        $this->planPriceFollowingPeriod = $planPriceFollowingPeriod;

        return $this;
    }

    /**
     * Get planPriceFollowingPeriod
     *
     * @return float
     */
    public function getPlanPriceFollowingPeriod()
    {
        return $this->planPriceFollowingPeriod;
    }

    /**
     * Set common
     *
     * @param \AnalyticsBundle\Entity\Common $common
     * @return Lot
     */
    public function setCommon(\AnalyticsBundle\Entity\Common $common = null)
    {
        $this->common = $common;

        return $this;
    }

    /**
     * Get common
     *
     * @return \AnalyticsBundle\Entity\Common
     */
    public function getCommon()
    {
        return $this->common;
    }

    /**
     * Set marketplace
     *
     * @param \AnalyticsBundle\Entity\Marketplace $marketplace
     * @return Lot
     */
    public function setMarketplace(\AnalyticsBundle\Entity\Marketplace $marketplace = null)
    {
        $this->marketplace = $marketplace;

        return $this;
    }

    /**
     * Get marketplace
     *
     * @return \AnalyticsBundle\Entity\Marketplace
     */
    public function getMarketplace()
    {
        return $this->marketplace;
    }

    /**
     * Set supplier
     *
     * @param \AnalyticsBundle\Entity\Supplier $supplier
     * @return Lot
     */
    public function setSupplier(\AnalyticsBundle\Entity\Supplier $supplier = null)
    {
        $this->supplier = $supplier;

        return $this;
    }

    /**
     * Get supplier
     *
     * @return \AnalyticsBundle\Entity\Supplier
     */
    public function getSupplier()
    {
        return $this->supplier;
    }

    /**
     * @return KbkCsr
     */
    public function getKbkCsr()
    {
        return $this->kbkCsr;
    }

    /**
     * @param Kbk $kbkCsr
     *
     * @return Lot
     */
    public function setKbkCsr($kbkCsr)
    {
        $this->kbkCsr = $kbkCsr;

        return $this;
    }

    /**
     * @return KbkExpenseType
     */
    public function getKbkExpenseType()
    {
        return $this->kbkExpenseType;
    }

    /**
     * @param Kbk $kbkExpenseType
     *
     * @return Lot
     */
    public function setKbkExpenseType($kbkExpenseType)
    {
        $this->kbkExpenseType = $kbkExpenseType;

        return $this;
    }

    /**
     * @return KbkKosgu
     */
    public function getKbkKosgu()
    {
        return $this->kbkKosgu;
    }

    /**
     * @param Kbk $kbkKosgu
     *
     * @return Lot
     */
    public function setKbkKosgu($kbkKosgu)
    {
        $this->kbkKosgu = $kbkKosgu;

        return $this;
    }

    /**
     * @return KbkSection
     */
    public function getKbkSection()
    {
        return $this->kbkSection;
    }

    /**
     * set kbkSection
     *
     * @param KbkSection $kbkSection
     *
     * @return Lot
     */
    public function setKbkSection($kbkSection)
    {
        $this->kbkSection = $kbkSection;

        return $this;
    }

    /**
     * Set nks
     *
     * @param $nks
     * @return Lot
     */
    public function setNks($nks = null)
    {
        $this->nks = $nks;

        return $this;
    }

    /**
     * Get nks
     *
     * @return string
     */
    public function getNks()
    {
        return $this->nks;
    }

    /**
     * Set subProgramAction
     *
     * @param \AnalyticsBundle\Entity\SubProgramAction $subProgramAction
     * @return Lot
     */
    public function setSubProgramAction(\AnalyticsBundle\Entity\SubProgramAction $subProgramAction = null)
    {
        $this->subProgramAction = $subProgramAction;

        return $this;
    }

    /**
     * Get subProgramAction
     *
     * @return \AnalyticsBundle\Entity\SubProgramAction
     */
    public function getSubProgramAction()
    {
        return $this->subProgramAction;
    }

    /**
     * Set procResp
     *
     * @param \AnalyticsBundle\Entity\Users $procResp
     * @return Lot
     */
    public function setProcResp(\AnalyticsBundle\Entity\Users $procResp = null)
    {
        $this->procResp = $procResp;

        return $this;
    }

    /**
     * Get procResp
     *
     * @return \AnalyticsBundle\Entity\Users
     */
    public function getProcResp()
    {
        return $this->procResp;
    }

    /**
     * Set expenseType
     *
     * @param \AnalyticsBundle\Entity\ExpenseType $expenseType
     * @return Lot
     */
    public function setExpenseType(\AnalyticsBundle\Entity\ExpenseType $expenseType = null)
    {
        $this->expenseType = $expenseType;

        return $this;
    }

    /**
     * Get expenseType
     *
     * @return \AnalyticsBundle\Entity\ExpenseType
     */
    public function getExpenseType()
    {
        return $this->expenseType;
    }

    /**
     * Set project
     *
     * @param \AnalyticsBundle\Entity\Project $project
     * @return Lot
     */
    public function setProject(\AnalyticsBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \AnalyticsBundle\Entity\Project
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set fcpAction
     *
     * @param \AnalyticsBundle\Entity\FcpAction $fcpAction
     * @return Lot
     */
    public function setFcpAction(\AnalyticsBundle\Entity\FcpAction $fcpAction = null)
    {
        $this->fcpAction = $fcpAction;

        return $this;
    }

    /**
     * Get fcpAction
     *
     * @return \AnalyticsBundle\Entity\FcpAction
     */
    public function getFcpAction()
    {
        return $this->fcpAction;
    }

    /**
     * Set okei
     *
     * @param \AnalyticsBundle\Entity\Okei $okei
     * @return Lot
     */
    public function setOkei(\AnalyticsBundle\Entity\Okei $okei = null)
    {
        $this->okei = $okei;

        return $this;
    }

    /**
     * Get okei
     *
     * @return \AnalyticsBundle\Entity\Okei
     */
    public function getOkei()
    {
        return $this->okei;
    }

    /**
     * Set procurementType
     *
     * @param \AnalyticsBundle\Entity\ProcurementType $procurementType
     * @return Lot
     */
    public function setProcurementType(\AnalyticsBundle\Entity\ProcurementType $procurementType = null)
    {
        $this->procurementType = $procurementType;

        return $this;
    }

    /**
     * Get procurementType
     *
     * @return \AnalyticsBundle\Entity\ProcurementType
     */
    public function getProcurementType()
    {
        return $this->procurementType;
    }

    /**
     * Set nmckType
     *
     * @param \AnalyticsBundle\Entity\NmckType $nmckType
     * @return Lot
     */
    public function setNmckType(\AnalyticsBundle\Entity\NmckType $nmckType = null)
    {
        $this->nmckType = $nmckType;

        return $this;
    }

    /**
     * Get nmckType
     *
     * @return \AnalyticsBundle\Entity\NmckType
     */
    public function getNmckType()
    {
        return $this->nmckType;
    }

    /**
     * Set procurementCause
     *
     * @param \AnalyticsBundle\Entity\ProcurementCause $procurementCause
     * @return Lot
     */
    public function setProcurementCause(\AnalyticsBundle\Entity\ProcurementCause $procurementCause = null)
    {
        $this->procurementCause = $procurementCause;

        return $this;
    }

    /**
     * Get procurementCause
     *
     * @return \AnalyticsBundle\Entity\ProcurementCause
     */
    public function getProcurementCause()
    {
        return $this->procurementCause;
    }

    /**
     * Add stages
     *
     * @param \AnalyticsBundle\Entity\Stage $stages
     * @return Lot
     */
    public function addStage(\AnalyticsBundle\Entity\Stage $stages)
    {
        if (!$this->stages->contains($stages)) {
            $stages->setLot($this);

            $this->stages->add($stages);
        }

        return $this;
    }

    /**
     * Remove stages
     *
     * @param \AnalyticsBundle\Entity\Stage $stages
     */
    public function removeStage(\AnalyticsBundle\Entity\Stage $stages)
    {
        $this->stages->removeElement($stages);
    }

    /**
     * Get stages
     *
     * @return \Doctrine\Common\Collections\Collection|Stage[]
     */
    public function getStages()
    {
        return $this->stages;
    }

    /**
     * Add financings
     *
     * @param \AnalyticsBundle\Entity\Financing $financings
     * @return Lot
     */
    public function addFinancing(\AnalyticsBundle\Entity\Financing $financings)
    {
        if (!$this->financings->contains($financings)) {
            $financings->setLot($this);
            //$is_find = false;
            /**
             * @var mixed $key
             * @var \AnalyticsBundle\Entity\Financing $element
             */
            /*foreach ($this->financings as $key => $element) {
                if ($financings->getRelYear() == $element->getRelYear()) {
                    $element = $financings;
                    $is_find = true;
                }
            }*/
            //if (!$is_find) {
                $this->financings->add($financings);
            //}
        }

        return $this;
    }

    /**
     * Remove financings
     *
     * @param \AnalyticsBundle\Entity\Financing $financings
     */
    public function removeFinancing(\AnalyticsBundle\Entity\Financing $financings)
    {
        $this->financings->removeElement($financings);
    }

    /**
     * Get financings
     *
     * @return Financing[]|\Doctrine\Common\Collections\Collection
     */
    public function getFinancings()
    {
        return $this->financings;
    }


    /**
     * Add financingsPlan
     *
     * @param \AnalyticsBundle\Entity\FinancingPlan $financingsPlan
     * @return Lot
     */
    public function addFinancingPlan(\AnalyticsBundle\Entity\FinancingPlan $financingsPlan)
    {
        if (!$this->financingsPlan->contains($financingsPlan)) {
            $financingsPlan->setLot($this);
            $this->financingsPlan->add($financingsPlan);
        }

        return $this;
    }

    /**
     * @param FinancingPlan $financingsPlan
     * @return $this
     */
    public function removeFinancingPlan(\AnalyticsBundle\Entity\FinancingPlan $financingsPlan)
    {
        $this->financingsPlan->removeElement($financingsPlan);

        return $this;
    }

    /**
     * Get FinancingPlan
     *
     * @return Financing[]|\Doctrine\Common\Collections\Collection
     */
    public function getFinancingsPlan()
    {
        return $this->financingsPlan;
    }

    /**
     * Set fcpActionTask
     *
     * @param \AnalyticsBundle\Entity\FcpAction $fcpActionTask
     * @return Lot
     */
    public function setFcpActionTask(\AnalyticsBundle\Entity\FcpAction $fcpActionTask = null)
    {
        $this->fcpActionTask = $fcpActionTask;

        return $this;
    }

    /**
     * Get fcpActionTask
     *
     * @return \AnalyticsBundle\Entity\FcpAction
     */
    public function getFcpActionTask()
    {
        return $this->fcpActionTask;
    }

    /**
     * Set fcpActionSubaction
     *
     * @param \AnalyticsBundle\Entity\FcpAction $fcpActionSubaction
     * @return Lot
     */
    public function setFcpActionSubaction(\AnalyticsBundle\Entity\FcpAction $fcpActionSubaction = null)
    {
        $this->fcpActionSubaction = $fcpActionSubaction;

        return $this;
    }

    /**
     * Get fcpActionSubaction
     *
     * @return \AnalyticsBundle\Entity\FcpAction
     */
    public function getFcpActionSubaction()
    {
        return $this->fcpActionSubaction;
    }

    /**
     * Add plan
     *
     * @param \AnalyticsBundle\Entity\Plan $plan
     * @return Lot
     */
    public function addPlan(\AnalyticsBundle\Entity\Plan $plan)
    {
        $this->plan[] = $plan;
        return $this;
    }

    /**
     * Remove plan
     *
     * @param \AnalyticsBundle\Entity\Plan $plan
     */
    public function removePlan(\AnalyticsBundle\Entity\Plan $plan)
    {
        $this->plan->removeElement($plan);
    }

    /**
     * Get plan
     *
     * @return \Doctrine\Common\Collections\Collection|Plan[]
     */
    public function getPlan()
    {
        return $this->plan->filter(function($el){
            return $el->getIsRevision() != true;
        });
    }

    /**
     * Set requirement3044
     *
     * @param boolean $requirement3044
     * @return Lot
     */
    public function setRequirement3044($requirement3044)
    {
        $this->requirement3044 = $requirement3044;

        return $this;
    }

    /**
     * Get requirement3044
     *
     * @return boolean
     */
    public function getRequirement3044()
    {
        return $this->requirement3044;
    }

    /**
     * Set subProgram
     *
     * @param \AnalyticsBundle\Entity\SubProgramAction $subProgram
     * @return Lot
     */
    public function setSubProgram(\AnalyticsBundle\Entity\SubProgramAction $subProgram = null)
    {
        $this->subProgram = $subProgram;

        return $this;
    }

    /**
     * Get subProgram
     *
     * @return \AnalyticsBundle\Entity\SubProgramAction
     */
    public function getSubProgram()
    {
        return $this->subProgram;
    }

    /**
     * Set subProgramMainAction
     *
     * @param \AnalyticsBundle\Entity\SubProgramAction $subProgramMainAction
     * @return Lot
     */
    public function setSubProgramMainAction(\AnalyticsBundle\Entity\SubProgramAction $subProgramMainAction = null)
    {
        $this->subProgramMainAction = $subProgramMainAction;

        return $this;
    }

    /**
     * Get subProgramMainAction
     *
     * @return \AnalyticsBundle\Entity\SubProgramAction
     */
    public function getSubProgramMainAction()
    {
        return $this->subProgramMainAction;
    }

    /**
     * Set govProgram
     *
     * @param \AnalyticsBundle\Entity\GovProgram $govProgram
     * @return Lot
     */
    public function setGovProgram(\AnalyticsBundle\Entity\GovProgram $govProgram = null)
    {
        $this->govProgram = $govProgram;

        return $this;
    }

    /**
     * Get govProgram
     *
     * @return \AnalyticsBundle\Entity\GovProgram
     */
    public function getGovProgram()
    {
        return $this->govProgram;
    }

    /**
     * Set quantity
     *
     * @param integer $quantity
     * @return Lot
     */
    public function setQuantity($quantity)
    {
        $this->quantity = $quantity;

        return $this;
    }

    /**
     * Get quantity
     *
     * @return integer
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     * Set orderTitle
     *
     * @param string $orderTitle
     * @return Lot
     */
    public function setOrderTitle($orderTitle)
    {
        $this->orderTitle = $orderTitle;

        return $this;
    }

    /**
     * Get orderTitle
     *
     * @return string
     */
    public function getOrderTitle()
    {
        return $this->orderTitle;
    }

    /**
     * Set orderNumber
     *
     * @param string $orderNumber
     * @return Lot
     */
    public function setOrderNumber($orderNumber)
    {
        $this->orderNumber = $orderNumber;

        return $this;
    }

    /**
     * Get orderNumber
     *
     * @return string
     */
    public function getOrderNumber()
    {
        return $this->orderNumber;
    }

    /**
     * Set orderDate
     *
     * @param \DateTime $orderDate
     * @return Lot
     */
    public function setOrderDate($orderDate)
    {
        $this->orderDate = $orderDate;

        return $this;
    }

    /**
     * Get orderDate
     *
     * @return \DateTime
     */
    public function getOrderDate()
    {
        return $this->orderDate;
    }

    /**
     * Add lotDoc
     *
     * @param \AnalyticsBundle\Entity\LotDoc $lotDoc
     * @return Lot
     */
    public function addLotDoc(\AnalyticsBundle\Entity\LotDoc $lotDoc)
    {
        if (!$this->lotDoc->contains($lotDoc)) {
            $lotDoc->setLot($this);

            $this->lotDoc->add($lotDoc);
        }

        return $this;
    }

    /**
     * Remove lotDoc
     *
     * @param \AnalyticsBundle\Entity\LotDoc $lotDoc
     */
    public function removeLotDoc(\AnalyticsBundle\Entity\LotDoc $lotDoc)
    {
        $this->lotDoc->removeElement($lotDoc);
    }

    /**
     * Get lotDoc
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLotDoc()
    {
        return $this->lotDoc;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getTitle();
    }

    /**
     * Add okved
     *
     * @param \AnalyticsBundle\Entity\Okved $okved
     * @return Lot
     */
    public function addOkved(\AnalyticsBundle\Entity\Okved $okved)
    {
        $this->okved[] = $okved;

        return $this;
    }

    /**
     * Remove okved
     *
     * @param \AnalyticsBundle\Entity\Okved $okved
     */
    public function removeOkved(\AnalyticsBundle\Entity\Okved $okved)
    {
        $this->okved->removeElement($okved);
    }

    /**
     * Add okpd
     *
     * @param \AnalyticsBundle\Entity\Okpd $okpd
     * @return Lot
     */
    public function addOkpd(\AnalyticsBundle\Entity\Okpd $okpd)
    {
        $this->okpd[] = $okpd;

        return $this;
    }

    /**
     * Remove okpd
     *
     * @param \AnalyticsBundle\Entity\Okpd $okpd
     */
    public function removeOkpd(\AnalyticsBundle\Entity\Okpd $okpd)
    {
        $this->okpd->removeElement($okpd);
    }

    /**
     * Get okved
     *
     * @return \Doctrine\Common\Collections\Collection|Okved[]
     */
    public function getOkved()
    {
        return $this->okved;
    }

    /**
     * Get okpd
     *
     * @return \Doctrine\Common\Collections\Collection|Okpd[]
     */
    public function getOkpd()
    {
        return $this->okpd;
    }

    /**
     * Set nmckPrice
     *
     * @param float $nmckPrice
     * @return Lot
     */
    public function setNmckPrice($nmckPrice)
    {
        $this->nmckPrice = $nmckPrice;

        return $this;
    }

    /**
     * Get nmckPrice
     *
     * @return float
     */
    public function getNmckPrice()
    {
        return $this->nmckPrice;
    }

    /**
     * Set nmckComment
     *
     * @param string $nmckComment
     * @return Lot
     */
    public function setNmckComment($nmckComment)
    {
        $this->nmckComment = $nmckComment;

        return $this;
    }

    /**
     * Get nmckComment
     *
     * @return string
     */
    public function getNmckComment()
    {
        return $this->nmckComment;
    }

    /**
     * Add nmckDoc
     *
     * @param \AnalyticsBundle\Entity\NmckDoc $nmckDoc
     * @return Lot
     */
    public function addNmckDoc(\AnalyticsBundle\Entity\NmckDoc $nmckDoc)
    {
        if (!$this->nmckDoc->contains($nmckDoc)) {
            $nmckDoc->setLot($this);

            $this->nmckDoc->add($nmckDoc);
        }

        return $this;
    }

    /**
     * Remove nmckDoc
     *
     * @param \AnalyticsBundle\Entity\NmckDoc $nmckDoc
     */
    public function removeNmckDoc(\AnalyticsBundle\Entity\NmckDoc $nmckDoc)
    {
        $this->nmckDoc->removeElement($nmckDoc);
    }

    /**
     * Get nmckDoc
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getNmckDoc()
    {
        return $this->nmckDoc;
    }

    /**
     * @JMS\VirtualProperty
     * @JMS\Type("boolean")
     * @JMS\SerializedName("externalSource")
     * @JMS\Groups({"lot_list", "lot_detail", "lot_item_plans"})
     */
    public function externalSource()
    {
        return
            !is_null($this->getDfcpId()) ||
            !is_null($this->getSstpId());
    }

    /**
     * @return string
     */
    public function getIszNumber()
    {
        return $this->iszNumber;
    }

    /**
     * @param string $iszNumber
     */
    public function setIszNumber($iszNumber)
    {
        $this->iszNumber = $iszNumber;
    }

    /**
     * @return boolean
     */
    public function isIsOneSupplier()
    {
        return $this->isOneSupplier;
    }

    /**
     * @param boolean $isOneSupplier
     */
    public function setIsOneSupplier($isOneSupplier)
    {
        $this->isOneSupplier = $isOneSupplier;
    }

    /**
     * @return boolean
     */
    public function isIsUseCulturalHeritage()
    {
        return $this->isUseCulturalHeritage;
    }

    /**
     * @param boolean $isUseCulturalHeritage
     */
    public function setIsUseCulturalHeritage($isUseCulturalHeritage)
    {
        $this->isUseCulturalHeritage = $isUseCulturalHeritage;
    }

    /**
     * @return string
     */
    public function getSpecificationTasks()
    {
        return $this->specificationTasks;
    }

    /**
     * @param string $specificationTasks
     */
    public function setSpecificationTasks($specificationTasks)
    {
        $this->specificationTasks = $specificationTasks;
    }

    /**
     * @return string
     */
    public function getSpecificationContent()
    {
        return $this->specificationContent;
    }

    /**
     * @param string $specificationContent
     */
    public function setSpecificationContent($specificationContent)
    {
        $this->specificationContent = $specificationContent;
    }

    /**
     * @return string
     */
    public function getSpecificationDocReq()
    {
        return $this->specificationDocReq;
    }

    /**
     * @param string $specificationDocReq
     */
    public function setSpecificationDocReq($specificationDocReq)
    {
        $this->specificationDocReq = $specificationDocReq;
    }

    /**
     * @return string
     */
    public function getSpecificationStageContent()
    {
        return $this->specificationStageContent;
    }

    /**
     * @param string $specificationStageContent
     */
    public function setSpecificationStageContent($specificationStageContent)
    {
        $this->specificationStageContent = $specificationStageContent;
    }

    /**
     * @return string
     */
    public function getSpecificationAcceptConditions()
    {
        return $this->specificationAcceptConditions;
    }

    /**
     * @param string $specificationAcceptConditions
     */
    public function setSpecificationAcceptConditions($specificationAcceptConditions)
    {
        $this->specificationAcceptConditions = $specificationAcceptConditions;
    }

    /**
     * @return string
     */
    public function getNmckUrl()
    {
        return $this->nmckUrl;
    }

    /**
     * @param string $nmckUrl
     */
    public function setNmckUrl($nmckUrl)
    {
        $this->nmckUrl = $nmckUrl;
    }

    /**
     * Get isOneSupplier
     *
     * @return boolean 
     */
    public function getIsOneSupplier()
    {
        return $this->isOneSupplier;
    }

    /**
     * Get isUseCulturalHeritage
     *
     * @return boolean 
     */
    public function getIsUseCulturalHeritage()
    {
        return $this->isUseCulturalHeritage;
    }

    /**
     * Add nmckJustifications
     *
     * @param \AnalyticsBundle\Entity\NmckJustification $nmckJustifications
     * @return Lot
     */
    public function addNmckJustification(\AnalyticsBundle\Entity\NmckJustification $nmckJustifications)
    {
        if (!$this->nmckJustifications->contains($nmckJustifications)) {
            $nmckJustifications->setLot($this);

            $this->nmckJustifications->add($nmckJustifications);
        }

        return $this;
    }

    /**
     * Remove nmckJustifications
     *
     * @param \AnalyticsBundle\Entity\NmckJustification $nmckJustifications
     */
    public function removeNmckJustification(\AnalyticsBundle\Entity\NmckJustification $nmckJustifications)
    {
        $this->nmckJustifications->removeElement($nmckJustifications);
    }

    /**
     * Get nmckJustifications
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getNmckJustifications()
    {
        return $this->nmckJustifications;
    }

    /**
     * Set advancePaymentPercentage
     *
     * @param float $advancePaymentPercentage
     * @return Lot
     */
    public function setAdvancePaymentPercentage($advancePaymentPercentage)
    {
        $this->advancePaymentPercentage = $advancePaymentPercentage;

        return $this;
    }

    /**
     * Get advancePaymentPercentage
     *
     * @return float 
     */
    public function getAdvancePaymentPercentage()
    {
        return $this->advancePaymentPercentage;
    }

    /**
     * Set kdMethodProvision
     *
     * @param string $kdMethodProvision
     * @return Lot
     */
    public function setKdMethodProvision($kdMethodProvision)
    {
        $this->kdMethodProvision = $kdMethodProvision;

        return $this;
    }

    /**
     * Get kdMethodProvision
     *
     * @return string 
     */
    public function getKdMethodProvision()
    {
        return $this->kdMethodProvision;
    }

    /**
     * Set kdDateTimeStartProvision
     *
     * @param \DateTime $kdDateTimeStartProvision
     * @return Lot
     */
    public function setKdDateTimeStartProvision($kdDateTimeStartProvision)
    {
        $this->kdDateTimeStartProvision = $kdDateTimeStartProvision;

        return $this;
    }

    /**
     * Get kdDateTimeStartProvision
     *
     * @return \DateTime 
     */
    public function getKdDateTimeStartProvision()
    {
        return $this->kdDateTimeStartProvision;
    }

    /**
     * Set kdDateTimeEndProvision
     *
     * @param \DateTime $kdDateTimeEndProvision
     * @return Lot
     */
    public function setKdDateTimeEndProvision($kdDateTimeEndProvision)
    {
        $this->kdDateTimeEndProvision = $kdDateTimeEndProvision;

        return $this;
    }

    /**
     * Get kdDateTimeEndProvision
     *
     * @return \DateTime 
     */
    public function getKdDateTimeEndProvision()
    {
        return $this->kdDateTimeEndProvision;
    }

    /**
     * Set kdPlaceProvision
     *
     * @param string $kdPlaceProvision
     * @return Lot
     */
    public function setKdPlaceProvision($kdPlaceProvision)
    {
        $this->kdPlaceProvision = $kdPlaceProvision;

        return $this;
    }

    /**
     * Get kdPlaceProvision
     *
     * @return string 
     */
    public function getKdPlaceProvision()
    {
        return $this->kdPlaceProvision;
    }

    /**
     * Set kdOrderProvision
     *
     * @param string $kdOrderProvision
     * @return Lot
     */
    public function setKdOrderProvision($kdOrderProvision)
    {
        $this->kdOrderProvision = $kdOrderProvision;

        return $this;
    }

    /**
     * Get kdOrderProvision
     *
     * @return string 
     */
    public function getKdOrderProvision()
    {
        return $this->kdOrderProvision;
    }

    /**
     * Set fcp
     *
     * @param \AnalyticsBundle\Entity\Fcp $fcp
     * @return Lot
     */
    public function setFcp(\AnalyticsBundle\Entity\Fcp $fcp = null)
    {
        $this->fcp = $fcp;

        return $this;
    }

    /**
     * Get fcp
     *
     * @return \AnalyticsBundle\Entity\Fcp 
     */
    public function getFcp()
    {
        return $this->fcp;
    }

    /**
     * Set kbkFlowDirection
     *
     * @param \AnalyticsBundle\Entity\KbkFlowDirection $kbkFlowDirection
     * @return Lot
     */
    public function setKbkFlowDirection(\AnalyticsBundle\Entity\KbkFlowDirection $kbkFlowDirection = null)
    {
        $this->kbkFlowDirection = $kbkFlowDirection;

        return $this;
    }

    /**
     * Get kbkFlowDirection
     *
     * @return \AnalyticsBundle\Entity\KbkFlowDirection 
     */
    public function getKbkFlowDirection()
    {
        return $this->kbkFlowDirection;
    }

    /**
     * Add criteria
     *
     * @param \AnalyticsBundle\Entity\LotCriteria $criteria
     * @return Lot
     */
    public function addCriterium(\AnalyticsBundle\Entity\LotCriteria $criteria)
    {
        if (!$this->criteria->contains($criteria)) {
            $criteria->setLot($this);

            $this->criteria->add($criteria);
        }

        return $this;
    }

    /**
     * Add criteria
     *
     * @param \AnalyticsBundle\Entity\LotCriteria $criteria
     * @return Lot
     */
    public function addCriteria(\AnalyticsBundle\Entity\LotCriteria $criteria)
    {
        return $this->addCriterium($criteria);
    }

    /**
     * Remove criteria
     *
     * @param \AnalyticsBundle\Entity\LotCriteria $criteria
     */
    public function removeCriterium(\AnalyticsBundle\Entity\LotCriteria $criteria)
    {
        $this->criteria->removeElement($criteria);
    }

    /**
     * Remove criteria
     *
     * @param \AnalyticsBundle\Entity\LotCriteria $criteria
     */
    public function removeCriteria(\AnalyticsBundle\Entity\LotCriteria $criteria)
    {
        $this->removeCriterium($criteria);
    }

    /**
     * Get criteria
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getCriteria()
    {
        return $this->criteria;
    }

    /**
     * Set criteriaCondition
     *
     * @param \AnalyticsBundle\Entity\CriteriaCondition $criteriaCondition
     * @return Lot
     */
    public function setCriteriaCondition(\AnalyticsBundle\Entity\CriteriaCondition $criteriaCondition = null)
    {
        $this->criteriaCondition = $criteriaCondition;

        return $this;
    }

    /**
     * Get criteriaCondition
     *
     * @return \AnalyticsBundle\Entity\CriteriaCondition
     */
    public function getCriteriaCondition()
    {
        return $this->criteriaCondition;
    }

    /**
     * Add ria
     *
     * @param \AnalyticsBundle\Entity\LotRia $ria
     * @return Lot
     */
    public function addRium(\AnalyticsBundle\Entity\LotRia $ria)
    {
        if (!$this->ria->contains($ria)) {
            $ria->setLot($this);

            $this->ria->add($ria);
        }

        return $this;
    }

    /**
     * Add ria
     *
     * @param \AnalyticsBundle\Entity\LotRia $ria
     * @return Lot
     */
    public function addRia(\AnalyticsBundle\Entity\LotRia $ria)
    {
        return $this->addRium($ria);
    }

    /**
     * Remove ria
     *
     * @param \AnalyticsBundle\Entity\LotRia $ria
     */
    public function removeRium(\AnalyticsBundle\Entity\LotRia $ria)
    {
        $this->ria->removeElement($ria);
    }

    /**
     * Remove ria
     *
     * @param \AnalyticsBundle\Entity\LotRia $ria
     */
    public function removeRia(\AnalyticsBundle\Entity\LotRia $ria)
    {
        $this->removeRium($ria);
    }

    /**
     * Get ria
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getRia()
    {
        return $this->ria;
    }

    /**
     * Add rateIndicator
     *
     * @param \AnalyticsBundle\Entity\LotRateIndicator $rateIndicator
     * @return Lot
     */
    public function addRateIndicator(\AnalyticsBundle\Entity\LotRateIndicator $rateIndicator)
    {
        if (!$this->rateIndicator->contains($rateIndicator)) {
            $rateIndicator->setLot($this);

            $this->rateIndicator->add($rateIndicator);
        }

        return $this;
    }

    /**
     * Remove rateIndicator
     *
     * @param \AnalyticsBundle\Entity\LotRateIndicator $rateIndicator
     */
    public function removeRateIndicator(\AnalyticsBundle\Entity\LotRateIndicator $rateIndicator)
    {
        $this->rateIndicator->removeElement($rateIndicator);
    }

    /**
     * Get rateIndicator
     *
     * @return \Doctrine\Common\Collections\Collection|\AnalyticsBundle\Entity\LotRateIndicator[]
     */
    public function getRateIndicator()
    {
        return $this->rateIndicator;
    }

    /**
     * Set placingInEisDepartment
     *
     * @param string $placingInEisDepartment
     * @return Lot
     */
    public function setPlacingInEisDepartment($placingInEisDepartment)
    {
        $this->placingInEisDepartment = $placingInEisDepartment;

        return $this;
    }

    /**
     * Get placingInEisDepartment
     *
     * @return string 
     */
    public function getPlacingInEisDepartment()
    {
        return $this->placingInEisDepartment;
    }

    /**
     * Set placingInEisPerson
     *
     * @param string $placingInEisPerson
     * @return Lot
     */
    public function setPlacingInEisPerson($placingInEisPerson)
    {
        $this->placingInEisPerson = $placingInEisPerson;

        return $this;
    }

    /**
     * Get placingInEisPerson
     *
     * @return string 
     */
    public function getPlacingInEisPerson()
    {
        return $this->placingInEisPerson;
    }

    /**
     * Set placingInEisJobTitle
     *
     * @param string $placingInEisJobTitle
     * @return Lot
     */
    public function setPlacingInEisJobTitle($placingInEisJobTitle)
    {
        $this->placingInEisJobTitle = $placingInEisJobTitle;

        return $this;
    }

    /**
     * Get placingInEisJobTitle
     *
     * @return string 
     */
    public function getPlacingInEisJobTitle()
    {
        return $this->placingInEisJobTitle;
    }

    /**
     * Set placingInEisPhone
     *
     * @param string $placingInEisPhone
     * @return Lot
     */
    public function setPlacingInEisPhone($placingInEisPhone)
    {
        $this->placingInEisPhone = $placingInEisPhone;

        return $this;
    }

    /**
     * Get placingInEisPhone
     *
     * @return string 
     */
    public function getPlacingInEisPhone()
    {
        return $this->placingInEisPhone;
    }

    /**
     * Set placingInEisEmail
     *
     * @param string $placingInEisEmail
     * @return Lot
     */
    public function setPlacingInEisEmail($placingInEisEmail)
    {
        $this->placingInEisEmail = $placingInEisEmail;

        return $this;
    }

    /**
     * Get placingInEisEmail
     *
     * @return string 
     */
    public function getPlacingInEisEmail()
    {
        return $this->placingInEisEmail;
    }

    /**
     * Set placingInEisPersonFamily
     *
     * @param string $placingInEisPersonFamily
     * @return Lot
     */
    public function setPlacingInEisPersonFamily($placingInEisPersonFamily)
    {
        $this->placingInEisPersonFamily = $placingInEisPersonFamily;

        return $this;
    }

    /**
     * Get placingInEisPersonFamily
     *
     * @return string 
     */
    public function getPlacingInEisPersonFamily()
    {
        return $this->placingInEisPersonFamily;
    }

    /**
     * Set placingInEisPersonName
     *
     * @param string $placingInEisPersonName
     * @return Lot
     */
    public function setPlacingInEisPersonName($placingInEisPersonName)
    {
        $this->placingInEisPersonName = $placingInEisPersonName;

        return $this;
    }

    /**
     * Get placingInEisPersonName
     *
     * @return string 
     */
    public function getPlacingInEisPersonName()
    {
        return $this->placingInEisPersonName;
    }

    /**
     * Set placingInEisPersonPatronomic
     *
     * @param string $placingInEisPersonPatronomic
     * @return Lot
     */
    public function setPlacingInEisPersonPatronomic($placingInEisPersonPatronomic)
    {
        $this->placingInEisPersonPatronomic = $placingInEisPersonPatronomic;

        return $this;
    }

    /**
     * Get placingInEisPersonPatronomic
     *
     * @return string 
     */
    public function getPlacingInEisPersonPatronomic()
    {
        return $this->placingInEisPersonPatronomic;
    }


    /**
     * Add gz
     *
     * @param \AnalyticsBundle\Entity\Gz $gz
     * @return Lot
     */
    public function addGz(\AnalyticsBundle\Entity\Gz $gz)
    {
        if (!$this->ria->contains($gz)) {
            $gz->setLot($this);

            $this->gz->add($gz);
        }

        return $this;
    }


    /**
     * Remove gz
     *
     * @param \AnalyticsBundle\Entity\Gz $gz
     */
    public function removeGz(\AnalyticsBundle\Entity\Gz $gz)
    {
        $this->gz->removeElement($gz);
    }


    /**
     * Get ria
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getGz()
    {
        return $this->gz;
    }

    /**
     * Get documentFreshDoc
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getDocumentFreshDoc()
    {
        return $this->documentFreshDoc;
    }

}
