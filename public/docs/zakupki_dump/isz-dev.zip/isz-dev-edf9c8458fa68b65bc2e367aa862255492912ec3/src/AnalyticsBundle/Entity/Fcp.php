<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Fcp
 *
 * @ORM\Table(
 *     name="fcp",
 *     indexes={
 *         @ORM\Index(name="fcp_executor_id", columns={"executor_id"}),
 *         @ORM\Index(name="fcp_gov_program_id", columns={"gov_program_id"}),
 *         @ORM\Index(name="fcp_co_executor_id", columns={"co_executor_id"})
 *     }
 * )
 *
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\FcpRepository")
 * @Json\Schema("Fcp")
 */
class Fcp implements IEntity
{
    const SHORT_TITLE_FCPRO = 'ФЦПРО';

    // Раньше было a045e0af-ee4e-4881-9681-22289d31fa7a
    const ID_FCPRO = "d8239d59-cb9c-48de-8414-590c2ddd6926";  // @todo: Понимаю это бред!!! надо переделать и
                                                              // @todo: получать ФЦП по number и последней версии

    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"lot_detail", "lot_list", "fcp_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "lot_list", "fcp_detail"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="short_title", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "fcp_detail"})
     */
    private $shortTitle;

    /**
     * @var string
     *
     * @ORM\Column(name="number", type="string", length=255, nullable=true)
     * @JMS\Groups({"lot_detail", "lot_list", "fcp_detail"})
     */
    private $number;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="execution_startdate", type="date", nullable=true)
     * @JMS\Groups({"fcp_detail"})
     */
    private $executionStartdate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="execution_enddate", type="date", nullable=true)
     * @JMS\Groups({"fcp_detail"})
     */
    private $executionEnddate;

    /**
     * @var string
     *
     * @ORM\Column(name="goals", type="text", nullable=true)
     * @JMS\Groups({"fcp_detail"})
     */
    private $goals;

    /**
     * @var string
     *
     * @ORM\Column(name="tasks", type="text", nullable=true)
     * @JMS\Groups({"fcp_detail"})
     */
    private $tasks;

    /**
     * @var Common
     *
     * @ORM\ManyToOne(targetEntity="Common")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="executor_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"fcp_detail"})
     */
    private $executor;

    /**
     * @var Common
     *
     * @ORM\ManyToOne(targetEntity="Common")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="co_executor_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"fcp_detail"})
     */
    private $coExecutor;
 
    /**
     * @var GovProgram
     *
     * @ORM\ManyToOne(targetEntity="GovProgram")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="gov_program_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"fcp_detail"})
     */
    private $govProgram;

    /**
     * @var string
     *
     * @ORM\Column(name="ksuf_id", type="string", length=64, nullable=true)
     * @JMS\Groups({"fcp_detail"})
     */
    private $ksufId;


    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Fcp
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set number
     *
     * @param string $number
     * @return Fcp
     */
    public function setNumber($number)
    {
        $this->number = $number;

        return $this;
    }

    /**
     * Get number
     *
     * @return string 
     */
    public function getNumber()
    {
        return $this->number;
    }

    /**
     * Set executionStartdate
     *
     * @param \DateTime $executionStartdate
     * @return Fcp
     */
    public function setExecutionStartdate($executionStartdate)
    {
        $this->executionStartdate = $executionStartdate;

        return $this;
    }

    /**
     * Get executionStartdate
     *
     * @return \DateTime 
     */
    public function getExecutionStartdate()
    {
        return $this->executionStartdate;
    }

    /**
     * Set executionEnddate
     *
     * @param \DateTime $executionEnddate
     * @return Fcp
     */
    public function setExecutionEnddate($executionEnddate)
    {
        $this->executionEnddate = $executionEnddate;

        return $this;
    }

    /**
     * Get executionEnddate
     *
     * @return \DateTime 
     */
    public function getExecutionEnddate()
    {
        return $this->executionEnddate;
    }

    /**
     * Set goals
     *
     * @param string $goals
     * @return Fcp
     */
    public function setGoals($goals)
    {
        $this->goals = $goals;

        return $this;
    }

    /**
     * Get goals
     *
     * @return string 
     */
    public function getGoals()
    {
        return $this->goals;
    }

    /**
     * Set tasks
     *
     * @param string $tasks
     * @return Fcp
     */
    public function setTasks($tasks)
    {
        $this->tasks = $tasks;

        return $this;
    }

    /**
     * Get tasks
     *
     * @return string 
     */
    public function getTasks()
    {
        return $this->tasks;
    }

    /**
     * Set executor
     *
     * @param \AnalyticsBundle\Entity\Common $executor
     * @return Fcp
     */
    public function setExecutor(\AnalyticsBundle\Entity\Common $executor = null)
    {
        $this->executor = $executor;

        return $this;
    }

    /**
     * Get executor
     *
     * @return \AnalyticsBundle\Entity\Common
     */
    public function getExecutor()
    {
        return $this->executor;
    }

    /**
     * Set coExecutor
     *
     * @param \AnalyticsBundle\Entity\Common $coExecutor
     * @return Fcp
     */
    public function setCoExecutor(\AnalyticsBundle\Entity\Common $coExecutor = null)
    {
        $this->coExecutor = $coExecutor;

        return $this;
    }

    /**
     * Get coExecutor
     *
     * @return \AnalyticsBundle\Entity\Common
     */
    public function getCoExecutor()
    {
        return $this->coExecutor;
    }

    /**
     * Set govProgram
     *
     * @param \AnalyticsBundle\Entity\GovProgram $govProgram
     * @return Fcp
     */
    public function setGovProgram(\AnalyticsBundle\Entity\GovProgram $govProgram = null)
    {
        $this->govProgram = $govProgram;

        return $this;
    }

    /**
     * Get govProgram
     *
     * @return \AnalyticsBundle\Entity\GovProgram
     */
    public function getGovProgram()
    {
        return $this->govProgram;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getTitle();
    }

    /**
     * @return string
     */
    public function getShortTitle()
    {
        return $this->shortTitle;
    }

    /**
     * @param string $shortTitle
     */
    public function setShortTitle($shortTitle)
    {
        $this->shortTitle = $shortTitle;
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;

    /**
     * Set ksufId
     *
     * @param string $ksufId
     * @return Fcp
     */
    public function setKsufId($ksufId)
    {
        $this->ksufId = $ksufId;

        return $this;
    }

    /**
     * Get ksufId
     *
     * @return string 
     */
    public function getKsufId()
    {
        return $this->ksufId;
    }
}
