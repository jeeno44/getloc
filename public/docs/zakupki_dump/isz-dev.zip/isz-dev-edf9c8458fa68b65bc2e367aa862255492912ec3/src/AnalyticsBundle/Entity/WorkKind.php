<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * WorkKind
 *
 * @ORM\Table(
 *   name="work_kind",
 *   indexes={
 *     @ORM\Index(name="work_kind_work_type_id", columns={"work_type_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\WorkKindRepository")
 * @Json\Schema("WorkKind")
 */
class WorkKind implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"lot_detail", "work_kinds_detail", "work_kinds_list"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "work_kinds_detail", "work_kinds_list"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="qualitative_char", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "work_kinds_detail", "work_kinds_list"})
     */
    private $qualitativeChar;

    /**
     * @var string
     *
     * @ORM\Column(name="results", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "work_kinds_detail", "work_kinds_list"})
     */
    private $results;


    /**
     * @var string
     *
     * @ORM\Column(name="license", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "work_kinds_detail", "work_kinds_list"})
     */
    private $license;

    /**
     * @var string
     *
     * @ORM\Column(name="rights_ois", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "work_kinds_detail", "work_kinds_list"})
     */
    private $rightsOis;

    /**
     * @var string
     *
     * @ORM\Column(name="npa", type="text", nullable=true)
     * @JMS\Groups({"lot_detail", "work_kinds_detail", "work_kinds_list"})
     */
    private $npa;

    /**
     * @var WorkType
     *
     * @ORM\ManyToOne(targetEntity="WorkType")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="work_type_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"lot_detail", "work_kinds_detail"})
     */
    private $workType;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return WorkKind
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set qualitativeChar
     *
     * @param string $qualitativeChar
     * @return WorkKind
     */
    public function setQualitativeChar($qualitativeChar)
    {
        $this->qualitativeChar = $qualitativeChar;

        return $this;
    }

    /**
     * Get qualitativeChar
     *
     * @return string 
     */
    public function getQualitativeChar()
    {
        return $this->qualitativeChar;
    }

    /**
     * Set results
     *
     * @param string $results
     * @return WorkKind
     */
    public function setResults($results)
    {
        $this->results = $results;

        return $this;
    }

    /**
     * Get results
     *
     * @return string 
     */
    public function getResults()
    {
        return $this->results;
    }

    /**
     * Set license
     *
     * @param string $license
     * @return WorkKind
     */
    public function setLicense($license)
    {
        $this->license = $license;

        return $this;
    }

    /**
     * Get license
     *
     * @return string 
     */
    public function getLicense()
    {
        return $this->license;
    }

    /**
     * Set rightsOis
     *
     * @param string $rightsOis
     * @return WorkKind
     */
    public function setRightsOis($rightsOis)
    {
        $this->rightsOis = $rightsOis;

        return $this;
    }

    /**
     * Get rightsOis
     *
     * @return string 
     */
    public function getRightsOis()
    {
        return $this->rightsOis;
    }

    /**
     * Set npa
     *
     * @param string $npa
     * @return WorkKind
     */
    public function setNpa($npa)
    {
        $this->npa = $npa;

        return $this;
    }

    /**
     * Get npa
     *
     * @return string 
     */
    public function getNpa()
    {
        return $this->npa;
    }

    /**
     * Set workType
     *
     * @param \AnalyticsBundle\Entity\WorkType $workType
     * @return WorkKind
     */
    public function setWorkType(\AnalyticsBundle\Entity\WorkType $workType = null)
    {
        $this->workType = $workType;

        return $this;
    }

    /**
     * Get workType
     *
     * @return \AnalyticsBundle\Entity\WorkType
     */
    public function getWorkType()
    {
        return $this->workType;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
