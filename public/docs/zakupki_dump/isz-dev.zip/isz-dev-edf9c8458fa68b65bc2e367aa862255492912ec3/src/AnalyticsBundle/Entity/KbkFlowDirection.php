<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * KbkCsr
 *
 * @ORM\Table(name="kbk_flow_direction")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\KbkFlowDirectionRepository")
 * @Json\Schema("KbkFlowDirection")
 */
class KbkFlowDirection
{
    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"FlowDirection"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="number", type="string", length=16, nullable=true)
     * @JMS\Groups({"FlowDirection"})
     */
    private $number;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=512, nullable=false)
     * @JMS\Groups({"FlowDirection"})
     */
    private $title;


    /**
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getNumber() . ' - ' . $this->getTitle();
    }

    /**
     * Set number
     *
     * @param string $number
     * @return KbkFlowDirection
     */
    public function setNumber($number)
    {
        $this->number = $number;

        return $this;
    }

    /**
     * Get number
     *
     * @return string 
     */
    public function getNumber()
    {
        return $this->number;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return KbkFlowDirection
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }
}
