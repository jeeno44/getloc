<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * ProcurementCause
 *
 * @ORM\Table(name="procurement_cause")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\ProcurementCauseRepository")
 * @Json\Schema("ProcurementCause")
 */
class ProcurementCause implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"list", "details"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     * @JMS\Groups({"list", "details"})
     */
    private $title;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return ProcurementCause
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
