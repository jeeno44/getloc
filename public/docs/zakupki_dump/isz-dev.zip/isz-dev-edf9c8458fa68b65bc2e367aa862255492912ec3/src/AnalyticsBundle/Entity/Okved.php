<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Okved
 *
 * @ORM\Table(name="okved")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\OkvedRepository")
 * @Json\Schema("Okved")
 */
class Okved implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"okved", "okved_list", "okved_detail", "lot_detail", "all", "common_detail"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=1024, nullable=true)
     * @JMS\Groups({"okved", "okved_list", "okved_detail", "lot_detail", "common_detail"})
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=16, nullable=false)
     * @JMS\Groups({"okved", "okved_list", "okved_detail", "lot_detail", "all", "common_detail"})
     */
    private $code;

    /**
     * @var string
     *
     * @ORM\Column(name="value", type="decimal", precision=17, scale=2, nullable=true)
     * @JMS\Groups({"okved_list", "lot_detail", "okved_detail", "common_detail"})
     */
    private $value;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Okved
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return Okved
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set value
     *
     * @param string $value
     * @return Okved
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return string 
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return sprintf("%s - %s", $this->getCode(), $this->getTitle());
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
