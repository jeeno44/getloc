<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use AnalyticsBundle\Entity\IEntity;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * CriteriaRating
 *
 * @ORM\Table(
 *     name="criteria_rating",
 *     indexes={@ORM\Index(name="criteria_rating_criteria_type_id", columns={"criteria_type_id"})}
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\CriteriaRatingRepository")
 * @Json\Schema("CriteriaRating")
 */
class CriteriaRating implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="SEQUENCE")
     * @ORM\SequenceGenerator(sequenceName="criteria_rating_id_seq", allocationSize=1, initialValue=1)
     * @JMS\Groups({"CriteriaRating"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     * @JMS\Groups({"CriteriaRating"})
     */
    private $title;

    /**
     * @var CriteriaType
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\CriteriaType")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="criteria_type_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"CriteriaRating"})
     */
    private $criteriaType;

    /**
     * @var \AnalyticsBundle\Entity\CriteriaIndicator
     *
     * @ORM\OneToMany(targetEntity="AnalyticsBundle\Entity\CriteriaIndicator", mappedBy="criteriaRating", cascade={"remove"})
     * @JMS\Groups({"CriteriaRating", "CriteriaIndicator"})
     */
    private $criteriaIndicators;

    use \AnalyticsBundle\Versionable\VersionableTrait;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->criteriaIndicators = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return CriteriaRating
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set criteriaType
     *
     * @param \AnalyticsBundle\Entity\CriteriaType $criteriaType
     *
     * @return CriteriaRating
     */
    public function setCriteriaType(\AnalyticsBundle\Entity\CriteriaType $criteriaType = null)
    {
        $this->criteriaType = $criteriaType;

        return $this;
    }

    /**
     * Get criteriaType
     *
     * @return \AnalyticsBundle\Entity\CriteriaType
     */
    public function getCriteriaType()
    {
        return $this->criteriaType;
    }

    /**
     * Add criteriaIndicator
     *
     * @param \AnalyticsBundle\Entity\CriteriaIndicator $criteriaIndicator
     *
     * @return CriteriaRating
     */
    public function addCriteriaIndicator(\AnalyticsBundle\Entity\CriteriaIndicator $criteriaIndicator)
    {
        $this->criteriaIndicators[] = $criteriaIndicator;

        return $this;
    }

    /**
     * Remove criteriaIndicator
     *
     * @param \AnalyticsBundle\Entity\CriteriaIndicator $criteriaIndicator
     *
     * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
     */
    public function removeCriteriaIndicator(\AnalyticsBundle\Entity\CriteriaIndicator $criteriaIndicator)
    {
        return $this->criteriaIndicators->removeElement($criteriaIndicator);
    }

    /**
     * Get criteriaIndicators
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCriteriaIndicators()
    {
        return $this->criteriaIndicators;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }
}
