<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * FactCommissionCommissionMember
 *
 * @ORM\Table(name="fact_commission_commission_member", uniqueConstraints={@ORM\UniqueConstraint(name="fact_commission_commission_member_fact_commission_id_key", columns={"fact_commission_id"}), @ORM\UniqueConstraint(name="fact_commission_commission_member_commission_member_id_key", columns={"commission_member_id"}), @ORM\UniqueConstraint(name="uniquepair_id", columns={"fact_commission_id", "commission_member_id"})}, indexes={@ORM\Index(name="fact_commission_commission_member_commission_role_id", columns={"commission_role_id"})})
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\FactCommissionCommissionMemberRepository")
 * @Json\Schema("FactCommissionCommissionMember")
 */
class FactCommissionCommissionMember implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var FactCommission
     *
     * @ORM\ManyToOne(targetEntity="FactCommission")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fact_commission_id", referencedColumnName="id")
     * })
     */
    private $factCommission;

    /**
     * @var CommissionMember
     *
     * @ORM\ManyToOne(targetEntity="CommissionMember")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="commission_member_id", referencedColumnName="id")
     * })
     */
    private $commissionMember;

    /**
     * @var CommissionRole
     *
     * @ORM\ManyToOne(targetEntity="CommissionRole")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="commission_role_id", referencedColumnName="id")
     * })
     */
    private $commissionRole;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Protocol2Criteria", inversedBy="factCommissionCommissionMember")
     * @ORM\JoinTable(name="fact_commission_commission_member_protocol2_criteria",
     *   joinColumns={
     *     @ORM\JoinColumn(name="fact_commission_commission_member_id", referencedColumnName="id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="protocol2_criteria_id", referencedColumnName="id")
     *   }
     * )
     */
    private $protocol2Criteria;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->protocol2Criteria = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set factCommission
     *
     * @param \AnalyticsBundle\Entity\FactCommission $factCommission
     * @return FactCommissionCommissionMember
     */
    public function setFactCommission(\AnalyticsBundle\Entity\FactCommission $factCommission = null)
    {
        $this->factCommission = $factCommission;

        return $this;
    }

    /**
     * Get factCommission
     *
     * @return \AnalyticsBundle\Entity\FactCommission
     */
    public function getFactCommission()
    {
        return $this->factCommission;
    }

    /**
     * Set commissionMember
     *
     * @param \AnalyticsBundle\Entity\CommissionMember $commissionMember
     * @return FactCommissionCommissionMember
     */
    public function setCommissionMember(\AnalyticsBundle\Entity\CommissionMember $commissionMember = null)
    {
        $this->commissionMember = $commissionMember;

        return $this;
    }

    /**
     * Get commissionMember
     *
     * @return \AnalyticsBundle\Entity\CommissionMember
     */
    public function getCommissionMember()
    {
        return $this->commissionMember;
    }

    /**
     * Set commissionRole
     *
     * @param \AnalyticsBundle\Entity\CommissionRole $commissionRole
     * @return FactCommissionCommissionMember
     */
    public function setCommissionRole(\AnalyticsBundle\Entity\CommissionRole $commissionRole = null)
    {
        $this->commissionRole = $commissionRole;

        return $this;
    }

    /**
     * Get commissionRole
     *
     * @return \AnalyticsBundle\Entity\CommissionRole
     */
    public function getCommissionRole()
    {
        return $this->commissionRole;
    }

    /**
     * Add protocol2Criteria
     *
     * @param \AnalyticsBundle\Entity\Protocol2Criteria $protocol2Criteria
     * @return FactCommissionCommissionMember
     */
    public function addProtocol2Criterium(\AnalyticsBundle\Entity\Protocol2Criteria $protocol2Criteria)
    {
        $this->protocol2Criteria[] = $protocol2Criteria;

        return $this;
    }

    /**
     * Remove protocol2Criteria
     *
     * @param \AnalyticsBundle\Entity\Protocol2Criteria $protocol2Criteria
     */
    public function removeProtocol2Criterium(\AnalyticsBundle\Entity\Protocol2Criteria $protocol2Criteria)
    {
        $this->protocol2Criteria->removeElement($protocol2Criteria);
    }

    /**
     * Get protocol2Criteria
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getProtocol2Criteria()
    {
        return $this->protocol2Criteria;
    }
}
