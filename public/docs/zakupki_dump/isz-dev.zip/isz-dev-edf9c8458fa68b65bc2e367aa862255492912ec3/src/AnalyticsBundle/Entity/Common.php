<?php

namespace AnalyticsBundle\Entity;

use Doctrine\Common\Collections\Criteria;
use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * Common
 *
 * @ORM\Table(
 *   name="common",
 *   uniqueConstraints={
 *     @ORM\UniqueConstraint(name="type_short_name", columns={"type", "short_name"}),
 *     @ORM\UniqueConstraint(name="type_full_name", columns={"type", "full_name"})
 *   },
 *   indexes={
 *     @ORM\Index(name="common_dfcp_id", columns={"dfcp_id"}),
 *     @ORM\Index(name="common_okopf_id", columns={"okopf_id"}),
 *     @ORM\Index(name="common_sstp_id", columns={"sstp_id"}),
 *     @ORM\Index(name="common_type", columns={"type"}),
 *     @ORM\Index(name="common_parent_id", columns={"parent_id"}),
 *     @ORM\Index(name="common_deputyhead_id", columns={"deputyhead_id"}),
 *     @ORM\Index(name="common_okved_id", columns={"okved_id"}),
 *     @ORM\Index(name="common_head_id", columns={"head_id"})
 *   }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\CommonRepository")
 * @Json\Schema("Common")
 */
class Common implements IEntity
{
    const TYPE_FOIV         = 'foiv';
    const TYPE_ORGANIZATION = 'organization';
    const TYPE_DEPARTMENT   = 'department';
    const TYPE_SPEC         = 'spec';          // спец.организация
    const TYPE_MONITOR      = 'monitor';       // организация-монитор

    const CODE_SPZ_FOIV_MINOBR = '01731000037';

    /**
     * @var array
     *
     * @JMS\Groups({"all_all"})
     */
    public static $types = [
        self::TYPE_FOIV         => 'Ведомство',
        self::TYPE_ORGANIZATION => 'Подведомственная организация',
        self::TYPE_DEPARTMENT   => 'Департамент',
        self::TYPE_SPEC         => 'Специализированная организация',
        self::TYPE_MONITOR      => 'Организация-монитор',
    ];

    /**
     * @var guid|string
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @JMS\Groups({"common", "common_list", "common_detail", "expert_group_list", "expert_group_detail", "all",
     *      "users_detail", "plan_common", "lot_detail", "lot_list", "plan_current", "plan_next", "expert_light"})
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=32, nullable=false)
     * @JMS\Groups({"common", "common_list", "common_detail", "all", "plan_common", "expert_group_list",
     *     "expert_group_detail", "lot_detail", "lot_list", "users_detail", "expert_light",
     *     "plan_current", "plan_next", "notice_ea"})
     */
    private $type;

    /**
     * @var string
     *
     * @ORM\Column(name="dfcp_id", type="string", length=32, nullable=true)
     * @Json\Ignore()
     */
    private $dfcpId;

    /**
     * @var string
     *
     * @ORM\Column(name="sstp_id", type="string", length=32, nullable=true)
     * @Json\Ignore()
     */
    private $sstpId;

    /**
     * @var string
     *
     * @ORM\Column(name="full_name", type="string", length=255, nullable=false)
     * @JMS\Groups({"common", "common_list", "common_detail", "all", "plan_common", "expert_group_list",
     *      "expert_group_detail", "lot_detail", "lot_list", "plan_current", "plan_next", "notice_ea"})
     */
    private $fullName;

    /**
     * @var string
     *
     * @ORM\Column(name="short_name", type="string", length=255, nullable=false)
     * @JMS\Groups({"common", "common_list", "common_detail", "all", "users_detail", "expert_group_list",
     *      "expert_group_detail", "plan_common", "lot_detail", "lot_list", "plan_current", "plan_next",
     *      "lot_item_plans"})
     */
    private $shortName;

    /**
     * @var string
     *
     * @ORM\Column(name="fact_address", type="string", length=255, nullable=true)
     * @JMS\Groups({"common_detail", "all", "Common_zakupki", "notice_ea"})
     */
    private $factAddress;

    /**
     * @var string
     *
     * @ORM\Column(name="checking_account", type="string", length=255, nullable=true)
     * @JMS\Groups({"common_detail", "all", "Common_zakupki", "notice_ea"})
     */
    private $checkingAccount;

    /**
     * @var string
     *
     * @ORM\Column(name="personal_account", type="string", length=255, nullable=true)
     * @JMS\Groups({"common_detail", "all", "Common_zakupki", "notice_ea"})
     */
    private $personalAccount;

    /**
     * @var string
     *
     * @ORM\Column(name="post_address", type="string", length=255, nullable=true)
     * @JMS\Groups({"common_detail", "all", "notice_ea"})
     */
    private $postAddress;

    /**
     * @var string
     *
     * @ORM\Column(name="phone", type="string", length=255, nullable=true)
     * @JMS\Groups({"common_detail", "all", "notice_ea"})
     */
    private $phone;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=255, nullable=true)
     * @JMS\Groups({"common_detail", "all"})
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(name="http", type="string", length=255, nullable=true)
     * @JMS\Groups({"common_detail", "all"})
     */
    private $http;

    /**
     * @var string
     *
     * @ORM\Column(name="bank_account", type="string", length=255, nullable=true)
     * @JMS\Groups({"common_detail", "all"})
     */
    private $bankAccount;

    /**
     * @var string
     *
     * @ORM\Column(name="bank", type="string", length=255, nullable=true)
     * @JMS\Groups({"common_detail", "all"})
     */
    private $bank;

    /**
     * @var string
     *
     * @ORM\Column(name="inn", type="string", length=32, nullable=true)
     * @JMS\Groups({"common_detail", "all", "Common_zakupki", "notice_ea"})
     */
    private $inn;

    /**
     * @var string
     *
     * @ORM\Column(name="bik", type="string", length=32, nullable=true)
     * @JMS\Groups({"common_detail", "all"})
     */
    private $bik;

    /**
     * @var string
     *
     * @ORM\Column(name="kpp", type="string", length=32, nullable=true)
     * @JMS\Groups({"common_detail", "all", "Common_zakupki", "notice_ea"})
     */
    private $kpp;

    /**
     * @var string
     *
     * @ORM\Column(name="okpo", type="string", length=32, nullable=true)
     * @JMS\Groups({"common_detail", "all"})
     */
    private $okpo;

    /**
     * @var string
     *
     * @ORM\Column(name="okato", type="string", length=32, nullable=true)
     * @JMS\Groups({"common_detail", "all"})
     */
    private $okato;

    /**
     * @var string
     *
     * @ORM\Column(name="oktmo", type="string", length=32, nullable=true)
     * @JMS\Groups({"common_detail", "all", "Common_zakupki"})
     */
    private $oktmo;

    /**
     * @var string
     *
     * @ORM\Column(name="code_grbs", type="decimal", precision=3, scale=0, nullable=true)
     * @JMS\Groups({"common_detail", "all"})
     */
    private $codeGrbs;

    /**
     * @var string
     *
     * @ORM\Column(name="code_spz", type="string", length=32, nullable=true)
     * @JMS\Groups({"common_detail", "all"})
     */
    private $codeSpz;

    /**
     * @var Users
     *
     * @ORM\ManyToOne(targetEntity="Users", cascade={"persist", "remove"})
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="deputyhead_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"common_detail", "all"})
     */
    private $deputyhead;

    /**
     * @var DepartmentRole
     *
     * @ORM\ManyToMany(targetEntity="DepartmentRole", cascade={"persist", "remove"})
     * @ORM\JoinTable(
     *   name="department_role_common",
     *   joinColumns={
     *     @ORM\JoinColumn(name="common_id", referencedColumnName="id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="department_role_id", referencedColumnName="id")
     *   }
     * )
     * @JMS\Groups({"common_detail", "all"})
     */
    private $departmentRole;

    /**
     * @var Okved
     *
     * @ORM\ManyToOne(targetEntity="Okved")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="okved_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"common_detail", "all"})
     */
    private $okved;

    /**
     * @var Common
     *
     * @ORM\ManyToOne(targetEntity="Common")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"common_detail", "all", "users_detail"})
     */
    private $parent;

    /**
     * @var Okopf
     *
     * @ORM\ManyToOne(targetEntity="Okopf")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="okopf_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"common_detail", "all"})
     */
    private $okopf;

    /**
     * @var Okogy
     *
     * @ORM\ManyToOne(targetEntity="Okogy")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="okogy_id", referencedColumnName="id", nullable=true)
     * })
     * @JMS\Groups({"common_detail", "all"})
     */
    private $okogy;

    /**
     * @var Ogrn
     *
     * @ORM\ManyToOne(targetEntity="Ogrn")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="ogrn_id", referencedColumnName="id", nullable=true)
     * })
     * @JMS\Groups({"common_detail", "all"})
     */
    private $ogrn;

    /**
     * @var Okfs
     *
     * @ORM\ManyToOne(targetEntity="Okfs")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="okfs_id", referencedColumnName="id", nullable=true)
     * })
     * @JMS\Groups({"common_detail", "all"})
     */
    private $okfs;

    /**
     * @var Users
     *
     * @ORM\ManyToOne(targetEntity="AnalyticsBundle\Entity\Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="head_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"common_detail", "all", "Common_zakupki"})
     */
    private $head;

    /**
     * @var ExpertGroup
     *
     * @ORM\OneToMany(targetEntity="ExpertGroup", mappedBy="common", cascade={"persist"})
     * @JMS\Groups({"common_detail"})
     */
    private $expertGroups;

    /**
     * @var Plan
     *
     * @ORM\OneToMany(targetEntity="Plan", mappedBy="common", cascade={"persist"})
     * @JMS\Groups({"common_detail", "expert_group_list", "expert_group_detail"})
     */
    private $plans;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->expertGroups = new \Doctrine\Common\Collections\ArrayCollection();
        $this->plans = new \Doctrine\Common\Collections\ArrayCollection();
        $this->departmentRole = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return guid|string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return Common
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set $personalAccount
     *
     * @param string $personalAccount
     * @return Common
     */
    public function setPersonalAccount($personalAccount)
    {
        $this->personalAccount = $personalAccount;

        return $this;
    }

    /**
     * Get $personalAccount
     *
     * @return string
     */
    public function getPersonalAccount()
    {
        return $this->personalAccount;
    }

    /**
     * Set $checkingAccount
     *
     * @param string $checkingAccount
     * @return Common
     */
    public function setCheckingAccount($checkingAccount)
    {
        $this->checkingAccount = $checkingAccount;

        return $this;
    }

    /**
     * Get $checkingAccount
     *
     * @return string
     */
    public function getCheckingAccount()
    {
        return $this->checkingAccount;
    }

    /**
     * Set dfcpId
     *
     * @param string $dfcpId
     * @return Common
     */
    public function setDfcpId($dfcpId)
    {
        $this->dfcpId = $dfcpId;

        return $this;
    }

    /**
     * Get dfcpId
     *
     * @return string 
     */
    public function getDfcpId()
    {
        return $this->dfcpId;
    }

    /**
     * Set sstpId
     *
     * @param string $sstpId
     * @return Common
     */
    public function setSstpId($sstpId)
    {
        $this->sstpId = $sstpId;

        return $this;
    }

    /**
     * Get sstpId
     *
     * @return string
     */
    public function getSstpId()
    {
        return $this->sstpId;
    }

    /**
     * Set fullName
     *
     * @param string $fullName
     * @return Common
     */
    public function setFullName($fullName)
    {
        $this->fullName = $fullName;

        return $this;
    }

    /**
     * Get fullName
     *
     * @return string
     */
    public function getFullName()
    {
        return $this->fullName;
    }

    /**
     * Set shortName
     *
     * @param string $shortName
     * @return Common
     */
    public function setShortName($shortName)
    {
        $this->shortName = $shortName;

        return $this;
    }

    /**
     * Get shortName
     *
     * @return string 
     */
    public function getShortName()
    {
        return $this->shortName;
    }

    /**
     * Set factAddress
     *
     * @param string $factAddress
     * @return Common
     */
    public function setFactAddress($factAddress)
    {
        $this->factAddress = $factAddress;

        return $this;
    }

    /**
     * Get factAddress
     *
     * @return string
     */
    public function getFactAddress()
    {
        return $this->factAddress;
    }

    /**
     * Set postAddress
     *
     * @param string $postAddress
     * @return Common
     */
    public function setPostAddress($postAddress)
    {
        $this->postAddress = $postAddress;

        return $this;
    }

    /**
     * Get postAddress
     *
     * @return string
     */
    public function getPostAddress()
    {
        return $this->postAddress;
    }

    /**
     * Set phone
     *
     * @param string $phone
     * @return Common
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return Common
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set http
     *
     * @param string $http
     * @return Common
     */
    public function setHttp($http)
    {
        $this->http = $http;

        return $this;
    }

    /**
     * Get http
     *
     * @return string 
     */
    public function getHttp()
    {
        return $this->http;
    }

    /**
     * Set bankAccount
     *
     * @param string $bankAccount
     * @return Common
     */
    public function setBankAccount($bankAccount)
    {
        $this->bankAccount = $bankAccount;

        return $this;
    }

    /**
     * Get bankAccount
     *
     * @return string 
     */
    public function getBankAccount()
    {
        return $this->bankAccount;
    }

    /**
     * Set bank
     *
     * @param string $bank
     * @return Common
     */
    public function setBank($bank)
    {
        $this->bank = $bank;

        return $this;
    }

    /**
     * Get bank
     *
     * @return string 
     */
    public function getBank()
    {
        return $this->bank;
    }

    /**
     * Set inn
     *
     * @param string $inn
     * @return Common
     */
    public function setInn($inn)
    {
        $this->inn = $inn;

        return $this;
    }

    /**
     * Get inn
     *
     * @return string 
     */
    public function getInn()
    {
        return $this->inn;
    }

    /**
     * Set bik
     *
     * @param string $bik
     * @return Common
     */
    public function setBik($bik)
    {
        $this->bik = $bik;

        return $this;
    }

    /**
     * Get bik
     *
     * @return string 
     */
    public function getBik()
    {
        return $this->bik;
    }

    /**
     * Set kpp
     *
     * @param string $kpp
     * @return Common
     */
    public function setKpp($kpp)
    {
        $this->kpp = $kpp;

        return $this;
    }

    /**
     * Get kpp
     *
     * @return string 
     */
    public function getKpp()
    {
        return $this->kpp;
    }

    /**
     * Set okpo
     *
     * @param string $okpo
     * @return Common
     */
    public function setOkpo($okpo)
    {
        $this->okpo = $okpo;

        return $this;
    }

    /**
     * Get okpo
     *
     * @return string 
     */
    public function getOkpo()
    {
        return $this->okpo;
    }

    /**
     * Set okato
     *
     * @param string $okato
     * @return Common
     */
    public function setOkato($okato)
    {
        $this->okato = $okato;

        return $this;
    }

    /**
     * Get okato
     *
     * @return string 
     */
    public function getOkato()
    {
        return $this->okato;
    }

    /**
     * Set oktmo
     *
     * @param string $oktmo
     * @return Common
     */
    public function setOktmo($oktmo)
    {
        $this->oktmo = $oktmo;

        return $this;
    }

    /**
     * Get oktmo
     *
     * @return string 
     */
    public function getOktmo()
    {
        return $this->oktmo;
    }

    /**
     * Set codeGrbs
     *
     * @param string $codeGrbs
     * @return Common
     */
    public function setCodeGrbs($codeGrbs)
    {
        $this->codeGrbs = $codeGrbs;

        return $this;
    }

    /**
     * Get codeGrbs
     *
     * @return string
     */
    public function getCodeGrbs()
    {
        return $this->codeGrbs;
    }

    /**
     * Set codeSpz
     *
     * @param string $codeSpz
     * @return Common
     */
    public function setCodeSpz($codeSpz)
    {
        $this->codeSpz = $codeSpz;

        return $this;
    }

    /**
     * Get codeSpz
     *
     * @return string
     */
    public function getCodeSpz()
    {
        return $this->codeSpz;
    }

    /**
     * Set deputyhead
     *
     * @param \AnalyticsBundle\Entity\Users $deputyhead
     * @return Common
     */
    public function setDeputyhead(\AnalyticsBundle\Entity\Users $deputyhead = null)
    {
        $this->deputyhead = $deputyhead;

        return $this;
    }

    /**
     * Get deputyhead
     *
     * @return \AnalyticsBundle\Entity\Users
     */
    public function getDeputyhead()
    {
        return $this->deputyhead;
    }

    /**
     * Add departmentRole
     *
     * @param \AnalyticsBundle\Entity\DepartmentRole $departmentRole
     * @return Common
     */
    public function addDepartmentRole(\AnalyticsBundle\Entity\DepartmentRole $departmentRole)
    {
        $this->departmentRole[] = $departmentRole;

        return $this;
    }

    /**
     * Remove departmentRole
     *
     * @param \AnalyticsBundle\Entity\DepartmentRole $plan
     */
    public function removeDepartmentRole(\AnalyticsBundle\Entity\DepartmentRole $departmentRole)
    {
        $this->departmentRole->removeElement($departmentRole);
    }

    /**
     * Get departmentRole
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getDepartmentRole()
    {
        return $this->departmentRole;
    }

    /**
     * Set okved
     *
     * @param \AnalyticsBundle\Entity\Okved $okved
     * @return Common
     */
    public function setOkved(\AnalyticsBundle\Entity\Okved $okved = null)
    {
        $this->okved = $okved;

        return $this;
    }

    /**
     * Get okved
     *
     * @return \AnalyticsBundle\Entity\Okved
     */
    public function getOkved()
    {
        return $this->okved;
    }

    /**
     * Set parent
     *
     * @param \AnalyticsBundle\Entity\Common $parent
     * @return Common
     */
    public function setParent(\AnalyticsBundle\Entity\Common $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \AnalyticsBundle\Entity\Common
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Set okopf
     *
     * @param \AnalyticsBundle\Entity\Okopf $okopf
     * @return Common
     */
    public function setOkopf(\AnalyticsBundle\Entity\Okopf $okopf = null)
    {
        $this->okopf = $okopf;

        return $this;
    }

    /**
     * Get okopf
     *
     * @return \AnalyticsBundle\Entity\Okopf
     */
    public function getOkopf()
    {
        return $this->okopf;
    }

    /**
     * Set ogrn
     *
     * @param \AnalyticsBundle\Entity\Ogrn $ogrn
     * @return Common
     */
    public function setOgrn(\AnalyticsBundle\Entity\Ogrn $ogrn = null)
    {
        $this->ogrn = $ogrn;

        return $this;
    }

    /**
     * Get ogrn
     *
     * @return \AnalyticsBundle\Entity\Ogrn
     */
    public function getOgrn()
    {
        return $this->ogrn;
    }

    /**
     * Set Okogy
     *
     * @param \AnalyticsBundle\Entity\Okogy $okogy
     * @return Common
     */
    public function setOkogy(\AnalyticsBundle\Entity\Okogy $okogy= null)
    {
        $this->okogy = $okogy;

        return $this;
    }

    /**
     * Get Okogy
     *
     * @return \AnalyticsBundle\Entity\Okogy
     */
    public function getOkogy()
    {
        return $this->okogy;
    }

    /**
     * Set Okfs
     *
     * @param \AnalyticsBundle\Entity\Okfs $okfs
     * @return Common
     */
    public function setOkfs(\AnalyticsBundle\Entity\Okfs $okfs= null)
    {
        $this->okfs = $okfs;

        return $this;
    }

    /**
     * Get Okfs
     *
     * @return \AnalyticsBundle\Entity\Okfs
     */
    public function getOkfs()
    {
        return $this->okfs;
    }

    /**
     * Set head
     *
     * @param \AnalyticsBundle\Entity\Users $head
     * @return Common
     */
    public function setHead(\AnalyticsBundle\Entity\Users $head = null)
    {
        $this->head = $head;

        return $this;
    }

    /**
     * Get head
     *
     * @return \AnalyticsBundle\Entity\Users
     */
    public function getHead()
    {
        return $this->head;
    }

    /**
     * Add expertGroups
     *
     * @param \AnalyticsBundle\Entity\ExpertGroup $expertGroups
     * @return Common
     */
    public function addExpertGroup(\AnalyticsBundle\Entity\ExpertGroup $expertGroups)
    {
        $this->expertGroups[] = $expertGroups;

        return $this;
    }

    /**
     * Remove expertGroups
     *
     * @param \AnalyticsBundle\Entity\ExpertGroup $expertGroups
     */
    public function removeExpertGroup(\AnalyticsBundle\Entity\ExpertGroup $expertGroups)
    {
        $this->expertGroups->removeElement($expertGroups);
    }

    /**
     * Get expertGroups
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getExpertGroups()
    {
        return $this->expertGroups;
    }

    /**
     * Add plans
     *
     * @param \AnalyticsBundle\Entity\Plan $plans
     * @return Common
     */
    public function addPlan(\AnalyticsBundle\Entity\Plan $plans)
    {
        if (!$this->plans->contains($plans)) {
            $plans->setCommon($this);

            $this->plans->add($plans);
        }

        return $this;
    }

    /**
     * Remove plans
     *
     * @param \AnalyticsBundle\Entity\Plan $plans
     */
    public function removePlan(\AnalyticsBundle\Entity\Plan $plans)
    {
        $this->plans->removeElement($plans);
    }

    /**
     * Get plans
     *
     * @return \Doctrine\Common\Collections\Collection|Plan[]
     */
    public function getPlans()
    {
        return $this->plans->filter(function($el){
            return $el->getIsRevision() != true;
        });
    }

    /**
     * Get fullName
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->getFullName();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
