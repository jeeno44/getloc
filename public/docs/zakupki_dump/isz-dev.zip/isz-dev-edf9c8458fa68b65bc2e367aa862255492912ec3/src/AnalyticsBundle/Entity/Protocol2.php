<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * Protocol2
 *
 * @ORM\Table(name="protocol2", indexes={@ORM\Index(name="protocol2_lot_id", columns={"lot_id"}), @ORM\Index(name="protocol2_commission_id", columns={"commission_id"})})
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\Protocol2Repository")
 * @Json\Schema("Protocol2")
 */
class Protocol2 implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     */
    private $title;

    /**
     * @var \Commission
     *
     * @ORM\ManyToOne(targetEntity="Commission")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="commission_id", referencedColumnName="id")
     * })
     */
    private $commission;

    /**
     * @var \Lot
     *
     * @ORM\ManyToOne(targetEntity="Lot")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="lot_id", referencedColumnName="id")
     * })
     */
    private $lot;



    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Protocol2
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set commission
     *
     * @param \AnalyticsBundle\Entity\Commission $commission
     * @return Protocol2
     */
    public function setCommission(\AnalyticsBundle\Entity\Commission $commission = null)
    {
        $this->commission = $commission;

        return $this;
    }

    /**
     * Get commission
     *
     * @return \AnalyticsBundle\Entity\Commission
     */
    public function getCommission()
    {
        return $this->commission;
    }

    /**
     * Set lot
     *
     * @param \AnalyticsBundle\Entity\Lot $lot
     * @return Protocol2
     */
    public function setLot(\AnalyticsBundle\Entity\Lot $lot = null)
    {
        $this->lot = $lot;

        return $this;
    }

    /**
     * Get lot
     *
     * @return \AnalyticsBundle\Entity\Lot
     */
    public function getLot()
    {
        return $this->lot;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
