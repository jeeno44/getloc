<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * IntermediateEvent
 *
 * @ORM\Table(name="intermediate_event", indexes={@ORM\Index(name="intermediate_event_sub_program_action_id", columns={"sub_program_action_id"}), @ORM\Index(name="intermediate_event_execution_date", columns={"execution_date"})})
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\IntermediateEventRepository")
 * @Json\Schema("IntermediateEvent")
 */
class IntermediateEvent implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="execution_date", type="date", nullable=true)
     */
    private $executionDate;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="number", type="string", length=255, nullable=true)
     */
    private $number;

    /**
     * @var SubProgramAction
     *
     * @ORM\ManyToOne(targetEntity="SubProgramAction")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="sub_program_action_id", referencedColumnName="id")
     * })
     */
    private $subProgramAction;


    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set executionDate
     *
     * @param \DateTime $executionDate
     * @return IntermediateEvent
     */
    public function setExecutionDate($executionDate)
    {
        $this->executionDate = $executionDate;

        return $this;
    }

    /**
     * Get executionDate
     *
     * @return \DateTime
     */
    public function getExecutionDate()
    {
        return $this->executionDate;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return IntermediateEvent
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set number
     *
     * @param string $number
     * @return IntermediateEvent
     */
    public function setNumber($number)
    {
        $this->number = $number;

        return $this;
    }

    /**
     * Get number
     *
     * @return string 
     */
    public function getNumber()
    {
        return $this->number;
    }

    /**
     * Set subProgramAction
     *
     * @param \AnalyticsBundle\Entity\SubProgramAction $subProgramAction
     * @return IntermediateEvent
     */
    public function setSubProgramAction(\AnalyticsBundle\Entity\SubProgramAction $subProgramAction = null)
    {
        $this->subProgramAction = $subProgramAction;

        return $this;
    }

    /**
     * Get subProgramAction
     *
     * @return \AnalyticsBundle\Entity\SubProgramAction
     */
    public function getSubProgramAction()
    {
        return $this->subProgramAction;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    use \AnalyticsBundle\Versionable\VersionableTrait;
}
