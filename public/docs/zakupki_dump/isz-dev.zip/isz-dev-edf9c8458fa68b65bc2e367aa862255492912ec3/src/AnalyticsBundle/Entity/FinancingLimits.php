<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;
use JMS\Serializer\Annotation as JMS;

/**
 * FinancingLimits
 *
 * @ORM\Table(
 *     name="financing_limits",
 *     indexes={
 *          @ORM\Index(name="financing_limits_common_id", columns={"common_id"}),
 *          @ORM\Index(name="financing_limits_fcp_id", columns={"fcp_id"}),
 *          @ORM\Index(name="financing_limits_gov_program_id", columns={"gov_program_id"}),
 *          @ORM\Index(name="financing_limits_kbk_expense_type_id", columns={"kbk_expense_type_id"}),
 *          @ORM\Index(name="financing_limits_sub_program_action_id", columns={"sub_program_action_id"}),
 *          @ORM\Index(name="financing_limits_fcp_action_id", columns={"fcp_action_id"}),
 *          @ORM\Index(name="financing_limits_kbk_csr_id", columns={"kbk_csr_id"}),
 *          @ORM\Index(name="financing_limits_kbk_section_id", columns={"kbk_section_id"}),
 *          @ORM\Index(name="financing_limits_kbk_kosgu_id", columns={"kbk_kosgu_id"})
 *      }
 * )
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\FinancingLimitsRepository")
 * @Json\Schema("FinancingLimits")
 */
class FinancingLimits implements IEntity
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="SEQUENCE")
     * @ORM\SequenceGenerator(sequenceName="seq_financing_limits", allocationSize=1, initialValue=1)
     * @JMS\Groups({"financing_limits"})
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="year", type="decimal", precision=4, scale=0, nullable=true)
     * @JMS\Groups({"financing_limits"})
     */
    private $year;

    /**
     * @var float
     *
     * @ORM\Column(name="financing", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"financing_limits"})
     */
    private $financing;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="year_1", type="decimal", precision=4, scale=0, nullable=true)
     * @JMS\Groups({"financing_limits"})
     */
    private $year1;

    /**
     * @var float
     *
     * @ORM\Column(name="financing_1", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"financing_limits"})
     */
    private $financing1;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="year_2", type="decimal", precision=4, scale=0, nullable=true)
     * @JMS\Groups({"financing_limits"})
     */
    private $year2;

    /**
     * @var float
     *
     * @ORM\Column(name="financing_2", type="float", precision=10, scale=0, nullable=true)
     * @JMS\Groups({"financing_limits"})
     */
    private $financing2;

    /**
     * @var SubProgramAction
     *
     * @ORM\ManyToOne(targetEntity="GovProgram")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="gov_program_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"financing_limits"})
     */
    private $govProgram;

    /**
     * @var SubProgramAction
     *
     * @ORM\ManyToOne(targetEntity="SubProgramAction")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="sub_program_action_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"financing_limits"})
     */
    private $subProgramAction;

    /**
     * @var FcpAction
     *
     * @ORM\ManyToOne(targetEntity="FcpAction")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_action_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"financing_limits"})
     */
    private $fcpAction;

    /**
     * @var Common
     *
     * @ORM\ManyToOne(targetEntity="Common")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="common_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"financing_limits"})
     */
    private $common;

    /**
     * @var Kbk
     *
     * @ORM\ManyToOne(targetEntity="KbkCsr")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_csr_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"financing_limits"})
     */
    private $kbkCsr;

    /**
     * @var Kbk
     *
     * @ORM\ManyToOne(targetEntity="KbkExpenseType")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_expense_type_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"financing_limits"})
     */
    private $kbkExpenseType;

    /**
     * @var Kbk
     *
     * @ORM\ManyToOne(targetEntity="KbkKosgu")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_kosgu_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"financing_limits"})
     */
    private $kbkKosgu;

    /**
     * @var Kbk
     *
     * @ORM\ManyToOne(targetEntity="KbkSection")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="kbk_section_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"financing_limits"})
     */
    private $kbkSection;

    /**
     * @var FcpAction
     *
     * @ORM\ManyToOne(targetEntity="Fcp")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="fcp_id", referencedColumnName="id")
     * })
     * @JMS\Groups({"financing_limits"})
     */
    private $fcp;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set year
     *
     * @param string $year
     * @return FinancingLimits
     */
    public function setYear($year)
    {
        $this->year = $year;

        return $this;
    }

    /**
     * Get year
     *
     * @return string 
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * Set financing
     *
     * @param float $financing
     * @return FinancingLimits
     */
    public function setFinancing($financing)
    {
        $this->financing = $financing;

        return $this;
    }

    /**
     * Get financing
     *
     * @return float 
     */
    public function getFinancing()
    {
        return $this->financing;
    }

    /**
     * Set year1
     *
     * @param string $year1
     * @return FinancingLimits
     */
    public function setYear1($year1)
    {
        $this->year1 = $year1;

        return $this;
    }

    /**
     * Get year1
     *
     * @return string 
     */
    public function getYear1()
    {
        return $this->year1;
    }

    /**
     * Set financing1
     *
     * @param float $financing1
     * @return FinancingLimits
     */
    public function setFinancing1($financing1)
    {
        $this->financing1 = $financing1;

        return $this;
    }

    /**
     * Get financing1
     *
     * @return float 
     */
    public function getFinancing1()
    {
        return $this->financing1;
    }

    /**
     * Set year2
     *
     * @param string $year2
     * @return FinancingLimits
     */
    public function setYear2($year2)
    {
        $this->year2 = $year2;

        return $this;
    }

    /**
     * Get year2
     *
     * @return string 
     */
    public function getYear2()
    {
        return $this->year2;
    }

    /**
     * Set financing2
     *
     * @param float $financing2
     * @return FinancingLimits
     */
    public function setFinancing2($financing2)
    {
        $this->financing2 = $financing2;

        return $this;
    }

    /**
     * Get financing2
     *
     * @return float 
     */
    public function getFinancing2()
    {
        return $this->financing2;
    }

    /**
     * Set govProgram
     *
     * @param \AnalyticsBundle\Entity\GovProgram $govProgram
     * @return FinancingLimits
     */
    public function setGovProgram(\AnalyticsBundle\Entity\GovProgram $govProgram = null)
    {
        $this->govProgram = $govProgram;

        return $this;
    }

    /**
     * Get govProgram
     *
     * @return \AnalyticsBundle\Entity\GovProgram 
     */
    public function getGovProgram()
    {
        return $this->govProgram;
    }

    /**
     * Set subProgramAction
     *
     * @param \AnalyticsBundle\Entity\SubProgramAction $subProgramAction
     * @return FinancingLimits
     */
    public function setSubProgramAction(\AnalyticsBundle\Entity\SubProgramAction $subProgramAction = null)
    {
        $this->subProgramAction = $subProgramAction;

        return $this;
    }

    /**
     * Get subProgramAction
     *
     * @return \AnalyticsBundle\Entity\SubProgramAction 
     */
    public function getSubProgramAction()
    {
        return $this->subProgramAction;
    }

    /**
     * Set fcpAction
     *
     * @param \AnalyticsBundle\Entity\FcpAction $fcpAction
     * @return FinancingLimits
     */
    public function setFcpAction(\AnalyticsBundle\Entity\FcpAction $fcpAction = null)
    {
        $this->fcpAction = $fcpAction;

        return $this;
    }

    /**
     * Get fcpAction
     *
     * @return \AnalyticsBundle\Entity\FcpAction 
     */
    public function getFcpAction()
    {
        return $this->fcpAction;
    }

    /**
     * Set common
     *
     * @param \AnalyticsBundle\Entity\Common $common
     * @return FinancingLimits
     */
    public function setCommon(\AnalyticsBundle\Entity\Common $common = null)
    {
        $this->common = $common;

        return $this;
    }

    /**
     * Get common
     *
     * @return \AnalyticsBundle\Entity\Common 
     */
    public function getCommon()
    {
        return $this->common;
    }

    /**
     * Set kbkCsr
     *
     * @param \AnalyticsBundle\Entity\KbkCsr $kbkCsr
     * @return FinancingLimits
     */
    public function setKbkCsr(\AnalyticsBundle\Entity\KbkCsr $kbkCsr = null)
    {
        $this->kbkCsr = $kbkCsr;

        return $this;
    }

    /**
     * Get kbkCsr
     *
     * @return \AnalyticsBundle\Entity\KbkCsr 
     */
    public function getKbkCsr()
    {
        return $this->kbkCsr;
    }

    /**
     * Set kbkExpenseType
     *
     * @param \AnalyticsBundle\Entity\KbkExpenseType $kbkExpenseType
     * @return FinancingLimits
     */
    public function setKbkExpenseType(\AnalyticsBundle\Entity\KbkExpenseType $kbkExpenseType = null)
    {
        $this->kbkExpenseType = $kbkExpenseType;

        return $this;
    }

    /**
     * Get kbkExpenseType
     *
     * @return \AnalyticsBundle\Entity\KbkExpenseType 
     */
    public function getKbkExpenseType()
    {
        return $this->kbkExpenseType;
    }

    /**
     * Set kbkKosgu
     *
     * @param \AnalyticsBundle\Entity\KbkKosgu $kbkKosgu
     * @return FinancingLimits
     */
    public function setKbkKosgu(\AnalyticsBundle\Entity\KbkKosgu $kbkKosgu = null)
    {
        $this->kbkKosgu = $kbkKosgu;

        return $this;
    }

    /**
     * Get kbkKosgu
     *
     * @return \AnalyticsBundle\Entity\KbkKosgu 
     */
    public function getKbkKosgu()
    {
        return $this->kbkKosgu;
    }

    /**
     * Set kbkSection
     *
     * @param \AnalyticsBundle\Entity\KbkSection $kbkSection
     * @return FinancingLimits
     */
    public function setKbkSection(\AnalyticsBundle\Entity\KbkSection $kbkSection = null)
    {
        $this->kbkSection = $kbkSection;

        return $this;
    }

    /**
     * Get kbkSection
     *
     * @return \AnalyticsBundle\Entity\KbkSection 
     */
    public function getKbkSection()
    {
        return $this->kbkSection;
    }

    /**
     * Set fcp
     *
     * @param \AnalyticsBundle\Entity\Fcp $fcp
     * @return FinancingLimits
     */
    public function setFcp(\AnalyticsBundle\Entity\Fcp $fcp = null)
    {
        $this->fcp = $fcp;

        return $this;
    }

    /**
     * Get fcp
     *
     * @return \AnalyticsBundle\Entity\Fcp 
     */
    public function getFcp()
    {
        return $this->fcp;
    }
}
