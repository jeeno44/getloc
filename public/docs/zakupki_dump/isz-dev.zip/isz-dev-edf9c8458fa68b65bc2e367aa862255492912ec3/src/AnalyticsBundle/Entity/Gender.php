<?php

namespace AnalyticsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\JsonSchemaBundle\Annotations as Json;

/**
 * Gender
 *
 * @ORM\Table(name="gender")
 * @ORM\Entity(repositoryClass="AnalyticsBundle\Repository\GenderRepository")
 * @Json\Schema("Gender")
 */
class Gender implements IEntity
{
    /**
     * @var guid
     *
     * @ORM\Column(name="id", type="guid", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=32, nullable=true)
     */
    private $code;

    /**
     * @var string
     *
     * @ORM\Column(name="full_title", type="string", length=128, nullable=true)
     */
    private $fullTitle;

    /**
     * @var string
     *
     * @ORM\Column(name="short_title", type="string", length=128, nullable=true)
     */
    private $shortTitle;


    /**
     * Get id
     *
     * @return guid
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return Gender
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string 
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set fullTitle
     *
     * @param string $fullTitle
     * @return Gender
     */
    public function setFullTitle($fullTitle)
    {
        $this->fullTitle = $fullTitle;

        return $this;
    }

    /**
     * Get fullTitle
     *
     * @return string 
     */
    public function getFullTitle()
    {
        return $this->fullTitle;
    }

    /**
     * Set shortTitle
     *
     * @param string $shortTitle
     * @return Gender
     */
    public function setShortTitle($shortTitle)
    {
        $this->shortTitle = $shortTitle;

        return $this;
    }

    /**
     * Get shortTitle
     *
     * @return string 
     */
    public function getShortTitle()
    {
        return $this->shortTitle;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getShortTitle();
    }
}
