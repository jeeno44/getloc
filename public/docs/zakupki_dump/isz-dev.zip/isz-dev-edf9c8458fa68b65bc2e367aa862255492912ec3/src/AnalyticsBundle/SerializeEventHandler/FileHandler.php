<?php

namespace AnalyticsBundle\SerializeEventHandler;

use AnalyticsBundle\Entity\PlanDoc;
use JMS\Serializer\EventDispatcher\EventSubscriberInterface;
use JMS\Serializer\EventDispatcher\PreSerializeEvent;

class FileHandler implements EventSubscriberInterface
{

    /**
     * @var string
     */
    protected $downloadLink;

    /**
     * FileHandler constructor.
     * @param string $downloadLink
     */
    public function __construct($downloadLink)
    {
        $this->downloadLink = $downloadLink;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return [
            [
                'event' => 'serializer.pre_serialize',
                'method' => 'onPreSerialize',
                'class' => 'AnalyticsBundle\Entity\PlanDoc'
            ],
            [
                'event' => 'serializer.pre_serialize',
                'method' => 'onPreSerialize',
                'class' => 'AnalyticsBundle\Entity\NmckDoc'
            ],
        ];
    }

    /**
     * Подмена пути к файлу при сериализации
     * @param PreSerializeEvent $event
     */
    public function onPreSerialize(PreSerializeEvent $event)
    {
        /** @var PlanDoc $planDoc */
        $planDoc = $event->getObject();
        $planDoc->setFile(
            $this->downloadLink . $planDoc->getFile()
        );
    }
}