<?php
namespace AnalyticsBundle\Repository;

use AnalyticsBundle\Model\AnalyticsRepository;

/**
 * Class KbkCsrRepository
 * @package AnalyticsBundle\Repository
 */
class KbkCsrRepository extends AnalyticsRepository
{

}
