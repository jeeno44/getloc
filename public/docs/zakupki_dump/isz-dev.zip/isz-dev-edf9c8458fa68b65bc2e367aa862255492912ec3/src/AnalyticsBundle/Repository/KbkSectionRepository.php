<?php
namespace AnalyticsBundle\Repository;

use AnalyticsBundle\Model\AnalyticsRepository;

/**
 * Class KbkSectionRepository
 * @package AnalyticsBundle\Repository
 */
class KbkSectionRepository extends AnalyticsRepository
{
    /**
     * @param array $criteria
     * @param array $orderBy
     * @param null|integer $limit
     * @param null|integer $offset
     *
     * @return array
     */
    public function findBySelect(array $criteria, array $orderBy = null, $limit = null, $offset = null)
    {
        $em = $this->getEntityManager();

        $govProgramm = null;

        if (isset($criteria['govProgram'])) {
            $iDs = [];
            $govProgramm = $em->getRepository('AnalyticsBundle:GovProgram')->findOneBy(['id' => $criteria['govProgram']]);
            if (!empty($govProgramm)) {
                $kbkItems = $em->getRepository('AnalyticsBundle:Kbk')->findBy(['govProgram' => $govProgramm]);
                $iDs = [];
                if (!empty($kbkItems)) {
                    foreach ($kbkItems as $item) {
                        $kbkSection = $item->getKbkSection();
                        if (!empty($kbkSection)) {
                            $id = $kbkSection->getId();
                            $iDs[$id] = $id;
                        }
                    }
                }
                $iDs = array_values($iDs);
            }

            $criteria['id'] = $iDs;

            if (count($criteria['id']) <= 0) {
                return null;
            }
        }

        unset($criteria['govProgram']);


        $qb = $this
            ->getSelect($criteria, $orderBy, $limit, $offset);
        $query = $qb->getQuery(); //->useResultCache(true); @todo: В рабочей системе это нужно вернуть

        $items = array_map(
            function ($item) use($em, $govProgramm) {
                $values = array(
                    'id'          => $item['id'],
                    'value'       => $item['id'], // @todo: убрать, когда откажемся от реактовой части!
                    'title'       => $item['title'],
                    'description' => $item['title'],
                );
                if (!empty($govProgramm)) {
                    $values['number']        = $item['code'];
                    $values['is_fcp']        = count($em->getRepository('AnalyticsBundle:Fcp')->findOneBy(['govProgram' => $govProgramm])) > 0;
                    $values['is_subprogram'] = count($em->getRepository('AnalyticsBundle:GovProgram')->findOneBy(['parent' => $govProgramm])) > 0;
                }
                return $values;
            },
            $query->getArrayResult()
        );

        return $items;
    }
}
