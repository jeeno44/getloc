<?php
namespace AnalyticsBundle\Repository;

use AnalyticsBundle\Model\AnalyticsRepository;

/**
 * Class KbkKosguRepository
 * @package AnalyticsBundle\Repository
 */
class KbkKosguRepository extends AnalyticsRepository
{

}
