<?php

namespace AnalyticsBundle\Repository;

use AnalyticsBundle\Entity\Notify;
use AnalyticsBundle\Model\AnalyticsRepository;

class NotifyRepository extends AnalyticsRepository
{

    /**
     * @param string $type
     * @return array
     */
    public function getNotifyByType($type)
    {
        return $this
            ->createQueryBuilder('n')
            ->select('n, rul, rol, sms, em, per, com')
            ->leftJoin('n.rules', 'rul')
            ->leftJoin('n.roles', 'rol')
            ->leftJoin('n.sms', 'sms')
            ->leftJoin('n.email', 'em')
            ->leftJoin('n.periods', 'per')
            ->leftJoin('n.common', 'com')
            ->where('rul.type = :type')
            ->setParameter('type', $type)
            ->getQuery()
            ->getResult();
    }
}
