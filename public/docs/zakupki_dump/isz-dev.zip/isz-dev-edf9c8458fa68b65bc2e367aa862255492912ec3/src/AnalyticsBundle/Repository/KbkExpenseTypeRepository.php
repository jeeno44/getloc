<?php
namespace AnalyticsBundle\Repository;

use AnalyticsBundle\Model\AnalyticsRepository;

/**
 * Class KbkExpenseTypeRepository
 * @package AnalyticsBundle\Repository
 */
class KbkExpenseTypeRepository extends AnalyticsRepository
{
    /**
     * @param array $criteria
     * @param array $orderBy
     * @param null|integer $limit
     * @param null|integer $offset
     *
     * @return array
     */
    public function findBySelect(array $criteria, array $orderBy = null, $limit = null, $offset = null)
    {
        $em = $this->getEntityManager();
        $kbkSection = false;
        if (isset($criteria['kbkSection']) && !empty($criteria['kbkSection'])) {
            $criteria = array_merge([
                'govProgram'       => [],
                'fcp'              => [],
                'subProgramAction' => [],
                'kbkFlowDirection' => [],
            ], $criteria);
            $criteria['id'] = $em
                ->getRepository('AnalyticsBundle:Kbk')
                ->getKbkExpenseTypeIds(
                    $criteria['kbkSection'],
                    (array) $criteria['govProgram'],
                    (array) $criteria['fcp'],
                    (array) $criteria['subProgramAction'],
                    (array) $criteria['kbkFlowDirection']
                );
            $kbkSection = $criteria['kbkSection'];
            unset($criteria['kbkSection'], $criteria['govProgram'], $criteria['fcp'], $criteria['subProgramAction'], $criteria['kbkFlowDirection']);

            if (count($criteria['id']) <= 0) {
                return null;
            }
        }

        $qb = $this
            ->getSelect($criteria, $orderBy, $limit, $offset);
        $query = $qb->getQuery(); //->useResultCache(true); @todo: В рабочей системе это нужно вернуть

        $items = $query->getArrayResult();



        $qb = $this
            ->getSelect([], $orderBy, $limit, $offset);

        foreach ($items as $item) {
            $qb->orWhere('SUBSTRING(t.code, 1, 1) = \'' . $item['code'][0] . '\'');
        }

        $query = $qb->getQuery(); //->useResultCache(true); @todo: В рабочей системе это нужно вернуть

        $items = $query->getArrayResult(); /*array_map(
            function ($item) use($em, $kbkSection, $rSubProgramAction) {
                $values = [
                    'id'          => $item['id'],
                    'value'       => $item['id'], // @todo: убрать, когда откажемся от реактовой части!
                    'title'       => $item['title'],
                    'description' => $item['title'],
                ];

                if ($kbkSection !== false) {
                    $values['number'] = $item['number'];
                }

                return $values;
            },
            $query->getArrayResult()
        );*/

        return $items;
    }
}
