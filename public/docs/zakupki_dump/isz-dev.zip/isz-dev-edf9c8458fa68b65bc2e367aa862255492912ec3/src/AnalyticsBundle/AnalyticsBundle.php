<?php

namespace AnalyticsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;
use Symfony\Component\DependencyInjection\ContainerBuilder;

/**
 * Class AnalyticsBundle
 * @package AnalyticsBundle
 */
class AnalyticsBundle extends Bundle
{
    /**
     * @param ContainerBuilder $container
     */
    public function build(ContainerBuilder $container)
    {
        $container->addCompilerPass(new \Knp\JsonSchemaBundle\DependencyInjection\Compiler\RegisterJsonSchemasPass($this));
    }
}
