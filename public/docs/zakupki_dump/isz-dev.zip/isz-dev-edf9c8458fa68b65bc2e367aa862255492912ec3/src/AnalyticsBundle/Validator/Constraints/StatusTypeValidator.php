<?php

namespace AnalyticsBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use AnalyticsBundle\Entity\EventManagement;
use AnalyticsBundle\Services\StatusManagerService;

class StatusTypeValidator extends ConstraintValidator
{
    /**
     * @var StatusManagerService
     */
    protected $statusManagerService;
    /**
     * @param StatusManagerService $statusManagerService
     */
    public function setStatusManager($statusManagerService)
    {
        $this->statusManagerService = $statusManagerService;
    }

    /**
     * @param EventManagement $eventManagement
     * @param Constraint $constraint
     */
    public function validate($eventManagement, Constraint $constraint)
    {
        $type = $eventManagement->getStatusTypeObject();
        $id = $eventManagement->getId();
        $statusTypes = $this->statusManagerService->getAllStatusType();
        $firstStatus = $eventManagement->getStatusStart();
        $secondStatus = $eventManagement->getStatusEnd();
        $interval = $eventManagement->getDays();
        $checkExistFirstStatus = $this->statusManagerService->checkExistStatus($firstStatus, $type);
        $checkExistSecondStatus = $this->statusManagerService->checkExistStatus($secondStatus, $type);
        $statusAlreadyUsed = $this->statusManagerService->checkUsedStatus($firstStatus, $type);

        if (!in_array($type, $statusTypes)) {
            $this->context->buildViolation($constraint->invalidType)
                ->atPath('statusTypeObject')
                ->addViolation();
        }
        if (is_null($checkExistFirstStatus)) {
            $this->context->buildViolation($constraint->invalidTypeStatus)
                ->atPath('statusStart')
                ->addViolation();
        }
        if (is_null($checkExistSecondStatus)) {
            $this->context->buildViolation($constraint->invalidTypeStatus)
                ->atPath('statusEnd')
                ->addViolation();
        }
        if (!is_null($statusAlreadyUsed) && is_null($id) && $statusAlreadyUsed->getId() != $id) {
            $this->context->buildViolation($constraint->statusExist)
                ->atPath('statusStart')
                ->addViolation();
        }
        if ($firstStatus === $secondStatus) {
            $this->context->buildViolation($constraint->duplicateStatus)
                ->atPath('statusEnd')
                ->addViolation();
        }
        if ($interval < 0) {
            $this->context->buildViolation($constraint->negativeAmountDays)
                ->atPath('days')
                ->addViolation();
        }
    }
}