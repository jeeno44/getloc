<?php

namespace AnalyticsBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

/**
 * @Annotation
 */
class StatusType extends Constraint
{
    public $invalidType = 'Данного типа не существует';

    public $invalidTypeStatus = 'Данного статуса не существует';

    public $statusExist = 'Статус уже был использован';

    public $duplicateStatus = 'Статусы не могут повторяться';

    public $negativeAmountDays = 'Интервал не может быть отрицательным';

    public function validatedBy()
    {
        return 'status_type_validator';
    }

    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
