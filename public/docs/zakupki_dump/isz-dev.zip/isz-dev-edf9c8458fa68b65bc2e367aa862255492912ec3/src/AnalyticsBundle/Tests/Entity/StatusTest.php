<?php
/**
 * Created by PhpStorm.
 * User: vadim
 * Date: 17.11.15
 * Time: 11:16
 */

namespace AnalyticsBundle\Tests\Entity;

use Liip\FunctionalTestBundle\Test\WebTestCase;
use AnalyticsBundle\Entity\Status;


class StatusTest extends WebTestCase
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $_em;

    //поля, которые должны быть в AnalyticsBundle\Entity\Status
    protected $fields = ['id', 'typeObject', 'subSystem', 'title'];

    /**
     *
     */
    public function setUp()
    {
        $this->_em = $this->getContainer()
            ->get('doctrine')
            ->getManager('analytics');
    }

    /**
     * @throws \Doctrine\Common\Persistence\Mapping\MappingException
     */
    public function testFields()
    {
        /** @var ClassMetadataInfo $entityMeta */
        $entityMeta = $this->_em->getMetadataFactory()->getMetadataFor('AnalyticsBundle:Status');

        foreach ($this->fields as $field) {
            $this->assertEquals(
                in_array($field, $entityMeta->getFieldNames()),
                true,
                "Поле $field не найдено в ".$entityMeta->getName()
            );
        }
    }
}