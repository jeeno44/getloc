<?php

namespace AnalyticsBundle\Tests\Repository;

use AnalyticsBundle\Entity\Status;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

/**
 * Тестирование репозития статусов - Status
 * @todo: Бля первый тест в бандле - можно прям Гордиться :-D
 * @package AnalyticsBundle\Tests\Repository
 */
class StatusRepositoryTest extends KernelTestCase
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $em;

    /**
     * {@inheritDoc}
     */
    protected function setUp()
    {
        self::bootKernel();

        $this->em = static::$kernel->getContainer()
            ->get('doctrine')
            ->getManager('analytics');
    }

    /**
     * Тестирование findIdsBySubsystemAndType
     * @todo: По правильному тестирование должно происходить на тестовой базе данных и в начале нужно добавить список
     * @todo: статусов (fixtures)
     */
    public function testFindIdsBySubsystemAndType()
    {
        $ids = $this->em
            ->getRepository('AnalyticsBundle:Status')
            ->findIdsBySubsystemAndType(Status::SUB_SYSTEM_FP_PLANIROVANIE, Status::OBJECT_TYPE_LOT);

        $this->assertTrue(count($ids) > 0, 'Ошибка получения ID-ов статусов ' . Status::OBJECT_TYPE_LOT . ' в подсистеме ' . Status::SUB_SYSTEM_FP_PLANIROVANIE);

        $_ids = true;
        foreach ($ids as $id) {
            if (!(is_string($id) || is_numeric($id))) {
                $_ids = false;
                break;
            }
        }
        $this->assertTrue($_ids, 'В списке статусов не должно быть объектов или массивов, должен быть string или numeric');
    }
}
