<?php
namespace AnalyticsBundle\Tests\Entity;

use AnalyticsBundle\Entity\Lot;
use Doctrine\ORM\Mapping\ClassMetadataInfo;
use Liip\FunctionalTestBundle\Test\WebTestCase;


use HWI\Bundle\OAuthBundle\Security\Core\Authentication\Token\OAuthToken;

use Doctrine\Common\DataFixtures\Loader;
use Doctrine\Common\DataFixtures\Executor\ORMExecutor;
use Doctrine\Common\DataFixtures\Purger\ORMPurger;

class LotTest extends WebTestCase
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $_em;

    /**
     * @var \Doctrine\Common\DataFixtures\Executor\ORMExecutor
     */
    protected $fixture;

    // Поля, обязательные для заполнения
    protected $fields_require = ['id', 'statusId', 'creationDate', 'procResp', 'common'];

    // Количество полей
    const COUNT_FIELDS = 58;

    public function setUp()
    {
        $kernel = static::createKernel();
        $kernel->boot();

        $this->logIn();

        $this->_em = $this->getContainer()
            ->get('doctrine')
            ->getManager('analytics');

        /*$classes = array(
            'AnalyticsBundle\DataFixtures\ORM\LoadUsersData',
            'AnalyticsBundle\DataFixtures\ORM\LoadCommonData',
            'AnalyticsBundle\DataFixtures\ORM\LoadLotData',
        );
        */

        //$this->fixture = $this->loadFixtures($classes, 'analytics');  //, 'doctrine', ORMPurger::PURGE_MODE_DELETE

        $loader = new Loader();

        $loadUsersData = new \AnalyticsBundle\DataFixtures\ORM\LoadUsersData;
        $loadUsersData->setContainer($this->getContainer());
        $loader->addFixture($loadUsersData);


        $loadCommonData = new \AnalyticsBundle\DataFixtures\ORM\LoadCommonData;
        $loadCommonData->setContainer($this->getContainer());
        $loader->addFixture($loadCommonData);


        $loadLotData = new \AnalyticsBundle\DataFixtures\ORM\LoadLotData;
        $loadLotData->setContainer($this->getContainer());
        $loader->addFixture($loadLotData);

        $fixtures = $loader->getFixtures();

        $purger = new ORMPurger();
        $executor = new ORMExecutor($this->_em, $purger);
        $executor->execute($fixtures);

        //print_r($fixtures);
    }

    public function testMeta()
    {
        /** @var ClassMetadataInfo $meta */
        $meta = $this->_em->getMetadataFactory()->getMetadataFor('AnalyticsBundle:Lot');

        $ct = count($meta->getFieldNames());
        $this->assertEquals($ct, self::COUNT_FIELDS, ($ct > self::COUNT_FIELDS ? 'Добавилось' : 'Удалилось') . ' поле');

        foreach ($this->fields_require as $name) {
            if ($meta->isAssociationWithSingleJoinColumn($name)) {
                $this->assertNotTrue((bool) $meta->getAssociationMapping($name)['joinColumns'][0]['nullable'], 'Поле ' . $name . ' не обязательное для заполнения');
            } else {
                $this->assertNotTrue($meta->isNullable($name), 'Поле ' . $name . ' не обязательное для заполнения');
            }
        }

        $this->assertTrue($meta->isIdentifierUuid(), 'Идентификатор UUID');

        $entity = new Lot();
        $entity->setTitle('title');
        $this->assertEquals((string) $entity, 'title', '__toString работает не праивльно');

        /*$reflect = new \ReflectionClass($entity);

        $fields = array_map(
            function (\ReflectionProperty $prop) {
                return $prop->name;
            },
            $reflect->getProperties()
        );*/
    }

    private function logIn()
    {
        $userId = '1d03f765-fdaa-4b64-9f88-a772eba12e51';
        $common = '01dd59a0-120c-4db8-9b16-dd1b309c8add';
        $token  = '321';
        $group  = '123';//$request->headers->get("X-Expert-Group-Id");

        /** @var \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage $context */
        $context = $this->getContainer()->get('security.token_storage');
        $token = new OAuthToken($token, ["ROLE_USER"]);
        $token->setAuthenticated(true);
        $token->setUser(new \ApiBundle\User\OAuthUser('ISZ User', $userId, $common, $group));

        $context->setToken($token);
    }
}