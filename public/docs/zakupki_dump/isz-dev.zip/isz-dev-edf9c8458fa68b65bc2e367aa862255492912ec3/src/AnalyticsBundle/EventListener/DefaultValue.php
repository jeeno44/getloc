<?php

namespace AnalyticsBundle\EventListener;

use AnalyticsBundle\Entity\Financing;
use AnalyticsBundle\Entity\Lot;
use AnalyticsBundle\Entity\Plan;
use AnalyticsBundle\Entity\Users;
use AnalyticsBundle\Repository\CommonRepository;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Event\LifecycleEventArgs;
use Doctrine\ORM\Event\OnFlushEventArgs;
use Doctrine\ORM\Event\PostFlushEventArgs;
use Symfony\Component\DependencyInjection\ContainerInterface;
use OldSound\RabbitMqBundle\RabbitMq\Producer;

class DefaultValue
{

    private $entities = [];

    /**
     * @var Producer
     */
    protected $_producer;

    /**
     * @var ContainerInterface
     */
    protected $container;

    /**
     * DefaultValue constructor.
     * @param ContainerInterface $container
     * @param Producer $producer
     */
    public function __construct(ContainerInterface $container, Producer $producer)
    {
        $this->container = $container;
        $this->_producer = $producer;
    }

    /**
     * Check is entity revision?
     *
     * @param $entity
     * @return bool
     */
    public function isRevision($entity){
        $isRevision = false;
        if (method_exists($entity, 'getIsRevision')) {
            $isRevision = $entity->getIsRevision();
        }
        return $isRevision;
    }

    /**
     * Create revision
     *
     * @param $entity
     * @return mixed
     */
    public function createRevision($entity){

        $revisionEntity = clone $entity;
        $em = $this->container->get('doctrine')->getManager('analytics');
        $em->detach($revisionEntity);
        $revisionEntity->setIsRevision(true);
        $revisionEntity->setRevisionDate(new \DateTime());
        $revisionEntity->setRevision(null);

        $em->persist($revisionEntity);

        return $revisionEntity;
    }


    /**
     * Update cache entity on app server
     *
     * @param $entity
     */
    public function warmEntityCache($entity) {
        try {
            $type = "";
            switch (get_class($entity)) {
                case "AnalyticsBundle\\Entity\\Lot" :
                    $type = "lots";
                    break;
                case "AnalyticsBundle\\Entity\\Plan" :
                    $type = "plans";
                    break;
            }

            $this->_producer->publish(json_encode([
                'id' => $entity->getId(),
                'type' => $type,
            ]), 'async.cache.warm');
        } catch (\Exception $e) {}
    }

    /**
     * @param PostFlushEventArgs $args
     */
    public function postFlush(PostFlushEventArgs $args)
    {
    }

    /**
     * @param OnFlushEventArgs $args
     */
    public function onFlush(OnFlushEventArgs $args)
    {
        $em = $args->getEntityManager();
        $uow = $em->getUnitOfWork();

        foreach ($uow->getScheduledEntityUpdates() AS $entity) {

            if (get_parent_class($entity) == "AnalyticsBundle\\Entity\\Revision") {

                // break if is revision
                if ($entity->getIsRevision()) {
                    return;
                }

                $revisionEntity = clone $entity;
                $em->detach($revisionEntity);

                $revisionEntity->setIsRevision(true);
                $revisionEntity->setRevisionDate(new \DateTime());
                $revisionEntity->setRevision(null);

                $class = $em->getClassMetadata(get_class($revisionEntity));

                $em->persist( $revisionEntity );
                $em->getUnitOfWork()->computeChangeSet($class, $revisionEntity);

                $entity->addRevision($revisionEntity);
                $em->persist($entity);
                $em->getUnitOfWork()->computeChangeSet($class, $entity);

                // обновляем кеш измененной сущности
                $this->warmEntityCache($entity);

                // кладем в кеш версию сущности
                //$this->warmEntityCache($revisionEntity);
            }
        }
    }

    /**
     * @param LifecycleEventArgs $args
     */
    public function postUpdate(LifecycleEventArgs $args)
    {
    }

    /**
     *
     * @param LifecycleEventArgs $args
     */
    public function preUpdate(LifecycleEventArgs $args)
    {
    }

    /**
     * @param LifecycleEventArgs $args
     * @throws \Exception
     */
    public function prePersist(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();

        switch (true) {
            case $entity instanceof Lot:

                /** cancel working with revision for revision */
                if ($this->isRevision($entity)) {
                    return;
                }

                /**
                 * Обрабатываем вставку данных в entity Lot
                 */
                $user = $this->container->get('analytics.system')->getUser();
                $common = $this->container->get('analytics.system')->getCommon();
                /** @var EntityManager $r */
                $em = $this->container->get('doctrine')->getManager('analytics');

                $entity
                    ->setProcResp($em->getReference('AnalyticsBundle:Users', $user->getId()))
                    ->setCommon($em->getReference('AnalyticsBundle:Common', $common->getId()))
                    ->setStatusId($entity::STATUS_DRAFT)
                    ->setCreationDate(new \DateTime());

                break;
            case $entity instanceof Plan:

                /** cancel working with revision for revision */
                if ($this->isRevision($entity)) {
                    return;
                }

                $lots = $entity->getLots();
                foreach ($lots as $lot) {
                    if ($lot->getCommon()->getId() != $this->container->get('analytics.system')->getCommon()->getId()) {
                        $entity->removeLot($lot);
                        throw new \Exception('error lot plan');
                    }
                }
                break;
        }
    }

}