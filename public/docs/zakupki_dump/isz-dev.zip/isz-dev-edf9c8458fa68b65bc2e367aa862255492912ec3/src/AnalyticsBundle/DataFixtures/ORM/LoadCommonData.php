<?php

namespace AnalyticsBundle\DataFixtures\ORM;

use AnalyticsBundle\Entity\Common;
use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

class LoadCommonData extends AbstractFixture implements ContainerAwareInterface
{
    /**
     * @var ContainerInterface
     */
    private $container;

    /**
     * {@inheritDoc}
     */
    public function setContainer(ContainerInterface $container = null)
    {
        $this->container = $container;
    }

    public function load(ObjectManager $manager)
    {
        $rUser = $manager->getRepository('AnalyticsBundle:Users');
        if ($_user = $rUser->find('1d03f765-fdaa-4b64-9f88-a772eba12e51')) {
            echo $_user->getVersionOwnerId();
        }
        $common = new Common();
        $common
            ->setType(Common::TYPE_FOIV)
            ->setFullName(Common::$types[Common::TYPE_FOIV])
            ->setShortName(Common::$types[Common::TYPE_FOIV])
            ->setHead($this->getReference('user'))
            ;
        $manager->persist($common);
        $manager->flush();
        $this->setReference('common.' . Common::TYPE_FOIV, $common);

        $common = new Common();
        $common
            ->setParent($this->getReference('common.' . Common::TYPE_FOIV))
            ->setType(Common::TYPE_ORGANIZATION)
            ->setFullName(Common::$types[Common::TYPE_ORGANIZATION])
            ->setShortName(Common::$types[Common::TYPE_ORGANIZATION])
            ->setHead($this->getReference('user'))
            ;
        $manager->persist($common);
        $manager->flush();
        $this->setReference('common.' . Common::TYPE_ORGANIZATION, $common);

        $common = new Common();
        $common
            ->setParent($this->getReference('common.' . Common::TYPE_ORGANIZATION))
            ->setType(Common::TYPE_DEPARTMENT)
            ->setFullName(Common::$types[Common::TYPE_ORGANIZATION] . ' ' . Common::$types[Common::TYPE_DEPARTMENT])
            ->setShortName(Common::$types[Common::TYPE_ORGANIZATION] . ' ' . Common::$types[Common::TYPE_DEPARTMENT])
            ->setHead($this->getReference('user'))
            ;
        $manager->persist($common);
        $manager->flush();
        $this->setReference('common.' . Common::TYPE_ORGANIZATION . '.' . Common::TYPE_DEPARTMENT, $common);



        /** @var \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage $context */
        $context = $this->container->get('security.token_storage');
        $user = $context
            ->getToken()
            ->getUser()
            ->setCommonId($common->getId());
        $context
            ->getToken()
            ->setUser($user);


        $common = new Common();
        $common
            ->setParent($this->getReference('common.' . Common::TYPE_FOIV))
            ->setType(Common::TYPE_DEPARTMENT)
            ->setFullName(Common::$types[Common::TYPE_FOIV] . ' ' . Common::$types[Common::TYPE_DEPARTMENT])
            ->setShortName(Common::$types[Common::TYPE_FOIV] . ' ' . Common::$types[Common::TYPE_DEPARTMENT])
            ->setHead($this->getReference('user'))
            ;
        $manager->persist($common);
        $manager->flush();
        $this->setReference('common.' . Common::TYPE_FOIV . '.' . Common::TYPE_DEPARTMENT, $common);
    }

    public function getDependencies()
    {
        return array(
            'AnalyticsBundle\DataFixtures\ORM\LoadUsersData',
        );
    }
}