<?php

namespace AnalyticsBundle\DataFixtures\ORM;

use AnalyticsBundle\Entity\Users;
use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

class LoadUsersData extends AbstractFixture implements ContainerAwareInterface
{
    /**
     * @var ContainerInterface
     */
    private $container;

    /**
     * {@inheritDoc}
     */
    public function setContainer(ContainerInterface $container = null)
    {
        $this->container = $container;
    }

    public function load(ObjectManager $manager)
    {
        $manager->clear();
        $user = new Users();
        $user
            ->setId('1d03f765-fdaa-4b64-9f88-a772eba12e51')
            ->setName('test')
            ->setLastName('lot - test - test')
            ->setJobTitle('test')
            ->setPhone('test')
            ->setEmail('test@test.com');

        $manager->persist($user);
        $manager->flush();

        $this->addReference('user', $user);

        /** @var \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage $context */
        $context = $this->container->get('security.token_storage');
        $user = $context
            ->getToken()
            ->getUser()
            ->setId($user->getId());
        $context
            ->getToken()
            ->setUser($user);
    }
}