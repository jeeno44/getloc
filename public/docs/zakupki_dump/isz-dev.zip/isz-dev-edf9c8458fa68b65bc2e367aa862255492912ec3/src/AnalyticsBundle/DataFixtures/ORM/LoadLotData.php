<?php

namespace AnalyticsBundle\DataFixtures\ORM;

use AnalyticsBundle\Entity\Common;
use AnalyticsBundle\Entity\Financing;
use AnalyticsBundle\Entity\Lot;
use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;

class LoadLotData extends AbstractFixture implements ContainerAwareInterface, DependentFixtureInterface
{
    const MAX_LOT = 20;

    /**
     * @var ContainerInterface
     */
    private $container;

    /**
     * {@inheritDoc}
     */
    public function setContainer(ContainerInterface $container = null)
    {
        $this->container = $container;
    }

    public function load(ObjectManager $manager)
    {
        $commons = [
            $this->getReference('common.' . Common::TYPE_FOIV),
            $this->getReference('common.' . Common::TYPE_ORGANIZATION),
            $this->getReference('common.' . Common::TYPE_FOIV . '.' . Common::TYPE_DEPARTMENT),
            $this->getReference('common.' . Common::TYPE_ORGANIZATION . '.' . Common::TYPE_DEPARTMENT),
        ];
        for ($j = 0; $j < self::MAX_LOT; $j++) {
            echo array_rand($commons);
            $lot = new Lot();
            $lot
                ->setTitle('Test Lot - ' . $j)
                ->setCommon($commons[array_rand($commons)]);
            for ($i = 1; $i <= rand(1, Financing::MAX_YEARS); $i++) {
                $financing = new Financing();
                $financing
                    ->setRelYear($i)
                    ->setPlanPrice(rand(10, 1000))
                    ->setPlanQuantity(rand(1, 100));
                $lot->addFinancing($financing);
            }
            $manager->persist($lot);
        }

        $manager->flush();
    }

    public function getDependencies()
    {
        return array(
            'AnalyticsBundle\DataFixtures\ORM\LoadUsersData',
            'AnalyticsBundle\DataFixtures\ORM\LoadCommonData',
        );
    }
}