<?php
namespace ApiBundle\EventListener;

use AnalyticsBundle\Entity\Users;
use AnalyticsBundle\Services\SystemService;
use ApiBundle\Controller\DirectoryController;
use ApiBundle\Controller\RestrictedController;
use ApiBundle\Controller\RestrictedSimpleController;
use Doctrine\ORM\EntityManager;
use HWI\Bundle\OAuthBundle\Security\Core\Authentication\Token\OAuthToken;
use HWI\Bundle\OAuthBundle\Security\Core\User\OAuthUser;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Event\FilterControllerEvent;
use FOS\RestBundle\Util\Codes;
use FOS\RestBundle\View\View as FOSView;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

/**
 * Class TokenVerifier
 * @package ApiBundle\EventListener
 */
class TokenVerifier
{
    /**
     * @var ContainerInterface
     */
    protected $container;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    /**
     * @param FilterControllerEvent $event
     */
    public function onKernelController(FilterControllerEvent $event)
    {
        $controller = $event->getController();

        if (!is_array($controller)) {
            return;
        }

        if ($controller[0] instanceof RestrictedController || $controller[0] instanceof DirectoryController || $controller[0] instanceof RestrictedSimpleController) {
            $request  = $event->getRequest();

            /** @var guid|string $userId */
            $userId = $request->headers->get("X-User-Id", $request->query->get("X-User-Id"));
            $subSystem  = $request->headers->get("X-Sub-System", $request->query->get("X-Sub-System"));

            /*if (empty($subSystem)) {
                throw new AccessDeniedException('Не передан X-Sub-System');
            }*/

            if (!empty($userId)) {
                $token      = $request->headers->get("X-Access-Token");
                $common     = $request->headers->get("X-Common-Id", $request->query->get("X-Common-Id"));
                $group      = $request->headers->get("X-Expert-Group-Id", $request->query->get("X-Expert-Group-Id"));

                /** @var \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage $context */
                $context = $this->container->get('security.token_storage');
                $token   = new OAuthToken($token, ["ROLE_USER"]);
                $token->setAuthenticated(true);



                /** @var EntityManager $em */
                $em = $this->container->get('doctrine')->getManager('analytics');

                $user = $em->getRepository('AnalyticsBundle:Users')->find($userId);

                if (!($user instanceof Users)) {
                    throw new AccessDeniedException('Пользователь не существует ID: ' . $userId);
                }

                $user->setSubSystem($subSystem)
                    ->setCommonId($common)
                    ->setExpertGroupId($group);


                /*$user = (new \ApiBundle\User\OAuthUser('ISZ User', $userId))
                    ->setSubSystem($subSystem)
                    ->setCommonId($common)
                    ->setExpertGroupId($group);*/
                //$user->container($this->container);

                $token->setUser($user);

                $context->setToken($token);

                /** @var SystemService $systemService */
                $systemService = $this
                    ->container
                    ->get('analytics.system');
                $token->setUser(
                    $token
                        ->getUser()
                        ->setPermissions(
                            $systemService
                                ->getUser()
                                ->getGroupRoles()
                        )
                );

                $context->setToken($token);
            } else {
                throw new AccessDeniedException();
            }
        }
    }
}
