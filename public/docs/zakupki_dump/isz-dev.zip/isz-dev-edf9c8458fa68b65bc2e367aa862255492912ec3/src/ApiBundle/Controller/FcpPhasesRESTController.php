<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * FcpPhases controller.
 * @RouteResource("FcpPhases")
 */
class FcpPhasesRESTController extends DirectoryRESTController
{
    const ENTITY = 'FcpPhases';
}
