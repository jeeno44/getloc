<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Documents controller.
 * @RouteResource("Documents")
 */
class DocumentsRESTController extends DirectoryRESTController
{
    const ENTITY = 'Documents';
}
