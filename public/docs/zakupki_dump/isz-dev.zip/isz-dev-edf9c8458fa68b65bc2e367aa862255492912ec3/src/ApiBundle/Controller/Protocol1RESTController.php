<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Protocol1 controller.
 * @RouteResource("Protocol1")
 */
class Protocol1RESTController extends DirectoryRESTController
{
    const ENTITY = 'Protocol1';
}
