<?php

namespace ApiBundle\Controller;

use ApiBundle\Controller\ApiRESTController;
use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * CriteriaCondition controller.
 * @RouteResource("Criteria/Condition")
 */
class CriteriaConditionRESTController extends ApiRESTController
{
    const ENTITY = 'CriteriaCondition';

    //static public $groupsGetEntity = ['CriteriaCondition', 'CriteriaCondition_detail', 'lot_list'];

    static public $groupsGetList = ['CriteriaCondition', 'CriteriaCondition_list', 'CriteriaMaxValues', 'CriteriaType'];
}
