<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

use AnalyticsBundle\Model\AnalyticsRepository,
    Doctrine\ORM\EntityManager,
    Doctrine\ORM\Mapping\ClassMetadataInfo,
    Doctrine\Common\Collections\Collection;
use Symfony\Component\Form\Form,
    Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request,
    Symfony\Component\HttpFoundation\Response,
    Symfony\Bundle\FrameworkBundle\Controller\Controller;
use FOS\RestBundle\Controller\Annotations\QueryParam,
    FOS\RestBundle\Controller\Annotations\View,
    FOS\RestBundle\Request\ParamFetcherInterface,
    FOS\RestBundle\Util\Codes,
    FOS\RestBundle\View\View as FOSView;
use Nelmio\ApiDocBundle\Annotation\ApiDoc,
    JMS\Serializer\SerializationContext;

/**
 * Supplier controller.
 * @RouteResource("Super")
 */
class SuperRESTController extends Controller
{
    /**
     * Get all entities.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка select значений"
     * )
     *
     * @View(serializerEnableMaxDepthChecks=true)
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="select", nullable=true, array=true, description="?select[kbks]=<uuid>&select[okpds]=<uuid>")
     */
    public function cgetSelectAction(ParamFetcherInterface $paramFetcher)
    {
        $selects = $this->getRequest()->get('select');

        $em = $this->getDoctrine()->getManager('analytics');

        $result = [];

        try {
            foreach ($selects as $key => $value) {
                /** @var AnalyticsRepository $repository */
                $repository = $em->getRepository('AnalyticsBundle:' . ucfirst($key));
                $result[$key] = $repository->findBySelect(['id' => $value]);
            }

            return $result;
        } catch (\Exception $e) {
            return FOSView::create(['errors' => ['Ошибка получения данных' . (isset($key) ? ': ' . $key : '')], 'result' => $result], Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
