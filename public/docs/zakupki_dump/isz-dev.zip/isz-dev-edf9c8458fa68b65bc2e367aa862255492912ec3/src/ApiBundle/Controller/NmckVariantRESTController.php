<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * NmckVariant controller.
 * @RouteResource("NmckVariant")
 */
class NmckVariantRESTController extends DirectoryRESTController
{
    const ENTITY = 'NmckVariant';
}
