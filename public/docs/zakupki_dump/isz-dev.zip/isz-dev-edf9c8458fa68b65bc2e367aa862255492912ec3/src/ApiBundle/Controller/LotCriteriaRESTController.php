<?php

namespace ApiBundle\Controller;

use ApiBundle\Controller\ApiRESTController;
use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * CriteriaType controller.
 * @RouteResource("Lot/Criteria")
 */
class LotCriteriaRESTController extends ApiRESTController
{
    const ENTITY = 'LotCriteria';

    static public $groupsGetEntity = ['LotCriteria', 'LotCriteria_detail', 'lot_list'];  //['detail']

    static public $groupsGetList = ['LotCriteria'];  //['list']
}
