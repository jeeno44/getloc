<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Okved controller.
 * @RouteResource("Okved")
 */
class OkvedRESTController extends DirectoryRESTController
{
    const ENTITY = 'Okved';

    /**
     * @var string
     */
    static public $selectFieldTitle = [ 'code', 'title'];
}
