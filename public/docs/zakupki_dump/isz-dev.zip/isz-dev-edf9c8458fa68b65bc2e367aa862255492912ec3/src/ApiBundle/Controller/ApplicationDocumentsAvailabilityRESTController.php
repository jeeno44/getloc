<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * ApplicationDocumentsAvailability controller.
 * @RouteResource("ApplicationDocumentsAvailability")
 */
class ApplicationDocumentsAvailabilityRESTController extends DirectoryRESTController
{
    const ENTITY = 'ApplicationDocumentsAvailability';
}
