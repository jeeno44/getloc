<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RequestParam;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * Class FileController
 * @package ApiBundle\Controller
 */
class FileController extends Controller
{
    /**
     * Загрузка файла
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Загрузка файла",
     *   section="System"
     * )
     *
     * @--RequestParam(name="file", nullable=false, array=true, description="Массив файлов")
     *
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function uploadAction(Request $request)
    {
        $files = [];

        /** @var \Symfony\Component\HttpFoundation\File\UploadedFile $file */
        foreach ($request->files as $files) {
            foreach ($files as $file) {
                try {
                    $origExt = $file->getClientOriginalExtension();
                    $origName = $file->getClientOriginalName();

                    $newFileName = substr($origName, 0, -strlen(".".$origExt))."_".time().".".$origExt;

                    $moveTo = $this->get('kernel')->getRootDir().'/../web/uploads/';

                    $file->move($moveTo, $newFileName);

                    $files[] = [
                        "path"     => '/uploads/'.$newFileName,
                        "filename" => $file->getClientOriginalName(),
                    ];
                } catch (FileException $e) {
                }
            }
        }

        return new JsonResponse([
            'status' => 'uploaded',
            'files'  => array_values(  // @todo: Это надо переписать и понять от куда добавляется 0-вой элемент в массив $files
                array_filter(
                    $files,
                    function ($file) {
                        return is_array($file);
                    }
                )
            ),
        ]);
    }

    /**
     * Загрузка аватара
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Загрузка аватара",
     *   section="System"
     * )
     *
     * @--RequestParam(name="file", nullable=false, description="Массив файлов")
     *
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function avatarAction(Request $request)
    {
        $files = [];

        /** @var \Symfony\Component\HttpFoundation\File\UploadedFile $file */
        foreach ($request->files as $files) {
            foreach ($files as $file) {
                try {
                    $origExt = $file->getClientOriginalExtension();
                    $origName = $file->getClientOriginalName();

                    $newFileName = substr($origName, 0, -strlen(".".$origExt))."_".time().".".$origExt;

                    $moveTo = $this->get('kernel')->getRootDir().'/../web/uploads/';

                    $file->move($moveTo, $newFileName);

                    $imagine = new \Imagine\Imagick\Imagine();
                    $size    = new \Imagine\Image\Box(48, 48);
                    $imagine->open($this->get('kernel')->getRootDir().'/../web/uploads/'.$newFileName)
                        ->thumbnail($size)
                        ->save();

                    $files[] = [
                        "path"     => '/uploads/'.$newFileName,
                        "filename" => $file->getClientOriginalName(),
                    ];
                } catch (FileException $e) {
                }
            }
        }

        return new JsonResponse([
            'status' => 'uploaded',
            'files'  => array_values(  // @todo: Это надо переписать и понять от куда добавляется 0-вой элемент в массив $files
                array_filter(
                    $files,
                    function ($file) {
                        return is_array($file);
                    }
                )
            ),
        ]);
    }
}
