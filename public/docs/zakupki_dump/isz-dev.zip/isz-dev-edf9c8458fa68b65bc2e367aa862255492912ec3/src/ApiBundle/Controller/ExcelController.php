<?php
namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RequestParam;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;


class ExcelController extends Controller implements RestrictedSimpleController
{

    /**
     * Загрузка файла
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Загрузка файла",
     *   section="System"
     * )
     *
     * @--RequestParam(name="file", nullable=false, array=true, description="Массив файлов")
     *
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function importAction(Request $request)
    {
        /** @var \Symfony\Component\HttpFoundation\File\UploadedFile $file */
        foreach($request->files as $files) {
            foreach ($files as $file) {
                try {
                    $new_file_name = substr($file->getClientOriginalName(), 0, -strlen("." . $file->getClientOriginalExtension())) .
                        "_" . time() .
                        "." .
                        $file->getClientOriginalExtension();

                    $file->move($this->get('kernel')->getRootDir() . '/../web/uploads/', $new_file_name);
                    $filename = $this->get('kernel')->getRootDir() . '/../web/uploads/' . $new_file_name;

                    $this->get("excel.import.lot")->import($filename);
                } catch (FileException $e) {
                    return new JsonResponse([
                        'status' => 'error',
                    ]);
                }
            }
        }

        return new JsonResponse([
            'status' => 'success',
        ]);
    }

    public function exportAction(Request $request)
    {
        $excel = $this->get('excel.export.lot');
        $result = $excel->export();

        return new JsonResponse($result);
    }

}