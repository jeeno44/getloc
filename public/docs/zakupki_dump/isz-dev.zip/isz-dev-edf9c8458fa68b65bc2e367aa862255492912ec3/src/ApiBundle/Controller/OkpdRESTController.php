<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Okpd controller.
 * @RouteResource("Okpd")
 */
class OkpdRESTController extends DirectoryRESTController
{
    const ENTITY = 'Okpd';
    static public $selectFieldTitle = ['codeOkpd', 'description'];
}
