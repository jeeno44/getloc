<?php

namespace ApiBundle\Controller;

use AnalyticsBundle\Entity\Lot;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use JMS\Serializer\SerializationContext;
use Symfony\Component\HttpFoundation\Request;

/**
 * Fcp controller.
 * @RouteResource("Fcp")
 */
class FcpRESTController extends DirectoryRESTController
{
    const ENTITY = 'Fcp';

    /**
     *
     * Получаем список FCP отсортированных по common
     *
     * @param Request $request
     * @return array
     */
    public function cgetCommonAction(Request $request)
    {
        $serializer = $this->get("jms_serializer");

        $em = $this->getDoctrine()->getManager('analytics');
        $lotRepo = $em->getRepository('AnalyticsBundle:Lot');
        $commonRepo = $em->getRepository('AnalyticsBundle:Common');
        $common = $commonRepo->findOneBy(['id' => $request->headers->get('x-common-id')]);

        $entities = $lotRepo->findBy(['common' => $common]);

        $items = [];

        /** @var Lot $entity */
        foreach ($entities as $entity) {
            if (!$entity->getIsRevision()) {

                $fcp = $entity->getFcp();

                if (!empty($fcp)) {
                    $items[$fcp->getId()] = json_decode($serializer->serialize($fcp, 'json', SerializationContext::create()->setGroups(['fcp_detail'])), 1);
                }
            }
        }

        return array_values($items);
    }

    /**
     *
     * Получаем список лотов групированных по
     *
     * @param Request $request
     * @return array
     */
    public function getLotsAction(Request $request, $fcp)
    {
        $em = $this->getDoctrine()->getManager('analytics');
        $fcpRepo = $em->getRepository('AnalyticsBundle:Fcp');
        $lotRepo = $em->getRepository('AnalyticsBundle:Lot');
        $commonRepo = $em->getRepository('AnalyticsBundle:Common');

        // ищем common
        $common = $commonRepo->find($request->headers->get('x-common-id'));
        // ищем fcp
        $fcp = $fcpRepo->find($fcp);

        $result = [];

        if (!empty($fcp) && !empty($common)) {
            $page = !empty($request->query->get('page')) ? $request->query->get('page') : 1;
            $limit = !empty($request->query->get('limit')) ? $request->query->get('limit') : 5;
            $lots = $lotRepo->getLotsByFcp($fcp->getId(), $common->getId(), $page, $limit);

            // You can also call the count methods (check PHPDoc for `paginate()`)
            $totalPostsReturned = $lots->getIterator()->count();
            $totalPosts = $lots->count();
            $iterator = $lots->getIterator();

            $result = [
                'pages' => ceil($lots->count() / $limit),
                'total' => $lots->count(),
                'lots' => array_map(function($lot){
                    return $lot->getId();
                }, $lots->getIterator()->getArrayCopy())
            ];

            return $result;
        }
    }
}
