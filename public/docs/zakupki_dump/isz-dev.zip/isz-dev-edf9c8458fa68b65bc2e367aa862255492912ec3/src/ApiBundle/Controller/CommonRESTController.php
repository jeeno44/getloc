<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Common controller.
 * @RouteResource("Common")
 */
class CommonRESTController extends DirectoryRESTController
{
    const ENTITY = 'Common';
    static public $selectFieldTitle = 'fullName';
    static public $groupsGetList   = ['common_list'];
    static public $groupsGetEntity   = ['common_detail', 'users_detail'];
}
