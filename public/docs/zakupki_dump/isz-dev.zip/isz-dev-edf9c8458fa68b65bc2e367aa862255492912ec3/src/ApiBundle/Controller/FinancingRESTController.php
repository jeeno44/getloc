<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Financing controller.
 * @RouteResource("Financing")
 */
class FinancingRESTController extends DirectoryRESTController
{
    const ENTITY = 'Financing';
}
