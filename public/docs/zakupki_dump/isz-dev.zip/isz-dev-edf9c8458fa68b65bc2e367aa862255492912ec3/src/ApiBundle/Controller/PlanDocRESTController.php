<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * LotDoc controller.
 * @RouteResource("PlanDoc")
 */
class PlanDocRESTController extends ApiRESTController
{
    const ENTITY = 'PlanDoc';
    static public $groupsGetEntity = ["plan_doc_detail"];
    static public $groupsGetList   = ["plan_doc_list"];
}