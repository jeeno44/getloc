<?php

namespace ApiBundle\Controller;

use AnalyticsBundle\AnalyticsBundle;
use AnalyticsBundle\Entity\Financing;
use AnalyticsBundle\Entity\FinancingPlan;
use AnalyticsBundle\Entity\Lot;
use AnalyticsBundle\Entity\Plan;

use AnalyticsBundle\Entity\Status;
use ApiBundle\Decorators\Lot\PlanType;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Criteria;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use FOS\RestBundle\Controller\Annotations\View;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Util\Codes;
use FOS\RestBundle\View\View as FOSView;
use JMS\Serializer\SerializationContext;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Form;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;

use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Validator\Validation;
use Symfony\Component\Validator\Constraints\Uuid;
use JMS\SecurityExtraBundle\Annotation\PreAuthorize;
use Symfony\Component\EventDispatcher\Event;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

/**
 * Lot controller.
 * @RouteResource("Lot")
 */
class LotRESTController extends ApiRESTController
{
    use \AppBundle\Traits\UuidTrait;

    const ENTITY_TYPE = 'lot';

    const ENTITY = 'Lot';
    static public $groupsGetEntity = [
        'lot_detail', 'stage', 'stage_detail', 'fcp_action', 'FlowDirection',
        "LotCriteria", "LotCriteria_detail", "CriteriaRating", "CriteriaIndicator", "CriteriaCondition", "CriteriaType",
        "LotRia"
    ];
    static public $groupsGetList = ['lot_list', 'common_list', 'fcp_action', 'gov_program'];

    /**
     * Возвращает список лотов отфильтрованный по залогиненному пользователю.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка Lot",
     *   section="Лоты"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"lot_list", "common_list", "fcp_action"}
     * )
     *
     * @PreAuthorize("token.getUser().hasPermission(['read_my_lots', 'find_all_lots', 'documents_read_section_all_documents'])")
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="offset", requirements="\d+", default="0", nullable=true, description="Offset from which to start listing notes.")
     * -QueryParam(name="limit", requirements="\d+", default="20", description="How many notes to return.")
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     */
    public function cgetAction(ParamFetcherInterface $paramFetcher)
    {
        try {
            $em = $this->getDoctrine()->getManager('analytics');

            $offset = $this->getRequest()->get('offset', 0);
            $limit = $this->getRequest()->get('limit', 20);
            $order_by = $this->getRequest()->get('order_by');
            $filters = !is_null($this->getRequest()->get('filters')) ? $this->getRequest()->get('filters') : array();

            //$filters['procResp'] = $this->getUser()->getId();

            $userId = $this->getUser()->getId();

            if (empty($userId)) {
                return [];
            }

            $common_ids = $em->getRepository('AnalyticsBundle:Users')->getCommonIds($userId);
            if (isset($filters['common']) && in_array($filters['common'], $common_ids)) {
                $filters['common'] = array_merge(
                    [$filters['common']],
                    $em->getRepository('AnalyticsBundle:Common')->findChildren($filters['common'])
                );
            } else {
                $filters['common'] = $common_ids;
            }

            if ($this->getRequest()->headers->has('X-Sub-System')) {
                // Фильтруем таким образом что бы в списке лотов отдавались только те лоты которые относятся к переданной подсистеме
                $filters['statusId'] =
                    $em
                        ->getRepository('AnalyticsBundle:Status')
                        ->findIdsBySubsystemAndType(
                            $this->getRequest()->headers->get('X-Sub-System'),
                            Status::OBJECT_TYPE_LOT
                        );
            }

            /** @var Lot[] $entities */
            $entities = $em->getRepository('AnalyticsBundle:Lot')->findBy($filters, $order_by, $limit, $offset);
            if ($entities) {
                $entities = PlanType::create($entities);

                $serializationContext = SerializationContext::create()
                    ->enableMaxDepthChecks();
                $request = $this->container->get('request_stack')->getCurrentRequest();
                if ($request->query->has('x_groups')) {
                    $groups = array_map('trim', explode(',', $request->query->get('x_groups')));
                    array_push($groups, static::ENTITY, lcfirst(static::ENTITY));
                    $serializationContext->setGroups($groups);
                } else if (!empty(static::$groupsGetList)) {
                    $serializationContext->setGroups(static::$groupsGetList);
                }

                return \FOS\RestBundle\View\View::create($entities)
                    ->setSerializationContext($serializationContext);

            }

            return FOSView::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return FOSView::create($e->getMessage(), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @param Request $request
     * @return array
     */
    public function cgetUserAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager('analytics');
        $lotRepo = $em->getRepository('AnalyticsBundle:Lot');

        $entities = $lotRepo->findBy(['procResp' => $request->headers->get('x-user-id')]);

        $items = [];
        foreach ($entities as $entity) {
            if (!$entity->getIsRevision()) {
                $items[$entity->getId()] = [
                    'id' => $entity->getId()
                ];
            }
        }

        return array_values($items);
    }


    /**
     * 
     * Получаем список лотов для ведомства + все лоты из подчиненных
     * 
     * @param Request $request
     * @return array
     */
    public function cgetCommonAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager('analytics');
        $lotRepo = $em->getRepository('AnalyticsBundle:Lot');
        $commonRepo = $em->getRepository('AnalyticsBundle:Common');
        $common = $commonRepo->findOneBy(['id' => $request->headers->get('x-common-id')]);

        $entities = $lotRepo->findBy(['common' => $this->getChildrenCommon($common)]);

        $items = [];
        foreach ($entities as $entity) {
            if (!$entity->getIsRevision()) {
                $items[$entity->getId()] = [
                    'id' => $entity->getId()
                ];
            }
        }

        return array_values($items);
    }

    /**
     *
     * Получаем список лотов групированных по
     *
     * @param Request $request
     * @return array
     */
    public function cgetFcpAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager('analytics');
        $lotRepo = $em->getRepository('AnalyticsBundle:Lot');
        $commonRepo = $em->getRepository('AnalyticsBundle:Common');
        $common = $commonRepo->findOneBy(['id' => $request->headers->get('x-common-id')]);

        $entities = $lotRepo->findBy(['common' => $this->getChildrenCommon($common)]);

        $items = [];
        foreach ($entities as $entity) {
            if (!$entity->getIsRevision()) {
                $items[$entity->getId()] = [
                    'id' => $entity->getId()
                ];
            }
        }

        return array_values($items);
    }

    /**
     * @param \AnalyticsBundle\Entity\Common $common
     *
     * @param $common
     * @return []
     */
    public function getChildrenCommon($common){
        $commons = [];
        $em = $this->getDoctrine()->getManager('analytics');
        $commonRepo = $em->getRepository('AnalyticsBundle:Common');
        $children = $commonRepo->findBy([
            'parent' => $common,
        ]);

        $commons[] = $common->getId();

        if (!empty($children)) {
            foreach ($children as $child) {
                $items = $this->getChildrenCommon($child);
                if (!empty($items)) {
                    $commons = array_merge($commons, $items);
                }
            }
        }

        return $commons;
    }


    /**
     * Удаление лота из плана
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Удаление лота из плана",
     *   section="Лоты"
     * )
     *
     * @View(
     *   statusCode=201,
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"lot_detail"}
     * )
     *
     * @param Request $request
     *
     * @return Response
     *
     */
    public function deletePlanAction(Request $request, $entityId)
    {
        $em = $this->container->get('doctrine')->getManager('analytics');

        $lotRepo = $em->getRepository('AnalyticsBundle:Lot');
        $lotEntity = $lotRepo->findOneBy(['id' => $entityId]);

        // отчищаем предыдущие значения финансирования для текущего лота
        // поддерживая целостность
        $finPlan = $lotEntity->getFinancingsPlan();
        foreach ($finPlan as $fp) {
            $em->remove($fp);
        }

        $plans = $lotEntity->getPlan();
        foreach ($plans as $plan) {
            if (!$plan->getIsRevision()) {
                $plan->removeLot($lotEntity);
                $em->persist($plan);
            }
        }

        $em->flush();

        return $lotEntity;
    }

    /**
     * Привязка лота к плану
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Привязка лота к плану",
     *   section="Лоты"
     * )
     *
     * @View(
     *   statusCode=201,
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"lot_detail", "plan_list"}
     * )
     *
     * @param Request $request
     *
     * @return Response
     *
     */
    public function postPlanAction(Request $request, $entityId)
    {

        $planType = $request->query->get('type');
        $em = $this->container->get('doctrine')->getManager('analytics');

        $planRepo = $em->getRepository('AnalyticsBundle:Plan');

        $lotRepo = $em->getRepository('AnalyticsBundle:Lot');
        $lotEntity = $lotRepo->findOneBy(['id' => $entityId]);
        $commonEntity = $lotEntity->getCommon();

        /** @var Financing[]|ArrayCollection $financing */
        $financing = $lotEntity->getFinancings();
        if (!empty($financing->count())) {

            if ($planType == "current") {
                $year = date("Y") * 1;
            } elseif ($planType == "next") {
                $year = date("Y") * 1 + 1;
            }

            // индекс перехода между годами плана
            $index = 0;

            // находим есть ли родительскиое ведомство
            $parentCommon = $commonEntity->getParent();

            foreach ($financing as $i) {

                // основная делта сдвига года по отношению к относительному значению из fin
                $delta = $i->getRelYear() - 1;

                // реальный год fin
                $deltaYear = $year + $delta;

                // ищем план
                $plan = $planRepo->findOneBy([
                    'isRevision' => null,
                    'year' => $deltaYear,
                    'common' => $commonEntity
                ]);

                // если план ненайден то создадим его
                // это пожалуй самый прекрасный вариант его создать
                if (empty($plan)) {
                    $plan = new Plan();
                    $plan->setYear($deltaYear);
                    $plan->setIsRevision(null);
                    $plan->setCommon($commonEntity);
                    $plan->setStatusId(Plan::STATUS_DRAFT);

                    // если есть родительский то прикрепим к нему
                    if (!empty($parentCommon)) {
                        $parentPlan = $planRepo->findBy([
                            'year' => $deltaYear,
                            'common' => $parentCommon,
                            'isRevision' => null
                        ]);

                        // если ненашли а он должен быть то создадим его
                        if (empty($parentPlan)) {
                            $parentPlan = new Plan();
                            $parentPlan->setYear($deltaYear);
                            $parentPlan->setIsRevision(null);
                            $parentPlan->setCommon($parentCommon);
                            $parentPlan->setStatusId(Plan::STATUS_DRAFT);
                            $em->persist($parentPlan);
                        }

                        $plan->setParent($parentPlan);
                    }

                }

                // добавляем лот в план
                $plan->addLot($lotEntity);

                $em->persist($plan);

                // отчищаем предыдущие значения финансирования для текущего лота
                // поддерживая целостность
                $finPlan = $lotEntity->getFinancingsPlan();
                foreach ($finPlan as $fp) {
                    $em->remove($fp);
                }

                // раставляем по планам финансирование в этих годах
                foreach ($financing as $j) {
                    $delta = $j->getRelYear() - 1 - $index;
                    $realYear = $plan->getYear() + $delta;
                    if ($realYear >= $plan->getYear()) {
                        $fin = new FinancingPlan();
                        $fin->setLot($lotEntity);
                        $fin->setYear($realYear);
                        $fin->setPlan($plan);
                        $em->persist($fin);
                    }
                }

                $i->setYear($deltaYear);
                $index++;
            }
        }

        $em->flush();

        return $lotEntity;
    }

    /**
     * @param Request $request
     * @return array
     */
    protected function _dataContent($request)
    {
        $data = parent::_dataContent($request);

        if (isset($data['number']) && !empty($data['number'])) {
            if ($this
                ->getDoctrine()
                ->getManager('analytics')
                ->getRepository('AnalyticsBundle:Lot')
                ->findOneBy(['number' => $data['number']])) {
                throw new BadRequestHttpException('Лот с номером "' . $data['number'] . '" уже есть.');
            }
        }

        if (isset($data['nmckVariant']) && is_array($data['nmckVariant']) && isset($data['nmckVariant']['nmckDoc']) && is_array($data['nmckVariant']['nmckDoc'])) {
            $data['nmckVariant']['nmckDoc'] = [$data['nmckVariant']['nmckDoc']];
        }

        if (isset($data['procurementCause']) && is_array($data['procurementCause'])) {
            if (count($data['procurementCause']) > 0) {
                $procurementCause = $data['procurementCause'];
                if (isset($procurementCause['cause']) && is_array($procurementCause['cause']) && count($procurementCause['cause']) > 0) {
                    $cause = $procurementCause['cause'];

                    unset($procurementCause['cause']);
                    $procurementCause = array_merge($procurementCause, $cause);
                }

                if (isset($procurementCause['chooseSubprogramFcp']) && is_array($procurementCause['chooseSubprogramFcp']) && count($procurementCause['chooseSubprogramFcp']) > 0) {
                    $cause = $procurementCause['chooseSubprogramFcp'];

                    if (isset($cause['rate']) && is_array($cause['rate'])) {
                        $cause['rateIndicator'] = $cause['rate'];
                        unset($cause['rate']);
                    }
                    if (isset($cause['indicator']) && is_array($cause['indicator'])) {
                        if (isset($cause['rateIndicator']) && is_array($cause['rateIndicator'])) {
                            $cause['rateIndicator'] = array_merge($cause['rateIndicator'], $cause['indicator']);
                        } else {
                            $cause['rateIndicator'] = $cause['indicator'];
                        }
                        unset($cause['indicator']);
                    }

                    unset($procurementCause['chooseSubprogramFcp']);
                    $procurementCause = array_merge($procurementCause, $cause);
                }
                if (isset($procurementCause['lotDoc']) && is_array($procurementCause['lotDoc']) && count($procurementCause['lotDoc']) > 0) {
                    if (isset($procurementCause['lotDoc']['title']) && is_array($procurementCause['lotDoc']['title'])) {
                        $procurementCause = array_merge($procurementCause, array(
                            'lotDoc' => array(
                                array(
                                    'file' => $procurementCause['lotDoc']['title'][0]['path'],
                                    'name' => $procurementCause['lotDoc']['title'][0]['filename'],
                                ),
                            ),
                        ));
                    }
                }

                unset($data['procurementCause']);

                $data = array_merge($data, $procurementCause);
            } else {
                unset($data['procurementCause']);
            }
        }

        // todo: все же понимают, что это хак?
        if (isset($data['stages']) && is_array($data['stages']) && !empty($data['stages'])) {
            foreach ($data['stages'] as $key => $stage) {
                if (isset($stage['workTypes']) && is_array($stage['workTypes']) && !empty($stage['workTypes'])) {
                    $data['stages'][$key]['workTypes'] = [];
                    foreach ($stage['workTypes'] as $wtType => $wtBlock) {
                        $wtType = str_replace('workTypes.', '', $wtType);
                        if (is_array($wtBlock) && !empty($wtBlock)) {
                            foreach ($wtBlock as $workType) {
                                $workType['type'] = $wtType;

                                $workType['startDate'] = date('Y-m-d');

                                if (isset($workType['executionDateTerm'])) {
                                    $executionDateTerm = $workType['executionDateTerm'];
                                    unset($workType['executionDateTerm']);
                                    if (is_array($executionDateTerm) && !empty($executionDateTerm)) {
                                        foreach ($executionDateTerm as $k => $v) {
                                            $workType[str_replace('workType.', '', $k)] = $v;
                                        }
                                    }
                                }

                                $data['stages'][$key]['workTypes'][] = $workType;
                            }
                        }
                    }
                }
            }
        }

        if (isset($data['procResp'])) {
            unset($data['procResp']);
        }
        if (isset($data['common'])) {
            unset($data['common']);
        }
        if (isset($data['fcp.title'])) {
            unset($data['fcp.title']);
        }

        return $data;
    }

    /**
     * @param Lot $entity
     */
    protected function eventPutLoadData($entity)
    {
//        $token = $this->container->get('security.token_storage')->getToken();
//        if (strtolower($entity->getProcResp()->getId()) != strtolower($token->getUser()->getId())) {
//            throw new AccessDeniedException('Пользователь пытается редактировать не свой лот');  // Пользователь пытается редактировать не свой лот
//        }

//        if (!in_array($entity->getStatusId(), [Lot::STATUS_DRAFT, Lot::STATUS_REWORK])) {
//            // Пользователь попытался отредактировать лот который нельзя редактировать
//            throw new BadRequestHttpException('Лот изменять нельзя, лот не находится в разработке');
//        }
    }

    /**
     * Update a entity.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Изменение лота",
     *   section="Лоты"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"lot_detail"}
     * )
     *
     *
     * @param Request $request
     * @param $entity
     *
     * @return Response
     *
     * @todo: Проблема с разграничением прав на редактирование лота такова что некоторые данные можно отредактировать
     * @todo: используя другие методы API а в них разграничения прав нет. В частности это касается:
     * @todo: work_type, stage, work_kind
     */
    public function putAction(Request $request, $entity)
    {
        return parent::putAction($request, $entity);
    }

    /**
     * Partial Update to a entity.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Изменение лота",
     *   section="Лоты"
     * )
     *
     * @PreAuthorize("token.getUser().hasPermission(['edit_lot'])")
     *
     * @View(serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"lot_detail"})
     *
     * @param Request $request
     * @param $entity
     *
     * @return Response
     */
    public function patchAction(Request $request, $entity)  // ApplicationDocumentsAvailability
    {
        return $this->putAction($request, $entity);
    }

    /**
     * Update a entity.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Добавление",
     *   section="Лоты"
     * )
     *
     * @View(
     *   statusCode=201,
     *   serializerEnableMaxDepthChecks=false,
     *   serializerGroups = {"lot_detail"}
     * )
     *
     * @PreAuthorize("token.getUser().hasPermission(['create_lot'])")
     * , 'create_all_lots' - это право нужно удалить
     *
     * @param Request $request
     * @param $entity
     *
     * @return Response
     */
    public function postAction(Request $request)
    {
        return parent::postAction($request);
    }

    /**
     * Get a entity
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение данных по лоту",
     *   section="Лоты"
     * )
     *
     * @PreAuthorize("token.getUser().hasPermission(['read_lot', 'documents_read_lot'])")
     *
     * @return Response
     *
     */
    public function getAction($entity)
    {
        return parent::getAction($entity);
    }

    /**
     * @param Lot $entity
     */
    protected function eventDeleteLoadData($entity)
    {
        $token = $this->container->get('security.token_storage')->getToken();
        if ($entity->getProcResp()->getId() != $token->getUser()->getId()) {
            //throw new AccessDeniedException();  // Пользователь пытается редактировать не свой лот
        }

        if (!in_array($entity->getStatusId(), Lot::$listStatusEdit)) {
            // Пользователь попытался отредактировать лот который нельзя редактировать
            throw new \Exception('Нельзя удалить лот, так как он не черновик', Codes::HTTP_CONFLICT);
            /*Response::create(json_encode(['errors' => 'Нельзя удалить лот, так как он не черновик']), Codes::HTTP_CONFLICT)
                ->send();
            die();*/
        }
    }

    /**
     * Delete a entity.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Удаление лота",
     *   section="Лоты"
     * )
     *
     * @View(statusCode=204)
     *
     * @-PreAuthorize("token.getUser().hasPermission(['edit_lot'])")
     *
     * @param Request $request
     * @param $entity
     * @internal param $id
     *
     * @return Response
     */
    public function deleteAction(Request $request, $entity)
    {
        return parent::deleteAction($request, $entity);
    }

    /**
     * Возвращает список лотов для WorkflowNameResolver.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка Lot для WorkflowNameResolver",
     *   section="Лоты"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     * )
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="ids", nullable=true, array=true, description="ids")
     */
    public function cgetWorkflowNameResolverAction(ParamFetcherInterface $paramFetcher)
    {
        try {
            $em = $this->getDoctrine()->getManager('analytics');

            $ids = $this->getRequest()->get('ids');

            $common_ids = $em->getRepository('AnalyticsBundle:Users')->getCommonIds($this->getUser()->getId());

            $entities = $em
                ->getRepository('AnalyticsBundle:Lot')
                ->findByWorkflowNameResolver(explode(',', $ids), $common_ids);
            if ($entities) {
                return \FOS\RestBundle\View\View::create($entities);
            }

            return FOSView::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return FOSView::create($e->getMessage(), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Получение ID шаблона freshdoc для лота, определённого типа (Извещение, КД, Задание).
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение ID шаблона freshdoc для лота, определённого типа (Извещение, КД, Задание)",
     *   section="Лоты"
     * )
     *
     * @return Response
     */
    public function getTemplateAction($lotId, $type = 'notice')
    {
        if (!in_array($type, ['notice', 'kd', 'order'])) {
            return \FOS\RestBundle\View\View::create(['error' => 'Тип указан не правильно'], Codes::HTTP_BAD_REQUEST);
        }
        $lot = $this
            ->getDoctrine()
            ->getManager('analytics')
            ->getRepository('AnalyticsBundle:Lot')
            ->find($lotId);

        if (!($lot instanceof Lot)) {
            return \FOS\RestBundle\View\View::create(['error' => 'Лот не найден'], Codes::HTTP_BAD_REQUEST);
        }

        $templates = $this
            ->getDoctrine()
            ->getManager()
            ->getRepository('FreshdocBundle:FreshdocTemplate')
            ->findAll();

        $id = null;
        foreach ($templates as $template) {
            if (substr($template->getMachineName(), 0, strlen($type)) == $type) {
                if (
                    (empty($template->getExpenseTypeId()) || $template->getExpenseTypeId() == $lot->getExpenseType()->getId()) &&
                    ($template->getRequirement3044() == $lot->getRequirement3044()) &&
                    (empty($template->getProcurementTypeId()) || $template->getProcurementTypeId() == $lot->getProcurementType()->getId()) &&
                    (empty($template->getFcpId()) || $template->getFcpId() == $lot->getFcpAction()->getFcp()->getId())
                ) {
                    $id = $template->getTemplate();
                    break;
                }
                if (empty($template->getExpenseTypeId()) && empty($template->getProcurementTypeId() && empty($template->getFcpId()))) {
                    $id = $template->getTemplate();
                }
            }
        }

        if ($id == null) {
            return \FOS\RestBundle\View\View::create(['error' => 'Шаблон не найден'], Codes::HTTP_NOT_FOUND);
        }

        return \FOS\RestBundle\View\View::create(['id' => $id]);
    }
}
