<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * InfoSource controller.
 * @RouteResource("InfoSource")
 */
class InfoSourceRESTController extends DirectoryRESTController
{
    const ENTITY = 'InfoSource';
    static public $selectFieldTitle = 'description';
}
