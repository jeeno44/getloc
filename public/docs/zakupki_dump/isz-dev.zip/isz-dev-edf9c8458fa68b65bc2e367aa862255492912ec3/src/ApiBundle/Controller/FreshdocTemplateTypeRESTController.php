<?php
namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use FOS\RestBundle\Controller\Annotations\View;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Util\Codes;
use FOS\RestBundle\View\View as FOSView;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;


/**
 * FreshdocTemplateType REST API controller.
 * @RouteResource("FreshdocTemplateType")
 */
class FreshdocTemplateTypeRESTController extends Controller
{
    /**
     * Get all FreshdocTemplateType entities.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка FreshdocTemplateType"
     * )
     *
     * @View(serializerEnableMaxDepthChecks=true)
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     */
    public function cgetAction(ParamFetcherInterface $paramFetcher)
    {
        try {
            $em = $this->getDoctrine()->getManager();
            $entities = $em->getRepository('FreshdocBundle:FreshdocTemplateType')->findAll();

            if ($entities) {
                $result = [];
                foreach ($entities as $entity) {
                    $entityData = [];
                    $entityData['title'] = $entity->getTitle();
                    $templates = [];
                    foreach ($entity->getTemplates() as $template) {
                        $templates[] = [
                            'documentType' => $template->getDocumentType(),
                            'machineName'  => $template->getMachineName(),
                            'template'     => $template->getTemplate(),
                        ];
                    }
                    $entityData['templates']  = $templates;
                    $result[] = $entityData;
                }

                return $result;
            }

            return FOSView::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return FOSView::create($e->getMessage(), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
