<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * SubProgramAction controller.
 * @RouteResource("SubProgramAction")
 */
class SubProgramActionRESTController extends DirectoryRESTController
{
    const ENTITY = 'SubProgramAction';
}
