<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Okei controller.
 * @RouteResource("Okei")
 */
class OkeiRESTController extends DirectoryRESTController
{
    const ENTITY = 'Okei';

    /**
     * @var string
     */
    static public $selectFieldTitle = ['code', 'description'];
}
