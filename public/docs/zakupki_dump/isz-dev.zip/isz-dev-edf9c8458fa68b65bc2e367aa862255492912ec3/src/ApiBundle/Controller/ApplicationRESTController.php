<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Application controller.
 * @RouteResource("Application")
 */
class ApplicationRESTController extends DirectoryRESTController
{
    const ENTITY = 'Application';
}
