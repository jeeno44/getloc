<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\RequestParam;
use FOS\RestBundle\Controller\Annotations\View;
use FOS\RestBundle\Request\ParamFetcherInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;

interface DirectoryController
{
    /**
     * Get all entities.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка ajax select"
     * )
     *
     * @View(serializerEnableMaxDepthChecks=true)
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="offset", requirements="\d+", default="0", description="Offset from which to start listing notes.")
     * -QueryParam(name="limit", requirements="\d+", default="20", description="How many notes to return.")
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     */
    public function cgetSelectAction(ParamFetcherInterface $paramFetcher);

    /**
     * Get a entity
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение данных"
     * )
     *
     * @View(serializerEnableMaxDepthChecks=true)
     *
     * -RequestParam(name="x_groups", array=true, nullable=true, description="Выдача полей определённой группы")
     *
     * @return Response
     *
     */
    public function getAction($entity);

    /**
     * Get all entities.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка"
     * )
     *
     * @View(serializerEnableMaxDepthChecks=true)
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="offset", requirements="\d+", default="0", description="Offset from which to start listing notes.")
     * -QueryParam(name="limit", requirements="\d+", default="20", description="How many notes to return.")
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     * -RequestParam(name="x_groups", array=true, nullable=true, description="Выдача полей определённой группы")
     */
    public function cgetAction(ParamFetcherInterface $paramFetcher);
}