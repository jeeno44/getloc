<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * UsersExpertGroup controller.
 * @RouteResource("UsersExpertGroup")
 */
class UsersExpertGroupRESTController extends DirectoryRESTController
{
    const ENTITY = 'UsersExpertGroup';
  static public $groupsGetEntity = ['users_expert_group_detail'];
  static public $groupsGetList   = ['users_expert_group_list'];
}
