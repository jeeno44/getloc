<?php
namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * KbkKosgu controller.
 * @RouteResource("KbkKosgu")
 */
class KbkKosguRESTController extends DirectoryRESTController
{
    const ENTITY = 'KbkKosgu';

    /**
     * @var string
     */
    static public $selectFieldTitle = ['code', 'title'];

    static public $groupsGetEntity = ["kbkkosgu_detail"];
    static public $groupsGetList   = ["kbkkosgu_list"];
}
