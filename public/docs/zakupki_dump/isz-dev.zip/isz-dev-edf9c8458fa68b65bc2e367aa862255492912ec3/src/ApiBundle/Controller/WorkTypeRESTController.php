<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * WorkType controller.
 * @RouteResource("WorkType")
 */
class WorkTypeRESTController extends ApiRESTController
{
    const ENTITY = 'WorkType';
    static public $groupsGetEntity = ['work_type_detail'];
    static public $groupsGetList   = ['work_type'];
}
