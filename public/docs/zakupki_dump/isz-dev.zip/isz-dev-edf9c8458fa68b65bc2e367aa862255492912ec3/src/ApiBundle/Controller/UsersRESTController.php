<?php

namespace ApiBundle\Controller;

use AnalyticsBundle\Entity\Users;
use AnalyticsBundle\Entity\UsersExpertGroup;
use AnalyticsBundle\Services\SystemService;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use Nelmio\ApiDocBundle\Annotation\ApiDoc,
    JMS\Serializer\SerializationContext;
use Symfony\Component\HttpFoundation\Response;
use FOS\RestBundle\Controller\Annotations\View;
use Symfony\Component\HttpFoundation\Request,
    FOS\RestBundle\Util\Codes;
use JMS\SecurityExtraBundle\Annotation\PreAuthorize;
use Swagger\Annotations as SWG;

/**
 * Users controller.
 * @RouteResource("Users")
 *
 * @SWG\Path(path="/users.{format}")
 * @SWG\Path(path="/users/{guid}.{format}")
 */
class UsersRESTController extends ApiRESTController
{
    const ENTITY                     = 'Users';
    static public $groupsGetEntity = ['users_detail'];
    static public $groupsGetList   = ['users_list'];
    static public $selectFieldTitle = 'name';

    public function postPasswordAction(Request $request)
    {
        $userId         = $request->request->get('id');
        $newPassword    = $request->request->get('newPassword');
        $oldPassword    = $request->request->get('oldPassword');
        $repeatPassword = $request->request->get('confirmPassword');

        if(!$userId){
            return \FOS\RestBundle\View\View::create('User id required', Codes::HTTP_BAD_REQUEST);
        }

        if($newPassword != $repeatPassword){
            return \FOS\RestBundle\View\View::create('Passwords do not match', Codes::HTTP_BAD_REQUEST);
        }

        // проверка пароля
        $messageId = 'auth' . microtime();
        $client = $this->get('old_sound_rabbit_mq.auth_rpc');
        $client->addRequest(json_encode([
            'id'       => $userId,
            'password' => $oldPassword,
        ]), 'isz', $messageId, "auth.password.verify", 5);
        $replies  = $client->getReplies();
        $passVerifyResponse = $replies[$messageId];

        if(!$passVerifyResponse){
            return \FOS\RestBundle\View\View::create('Password has not changed', Codes::HTTP_INTERNAL_SERVER_ERROR);
        }

        if($passVerifyResponse->status == "failed"){
            return \FOS\RestBundle\View\View::create('Not valid password', Codes::HTTP_BAD_REQUEST);
        }

        // установка нового пароля
        $messageId = 'auth' . microtime();
        $client = $this->get('old_sound_rabbit_mq.auth_rpc');
        $client->addRequest(json_encode([
            'id'       => $userId,
            'password' => $newPassword,
        ]), 'isz', $messageId, "auth.password.change", 5);
        $replies  = $client->getReplies();
        $passChangeResponse = $replies[$messageId];

        if(!$passVerifyResponse){
            return \FOS\RestBundle\View\View::create('Password has not changed', Codes::HTTP_INTERNAL_SERVER_ERROR);
        }

        if($passChangeResponse->status == "failed"){
            return \FOS\RestBundle\View\View::create('Password has not changed', Codes::HTTP_INTERNAL_SERVER_ERROR);
        }

        return ["status" => "success"];
    }

    /**
     * Get a entity
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение данных",
     *   section="Пользователи"
     * )
     *
     * @PreAuthorize("token.getUser().hasPermission('read_profile')")
     *
     * @return Response
     *
     * @SWG\Get(
     *     path="/users.{format}",
     *     tags={"Пользователи"},
     *     summary="Получение списка пользователей",
     *     @SWG\Parameter(name="format", in="path", type="string", required=true, description="Формат получения данных"),
     *     @SWG\Parameter(name="offset", in="query", type="integer", required=false, description="Отступ"),
     *     @SWG\Parameter(name="limit", in="query", type="integer", required=false, description="Количество возвращаемых записей"),
     *     @SWG\Parameter(
     *       name="order_by",
     *       in="query",
     *       required=false,
     *       collectionFormat="multi",
     *       type="array",
     *       @SWG\Items(type="string"),
     *       description="Сортировка по полю. Должен быть массивом, т.е. &order_by[name]=ASC&order_by[description]=DESC"
     *     ),
     *     @SWG\Parameter(
     *       name="filters",
     *       in="query",
     *       required=false,
     *       collectionFormat="multi",
     *       type="array",
     *       @SWG\Items(type="string"),
     *       description="Фильтрация по полю. Должен быть массивом, т.е. &filters[id]=3"
     *     ),
     *     @SWG\Response(
     *       response=200,
     *       description="Все ок",
     *       @SWG\Schema(
     *         type="array",
     *         @SWG\Items(ref="#/definitions/UsersList")
     *       ),
     *     )
     * )
     * @SWG\Get(
     *     path="/users/{guid}.{format}",
     *     tags={"Пользователи", "[GET] REST"},
     *     summary="Получение пользователя по ID",
     *     @SWG\Parameter(name="format", in="path", type="string", required=true, description="Формат получения данных"),
     *     @SWG\Parameter(name="guid", in="path", type="string", required=true, description="ID пользователя"),
     *     @SWG\Response(
     *         response=200,
     *         description="successful operation",
     *         @SWG\Schema(ref="#/definitions/User")
     *     )
     * )
     *
     */
    public function getAction($entity)  // ApplicationDocumentsAvailability
    {

        /** @var Users $user */
        $user = is_object($entity)
            ? $entity
            : $this
                ->getDoctrine()
                ->getManager('analytics')
                ->getRepository('AnalyticsBundle:'.static::ENTITY)
                ->find($entity);

        $serializationContext = SerializationContext::create()
            ->enableMaxDepthChecks();
        if (!empty(static::$groupsGetEntity)) {
            $serializationContext->setGroups(static::$groupsGetEntity);
        }

        return
            \FOS\RestBundle\View\View::create($user)
                ->setSerializationContext($serializationContext);
    }

    /**
     * Update a entity.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Изменение",
     *   section="Пользователи"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups={"users_detail"}
     * )
     *
     * @PreAuthorize("token.getUser().hasPermission('edit_profile')")
     *
     * @param Request $request
     * @param $entity
     *
     * @return Response
     */
    public function putAction(Request $request, $entity)
    {
        if ($entity != $this->container->get('security.token_storage')->getToken()->getUser()->getId()) {
            return \FOS\RestBundle\View\View::create('Forbidden', Codes::HTTP_FORBIDDEN);
        }

        return parent::putAction($request, $entity);
    }

    /**
     * Create a entity.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Добавление",
     *   section="Пользователи"
     * )
     *
     * @PreAuthorize("token.getUser().hasPermission('create_profile')")
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups={"users_detail"}
     * )
     *
     * @param Request $request
     *
     * @return Response
     *
     * @SWG\Post(
     *     path="/users.{format}",
     *     tags={"Пользователи"},
     *     summary="Сохранение списка пользователей",
     *     @SWG\Parameter(name="format", in="path", type="string", required=true, description="Формат получения данных"),
     *     @SWG\Parameter(name="offset", in="query", type="integer", required=false, description="Отступ"),
     *     @SWG\Parameter(name="limit", in="query", type="integer", required=false, description="Количество возвращаемых записей"),
     *     @SWG\Parameter(
     *       name="order_by",
     *       in="query",
     *       required=false,
     *       collectionFormat="multi",
     *       type="array",
     *       @SWG\Items(type="string"),
     *       description="Сортировка по полю. Должен быть массивом, т.е. &order_by[name]=ASC&order_by[description]=DESC"
     *     ),
     *     @SWG\Parameter(
     *       name="filters",
     *       in="query",
     *       required=false,
     *       collectionFormat="multi",
     *       type="array",
     *       @SWG\Items(type="string"),
     *       description="Фильтрация по полю. Должен быть массивом, т.е. &filters[id]=3"
     *     ),
     *     @SWG\Response(response="200", description="An example resource"),
     *     @SWG\Response(response="500", description="An example resource")
     * )
     *
     */
    public function postAction(Request $request)
    {
        return \FOS\RestBundle\View\View::create('Forbidden', Codes::HTTP_FORBIDDEN);
    }
}
