<?php

namespace ApiBundle\Controller;

use AnalyticsBundle\Model\AnalyticsRepository;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Mapping\ClassMetadataInfo;
use Doctrine\Common\Collections\Collection;
use FOS\RestBundle\Controller\Annotations\RequestParam;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\View;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Util\Codes;
use FOS\RestBundle\View\View as FOSView;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use JMS\Serializer\SerializationContext;

/**
 * Class DirectoryRESTController
 * @package ApiBundle\Controller
 */
class DirectoryRESTController extends Controller implements DirectoryController
{
    /**
     *
     */
    const ENTITY = '[entity]';

    /**
     * @var array
     */
    static public $groupsGetEntity = [];  //['detail']

    /**
     * @var array
     */
    static public $groupsGetList   = [];  //['list']

    /**
     * @var string
     */
    static public $selectFieldTitle;

    /**
     * @var string
     */
    static public $selectFieldCode;

    /**
     * Получение списка ajax select.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка ajax select"
     * )
     *
     * @View(serializerEnableMaxDepthChecks=true)
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="offset", requirements="\d+", default="0", description="Offset from which to start listing notes.")
     * -QueryParam(name="limit", requirements="\d+", default="20", description="How many notes to return.")
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     */
    public function cgetSelectAction(ParamFetcherInterface $paramFetcher)
    {
        try {
            $offset  = $this->getRequest()->get('offset', 0);
            $limit   = $this->getRequest()->get('limit', 20);

            $orderBy = [];
            foreach ((array) static::$selectFieldTitle as $key => $value) {
                if (is_array($value)) {
                    $orderBy[$key] = $value;
                } else {
                    $orderBy[$value] = 'ASC';
                }
            }
            $orderBy = $this->getRequest()->get('order_by', $orderBy);

            $filters  = !is_null($this->getRequest()->get('filters')) ? $this->getRequest()->get('filters') : array();

            $em = $this->getDoctrine()->getManager('analytics');

            if (isset($filters['title'])) {
                $expr = new \Doctrine\ORM\Query\Expr();

                if (is_array(static::$selectFieldTitle)) {
                    $sql = '';
                    foreach ((array) static::$selectFieldTitle as $field) {
                        $sql.= ' or (t.' . $field . ' like \'%' . $filters['title'] . '%\')';
                    }

                    $filters['like'] = // @todo: убиться об стену
                        (object) [
                            'expr' => substr($sql, 4),
                        ];
                } else {
                    $filters[static::$selectFieldTitle] = // @todo: убиться об стену
                        (object)[
                            'expr' => $expr->like('t.' . static::$selectFieldTitle, ':t_' . static::$selectFieldTitle),
                            'parameters' => [
                                't_' . static::$selectFieldTitle => '%' . $filters['title'] . '%',
                            ],
                        ];
                }
                if (static::$selectFieldTitle != 'title') {
                    unset($filters['title']);
                }
            }

            if (isset($filters['code'])) {
                $expr = new \Doctrine\ORM\Query\Expr();
                $filters[static::$selectFieldCode] = // @todo: убиться об стену
                    (object) [
                        'expr' => $expr->like('t.'.static::$selectFieldCode, ':t_'.static::$selectFieldCode),
                        'parameters' => [
                            't_'.static::$selectFieldCode => $filters['code'].'%',
                        ],
                    ];
                if (static::$selectFieldCode != 'code') {
                    unset($filters['code']);
                }
            }

            /** @var AnalyticsRepository $repository */
            $repository = $em->getRepository('AnalyticsBundle:'.static::ENTITY);
            $entities   = $repository->findBySelect($filters, $orderBy, $limit, $offset);

            if ($entities) {
                return $entities;
            }

            return FOSView::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return FOSView::create($e->getMessage(), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get a entity
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение данных"
     * )
     *
     * @1View(serializerEnableMaxDepthChecks=true)
     *
     * -RequestParam(name="x_groups", array=true, nullable=true, description="Выдача полей определённой группы")
     *
     * @return Response
     *
     */
    public function getAction($entity)
    {
        $data = is_object($entity)
            ? $entity
            : $this
                ->getDoctrine()
                ->getManager('analytics')
                ->getRepository('AnalyticsBundle:'.static::ENTITY)
                ->find($entity);

        $serializationContext = SerializationContext::create()
            ->enableMaxDepthChecks();
        if ($this->has('fos_rest.version_listener')) {
            $serializationContext->setVersion($this->get('fos_rest.version_listener')->getVersion());
        }

        $request = $this->container->get('request_stack')->getCurrentRequest();
        if ($request->query->has('x_groups')) {
            $groups = array_map('trim', explode(',', $request->query->get('x_groups')));
            array_push($groups, static::ENTITY, lcfirst(static::ENTITY));
            $serializationContext->setGroups($groups);
        } elseif (!empty(static::$groupsGetEntity)) {
            $serializationContext->setGroups(static::$groupsGetEntity);
        }

        return
            \FOS\RestBundle\View\View::create($data)
                ->setSerializationContext($serializationContext);
    }

    /**
     * Get all entities.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка"
     * )
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="offset", requirements="\d+", default="0", description="Offset from which to start listing notes.")
     * -QueryParam(name="limit", requirements="\d+", default="20", description="How many notes to return.")
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     * -RequestParam(name="x_groups", array=true, nullable=true, description="Выдача полей определённой группы")
     */
    public function cgetAction(ParamFetcherInterface $paramFetcher)
    {

        try {
            $offset = $this->getRequest()->get('offset', 0);
            $limit = $this->getRequest()->get('limit', 20);
            $orderBy = $this->getRequest()->get('order_by');
            $filters = !is_null($this->getRequest()->get('filters')) ? $this->getRequest()->get('filters') : array();

            $em = $this->getDoctrine()->getManager('analytics');
            /** @var AnalyticsRepository $repository */
            $repository = $em->getRepository('AnalyticsBundle:'.static::ENTITY);
            $entities = $repository->findBy($filters, $orderBy, $limit, $offset);

            if ($entities) {
                $serializationContext = SerializationContext::create()
                    ->enableMaxDepthChecks();
                $request = $this->container->get('request_stack')->getCurrentRequest();

                if ($request->query->has('x_groups')) {
                    $groups = array_map('trim', explode(',', $request->query->get('x_groups')));
                    array_push($groups, static::ENTITY, lcfirst(static::ENTITY));
                    $serializationContext->setGroups($groups);
                } elseif (!empty(static::$groupsGetList)) {
                    $serializationContext->setGroups(static::$groupsGetList);
                }

                return
                    \FOS\RestBundle\View\View::create($entities)
                        ->setSerializationContext($serializationContext);
            }

            return \FOS\RestBundle\View\View::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return \FOS\RestBundle\View\View::create($e, Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
