<?php
namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * KbkExpenseType controller.
 * @RouteResource("KbkExpenseType")
 */
class KbkExpenseTypeRESTController extends DirectoryRESTController
{
    const ENTITY = 'KbkExpenseType';

    /**
     * @var string
     */
    static public $selectFieldTitle = ['code', 'title'];

    static public $groupsGetEntity = ["kbkexpensetype_detail"];
    static public $groupsGetList   = ["kbkexpensetype_list"];
}
