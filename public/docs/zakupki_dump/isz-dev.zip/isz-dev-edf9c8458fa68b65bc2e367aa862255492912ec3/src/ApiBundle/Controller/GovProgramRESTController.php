<?php

namespace ApiBundle\Controller;

use AnalyticsBundle\Entity\FcpAction;
use AnalyticsBundle\Entity\SubProgramAction;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use FOS\RestBundle\Controller\Annotations\View;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Util\Codes;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use Symfony\Component\HttpFoundation\Response;
use FOS\RestBundle\View\View as FOSView;

/**
 * GovProgram controller.
 * @RouteResource("GovProgram")
 */
class GovProgramRESTController extends DirectoryRESTController
{
    const ENTITY = 'GovProgram';

    static public $selectFieldTitle = ['number', 'title'];

    /**
     * Получение списка оснований
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка оснований",
     *   section="Госпрограммы"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true
     * )
     *
     * @return Response
     */
    public function cgetListAction()
    {
        try {
            $em = $this->getDoctrine()->getManager('analytics');

            $result = [];

            $subProgramAction = $em->getRepository('AnalyticsBundle:SubProgramAction')->findAll();
            $fcp = $em->getRepository('AnalyticsBundle:Fcp')->findAll();
            $fcpAction = $em->getRepository('AnalyticsBundle:FcpAction')->findAll();
            foreach ($em->getRepository('AnalyticsBundle:GovProgram')->findAll() as $govProgram) {
                $result[$govProgram->getId()] = [
                    'id' => $govProgram->getId(),
                    'title' => $govProgram->getTitle(),
                    'type' => 'govprogram',
                    'subprograms' => [],
                    'fcps' => [],
                ];

                foreach ($subProgramAction as $subprogram) {
                    if (
                        $subprogram->getGovProgram() &&
                        $subprogram->getGovProgram()->getId() == $govProgram->getId() &&
                        $subprogram->getType() == SubProgramAction::TYPE_SUBPROGRAM
                    ) {
                        $result[$govProgram->getId()]['subprograms'][$subprogram->getId()] = [
                            'id' => $subprogram->getId(),
                            'title' => $subprogram->getTitle(),
                            'type' => $subprogram->getType(),
                            'items' => [],
                        ];
                        foreach ($subProgramAction as $mainaction) {
                            if (
                                $mainaction->getParent() &&
                                $mainaction->getParent()->getId() == $subprogram->getId() &&
                                $mainaction->getType() == SubProgramAction::TYPE_MAINACTION
                            ) {
                                $result[$govProgram->getId()]['subprograms'][$subprogram->getId()]['items'][$mainaction->getId()] = [
                                    'id' => $mainaction->getId(),
                                    'title' => $mainaction->getTitle(),
                                    'type' => $mainaction->getType(),
                                    'items' => [],
                                ];
                                foreach ($subProgramAction as $action) {
                                    if (
                                        $action->getParent() &&
                                        $action->getParent()->getId() == $mainaction->getId() &&
                                        $action->getType() == SubProgramAction::TYPE_ACTION
                                    ) {
                                        $result[$govProgram->getId()]['subprograms'][$subprogram->getId()]['items'][$mainaction->getId()]['items'][$action->getId()] = [
                                            'id' => $action->getId(),
                                            'title' => $action->getTitle(),
                                            'type' => $action->getType(),
                                        ];
                                    }
                                }

                                if (empty($result[$govProgram->getId()]['subprograms'][$subprogram->getId()]['items'][$mainaction->getId()]['items'])) {
                                    unset($result[$govProgram->getId()]['subprograms'][$subprogram->getId()]['items'][$mainaction->getId()]['items']);
                                } else {
                                    $result[$govProgram->getId()]['subprograms'][$subprogram->getId()]['items'][$mainaction->getId()]['items'] = array_values($result[$govProgram->getId()]['subprograms'][$subprogram->getId()]['items'][$mainaction->getId()]['items']);
                                }
                            }
                        }

                        $result[$govProgram->getId()]['subprograms'][$subprogram->getId()]['items'] = array_values($result[$govProgram->getId()]['subprograms'][$subprogram->getId()]['items']);
                    }
                }

                $result[$govProgram->getId()]['subprograms'] = array_values($result[$govProgram->getId()]['subprograms']);

                foreach ($fcp as $item) {
                    $result[$govProgram->getId()]['fcps'][$item->getId()] = [
                        'id' => $item->getId(),
                        'title' => $item->getTitle(),
                        'type' => 'fcp',
                        'items' => [],
                    ];

                    foreach ($fcpAction as $task) {
                        if (
                            $task->getFcp() &&
                            $task->getFcp()->getId() == $item->getId() &&
                            $task->getType() == FcpAction::TYPE_TASK
                        ) {
                            $result[$govProgram->getId()]['fcps'][$item->getId()]['items'][$task->getId()] = [
                                'id' => $task->getId(),
                                'title' => $task->getTitle(),
                                'type' => $task->getType(),
                                'items' => [],
                            ];

                            foreach ($fcpAction as $action) {
                                if (
                                    $action->getParent() &&
                                    $action->getParent()->getId() == $task->getId() &&
                                    $action->getType() == FcpAction::TYPE_ACTION
                                ) {
                                    $result[$govProgram->getId()]['fcps'][$item->getId()]['items'][$task->getId()]['items'][$action->getId()] = [
                                        'id' => $action->getId(),
                                        'title' => $action->getTitle(),
                                        'type' => $action->getType(),
                                        'items' => [],
                                    ];


                                    foreach ($fcpAction as $subaction) {
                                        if (
                                            $subaction->getParent() &&
                                            $subaction->getParent()->getId() == $action->getId() &&
                                            $subaction->getType() == FcpAction::TYPE_SUBACTION
                                        ) {
                                            $result[$govProgram->getId()]['fcps'][$item->getId()]['items'][$task->getId()]['items'][$action->getId()]['items'][$subaction->getId()] = [
                                                'id' => $subaction->getId(),
                                                'title' => $subaction->getTitle(),
                                                'type' => $subaction->getType(),
                                            ];
                                        }
                                    }

                                    if (count($result[$govProgram->getId()]['fcps'][$item->getId()]['items'][$task->getId()]['items'][$action->getId()]['items']) > 0) {
                                        $result[$govProgram->getId()]['fcps'][$item->getId()]['items'][$task->getId()]['items'][$action->getId()]['items'] = array_values($result[$govProgram->getId()]['fcps'][$item->getId()]['items'][$task->getId()]['items'][$action->getId()]['items']);
                                    } else {
                                        unset($result[$govProgram->getId()]['fcps'][$item->getId()]['items'][$task->getId()]['items'][$action->getId()]['items']);
                                    }
                                }
                            }

                            if (count($result[$govProgram->getId()]['fcps'][$item->getId()]['items'][$task->getId()]['items']) > 0) {
                                $result[$govProgram->getId()]['fcps'][$item->getId()]['items'][$task->getId()]['items'] = array_values($result[$govProgram->getId()]['fcps'][$item->getId()]['items'][$task->getId()]['items']);
                            } else {
                                unset($result[$govProgram->getId()]['fcps'][$item->getId()]['items'][$task->getId()]['items']);
                            }
                        }
                    }

                    if (count($result[$govProgram->getId()]['fcps'][$item->getId()]['items']) > 0) {
                        $result[$govProgram->getId()]['fcps'][$item->getId()]['items'] = array_values($result[$govProgram->getId()]['fcps'][$item->getId()]['items']);
                    } else {
                        unset($result[$govProgram->getId()]['fcps'][$item->getId()]['items']);
                    }
                }
                $result[$govProgram->getId()]['fcps'] = array_values($result[$govProgram->getId()]['fcps']);
            }

            return array_values($result);

            //return FOSView::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return FOSView::create($e->getMessage(), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
