<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * PassportData controller.
 * @RouteResource("PassportData")
 */
class PassportDataRESTController extends DirectoryRESTController
{
    const ENTITY = 'PassportData';
}
