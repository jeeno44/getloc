<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Protocol2Criteria controller.
 * @RouteResource("Protocol2Criteria")
 */
class Protocol2CriteriaRESTController extends DirectoryRESTController
{
    const ENTITY = 'Protocol2Criteria';
}
