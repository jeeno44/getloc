<?php

namespace ApiBundle\Controller;

use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Mapping\ClassMetadataInfo;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use FOS\RestBundle\View\View as FOSView;
use JMS\Serializer\SerializationContext;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Swagger\Annotations as SWG;
use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Correspondance controller.
 * @RouteResource("DocumentsFreshDoc")
 */
class DocumentsFreshDocRESTController extends ApiRESTController
{
    const ENTITY = 'DocumentsFreshDoc';

    static public $groupsGetEntity = ['DocumentsFreshDoc_detail'];
    static public $groupsGetList   = ['DocumentsFreshDoc_list'];

    /**
     * Get a entity
     *
     * @param  $entity
     * @return FOSView
     */
    public function getAction($entity)
    {
        $entity = $this->getDoctrine()->getManager('analytics')->getRepository('AnalyticsBundle:DocumentsFreshDoc')->find($entity);
        $serializationContext = SerializationContext::create()
            ->enableMaxDepthChecks();
        if ($this->has('fos_rest.version_listener')) {
            $serializationContext->setVersion($this->get('fos_rest.version_listener')->getVersion());
        }

        if (!empty(static::$groupsGetEntity)) {
            $serializationContext->setGroups(static::$groupsGetEntity);
        }

        return [
            'entityId' => $entity->getEntityId()->getId(),
            'id' => $entity->getId(),
            'status' => $entity->getStatus(),
            'created' => $entity->getCreated(),
            'docNumber' => $entity->getDocNumber(),
            'docType' => $entity->getDocType(),
            'type' => $entity->getType(),
            'uri' => $entity->getUri(),
        ];
    }
}


