<?php
/**
 * Created by PhpStorm.
 * User: iGusev
 * Date: 26/10/15
 * Time: 15:07
 */

namespace ApiBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\JsonResponse;

class KladrController extends Controller
{
    protected $types = [
        'region' => [
            'parent' => null,
            'repository' => 'KladrBundle:Kladr',
            'substr' => null,
            'conditions' => [
                'o.name LIKE :name',
                "o.code LIKE '%00'",
                "o.socr in ('Респ','- Чувашия','край','обл','Аобл','АО')",
            ],
        ],
        'city' => [
            'parent' => 'region',
            'repository' => 'KladrBundle:Kladr',
            'substr' => 2,
            'conditions' => [
                'o.name LIKE :name',
                "o.code LIKE :code",
                "o.code LIKE '%00'",
                "o.socr not in ('Респ','- Чувашия','край','обл','Аобл','АО','р-н')",
            ],
        ],
        'street' => [
            'parent' => 'city',
            'repository' => 'KladrBundle:Street',
            'substr' => -2,
            'conditions' => [
                'o.name LIKE :name',
                "o.code LIKE :code",
                "o.code LIKE '%00'",
                "o.socr not in ('Респ','- Чувашия','край','обл','Аобл','АО','р-н')",
            ],
        ],
        'building' => [
            'parent' => 'street',
            'repository' => 'KladrBundle:Doma',
            'substr' => null,
            'conditions' => [
                'o.name LIKE :name',
                "o.code LIKE :code",
            ],
        ],
    ];

    public function indexAction()
    {
        $result = [];
        $em = $this->getDoctrine()->getManager('analytics');
        $query = $this->getRequest()->get('query');
        $type = $this->getRequest()->get('type');
        if (array_key_exists($type, $this->types)) {
            $typeConfig = $this->types[$type];

            /* @var \Doctrine\DBAL\Query\QueryBuilder $entities */
            $entities = $em->getRepository($typeConfig['repository'])->createQueryBuilder('o')
                ->where($typeConfig['conditions'][0]);

            for ($i = 1; $i < count($typeConfig['conditions']); $i++) {
                $entities = $entities->andWhere($typeConfig['conditions'][$i]);
            }

            $entities = $entities->setParameter('name', "%{$query}%");

            if (!is_null($typeConfig['parent'])) {
                if(!is_null($typeConfig['substr'])) {
                    $code = substr($this->getRequest()->get('parentId'), 0, $typeConfig['substr'])."%";
                } else {
                    $code = substr($this->getRequest()->get('parentId'), 0)."%";
                }
                $entities = $entities->setParameter('code', $code);
            }

            $entities = $entities->getQuery()->getResult();

            foreach ($entities as $entity) {
                $result[$entity->getCode()] = sprintf("%s. %s", $entity->getSocr(), $entity->getName());
            }
        }

        return new JsonResponse($result);
    }

}
