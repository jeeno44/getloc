<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Okopf controller.
 * @RouteResource("Okopf")
 */
class OkopfRESTController extends DirectoryRESTController
{
    const ENTITY = 'Okopf';
    static public $selectFieldTitle = 'description';
}
