<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Correspondance controller.
 * @RouteResource("Gz")
 */
class GzRESTController extends DirectoryRESTController
{
    const ENTITY = 'Gz';

    static public $groupsGetEntity = ['gz_detail'];
    static public $groupsGetList   = ['gz_list'];
}
