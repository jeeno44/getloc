<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Gender controller.
 * @RouteResource("Gender")
 */
class GenderRESTController extends DirectoryRESTController
{
    const ENTITY = 'Gender';
    static public $selectFieldTitle = 'shortTitle';
}
