<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Supplier controller.
 * @RouteResource("Supplier")
 */
class SupplierRESTController extends DirectoryRESTController
{
    const ENTITY = 'Supplier';
    static public $selectFieldTitle = 'fullName';
}
