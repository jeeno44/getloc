<?php
namespace ApiBundle\Controller;

use AnalyticsBundle\Model\AnalyticsRepository;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Util\Codes;
use FOS\RestBundle\View\View as FOSView;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use FOS\RestBundle\Controller\Annotations\View;
use Symfony\Component\HttpFoundation\Response;
use ApiBundle\Controller\DirectoryRESTController;

/**
 * KbkFlowDirection controller.
 * @RouteResource("Kbk/FlowDirection")
 */
class KbkFlowDirectionRESTController extends DirectoryRESTController
{
    const ENTITY = 'KbkFlowDirection';

    /**
     * @var string
     */
    static public $selectFieldTitle = ['number', 'title'];

    /**
     * @var string
     */
    static public $selectFieldCode = ['number'];

    static public $groupsGetEntity = ["FlowDirection"];
    static public $groupsGetList   = ["FlowDirection"];
}
