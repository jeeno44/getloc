<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Protocol2 controller.
 * @RouteResource("Protocol2")
 */
class Protocol2RESTController extends DirectoryRESTController
{
    const ENTITY = 'Protocol2';
}
