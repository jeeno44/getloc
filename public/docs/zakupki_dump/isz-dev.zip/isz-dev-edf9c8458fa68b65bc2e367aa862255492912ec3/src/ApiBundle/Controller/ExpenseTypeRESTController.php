<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * ExpenseType controller.
 * @RouteResource("ExpenseType")
 */
class ExpenseTypeRESTController extends DirectoryRESTController
{
    const ENTITY = 'ExpenseType';
    static public $selectFieldTitle = 'description';
}
