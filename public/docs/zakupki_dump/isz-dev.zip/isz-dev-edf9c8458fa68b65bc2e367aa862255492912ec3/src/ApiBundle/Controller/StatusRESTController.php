<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Users controller.
 * @RouteResource("Status")
 */
class StatusRESTController extends DirectoryRESTController
{
    const ENTITY                     = 'Status';
    static public $groupsGetEntity = ['status_detail'];
    static public $selectFieldTitle = 'title';
}
