<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use FOS\RestBundle\Controller\Annotations\View;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Util\Codes;
use FOS\RestBundle\View\View as FOSView;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;


/**
 * LogMessage controller.
 * @RouteResource("FieldRestriction")
 */
class FieldRestrictionRESTController extends Controller
{
    /**
     * Get all FieldRestriction entities.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка ограничений редактирования лота"
     * )
     *
     * @View(serializerEnableMaxDepthChecks=true)
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="offset", requirements="\d+", default="0", description="Offset from which to start listing notes.")
     * -QueryParam(name="limit", requirements="\d+", default="20", description="How many notes to return.")
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     */
    public function cgetAction(ParamFetcherInterface $paramFetcher)
    {
        try {
            $offset = $this->getRequest()->get('offset', 0);
            $limit = $this->getRequest()->get('limit', 20);
            $order_by = $this->getRequest()->get('order_by');
            $filters = !is_null($this->getRequest()->get('filters')) ? $this->getRequest()->get('filters') : array();

            $em = $this->getDoctrine()->getManager();
            $entities = $em->getRepository('FormBundle:FieldRestriction')->findBy($filters, $order_by, $limit, $offset);

            if ($entities) {
                return $entities;
            }

            return FOSView::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return FOSView::create($e->getMessage(), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
