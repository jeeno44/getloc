<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Marketplace controller.
 * @RouteResource("Marketplace")
 */
class MarketplaceRESTController extends DirectoryRESTController
{
    const ENTITY = 'Marketplace';
}
