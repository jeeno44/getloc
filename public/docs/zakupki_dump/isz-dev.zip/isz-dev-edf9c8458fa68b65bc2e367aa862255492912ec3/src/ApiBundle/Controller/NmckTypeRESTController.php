<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * NmckType controller.
 * @RouteResource("NmckType")
 */
class NmckTypeRESTController extends DirectoryRESTController
{
    const ENTITY = 'NmckType';
}
