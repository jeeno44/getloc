<?php

namespace ApiBundle\Controller;

interface RestrictedSimpleController
{

}