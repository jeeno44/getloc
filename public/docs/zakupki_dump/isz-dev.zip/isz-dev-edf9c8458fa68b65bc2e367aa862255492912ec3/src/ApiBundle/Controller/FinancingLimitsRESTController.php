<?php

namespace ApiBundle\Controller;

use AnalyticsBundle\Model\AnalyticsRepository,
    Doctrine\ORM\EntityManager,
    Doctrine\ORM\Mapping\ClassMetadataInfo,
    Doctrine\Common\Collections\Collection;
use Symfony\Component\Form\Form,
    Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request,
    Symfony\Component\HttpFoundation\Response,
    Symfony\Bundle\FrameworkBundle\Controller\Controller;
use FOS\RestBundle\Controller\Annotations\QueryParam,
    FOS\RestBundle\Controller\Annotations\View,
    FOS\RestBundle\Request\ParamFetcherInterface,
    FOS\RestBundle\Util\Codes,
    FOS\RestBundle\View\View as FOSView;
use Nelmio\ApiDocBundle\Annotation\ApiDoc,
    JMS\Serializer\SerializationContext;
use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * FinancingLimits controller.
 * @RouteResource("FinancingLimits")
 */
class FinancingLimitsRESTController extends DirectoryRESTController
{
    const ENTITY = 'FinancingLimits';
    static public $groupsGetList   = ['financing_limits', 'common', 'kbk', 'fcp_action', 'gov_program', 'sub_program_action'];  //['list']

    /**
     * Get all entities.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка"
     * )
     *
     * @12View(serializerEnableMaxDepthChecks=true)
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="offset", requirements="\d+", default="0", description="Offset from which to start listing notes.")
     * -QueryParam(name="limit", requirements="\d+", default="20", description="How many notes to return.")
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     */
    public function cgetAction(ParamFetcherInterface $paramFetcher)
    {
        try {
            $offset = $this->getRequest()->get('offset', 0);
            $limit = $this->getRequest()->get('limit', 20);
            $order_by = $this->getRequest()->get('order_by');
            $filters = !is_null($this->getRequest()->get('filters')) ? $this->getRequest()->get('filters') : array();

            if (isset($filters['kbk.section'])){
                $section = $filters['kbk.section'];

                $em = $this->getDoctrine()->getManager('analytics');

                /** @var AnalyticsRepository $repository */
                $repository = $em->getRepository('AnalyticsBundle:' . static::ENTITY);

                $entities = $repository->findByKbkSection($section);
                if ($entities) {
                    $serializationContext = SerializationContext::create()
                        ->enableMaxDepthChecks();
                    if (!empty(static::$groupsGetList)) {
                        $serializationContext->setGroups(static::$groupsGetList);
                    }

                    return
                        \FOS\RestBundle\View\View::create($entities)
                            ->setSerializationContext($serializationContext);
                }
            }

            $em = $this->getDoctrine()->getManager('analytics');
            /** @var AnalyticsRepository $repository */
            $repository = $em->getRepository('AnalyticsBundle:' . static::ENTITY);
            $entities = $repository->findBy($filters, $order_by, $limit, $offset);
            if ($entities) {
                $serializationContext = SerializationContext::create()
                    ->enableMaxDepthChecks();
                if (!empty(static::$groupsGetList)) {
                    $serializationContext->setGroups(static::$groupsGetList);
                }

                return
                    \FOS\RestBundle\View\View::create($entities)
                        ->setSerializationContext($serializationContext);
            }

            return \FOS\RestBundle\View\View::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return \FOS\RestBundle\View\View::create($e, Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

}
