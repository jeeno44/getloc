<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * DefaultCriteriaRating controller.
 * @RouteResource("DefaultCriteriaRating")
 */
class DefaultCriteriaRatingRESTController extends DirectoryRESTController
{
    const ENTITY = 'DefaultCriteriaRating';
}
