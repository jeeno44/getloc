<?php

namespace ApiBundle\Controller;

use ApiBundle\Controller\ApiRESTController;
use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * CriteriaIndicator controller.
 * @RouteResource("Criteria/Indicator")
 */
class CriteriaIndicatorRESTController extends ApiRESTController
{
    const ENTITY = 'CriteriaIndicator';
}
