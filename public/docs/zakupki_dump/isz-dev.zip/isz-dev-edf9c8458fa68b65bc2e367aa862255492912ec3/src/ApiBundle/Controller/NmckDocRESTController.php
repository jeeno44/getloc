<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * NmckDoc controller.
 * @RouteResource("NmckDoc")
 */
class NmckDocRESTController extends ApiRESTController
{
    const ENTITY = 'NmckDoc';
}
