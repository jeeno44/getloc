<?php
namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * KbkCsr controller.
 * @RouteResource("KbkCsr")
 */
class KbkCsrRESTController extends DirectoryRESTController
{
    const ENTITY = 'KbkCsr';

    /**
     * @var string
     */
    static public $selectFieldTitle = ['code', 'title'];

    static public $groupsGetEntity = ["kbkcsr_detail"];
    static public $groupsGetList   = ["kbkcsr_list"];
}
