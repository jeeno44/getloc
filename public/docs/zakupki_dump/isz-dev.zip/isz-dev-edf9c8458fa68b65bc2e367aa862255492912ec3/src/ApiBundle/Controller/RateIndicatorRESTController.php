<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * RateIndicator controller.
 * @RouteResource("RateIndicator")
 */
class RateIndicatorRESTController extends DirectoryRESTController
{
    const ENTITY = 'RateIndicator';
}
