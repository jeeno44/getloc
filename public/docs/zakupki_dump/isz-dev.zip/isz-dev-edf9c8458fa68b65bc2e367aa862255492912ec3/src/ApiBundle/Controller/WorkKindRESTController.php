<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * WorkKind controller.
 * @RouteResource("WorkKind")
 */
class WorkKindRESTController extends ApiRESTController
{
    const ENTITY = 'WorkKind';
    static public $groupsGetEntity = ['work_kinds_detail'];
    static public $groupsGetList   = ['work_kinds_list'];
}