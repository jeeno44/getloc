<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * NmckMarketPriceMethod controller.
 * @RouteResource("NmckMarketPriceMethod")
 */
class NmckMarketPriceMethodRESTController extends DirectoryRESTController
{
    const ENTITY = 'NmckMarketPriceMethod';
}
