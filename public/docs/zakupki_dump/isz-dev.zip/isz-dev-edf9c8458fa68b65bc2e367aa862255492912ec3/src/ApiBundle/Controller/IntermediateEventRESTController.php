<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * IntermediateEvent controller.
 * @RouteResource("IntermediateEvent")
 */
class IntermediateEventRESTController extends DirectoryRESTController
{
    const ENTITY = 'IntermediateEvent';
}
