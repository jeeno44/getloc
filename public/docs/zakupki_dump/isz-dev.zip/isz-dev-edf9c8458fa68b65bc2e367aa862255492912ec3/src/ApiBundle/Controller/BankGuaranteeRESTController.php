<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * BankGuarantee controller.
 * @RouteResource("BankGuarantee")
 */
class BankGuaranteeRESTController extends DirectoryRESTController
{
    const ENTITY = 'BankGuarantee';
}
