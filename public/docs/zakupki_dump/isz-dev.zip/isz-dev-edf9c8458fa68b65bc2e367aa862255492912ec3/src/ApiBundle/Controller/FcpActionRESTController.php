<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * FcpAction controller.
 * @RouteResource("FcpAction")
 */
class FcpActionRESTController extends DirectoryRESTController
{
    const ENTITY = 'FcpAction';
}
