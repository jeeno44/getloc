<?php

namespace ApiBundle\Controller;

use ApiBundle\Controller\ApiRESTController;
use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * CriteriaType controller.
 * @RouteResource("CriteriaType")
 */
class CriteriaTypeRESTController extends ApiRESTController
{
    const ENTITY = 'CriteriaType';

//    static public $groupsGetEntity = ['CriteriaType', 'CriteriaType_detail', 'lot_list'];  //['detail']

//    static public $groupsGetList = ['CriteriaType', 'lot_list'];  //['list']
}
