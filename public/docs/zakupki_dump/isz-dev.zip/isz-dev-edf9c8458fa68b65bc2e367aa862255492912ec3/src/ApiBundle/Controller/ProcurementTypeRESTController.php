<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * ProcurementType controller.
 * @RouteResource("ProcurementType")
 */
class ProcurementTypeRESTController extends DirectoryRESTController
{
    const ENTITY = 'ProcurementType';
    static public $selectFieldTitle = 'description';
}
