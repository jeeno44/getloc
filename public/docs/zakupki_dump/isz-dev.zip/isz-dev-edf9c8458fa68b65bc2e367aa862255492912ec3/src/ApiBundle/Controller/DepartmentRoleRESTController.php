<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * DepartmentRole controller.
 * @RouteResource("DepartmentRole")
 */
class DepartmentRoleRESTController extends DirectoryRESTController
{
    const ENTITY = 'DepartmentRole';
    static public $selectFieldTitle = 'description';
}
