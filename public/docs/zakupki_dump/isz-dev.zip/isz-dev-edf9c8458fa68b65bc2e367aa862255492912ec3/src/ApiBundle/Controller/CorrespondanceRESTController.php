<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Correspondance controller.
 * @RouteResource("Correspondance")
 */
class CorrespondanceRESTController extends DirectoryRESTController
{
    const ENTITY = 'Correspondance';
}
