<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Stage controller.
 * @RouteResource("Stage")
 */
class StageRESTController extends ApiRESTController
{
    const ENTITY = 'Stage';
    static public $groupsGetEntity = ['stage_detail', 'work_type'];
}