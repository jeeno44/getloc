<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * CommissionMember controller.
 * @RouteResource("CommissionMember")
 */
class CommissionMemberRESTController extends DirectoryRESTController
{
    const ENTITY = 'CommissionMember';
}
