<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * ExpertGroup controller.
 * @RouteResource("ExpertGroup")
 */
class ExpertGroupRESTController extends DirectoryRESTController
{
    const ENTITY = 'ExpertGroup';
    static public $groupsGetEntity = ['expert_group_detail'];
    static public $groupsGetList   = ['expert_group_list'];
}
