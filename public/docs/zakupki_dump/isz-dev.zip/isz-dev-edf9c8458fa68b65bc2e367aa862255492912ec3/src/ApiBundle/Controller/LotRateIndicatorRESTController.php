<?php

namespace ApiBundle\Controller;

use ApiBundle\Controller\ApiRESTController;
use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * RiaType controller.
 * @RouteResource("LotRateIndicator")
 */
class LotRateIndicatorRESTController extends ApiRESTController
{
    const ENTITY = 'LotRateIndicator';

    static public $groupsGetEntity = ['LotRateIndicator', 'LotRateIndicator_detail', 'lot_list'];

    static public $groupsGetList = ['LotRateIndicator'];
}
