<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Project controller.
 * @RouteResource("Project")
 */
class ProjectRESTController extends DirectoryRESTController
{
    const ENTITY = 'Project';
}
