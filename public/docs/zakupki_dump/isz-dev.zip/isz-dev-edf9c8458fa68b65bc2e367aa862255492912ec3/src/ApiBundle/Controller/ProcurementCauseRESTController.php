<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * ProcurementCause controller.
 * @RouteResource("ProcurementCause")
 */
class ProcurementCauseRESTController extends DirectoryRESTController
{
    const ENTITY = 'ProcurementCause';
}
