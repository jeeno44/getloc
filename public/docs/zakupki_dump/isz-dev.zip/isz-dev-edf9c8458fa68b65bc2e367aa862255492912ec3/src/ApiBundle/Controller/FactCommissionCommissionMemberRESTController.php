<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * FactCommissionCommissionMember controller.
 * @RouteResource("FactCommissionCommissionMember")
 */
class FactCommissionCommissionMemberRESTController extends DirectoryRESTController
{
    const ENTITY = 'FactCommissionCommissionMember';
}
