<?php

namespace ApiBundle\Controller;

use ApiBundle\Controller\ApiRESTController;
use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * CriteriaRating controller.
 * @RouteResource("Criteria/Rating")
 */
class CriteriaRatingRESTController extends ApiRESTController
{
    const ENTITY = 'CriteriaRating';

    //static public $groupsGetEntity = ['CriteriaRating', 'CriteriaRating_detail', 'lot_list'];  //['detail']

    static public $groupsGetList = ['CriteriaRating', 'CriteriaIndicator', 'CriteriaType', 'MaxValues'];  //['list']
}
