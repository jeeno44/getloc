<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * CommissionRole controller.
 * @RouteResource("CommissionRole")
 */
class CommissionRoleRESTController extends DirectoryRESTController
{
    const ENTITY = 'CommissionRole';
}
