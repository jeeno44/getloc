<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Commission controller.
 * @RouteResource("Commission")
 */
class CommissionRESTController extends DirectoryRESTController
{
    const ENTITY = 'Commission';
}
