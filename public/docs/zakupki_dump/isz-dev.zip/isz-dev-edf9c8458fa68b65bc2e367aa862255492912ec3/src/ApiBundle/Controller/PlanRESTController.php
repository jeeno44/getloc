<?php

namespace ApiBundle\Controller;

use AnalyticsBundle\Entity\Common;
use AnalyticsBundle\Entity\ExpertGroup;
use AnalyticsBundle\Entity\Financing;
use AnalyticsBundle\Entity\FinancingPlan;
use AnalyticsBundle\Entity\Lot;
use AnalyticsBundle\Entity\Plan;

use Doctrine\DBAL\Connection;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\RequestParam;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use FOS\RestBundle\Controller\Annotations\View;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Util\Codes;
use FOS\RestBundle\View\View as FOSView;
use JMS\Serializer\SerializationContext;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;

use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

/**
 * Plan controller.
 * @RouteResource("Plan")
 */
class PlanRESTController extends ApiRESTController
{

    const ENTITY_TYPE = 'lot';

    const ENTITY = 'Plan';
    static public $groupsGetEntity = ["plan", "plan_detail", "common"];  //, "lot_list"
    static public $groupsGetList   = ["plan", "plan_list"];  //['list']

    /**
     * Подписание консолидированного плана
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Подписание консолидированного плана"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {}
     * )
     *
     * @return Response
     */
    public function patchSignConsolidatedAction(Request $request)
    {
        $content = $request->getContent();
        $data = is_string($content) ? json_decode($content) : (object) $content;

        if (!isset($data->year)) {
            throw new BadRequestHttpException('Need `year` field in income data!');
        }

        $em = $this->getDoctrine()->getManager('analytics');

        /** @var Connection $conn */
        $conn = $em->getConnection();

        $conn->beginTransaction();
        try {
            $plans = $em->getRepository('AnalyticsBundle:Plan')->findBy([
                'year' => is_string($data->year)
                    ? Plan::$year_list[$data->year]
                    : $data->year,
            ]);

            if (!empty($plans)) {
                /** @var Plan $planItem */
                foreach ($plans as $planItem) {
                    $sql = "
                        UPDATE plan
                        SET status_id = '" . Plan::STATUS_PLANNED . "'
                        WHERE id = '" . $planItem->getId() . "' OR status_id = '" . Plan::STATUS_PLANING . "'
                    ";
                    $conn->query($sql)->execute();
                    $sql = "
                        UPDATE lot
                        SET status_id = '" . Lot::STATUS_PLANNED . "'
                        WHERE id in (SELECT lot_id FROM lot_plan WHERE plan_id='" . $planItem->getId() . "') AND status_id = '" . Lot::STATUS_PLANING . "'
                    ";
                    $conn->query($sql)->execute();
                }
            }

            $conn->commit();

            return [
                "status" => "ok",
            ];
        } catch (\Exception $e) {
            $conn->rollBack();
            return [
                "status"  => "error",
                "message" => $e->getMessage(),
            ];
        }
    }


    /**
     * Получение текущего плана
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"plan_current", "lot_list"}
     * )
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение excel"
     * )
     *
     * @return Response
     *
     */
    public function getExcelAction(Request $request)
    {
        $planId = $request->get('planId');

        return $this->get("plan_chart")->generateExcel($planId);
    }

    /**
     * Получение текущего плана
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"plan_current", "lot_list"}
     * )
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение excel"
     * )
     *
     * @return Response
     *
     */
    public function getPdfAction(Request $request)
    {
        $planId = $request->get('planId');

        return $this->get("plan_chart")->generatePDF($planId);
    }

    /**
     * Получение текущего плана
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение текущего плана"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"plan", "plan_current", "lot"}
     * )
     *
     * @return Response
     *
     */
    public function getCurrentAction()
    {
        try{
            /** @var Plan $plan */
            $plan = $this->container->get('analytics.system')->getPlan(Plan::TYPE_CURRENT);
            $plan->type = Plan::YEAR_CURRENT == $plan->getYear()
                ? Plan::TYPE_CURRENT
                : (Plan::YEAR_NEXT == $plan->getYear()
                    ? Plan::TYPE_NEXT
                    : (Plan::YEAR_CURRENT > $plan->getYear()
                        ? Plan::TYPE_ARCHIVE
                        : null)
                );
            return $plan;
        } catch (\Exception $e) {
            return FOSView::create([
                'errors' => [$e->getMessage()]
            ], Codes::HTTP_BAD_REQUEST);
        }
    }

    /**
     * Очищение планов
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Очистка планов"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"plan", "plan_current", "lot"}
     * )
     *
     * @return Response
     *
     */
    public function postPurgeAction()
    {
        $emAnalytics = $this->getDoctrine()->getManager('analytics');
        $emExpertise = $this->getDoctrine()->getManager('expertise');

        $sql = "UPDATE lot SET status_id='draft'";
        $stmt = $emAnalytics->getConnection()->prepare($sql);
        $stmt->execute();

        $sql = "UPDATE plan SET status_id='draft'";
        $stmt = $emAnalytics->getConnection()->prepare($sql);
        $stmt->execute();

        $sql = "TRUNCATE expertise_group CASCADE";
        $stmt = $emExpertise->getConnection()->prepare($sql);
        $stmt->execute();

        $this->get("doctrine.orm.analytics_entity_manager")->clear();

        return FOSView::create(null, Codes::HTTP_OK);
    }

    /**
     * Получение архивных планов
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение архивных планов"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"plan"}
     * )
     *
     * @return Response
     *
     */
    public function getArchivesAction()
    {
        try{
            /** @var Plan $plan */
            $plan = $this->container->get('analytics.system')->getPlan(Plan::TYPE_ARCHIVE);
            return array_map(
                function (Plan $plan) {
                    $plan->type = Plan::TYPE_ARCHIVE;
                    return $plan;
                },
                $plan
            );
        } catch (\Exception $e) {
            return FOSView::create([
                'errors' => [$e->getMessage()]
            ], Codes::HTTP_BAD_REQUEST);
        }
    }

    /**
     * Получение следующего плана
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение следующего плана"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"plan", "plan_next", "lot"}
     * )
     *
     * @return Response
     *
     */
    public function getNextAction()
    {
        try{
            /** @var Plan $plan */
            $plan = $this->container->get('analytics.system')->getPlan(Plan::TYPE_NEXT);
            $plan->type = Plan::YEAR_CURRENT == $plan->getYear()
                ? Plan::TYPE_CURRENT
                : (Plan::YEAR_NEXT == $plan->getYear()
                    ? Plan::TYPE_NEXT
                    : (Plan::YEAR_CURRENT > $plan->getYear()
                        ? Plan::TYPE_ARCHIVE
                        : null)
                );
            return $plan;
        } catch (\Exception $e) {
            return FOSView::create([
                'errors' => [$e->getMessage()]
            ], Codes::HTTP_BAD_REQUEST);
        }
    }

    /**
     * Получение списка планов текущего пользователя
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка планов текущего пользователя"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"plan", "plan_list", "plan_common"}
     * )
     *
     * @return Response
     *
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     */
    public function getCommonAction(ParamFetcherInterface $paramFetcher)
    {
        $em = $this->getDoctrine()->getManager('analytics');

        /**
         * @var \AnalyticsBundle\Repository\UsersRepository  $rUsers
         * @var \AnalyticsBundle\Repository\CommonRepository $rCommon
         * @var \AnalyticsBundle\Entity\Users            $user
         */
        $rUsers  = $em->getRepository('AnalyticsBundle:Users');
        $user    = $rUsers->find($this->getUser()->getId());
        $rCommon = $em->getRepository('AnalyticsBundle:Common');

        $common_ids = array_map(
            function (ExpertGroup $expertGroup) {
                return $expertGroup->getCommon() ? $expertGroup->getCommon()->getId() : null;
            },
            $user->getExpertGroup()->toArray()
        );

        if (count($common_ids) <= 0) {
            return null;
        }

        $common_ids = array_unique($common_ids);

        $common_ids = array_unique(
            array_merge(
                $common_ids,
                $rCommon->findChildren($common_ids)
            )
        );

        /** @var \AnalyticsBundle\Repository\PlanRepository $rPlan */
        $rPlan = $em->getRepository('AnalyticsBundle:Plan');


        $order_by = $this->getRequest()->get('order_by');
        $filters  = !is_null($this->getRequest()->get('filters')) ? $this->getRequest()->get('filters') : array();

        if (isset($filters['type']) && isset(Plan::$year_list[$filters['type']])) {
            $filters['year'] = Plan::$year_list[$filters['type']];
            unset($filters['type']);
        }

        if (!isset($filters['common'])) {
            $filters['common'] = $this->getUser()->getCommonId();
        }

        if (isset($filters['common']) && !in_array($filters['common'], $common_ids)) {
            unset($filters['common']);
        }

        $filters = array_merge(
            [
                'common' => $common_ids,
                'year'   => Plan::YEAR_CURRENT,
            ],
            $filters
        );

        return array_map(
            function (Plan $plan) {
                $plan->type = Plan::YEAR_CURRENT == $plan->getYear()
                    ? Plan::TYPE_CURRENT
                    : (Plan::YEAR_NEXT == $plan->getYear()
                        ? Plan::TYPE_NEXT
                        : (Plan::YEAR_CURRENT > $plan->getYear()
                            ? Plan::TYPE_ARCHIVE
                            : null)
                    );
                return $plan;
            },
            $rPlan->findCommon($filters, $order_by)
        );
    }

    /**
     * Получение списка Lot для плана
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка Lot для плана"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"plan_common_lots", "financing_list"}
     * )
     *
     * @return Response
     */
    public function cgetLotsAction($plan)
    {
        try {

            $em = $this->getDoctrine()->getManager('analytics');

            /**
             * @var \AnalyticsBundle\Repository\UsersRepository  $rUsers
             * @var \AnalyticsBundle\Repository\CommonRepository $rCommon
             * @var \AnalyticsBundle\Entity\Users                $user
             */
            $rUsers  = $em->getRepository('AnalyticsBundle:Users');
            $user    = $rUsers->find($this->getUser()->getId());
            $rCommon = $em->getRepository('AnalyticsBundle:Common');

            $common_ids = array_map(
                function (ExpertGroup $expertGroup) {
                    return $expertGroup->getCommon() ? $expertGroup->getCommon()->getId() : null;
                },
                $user->getExpertGroup()->toArray()
            );

            if (count($common_ids) <= 0) {
                return null;
            }

            $common_ids = array_unique($common_ids);

            $common_ids = array_unique(
                array_merge(
                    $common_ids,
                    $rCommon->findChildren($common_ids)
                )
            );

            $plan = $em->getRepository('AnalyticsBundle:Plan')->findOneBy([
                'id'     => $plan,
                'common' => $common_ids
            ]);
            if ($plan instanceof Plan) {
                return $plan->getLots();
            }

            return FOSView::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return FOSView::create($e->getMessage(), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Получение списка лотов из консолидированного плана
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка лотов из консолидированного плана"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"lot", "lots_consolidated", "okei", "okved", "okpd", "financing", "kbk", "work_type"}
     * )
     *
     * @return Response
     */
    public function cgetConsolidatedLotsAction($planId)
    {
        try {
            $em = $this->getDoctrine()->getManager('analytics');

            $plan = $em->getRepository('AnalyticsBundle:Plan')->find($planId);
            if ($plan instanceof Plan) {
                return $plan->getConsolidatedLots();
            }

            return FOSView::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return FOSView::create($e->getMessage(), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * Получение списка планов текущего пользователя
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка планов текущего пользователя"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"plan", "plan_list", "plan_common"}
     * )
     *
     * @return Response
     *
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     */
    public function cgetOnagreementAction(ParamFetcherInterface $paramFetcher)
    {
        $em = $this->getDoctrine()->getManager('analytics');

        /**
         * @var \AnalyticsBundle\Repository\UsersRepository  $rUsers
         * @var \AnalyticsBundle\Repository\CommonRepository $rCommon
         * @var \AnalyticsBundle\Entity\Users            $user
         */
        /*$rUsers  = $em->getRepository('AnalyticsBundle:Users');
        $user    = $rUsers->find($this->getUser()->getId());
        $rCommon = $em->getRepository('AnalyticsBundle:Common');

        $common_ids = array_map(
            function (ExpertGroup $expertGroup) {
                return $expertGroup->getCommon() ? $expertGroup->getCommon()->getId() : null;
            },
            $user->getExpertGroup()->toArray()
        );

        if (count($common_ids) <= 0) {
            return null;
        }

        $common_ids = array_unique($common_ids);

        $common_ids = array_unique(
            array_merge(
                $common_ids,
                $rCommon->findChildren($common_ids)
            )
        );*/

        /** @var \AnalyticsBundle\Repository\PlanRepository $rPlan */
        $rPlan = $em->getRepository('AnalyticsBundle:Plan');

        $order_by = $this->getRequest()->get('order_by');
        $filters  = !is_null($this->getRequest()->get('filters')) ? $this->getRequest()->get('filters') : array();
        array_push($filters['id'], $rPlan->getConsolidate($filters['type'])->getId());

        if (isset($filters['type']) && isset(Plan::$year_list[$filters['type']])) {
            $filters['year'] = Plan::$year_list[$filters['type']];
            unset($filters['type']);
        }

        /*if (!isset($filters['common'])) {
            $filters['common'] = $this->getUser()->getCommonId();
        }

        if (isset($filters['common']) && !in_array($filters['common'], $common_ids)) {
            unset($filters['common']);
        }*/

        $filters = array_merge(
            [
                //'common' => $common_ids,
                'year'   => Plan::YEAR_CURRENT,
            ],
            $filters
        );

        return array_map(
            function (Plan $plan) {
                $plan->type = Plan::YEAR_CURRENT == $plan->getYear()
                    ? Plan::TYPE_CURRENT
                    : (Plan::YEAR_NEXT == $plan->getYear()
                        ? Plan::TYPE_NEXT
                        : (Plan::YEAR_CURRENT > $plan->getYear()
                            ? Plan::TYPE_ARCHIVE
                            : null)
                    );
                return $plan;
            },
            $rPlan->findCommon($filters, $order_by)
        );
    }

    /**
     * Получение списка Lot для плана
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка консолидированных планов"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"plan_consolidated"}
     * )
     *
     * @return Response
     */
    public function cgetConsolidatedAction($year)
    {
        $em = $this
            ->getDoctrine()
            ->getManager('analytics');

        return $em
            ->getRepository('AnalyticsBundle:Plan')
            ->findBy([
                'common' => array_map(
                    function (Common $foiv) use ($em) {
                        return $foiv->getId();
                    },
                    $em
                        ->getRepository('AnalyticsBundle:Common')
                        ->findBy([
                            'type' => Common::TYPE_FOIV,
                        ])
                ),
                'year'   => $year,
            ]);
    }

    /**
     * Добавление лота в план
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Добавление лота в план"
     * )
     *
     * @View(
     *   serializerEnableMaxDepthChecks=true,
     *   serializerGroups = {"plan_detail"}
     * )
     *
     * @return Response
     */
    public function postLotsAction(Request $request) {

        $op = $request->get('op');
        if ($op == "delete") {
            return $this->deleteLots($request);
        } elseif ($op == "post") {
            return $this->addLots($request);
        }
    }
    
}