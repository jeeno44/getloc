<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * CommissionCommissionMember controller.
 * @RouteResource("CommissionCommissionMember")
 */
class CommissionCommissionMemberRESTController extends DirectoryRESTController
{
    const ENTITY = 'CommissionCommissionMember';
}
