<?php

namespace ApiBundle\Controller;

use AppBundle\Entity\LogMessage;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use FOS\RestBundle\Controller\Annotations\View;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Util\Codes;
use FOS\RestBundle\View\View as FOSView;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;

/**
 * LogMessage controller.
 * @RouteResource("LogMessage")
 */
class LogMessageRESTController extends Controller
{
    const ENTITY = 'LogMessage';

    /**
     * Get all LogMessage entities.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка LogMessage"
     * )
     *
     * @View(serializerEnableMaxDepthChecks=true)
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="offset", requirements="\d+", default="0", description="Offset from which to start listing notes.")
     * -QueryParam(name="limit", requirements="\d+", default="20", description="How many notes to return.")
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     */
    public function cgetAction(ParamFetcherInterface $paramFetcher)
    {
        try {
            $offset = $this->getRequest()->get('offset', 0);
            $limit = $this->getRequest()->get('limit', 20);
            $orderBy = $this->getRequest()->get('order_by');
            $filters = !is_null($this->getRequest()->get('filters')) ? $this->getRequest()->get('filters') : array();

            $em = $this->getDoctrine()->getManager();
            $entities = $em->getRepository('AppBundle:LogMessage')->findBy($filters, $orderBy, $limit, $offset);

            if ($entities) {
                $result = [];
                foreach ($entities as $entity) {
                    $translations = $this->container->getParameter('field_translations');
                    $entityField = $entity->getEntityField();
                    if (isset($translations[$entityField])) {
                        $entityField = $translations[$entityField];
                    }

                    $entityData = [];
                    $entityData['id'] = $entity->getId();
                    $entityData['action'] = $entity->getAction();
                    $entityData['entityName'] = $entity->getEntityName();
                    $entityData['entityId'] = $entity->getEntityId();
                    $entityData['entityField'] = $entityField;
                    $entityData['oldValue'] = $entity->getOldValue();
                    $entityData['newValue'] = $entity->getNewValue();
                    $entityData['comment'] = $entity->getComment();
                    $entityData['createdAt'] = $entity->getCreatedAt();
                    $entityData['entityFieldTitle'] = $entity->getEntityField();

                    $userId = $entity->getUserId();

                    if ($userId) {
                        $user = $this->getDoctrine()->getManager('analytics')->getRepository('AnalyticsBundle:Users')->findOneBy([
                            'id' => $userId,
                        ]);
                        if ($user) {
                            $entityData['user']['id']       = $user->getId();
                            $entityData['user']['name']     = $user->getName();
                            $entityData['user']['lastname'] = $user->getLastName();
                            $entityData['user']['jobTitle'] = $user->getJobTitle();
                        }
                    }

                    $result[] = $entityData;
                }

                return $result;
            }

            return FOSView::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return FOSView::create($e->getMessage(), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Create a entity.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Добавление"
     * )
     *
     * @param Request $request
     *
     * @return Response
     *
     */
    public function postAction(Request $request)
    {
        // todo: сделать через формы, непонятный баг

        $em = $this->getDoctrine()->getManager('default');
        if ($request->getContent()) {
            $request->request->replace((array) json_decode($request->getContent(), true));
        }
        $entity = new LogMessage();
        $entity->setAction($request->request->get("action"));
        $entity->setEntityName($request->request->get("entityName"));
        $entity->setEntityId($request->request->get("entityId"));
        $entity->setEntityField($request->request->get("entityField"));
        $entity->setOldValue($request->request->get("oldValue"));
        $entity->setNewValue($request->request->get("newValue"));
        $entity->setUserId($request->request->get("userId"));
        $entity->setComment($request->request->get("comment"));

        $em->persist($entity);
        $em->flush();

        return $entity;
    }

}
