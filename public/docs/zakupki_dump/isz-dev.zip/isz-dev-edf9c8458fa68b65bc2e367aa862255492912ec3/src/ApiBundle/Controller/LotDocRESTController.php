<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * LotDoc controller.
 * @RouteResource("LotDoc")
 */
class LotDocRESTController extends ApiRESTController
{
    const ENTITY = 'LotDoc';
    static public $groupsGetEntity = ["lot_doc_detail"];
    static public $groupsGetList   = ["lot_doc_list"];
}
