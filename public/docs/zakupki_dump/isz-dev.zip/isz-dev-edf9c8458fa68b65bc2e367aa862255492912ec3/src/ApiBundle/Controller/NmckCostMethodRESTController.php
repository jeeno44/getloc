<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * NmckCostMethod controller.
 * @RouteResource("NmckCostMethod")
 */
class NmckCostMethodRESTController extends DirectoryRESTController
{
    const ENTITY = 'NmckCostMethod';
    static public $selectFieldTitle = 'description';
}
