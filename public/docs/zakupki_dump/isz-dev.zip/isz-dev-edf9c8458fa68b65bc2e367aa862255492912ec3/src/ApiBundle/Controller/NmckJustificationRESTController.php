<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Stage controller.
 * @RouteResource("NmckJustification")
 */
class NmckJustificationRESTController extends ApiRESTController
{
    const ENTITY = 'NmckJustification';
    static public $groupsGetEntity = ['nmck_justification_detail'];
}