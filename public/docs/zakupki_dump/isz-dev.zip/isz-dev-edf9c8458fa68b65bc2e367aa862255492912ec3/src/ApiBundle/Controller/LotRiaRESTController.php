<?php

namespace ApiBundle\Controller;

use ApiBundle\Controller\ApiRESTController;
use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * LotRiaType controller.
 * @RouteResource("LotRia")
 */
class LotRiaRESTController extends ApiRESTController
{
    const ENTITY = 'LotRia';

    static public $groupsGetEntity = ['LotRia', 'LotRia_detail', 'lot_list'];

    static public $groupsGetList = ['LotRia'];
}
