<?php

namespace ApiBundle\Controller;

use ApiBundle\Controller\DirectoryRESTController;
use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * @RouteResource("Criteria/MaxValues")
 */
class CriteriaMaxValuesRESTController extends DirectoryRESTController
{
    const ENTITY = 'CriteriaMaxValues';
}
