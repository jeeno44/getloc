<?php

namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * Nks controller.
 * @RouteResource("Nks")
 */
class NksRESTController extends DirectoryRESTController
{
    const ENTITY = 'Nks';
}
