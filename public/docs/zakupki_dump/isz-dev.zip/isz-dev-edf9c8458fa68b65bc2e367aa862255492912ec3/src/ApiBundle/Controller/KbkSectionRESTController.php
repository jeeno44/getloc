<?php
namespace ApiBundle\Controller;

use FOS\RestBundle\Controller\Annotations\RouteResource;

/**
 * KbkSection controller.
 * @RouteResource("KbkSection")
 */
class KbkSectionRESTController extends DirectoryRESTController
{
    const ENTITY = 'KbkSection';

    /**
     * @var string
     */
    static public $selectFieldTitle = ['code', 'title'];

    static public $groupsGetEntity = ["kbksection_detail"];
    static public $groupsGetList   = ["kbksection_list"];
}
