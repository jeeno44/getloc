<?php

namespace ApiBundle\Controller;

use AnalyticsBundle\Entity\IEntity;
use AnalyticsBundle\Model\AnalyticsRepository;
use Doctrine\DBAL\DBALException;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Mapping\ClassMetadataInfo;
use Doctrine\Common\Collections\Collection;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\View;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Util\Codes;
use FOS\RestBundle\View\View as FOSView;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use JMS\Serializer\SerializationContext;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Swagger\Annotations as SWG;
use FOS\RestBundle\Controller\Annotations\RequestParam;

/**
 * Class ApiRESTController
 * @package ApiBundle\Controller
 *
 * @-SWG\Swagger(
 *     schemes={"http"},
 *     host="isz.gosbook.ru",
 *     basePath="/api",
 *     @-SWG\Info(
 *         version="1.0.0",
 *         title="Storage API",
 *         description="Тут когда-нибудь будет описание нашего апи, а я пока что сам не понял как его описать",
 *         @-SWG\Contact(
 *             email="i.gusev@gblab.ru"
 *         ),
 *     )
 * )
 * @-SWG\SecurityScheme(
 *   securityDefinition="X-User-Id",
 *   type="apiKey",
 *   in="header",
 *   name="X-User-Id"
 * )
 *
 * @-SWG\Tag(name="Пользователи")
 * @-SWG\Tag(name="[GET] REST")
 */
class ApiRESTController extends Controller implements RestrictedController
{
    /**
     * @var string
     */
    const ENTITY = '[entity]';

    /**
     * @var array
     */
    static public $groupsGetEntity = [];  //['detail']

    /**
     * @var array
     */
    static public $groupsGetList = [];  //['list']

    /**
     * @var string
     */
    static public $selectFieldTitle;

    /**
     * Получение списка ajax select.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка ajax select"
     * )
     *
     * @View(serializerEnableMaxDepthChecks=true)
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="offset", requirements="\d+", default="0", description="Offset from which to start listing notes.")
     * -QueryParam(name="limit", requirements="\d+", default="20", description="How many notes to return.")
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     */
    public function cgetSelectAction(ParamFetcherInterface $paramFetcher)
    {
        try {
            $offset  = $this->getRequest()->get('offset', 0);
            $limit   = $this->getRequest()->get('limit', 20);

            $orderBy = [];
            foreach ((array) static::$selectFieldTitle as $key => $value) {
                if (is_array($value)) {
                    $orderBy[$key] = $value;
                } else {
                    $orderBy[$value] = 'ASC';
                }
            }
            $orderBy = $this->getRequest()->get('order_by', $orderBy);

            $filters = !is_null($this->getRequest()->get('filters')) ? $this->getRequest()->get('filters') : array();

            $em = $this->getDoctrine()->getManager('analytics');

            if (isset($filters['title'])) {
                $expr = new \Doctrine\ORM\Query\Expr();
                $filters[static::$selectFieldTitle] = // @todo: убиться об стену
                    (object)[
                        'expr' => $expr->like('t.' . static::$selectFieldTitle, ':t_'.static::$selectFieldTitle),
                        'parameters' => [
                            't_'.static::$selectFieldTitle => '%'.$filters['title'].'%',
                        ]
                    ];
                if (static::$selectFieldTitle != 'title') {
                    unset($filters['title']);
                }
            }

            /** @var AnalyticsRepository $repository */
            $repository = $em->getRepository('AnalyticsBundle:'.static::ENTITY);
            $entities   = $repository->findBySelect($filters, $orderBy, $limit, $offset);
            if ($entities) {
                return $entities;
            }

            return FOSView::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return FOSView::create($e->getMessage(), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get a entity
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение данных"
     * )
     *
     * @1View(serializerEnableMaxDepthChecks=true)
     *
     * @param  $entity
     * @return FOSView
     */
    public function getAction($entity)
    {
        $data = is_object($entity)
            ? $entity
            : $this
                ->getDoctrine()
                ->getManager('analytics')
                ->getRepository('AnalyticsBundle:' . static::ENTITY)
                ->find($entity);

        $serializationContext = SerializationContext::create()
            ->enableMaxDepthChecks();
        if ($this->has('fos_rest.version_listener')) {
            $serializationContext->setVersion($this->get('fos_rest.version_listener')->getVersion());
        }

        if (!empty(static::$groupsGetEntity)) {
            $serializationContext->setGroups(static::$groupsGetEntity);
        }

        return \FOS\RestBundle\View\View::create($data)->setSerializationContext($serializationContext);
    }

    /**
     * Get all entities.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Получение списка"
     * )
     *
     * @param ParamFetcherInterface $paramFetcher
     *
     * @return Response
     *
     * -QueryParam(name="offset", requirements="\d+", default="0", description="Offset from which to start listing notes.")
     * -QueryParam(name="limit", requirements="\d+", default="20", description="How many notes to return.")
     * -QueryParam(name="order_by", nullable=true, array=true, description="Order by fields. Must be an array ie. &order_by[name]=ASC&order_by[description]=DESC")
     * -QueryParam(name="filters", nullable=true, array=true, description="Filter by fields. Must be an array ie. &filters[id]=3")
     * -RequestParam(name="x_groups", array=true, nullable=true, description="Выдача полей определённой группы")
     */
    public function cgetAction(ParamFetcherInterface $paramFetcher)
    {
        try {
            $offset  = $this->getRequest()->get('offset', 0);
            $limit   = $this->getRequest()->get('limit', 20);
            $orderBy = $this->getRequest()->get('order_by');
            $filters = !is_null($this->getRequest()->get('filters')) ? $this->getRequest()->get('filters') : array();

            $em = $this->getDoctrine()->getManager('analytics');
            /** @var AnalyticsRepository $repository */
            $repository = $em->getRepository('AnalyticsBundle:'.static::ENTITY);
            $entities = $repository->findBy($filters, $orderBy, $limit, $offset);
            if ($entities) {
                $serializationContext = SerializationContext::create()
                    ->enableMaxDepthChecks();
                $request = $this->container->get('request_stack')->getCurrentRequest();
                if ($request->query->has('x_groups')) {
                    $groups = array_map('trim', explode(',', $request->query->get('x_groups')));
                    array_push($groups, static::ENTITY, lcfirst(static::ENTITY));
                    $serializationContext->setGroups($groups);
                } else if (!empty(static::$groupsGetList)) {
                    $serializationContext->setGroups(static::$groupsGetList);
                }

                return
                    \FOS\RestBundle\View\View::create($entities)
                        ->setSerializationContext($serializationContext);
            }

            return \FOS\RestBundle\View\View::create('Not Found', Codes::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return \FOS\RestBundle\View\View::create($e, Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Create a entity.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Добавление"
     * )
     *
     * @param Request $request
     *
     * @return Response
     *
     * @throws \Exception
     */
    public function postAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager('analytics');

        $data = $this->_dataContent($request);
        $entityClass = 'AnalyticsBundle\\Entity\\' . static::ENTITY;
        $entity = new $entityClass();
        $entityType = 'ApiBundle\\Form\\' . static::ENTITY . 'Type';
        $form = $this->createForm(new $entityType(), $entity, array("method" => $request->getMethod()));
        $data2 = [];

        $class = $em->getMetadataFactory()->getMetadataFor($entityClass);

        foreach ($class->getAssociationNames() as $fieldName) {
            $associatedClass = $class->getAssociationTargetClass($fieldName);
            $isManyToMany = array_key_exists($fieldName, $class->associationMappings) &&
                in_array($class->associationMappings[$fieldName]['type'], [
                    \Doctrine\ORM\Mapping\ClassMetadataInfo::ONE_TO_MANY,
                    \Doctrine\ORM\Mapping\ClassMetadataInfo::MANY_TO_MANY,
                    \Doctrine\ORM\Mapping\ClassMetadataInfo::TO_MANY,
                ]);
            if ($associatedClass && !$isManyToMany && isset($data[$fieldName]) && !empty($data[$fieldName])) {
                $isIncorrect = false;
                try {
                    if (is_null($em->getRepository($associatedClass)->find($data[$fieldName]))) {
                        $isIncorrect = true;
                    }
                } catch (DBALException $e) {
                    $isIncorrect = true;
                }

                if($isIncorrect) {
                    $form->get($fieldName)->addError(new FormError('Значение в справочнике не найдено'));
                }
            }
        }

        /** @var \Symfony\Component\Form\Form $a */
        foreach ($form->all() as $a) {
            $d = $a->getData();
            if ($d instanceof Collection) {
                if (isset($data[$a->getName()])) {
                    $data2[$a->getName()] = $data[$a->getName()];
                    unset($data[$a->getName()]);
                }
            }
        }

        $em->getConnection()->beginTransaction();
        try {
            $request->request->replace($data);
            $this->removeExtraFields($request, $form);

            if ($form->handleRequest($request) && $form->isValid()) {
                $em->persist($entity);
                $em->flush();

                $this->_putChildCollections($request, $entity, $form, $em, $data2);

                $em->getConnection()->commit();

                $serializationContext = SerializationContext::create()
                    ->enableMaxDepthChecks();

                if (!empty(static::$groupsGetEntity)) {
                    $serializationContext->setGroups(static::$groupsGetEntity);
                }
                //$em->flush();

                $return = \FOS\RestBundle\View\View::create($entity, Codes::HTTP_CREATED)
                    ->setSerializationContext($serializationContext);

                return $return;
            }
            $em->getConnection()->rollback();

            return FOSView::create(array('errors' => $form->getErrors()), Codes::HTTP_BAD_REQUEST);
        }
        catch (DBALException $e) {
            $em->getConnection()->rollback();
            return FOSView::create($e->getMessage(), Codes::HTTP_UNPROCESSABLE_ENTITY);
        } catch (\Exception $e) {
            $em->getConnection()->rollback();
            throw $e;
        }
    }

    /**
     * @param Request $request
     * @return array
     */
    protected function _dataContent($request)
    {
        if ($request->getContent()) {
            return (array)json_decode($request->getContent(), true);
        }
        return [];
    }

    /**
     * Событие вызываемое когда были получены данные по сущности
     *
     * @param object $entity
     */
    protected function eventPutLoadData($entity)
    {
        // EMPTY!!!
    }

    /**
     * Update a entity.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Изменение",
     *   authentication=true
     * )
     *
     * @param Request $request
     * @param $entity
     *
     * @return Response
     */
    public function putAction(Request $request, $entity)
    {
        /** @var EntityManager $em */
        $em = $this->getDoctrine()->getManager('analytics');

        /** @var IEntity|string|uuid $entity */
        $entity = is_object($entity)
            ? $entity
            : $em
                ->getRepository('AnalyticsBundle:' . static::ENTITY)
                ->find($entity);
        // Если объект не был найден в базе то ошибка
        if (!is_object($entity)) {
            return FOSView::create(array('errors' => 'Объект не был найден (' . $entity . ')'), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
        $em->getConnection()->beginTransaction();
        try {
            $this->eventPutLoadData($entity);
            $entityType = 'ApiBundle\\Form\\' . static::ENTITY . 'Type';

            /** @var \Symfony\Component\Form\AbstractType $type */
            $type = new $entityType();

            $data = $this->_dataContent($request);

            // todo: why?
            $request->setMethod('PATCH'); //Treat all PUTs as PATCH

            $form = $this->createForm($type, $entity, array("method" => $request->getMethod()));

            $data2 = [];
            foreach ($form->all() as $a) {
                $d = $a->getData();
                if ($d instanceof Collection) {
                    if (isset($data[$a->getName()])) {
                        $data2[$a->getName()] = $data[$a->getName()];
                        unset($data[$a->getName()]);
                    }
                }
            }
            $request->request->replace($data);

            $this->removeExtraFields($request, $form);

            $form->handleRequest($request);
            if (!$form->isValid() && !empty($data2)) {
                $this->_putChildCollections($request, $entity, $form, $em, $data2);

                $em->getConnection()->commit();
                $id = $entity->getId();
                $em->detach($entity);

                $serializationContext = SerializationContext::create()
                    ->enableMaxDepthChecks();
                if (!empty(static::$groupsGetEntity)) {
                    $serializationContext->setGroups(static::$groupsGetEntity);
                }

                return
                    \FOS\RestBundle\View\View::create(
                        $em
                            ->getRepository('AnalyticsBundle:' . static::ENTITY)
                            ->find($id)
                    )
                        ->setSerializationContext($serializationContext);
            }

            if ($form->isValid()) {

                $em->persist($entity);
                $em->flush();

                $this->_putChildCollections($request, $entity, $form, $em, $data2);
                $em->getConnection()->commit();
                $id = $entity->getId();
                $em->detach($entity);
                $serializationContext = SerializationContext::create()
                    ->enableMaxDepthChecks();
                if (!empty(static::$groupsGetEntity)) {
                    $serializationContext->setGroups(static::$groupsGetEntity);
                }
                return
                    \FOS\RestBundle\View\View::create(
                        $em
                            ->getRepository('AnalyticsBundle:' . static::ENTITY)
                            ->find($id)
                    )
                        ->setSerializationContext($serializationContext);
            }

            $em->getConnection()->rollback();
            return FOSView::create(['errors' => $form->getErrors()], Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
        catch (DBALException $e) {
            $em->getConnection()->rollback();
            return FOSView::create($e->getMessage(), Codes::HTTP_UNPROCESSABLE_ENTITY);
        }
        catch (\Exception $e) {
            $em->getConnection()->rollback();
            if ($e instanceof HttpException) {
                // No handling, everything is OK, keep throwing
                throw $e;
            }
            return FOSView::create($e, Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Partial Update to a entity.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Изменение",
     *   authentication=true
     * )
     *
     * @View(serializerEnableMaxDepthChecks=true)
     *
     * @param Request $request
     * @param $entity
     *
     * @return Response
     */
    public function patchAction(Request $request, $entity)  // ApplicationDocumentsAvailability
    {
        return $this->putAction($request, $entity);
    }

    /**
     * Событие вызываемое когда были получены данные по сущности, при удалении сущности
     *
     * @param object $entity
     */
    protected function eventDeleteLoadData($entity)
    {
        // EMPTY!!!
    }

    /**
     * Delete a entity.
     *
     * @ApiDoc(
     *   resource=true,
     *   description="Удаление",
     *   authentication=true
     * )
     *
     * @View(statusCode=204)
     *
     * @param Request $request
     * @param $entity
     * @internal param $id
     *
     * @return Response
     */
    public function deleteAction(Request $request, $entity)
    {
        $em = $this->getDoctrine()->getManager('analytics');
        $entity = is_object($entity)
            ? $entity
            : $em
                ->getRepository('AnalyticsBundle:' . static::ENTITY)
                ->find($entity);
        if (!$entity) {
            //return FOSView::create('Not found', Codes::HTTP_NOT_FOUND);
            return null;
        }

        try {
            $this->eventDeleteLoadData($entity);
        } catch (\Exception $e) {
            return FOSView::create(['errors' => $e->getMessage()], $e->getCode());
        }

        try {
            $em->remove($entity);
            $em->flush();

            return null;
        } catch (\Exception $e) {
            return FOSView::create($e->getMessage(), Codes::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Create a form without a name
     *
     * @param null $type
     * @param null $data
     * @param array $options
     *
     * @return Form|FormInterface
     */
    public function createForm($type = null, $data = null, array $options = array())
    {
        $form = $this->container->get('form.factory')->createNamed(
            null, //since we're not including the form name in the request, set this to null
            $type,
            $data,
            $options
        );

        return $form;
    }

    /**
     * Get rid on any fields that don't appear in the form
     *
     * @param Request $request
     * @param Form $form
     */
    protected function removeExtraFields(Request $request, Form $form)
    {
        $data = $request->request->all();
        $children = $form->all();
        $data = array_intersect_key($data, $children);
        $request->request->replace($data);
    }

    /**
     * @param Request $request
     * @param $entity
     * @param Form|FormInterface $form
     * @param $em
     */
    protected function _putChildCollections(Request &$request, $entity, $form, EntityManager $em, $data)
    {
        foreach ($form->all() as $fieldKey => $formField) {
            /** @var \Doctrine\ORM\PersistentCollection $fieldData */
            $fieldData = $formField->getData();
            if (
                $fieldData instanceof Collection &&
                isset($data[$formField->getName()]) &&
                count($data[$formField->getName()]) > 0
            ) {

                $incomeData = $data[$formField->getName()];

                // @todo Now it works only for first level
                $class = $em->getMetadataFactory()->getMetadataFor('AnalyticsBundle:Lot');
                $isManyToMany = array_key_exists($formField->getName(), $class->associationMappings) &&
                    $class->associationMappings[$formField->getName()]['type'] == \Doctrine\ORM\Mapping\ClassMetadataInfo::MANY_TO_MANY;

                $entityName = ucfirst($formField->getName());

                if ($isManyToMany) {
                    $fRemove = 'remove' . $entityName;

                    if (!method_exists($entity, $fRemove)) {
                        $fRemove = 'remove' . ucfirst(substr($formField->getName(), 0, -1));
                    }

                    $fAdd = 'add' . $entityName;

                    if (!method_exists($entity, $fRemove)) {
                        $fAdd = 'add' . ucfirst(substr($formField->getName(), 0, -1));
                    }

                    if (!empty($incomeData) && is_array($incomeData)) {
                        foreach ($incomeData as $entityItem) {
                            if (isset($entityItem['id']) && !empty($entityItem['id'])) {
                                $ri = $em->getRepository('AnalyticsBundle:' . $entityName)->find($entityItem['id']);
                                $entity->$fAdd($ri);
                            }
                        }
                    }
                }

                if (!is_array($incomeData)) {
                    throw new BadRequestHttpException('Invalid incoming data (not array)' . $formField->getName() .  json_encode($incomeData));
                }

                // Получение списка обновлемых объектов
                $incomeIds = array_values(array_map(
                    function ($v) {
                        return $v['id'];
                    },
                    array_filter($incomeData, function ($v) {
                        return isset($v['id']);
                    })
                ));
                $incomeIds = array_combine($incomeIds, $incomeIds);

                $fGet = 'get' . ucfirst($formField->getName());
                if (!method_exists($entity, $fGet)) {
                    $fGet = 'get' . ucfirst(substr($formField->getName(), 0, -1));
                }

                foreach ($entity->$fGet() as $childEntity) {
                    if (!isset($incomeIds[$childEntity->getId()])) {
                        if ($isManyToMany) {
                            $entity->$fRemove($childEntity);
                        } else {
                            $em->remove($childEntity);
                            $em->detach($childEntity);
                        }
                    } else {
                        unset($incomeIds[$childEntity->getId()]);
                    }
                }

                try {
                    $em->flush();
                } catch (\Exception $e) {
                    throw new HttpException(500, $e->getMessage());
                }

                /**
                 * Если переданы id объектов которых не было у родительского объекта, то вызываем исключение со списком объектов.
                 */
                if (count($incomeIds) > 0) {
                    throw new \Exception(json_encode([
                        'errors' => array_map(
                            function ($id) use ($formField) {
                                throw new BadRequestHttpException('Объект не был найден (' . $formField->getName() . ': ' . $id . ')');
                            },
                            $incomeIds
                        )
                    ]));
                }

                if ($isManyToMany) {
                    continue;
                }

                foreach ($incomeData as $value) {
                    if (!$this->_checkNullArray($value)) {
                        continue;
                    }

                    $getTypeClass = '';
                    if (!method_exists($fieldData, 'getTypeClass')) {
                        $getTypeClass = 'AnalyticsBundle\Entity' . substr(get_class($formField->getConfig()->getOption('type')), strlen('ApiBundle\Form'), -4);
                    }
                    if ($getTypeClass == '') {
                        $getTypeClass = $fieldData->getTypeClass()->getName();
                    }

                    $req = clone $request;
                    if (isset($value['id'])) {
                        $entity2 = $em->getRepository($getTypeClass)->find($value['id']);

                        if (is_null($entity2)) {
                            throw new BadRequestHttpException(json_encode([
                                'errors' => [
                                    'Объект не был найден (' . $formField->getName() . ': ' . $value['id'] . ')'
                                ]
                            ]));
                        }

                        unset($value['id']);
                        $req->setMethod('PATCH');
                    } else {
                        $entity2 = new $getTypeClass;
                        $req->setMethod('POST');
                    }

                    $form2 = $this->createForm(
                        clone $formField->getConfig()->getOption('type'),
                        $entity2,
                        ["method" => $req->getMethod()]);

                    $data2 = [];
                    foreach ($form2->all() as $a) {
                        $d = $a->getData();
                        if ($d instanceof Collection) {
                            if (isset($value[$a->getName()])) {
                                $data2[$a->getName()] = $value[$a->getName()];
                                unset($value[$a->getName()]);
                            }
                        }
                    }

                    if (is_null($value)) {
                        continue;
                    }

                    $req->request->replace($value);
                    $this->removeExtraFields($req, $form2);
                    $form2->handleRequest($req);
                    if ($form2->isValid()) {
                        $n = 'add' . ucfirst($formField->getName());
                        /** @var \Doctrine\Common\Collections\Collection $dd */
                        if (!method_exists($entity, $n)) {
                            $n = 'add' . ucfirst(substr($formField->getName(), 0, -1));
                        }
                        if (isset($value['id'])) {
                            $em->persist($entity2);
                        }
                        $entity->$n($entity2);
                        //$em->persist($entity);
                        $em->flush();

                        if (!is_null($data2)) {
                            $this->_putChildCollections($req, $entity2, $form2, $em, $data2);
                        }
                    } else {
                        //echo '==========' . $form2->getErrorsAsString();
                        //die;
                        throw new \Exception(json_encode(['errors' => $form2->getErrors()]));
                    }
                }
            }
        }
    }

    /**
     * @param $val
     * @return bool
     */
    private function _checkNullArray($val)
    {
        if (is_array($val) && count($val) > 0) {
            $haveNotNull = false;
            foreach ($val as $valItem) {
                if (!is_null($valItem)) {
                    $haveNotNull = true;
                }
            }

            return $haveNotNull;
        }

        return true;
    }
}
