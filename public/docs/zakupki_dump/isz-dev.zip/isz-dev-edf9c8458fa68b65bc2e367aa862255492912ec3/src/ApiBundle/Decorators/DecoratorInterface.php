<?php

namespace ApiBundle\Decorators;

/**
 * Интерфейс для построения декораторов, для обработки объекта(-ов)
 * @package ApiBundle\Decorators
 */
interface DecoratorInterface
{
    /**
     * @return mixed
     */
    public function get();
}