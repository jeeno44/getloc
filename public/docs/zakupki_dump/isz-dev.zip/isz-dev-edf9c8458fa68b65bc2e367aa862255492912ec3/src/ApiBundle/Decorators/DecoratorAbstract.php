<?php

namespace ApiBundle\Decorators;

/**
 * Class DecoratorAbstract
 * @package ApiBundle\Decorators
 */
abstract class DecoratorAbstract implements DecoratorInterface
{
    protected $_data;

    /**
     * DecoratorAbstract constructor.
     */
    public function __construct()
    {
    }

    /**
     * @param null $data
     * @return mixed
     */
    static public function create($data = null)
    {
        $decorator = new static();

        $decorator->setData($data);

        return $decorator->get();
    }

    /**
     * @return mixed
     */
    public function getData()
    {
        return $this->_data;
    }

    /**
     * @param $data
     *
     * @return $this
     */
    public function setData($data)
    {
        $this->_data = $data;

        return $this;
    }

    /**
     * @return mixed
     */
    public function get()
    {
        return $this->getData();
    }
}