<?php

namespace ApiBundle\Decorators\Lot;

use AnalyticsBundle\Entity\Lot;
use AnalyticsBundle\Entity\Plan;
use ApiBundle\Decorators\DecoratorAbstract;

/**
 * Обработка списка лотов для того что бы в планах появилось поле type обозначающее какой тип плана (current, next)
 * @package ApiBundle\Decorators\Lot
 */
class PlanType extends DecoratorAbstract
{
    /**
     * @return \AnalyticsBundle\Entity\Lot[]
     */
    public function getData()
    {
        /** @var Lot[] $entities */
        $entities = parent::getData();

        foreach ($entities as $lot) {
            $i = 1;
            foreach ($lot->getPlan() as $plan) {
                if ($i == 1 && $plan->getYear() == Plan::YEAR_CURRENT) {
                    $plan->type = Plan::TYPE_CURRENT;
                } else if ($i == 2 && $plan->getYear() == Plan::YEAR_NEXT) {
                    $plan->type = Plan::TYPE_NEXT;
                } else {
                    break;
                }
                $i++;
            }
        }

        return $entities;
    }
}