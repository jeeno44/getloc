<?php

namespace AdminBundle\Form\Type;

use AnalyticsBundle\Entity\MailList;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EmailNotifyFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('title', 'text')
            ->add('body', 'textarea')
            ->add('subject', 'text')
            ->add('type', 'hidden', [
                'data' => MailList::TYPE_EMAIL
            ])
        ;
    }

    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => 'AnalyticsBundle\Entity\MailList',
            'csrf_protection' => false,
            'cascade_validation' => true,
        ]);
    }

    /**
     * Returns the name of this type.
     *
     * @return string The name of this type
     */
    public function getName()
    {
        return 'email_notify';
    }
}