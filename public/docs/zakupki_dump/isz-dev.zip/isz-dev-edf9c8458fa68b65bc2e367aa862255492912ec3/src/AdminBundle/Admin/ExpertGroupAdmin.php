<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use AnalyticsBundle\Entity\ExpertGroup;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class ExpertGroupAdmin extends Admin
{
    public $baseRouteName = 'ExpertGroupAdmin';
    public $baseRoutePattern = 'ExpertGroupAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('title')
            ->add('type', null, [], 'choice', array('choices' => ExpertGroup::$type_lists, 'expanded' => true))
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('common.fullName')
                ->add('type', 'choice', array('choices' => ExpertGroup::$type_lists))
                ->add('title')
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('title')
                ->add('type', 'choice', array('choices' => ExpertGroup::$type_lists))
                //->add('versionStartAt')
            ->end()
            ->with('Reference data')
                ->add('parent', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('common', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('users', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => true,
                    'multiple'     => true,
                ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('title')
            ->add('type')
            ->add('versionStartAt')
            ->add('versionEndAt')
            ->add('versionOwnerId')
        ;
    }

    public function getFilterParameters()
    {
        $default = [
            'type' => ['value' => ExpertGroup::TYPE_EXPERT],
        ];

        $this->datagridValues = array_merge($default, $this->datagridValues);

        return parent::getFilterParameters();
    }
}
