<?php

namespace AdminBundle\Admin\RateIndicator;

use AnalyticsBundle\Entity\RateIndicator;
use AdminBundle\Admin\RateIndicatorAdmin;

/**
 * Class IndicatorAdmin
 * @package AdminBundle\Admin\RateIndicator
 */
class IndicatorAdmin extends RateIndicatorAdmin
{
    /**
     * @var string
     */
    public $baseRouteName = 'IndicatorAdmin';

    /**
     * @var string
     */
    public $baseRoutePattern = 'IndicatorAdmin';

    /**
     * @var string
     */
    static $type = RateIndicator::TYPE_INDICATOR;

    /**
     * @param string $context
     * @return \Sonata\AdminBundle\Datagrid\ProxyQueryInterface
     */
    public function createQuery($context = 'list')
    {
        $query = parent::createQuery($context);
        if ($context == 'list') {
            $query->andWhere("o.type='".RateIndicator::TYPE_INDICATOR."'");
        }

        return $query;
    }
}
