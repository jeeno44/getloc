<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class ApplicationAdmin extends Admin
{
    public $baseRouteName = 'ApplicationAdmin';
    public $baseRoutePattern = 'ApplicationAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('regNumber')
            ->add('title')
            ->add('totalFinancing')
            ->add('proposedChar')
            ->add('supplierQualification')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('regNumber')
                ->add('title')
                ->add('totalFinancing')
                ->add('proposedChar')
                ->add('supplierQualification')
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('regNumber')
                ->add('title')
                ->add('totalFinancing')
                ->add('proposedChar')
                ->add('supplierQualification')
                //->add('versionStartAt')
            ->end()
            ->with('Reference data')
                ->add('protocol1', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('protocol2', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('commission', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('supplier', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('regNumber')
            ->add('title')
            ->add('totalFinancing')
            ->add('proposedChar')
            ->add('supplierQualification')
            ->add('versionStartAt')
            ->add('versionEndAt')
            ->add('versionOwnerId')
        ;
    }
}
