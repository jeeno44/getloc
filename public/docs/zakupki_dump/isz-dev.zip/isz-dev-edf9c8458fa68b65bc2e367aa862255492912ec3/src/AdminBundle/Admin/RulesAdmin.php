<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use AdminBundle\Form\Type\EmailNotifyFormType;
use AdminBundle\Form\Type\RulesFormType;
use AdminBundle\Form\Type\SmsNotifyFormType;
use AnalyticsBundle\Entity\Rules;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;
use Sonata\AdminBundle\Validator\ErrorElement;

class RulesAdmin extends Admin
{
    public $baseRouteName = 'RulesAdmin';
    public $baseRoutePattern = 'RulesAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('type')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('type')
                ->add('field')
                ->add('value')
                ->add('_action', 'actions', array(
                    'actions' => array(
                        'show' => array(),
                        'edit' => array(),
                        'delete' => array(),
                    )
                ))
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->add('type', 'choice', [
                'choices' => [
                    Rules::TYPE_LOT => 'lot',
                    Rules::TYPE_PLAN => 'plan',
                    Rules::TYPE_CONTRACT => 'contract',
                    Rules::TYPE_PROTOCOL => 'protocol'
                ],
                'attr' => [
                    'class' => 'entity-type'
                ],
                'multiple' => false
            ])
            ->add('selecting', 'choice', [
                'choices' => [],
                'mapped' => false,
                'required' => false,
                'attr' => [
                    'class' => 'entity-field'
                ]
            ])
            ->add('symbol', 'choice', [
                'choices' => [
                    Rules::SYMBOL_MIN => '<',
                    Rules::SYMBOL_MAX => '>',
                    Rules::SYMBOL_EQUALLY => '='
                ]
            ])
            ->add('field', 'hidden', [
                'attr' => [
                    'class' => 'selected-value'
                ]
            ])
            ->add('value', 'text', [
                'attr' => [
                    'class' => 'entity-value'
                ]
            ]);
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('id')
            ->add('type')
            ->add('field')
            ->add('value')
        ;
    }

    /**
     * Override core method to display custom template(s)
     */
    public function getTemplate($name)
    {
        switch ($name) {
            case 'edit':
                return 'AdminBundle:Rules:edit.html.twig';
                break;
            default:
                return parent::getTemplate($name);
                break;
        }
    }
}
