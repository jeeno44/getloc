<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use AdminBundle\Form\Type\EmailNotifyFormType;
use AdminBundle\Form\Type\SmsNotifyFormType;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class NotifyAdmin extends Admin
{
    public $baseRouteName = 'NotifyAdmin';
    public $baseRoutePattern = 'NotifyAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('title')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('title')
                ->add('code')
                ->add('description')
                ->add('_action', 'actions', array(
                    'actions' => array(
                        'show' => array(),
                        'edit' => array(),
                        'delete' => array(),
                    )
                ))
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {

        $formMapper
            ->with('General')
            ->add('title')
            ->add('code')
            ->add('description')
            ->add('roles', 'sonata_type_model', [
                'multiple' => true,
                'by_reference' => false,
                'btn_add' => false,
                'required' => false
            ])
            ->end()
            ->with('Period')
            ->add('periods', 'sonata_type_model', [
                'multiple' => true,
                'by_reference' => false,
                'required' => false
            ])
            ->end()
            ->with('Email')
            ->add('common', null)
            ->add('email', new EmailNotifyFormType(), [
                'label' => false,
                'data_class' => 'AnalyticsBundle\Entity\MailList',
            ])
            ->end()
            ->with('SMS')
            ->add('sms', new SmsNotifyFormType(), [
                'label' => false,
                'data_class' => 'AnalyticsBundle\Entity\MailList',
            ])
            ->end()
            ->with('Rules')
            ->add('rules', 'sonata_type_model', [
                'multiple' => true,
                'by_reference' => false,
                'required' => false,
                'btn_add' => false
            ])
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('id')
            ->add('title')
            ->add('description')
        ;
    }
}