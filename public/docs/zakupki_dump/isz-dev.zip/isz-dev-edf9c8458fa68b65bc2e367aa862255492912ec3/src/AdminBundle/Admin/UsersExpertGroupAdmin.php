<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;

class UsersExpertGroupAdmin extends Admin
{
    public $baseRouteName = 'UsersExpertGroupAdmin';
    public $baseRoutePattern = 'UsersExpertGroupAdmin';

    private $_rabbit;

    public function setRabbit($rabbit)
    {
        $this->_rabbit = $rabbit;
    }

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->add('users.name')
            ->add('expertGroup.common.fullName')
            ->add('expertGroup.type')
            ->add('expertRole')
            ->add('_action', 'actions', array(
                'actions' => array(
                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                )
            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
//        $id     = time();
//        $client = $this->_rabbit;
//        $client->addRequest(json_encode([]), 'isz', $id, "auth.roles.get");
//        $roles = [];
//        $roles2 = (array) $client->getReplies()[$id];
//        foreach ($roles2 as $_role) {
//            $roles[$_role->code] = $_role->name;
//        }

        $formMapper
            ->with('Reference data')
                ->add('users', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('expertGroup', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('expertRole', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
//                ->add('expertRole', 'choice', [ 'choices' => $roles, 'label' => 'Роли', 'required'     => false,])
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('users.name')
            ->add('expertGroup.title')
            ->add('expertGroup.type')
            ->add('expertRole')
        ;
    }
}
