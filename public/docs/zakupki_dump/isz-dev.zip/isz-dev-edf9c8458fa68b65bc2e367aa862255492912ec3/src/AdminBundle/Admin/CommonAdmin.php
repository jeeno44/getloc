<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use AnalyticsBundle\Entity\Common;
use Doctrine\ORM\Query\Expr\Join;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class CommonAdmin extends Admin
{
    public $baseRouteName = 'CommonAdmin';
    public $baseRoutePattern = 'CommonAdmin';

    /**
     * Default Datagrid values
     *
     * @var array
     */
    protected $datagridValues = array(
        '_page' => 1,            // display the first page (default = 1)
        '_sort_order' => 'DESC', // reverse order (default = 'ASC')
        '_sort_by' => 'type'  // name of the ordered field
        // (default = the model's id field, if any)

        // the '_sort_by' key can be of the form 'mySubModel.mySubSubModel.myField'.
    );

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('type')
            ->add('parent')
            ->add('fullName')
            ->add('shortName')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->add('type', 'choice', array('choices' => Common::$types))
            ->add('fullName', 'text', [
                'template' => 'AdminBundle:CRUD:list__field_filter_parent.html.twig',
            ])
            ->add('shortName')
            ->add('_action', 'actions', array(
                'actions' => array(
                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                )
            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        /** @var Common $subject */
        $subject = $this->getSubject();
        $id = ($subject ? $subject->getId() : null);

        $formMapper
            ->with('General')
            ->add('type', 'choice', array('choices' => Common::$types))
            ->add('fullName')
            ->add('shortName')
            ->add('factAddress')
            ->add('postAddress')
            ->add('phone')
            ->add('email')
            ->add('http')
            ->add('bankAccount')
            ->add('bank')
            ->add('inn')
            ->add('bik')
            ->add('kpp')
            ->add('okpo')
            ->add('okato')
            ->add('oktmo')
            ->add('ogrn')
            ->add('okogy')
            ->add('okfs')
            ->add('codeGrbs')
            ->add('codeSpz')
            ->add('personalAccount')
            ->add('checkingAccount')
            //->add('versionStartAt')
            ->end()
            ->with('Reference data')
            ->add('parent', null, array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
                //'property' => 'full_name',
                'query_builder' => function(\Doctrine\ORM\EntityRepository $er) use ($id, $formMapper) {
                    $qb = $er->createQueryBuilder('p');
                    if ($id){
                        $qb
                            ->where('p.id != :id')  // and p.parent_id <> :id
                            ->setParameter('id', $id);
                    }
                    switch ($formMapper->getFormBuilder()->get('type')->getData()) {
                        case Common::TYPE_ORGANIZATION:
                            $qb
                                ->andWhere('p.parent_id IS NULL OR p.parent_id = p.id OR p.parent_id = 0');
                            break;
                        case Common::TYPE_DEPARTMENT:
                            //$qb->innerJoin('common', 'u', Join::WITH, 'u.type != "' . Common::TYPE_DEPARTMENT . '"');
                            $qb
                                ->andWhere('p.type != :type')
                                ->setParameter('type', Common::TYPE_DEPARTMENT);

                            //$qb->addSelect('IfElse(p.parent_id = p.id OR p.parent_id IS NULL OR p.parent_id = 0, 0, 1) as order1');

                            //$qb->orderBy('order1', 'ASC');
                            //$qb->addOrderBy('IF p.parent_id = p.id OR p.parent_id IS NULL OR p.parent_id = 0 THEN p.id ELSE p.parent_id END IF');
                            break;
                        case Common::TYPE_FOIV:
                            $qb
                                ->andWhere('1 = 0');
                            //$qb->addOrderBy('p.parent_id = p.id');
                            break;
                    }
                    return $qb;
                }
            ), array('placeholder' => 'No selected'))
            ->add('deputyhead', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
            ), array('placeholder' => 'No selected'))
            ->add('departmentRole', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => true,
            ), array('placeholder' => 'No selected'))
            ->add('okved', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
            ), array('placeholder' => 'No selected'))
            ->add('okopf', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
            ), array('placeholder' => 'No selected'))
            ->add('head', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
            ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('type')
            ->add('fullName')
            ->add('shortName')
            ->add('factAddress')
            ->add('postAddress')
            ->add('phone')
            ->add('email')
            ->add('http')
            ->add('bankAccount')
            ->add('bank')
            ->add('inn')
            ->add('bik')
            ->add('kpp')
            ->add('okpo')
            ->add('okato')
            ->add('oktmo')
            ->add('codeGrbs')
            ->add('codeSpz')
            ->add('personalAccount')
            ->add('checkingAccount')
            ->add('versionStartAt')
            ->add('versionEndAt')
            ->add('versionOwnerId')
        ;
    }

    public function createQuery($context = 'list')
    {
        $query = parent::createQuery($context);
        $filter = $this->request->query->get('filter');
        if (!(isset($filter['parent']) && isset($filter['parent']['value']))) {
            $query->andWhere('o.parent IS NULL');
        }
        return $query;
    }
}
