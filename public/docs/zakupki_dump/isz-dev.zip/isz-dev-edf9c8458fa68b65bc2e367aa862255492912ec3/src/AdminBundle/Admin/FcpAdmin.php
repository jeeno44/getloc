<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class FcpAdmin extends Admin
{
    public $baseRouteName = 'FcpAdmin';
    public $baseRoutePattern = 'FcpAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('title')
            ->add('shortTitle')
            ->add('number')
            ->add('executionStartdate')
            ->add('executionEnddate')
            ->add('goals')
            ->add('tasks')
            ->add('versionOwnerId', 'doctrine_orm_callback', [
                'type'     => 'hidden',
                'callback' => array($this, 'getVersionOwnerIdFilter'),
            ])
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('title')
                ->add('shortTitle')
                ->add('number')
                ->add('executionStartdate')
                ->add('executionEnddate')
                ->add('goals')
                ->add('tasks')
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('title')
                ->add('shortTitle')
                ->add('number')
                ->add('executionStartdate')
                ->add('executionEnddate')
                ->add('goals')
                ->add('tasks')
                ->add('versionStartAt')
            ->end()
            ->with('Reference data')
                ->add('executor', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('coExecutor', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('govProgram', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('title')
            ->add('shortTitle')
            ->add('number')
            ->add('executionStartdate')
            ->add('executionEnddate')
            ->add('goals')
            ->add('tasks')
            ->add('versionStartAt')
            ->add('versionEndAt')
            ->add('versionOwnerId')
        ;
    }
}
