<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class NmckCostMethodAdmin extends Admin
{
    public $baseRouteName = 'NmckCostMethodAdmin';
    public $baseRoutePattern = 'NmckCostMethodAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('description')
            ->add('costItemName')
            ->add('costDistribution')
            ->add('price')
            ->add('esn')
            ->add('expenses')
            ->add('profit')
            ->add('nds')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('description')
                ->add('costItemName')
                ->add('costDistribution')
                ->add('price')
                ->add('esn')
                ->add('expenses')
                ->add('profit')
                ->add('nds')
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('description')
                ->add('costItemName')
                ->add('costDistribution')
                ->add('price')
                ->add('esn')
                ->add('expenses')
                ->add('profit')
                ->add('nds')
                //->add('versionStartAt')
            ->end()
            ->with('Reference data')
                ->add('nmckVariant', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('description')
            ->add('costItemName')
            ->add('costDistribution')
            ->add('price')
            ->add('versionStartAt')
            ->add('versionEndAt')
            ->add('versionOwnerId')
            ->add('esn')
            ->add('expenses')
            ->add('profit')
            ->add('nds')
        ;
    }
}
