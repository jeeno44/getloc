<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;

class FinancingAdmin extends Admin
{
    public $baseRouteName = 'FinancingAdmin';
    public $baseRoutePattern = 'FinancingAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('year')
            ->add('relYear')
            ->add('planPrice')
            ->add('planQuantity')
            ->add('publicationPrice')
            ->add('publicationQuantity')
            ->add('contractPrice')
            ->add('contractQuantity')
            ->add('factPrice')
            ->add('factQuantity')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->add('year')
            ->add('relYear')
            ->add('planPrice')
            ->add('planQuantity')
            ->add('publicationPrice')
            ->add('publicationQuantity')
            ->add('contractPrice')
            ->add('contractQuantity')
            ->add('factPrice')
            ->add('factQuantity')
            ->add('_action', 'actions', array(
                'actions' => array(
                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                )
            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('year')
                ->add('relYear')
                ->add('planPrice')
                ->add('planQuantity')
                ->add('publicationPrice')
                ->add('publicationQuantity')
                ->add('contractPrice')
                ->add('contractQuantity')
                ->add('factPrice')
                ->add('factQuantity')
            ->end()
            ->with('Reference data')
                ->add('plan', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('lot', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('year')
            ->add('relYear')
            ->add('planPrice')
            ->add('planQuantity')
            ->add('publicationPrice')
            ->add('publicationQuantity')
            ->add('contractPrice')
            ->add('contractQuantity')
            ->add('factPrice')
            ->add('factQuantity')
        ;
    }
}
