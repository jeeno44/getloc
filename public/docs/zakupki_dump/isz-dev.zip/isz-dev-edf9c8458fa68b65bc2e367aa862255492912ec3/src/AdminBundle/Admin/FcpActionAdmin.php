<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class FcpActionAdmin extends Admin
{
    public $baseRouteName = 'FcpActionAdmin';
    public $baseRoutePattern = 'FcpActionAdmin';

    /**
     * Default Datagrid values
     *
     * @var array
     */
    protected $datagridValues = array(
        '_page' => 1,            // display the first page (default = 1)
        '_sort_order' => 'ASC', // reverse order (default = 'ASC')
        '_sort_by' => 'title'  // name of the ordered field
        // (default = the model's id field, if any)

        // the '_sort_by' key can be of the form 'mySubModel.mySubSubModel.myField'.
    );

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('title')
            ->add('number')
            ->add('financingTypeNum')
            ->add('type')
            ->add('parent', null, ['type' => 'hidden'])
            ->add('versionOwnerId', 'doctrine_orm_callback', [
                'type'     => 'hidden',
                'callback' => array($this, 'getVersionOwnerIdFilter'),
            ])
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('title', 'text', [
                    'template' => 'AdminBundle:CRUD:list__field_filter_parent.html.twig',
                ])
                ->add('number')
                ->add('financingTypeNum')
                ->add('type')
                ->add('fcp.title')
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
            ->add('title')
            ->add('number')
            ->add('financingTypeNum')
            ->add('type',
                'choice',
                array('choices' => array(
                    'task' => 'Задача',
                    'action' => 'Мероприятие',
                    'subaction' => 'Подмероприятие'
                )))
            ->add('versionStartAt')
            ->end()
            ->with('Reference data')
                ->add('parent', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('fcp', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('title')
            ->add('number')
            ->add('financingTypeNum')
            ->add('type')
            ->add('versionStartAt')
            ->add('versionEndAt')
            ->add('versionOwnerId')
        ;
    }

    public function createQuery($context = 'list')
    {
        $query = parent::createQuery($context);
        $filter = $this->request->query->get('filter');
        if (!(isset($filter['parent']) && isset($filter['parent']['value']))) {
            $query->andWhere('o.parent IS NULL');
        }
        return $query;
    }
}
