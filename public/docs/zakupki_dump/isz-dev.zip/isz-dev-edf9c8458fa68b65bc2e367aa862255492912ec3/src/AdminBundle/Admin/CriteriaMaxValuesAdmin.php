<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class CriteriaMaxValuesAdmin extends Admin
{
    public $baseRouteName = 'CriteriaMaxValuesAdmin';
    public $baseRoutePattern = 'CriteriaMaxValuesAdmin';

    /**
     * Default Datagrid values
     *
     * @var array
     */
    protected $datagridValues = array(
        '_page' => 1,            // display the first page (default = 1)
        '_sort_order' => 'ASC', // reverse order (default = 'ASC')
        '_sort_by' => 'criteriaCondition.title'  // name of the ordered field
        // (default = the model's id field, if any)

        // the '_sort_by' key can be of the form 'mySubModel.mySubSubModel.myField'.
    );

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('minValue')
            ->add('maxValue')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('criteriaCondition.title')
                ->add('criteriaType.title')
                ->add('minValue')
                ->add('maxValue')
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('minValue')
                ->add('maxValue')
            ->end()
            ->with('Reference data')
                ->add('criteriaType', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => true,
                    'multiple'     => false,
                ), array('placeholder' => 'No selected'))
                ->add('criteriaCondition', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => true,
                    'multiple'     => false,
                ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('minValue')
            ->add('maxValue')
        ;
    }
}
