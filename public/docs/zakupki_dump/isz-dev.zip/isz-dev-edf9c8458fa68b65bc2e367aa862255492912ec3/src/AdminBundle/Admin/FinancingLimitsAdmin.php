<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;

class FinancingLimitsAdmin extends Admin
{
    public $baseRouteName = 'FinancingLimitsAdmin';
    public $baseRoutePattern = 'FinancingLimitsAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('year')
            ->add('financing')
            ->add('year1')
            ->add('financing1')
            ->add('year2')
            ->add('financing2')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->add('year')
            ->add('financing')
            ->add('year1')
            ->add('financing1')
            ->add('year2')
            ->add('financing2')
            ->add('_action', 'actions', array(
                'actions' => array(
                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                )
            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('year')
                ->add('financing')
                ->add('year1')
                ->add('financing1')
                ->add('year2')
                ->add('financing2')
            ->end()
            ->with('Reference data')
                ->add('kbkSection', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => true,
                    'multiple'     => false,
                ), array('placeholder' => 'No selected'))
                ->add('govProgram', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => true,
                    'multiple'     => false,
                ), array('placeholder' => 'No selected'))
                ->add('subProgramAction', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => true,
                    'multiple'     => false,
                ), array('placeholder' => 'No selected'))
                ->add('fcp', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => true,
                    'multiple'     => false,
                ), array('placeholder' => 'No selected'))
                ->add('fcpAction', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => true,
                    'multiple'     => false,
                ), array('placeholder' => 'No selected'))
                ->add('kbkExpenseType', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => true,
                    'multiple'     => false,
                ), array('placeholder' => 'No selected'))
                ->add('kbkKosgu', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => true,
                    'multiple'     => false,
                ), array('placeholder' => 'No selected'))
                ->add('common', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => true,
                    'multiple'     => false,
                ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('year')
            ->add('financing')
            ->add('year1')
            ->add('financing1')
            ->add('year2')
            ->add('financing2')
        ;
    }
}
