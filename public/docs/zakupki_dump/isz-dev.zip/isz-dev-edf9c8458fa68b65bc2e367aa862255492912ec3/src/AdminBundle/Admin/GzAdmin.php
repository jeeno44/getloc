<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class GzAdmin extends Admin
{
    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('id')
            ->add('gzUser')
            ->add('gzPhoneNuberResp')
            ->add('gzMailResp')
            ->add('gzResp')
            ->add('passPhoneNumber')
            ->add('passAdress')
            ->add('kdExplanationDataStart')
            ->add('kdExplanationDataEnd')
            ->add('gzAgreementName')
            ->add('gzAgreementPosition')
            ->add('gzAgreementExtraPosition')
            ->add('gzApprovName')
            ->add('gzApprovPosition')
            ->add('gzSmpSonk')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->add('id')
            ->add('gzUser')
            ->add('gzPhoneNuberResp')
            ->add('gzMailResp')
            ->add('gzResp')
            ->add('passPhoneNumber')
            ->add('passAdress')
            ->add('kdExplanationDataStart')
            ->add('kdExplanationDataEnd')
            ->add('gzAgreementName')
            ->add('gzAgreementPosition')
            ->add('gzAgreementExtraPosition')
            ->add('gzApprovName')
            ->add('gzApprovPosition')
            ->add('gzSmpSonk')
            ->add('_action', 'actions', array(
                'actions' => array(
                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                )
            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->add('gzUser')
            ->add('gzPhoneNuberResp')
            ->add('gzMailResp')
            ->add('gzResp')
            ->add('passPhoneNumber')
            ->add('passAdress')
            ->add('kdExplanationDataStart')
            ->add('kdExplanationDataEnd')
            ->add('gzAgreementName')
            ->add('gzAgreementPosition')
            ->add('gzAgreementExtraPosition')
            ->add('gzApprovName')
            ->add('gzApprovPosition')
            ->add('gzSmpSonk')
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('id')
            ->add('gzUser')
            ->add('gzPhoneNuberResp')
            ->add('gzMailResp')
            ->add('gzResp')
            ->add('passPhoneNumber')
            ->add('passAdress')
            ->add('kdExplanationDataStart')
            ->add('kdExplanationDataEnd')
            ->add('gzAgreementName')
            ->add('gzAgreementPosition')
            ->add('gzAgreementExtraPosition')
            ->add('gzApprovName')
            ->add('gzApprovPosition')
            ->add('gzSmpSonk')
        ;
    }
}
