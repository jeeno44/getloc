<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class UsersAdmin extends Admin
{
    public $baseRouteName = 'UsersAdmin';
    public $baseRoutePattern = 'UsersAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('name')
            ->add('lastName')
            ->add('patronymic')
            ->add('jobTitle')
            ->add('phone')
            ->add('email')
            ->add('avatar')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('name')
                ->add('lastName')
                ->add('patronymic')
                ->add('jobTitle')
                ->add('phone')
                ->add('email')
                ->add('expertGroup')
                ->add('_action', 'actions', array(
                    'actions' => array(
                        'show'   => array(),
                        'edit'   => array(),
                        'delete' => array(),
                        //'user_info'   => array('template' => 'AdminBundle:Block:user_info.html.twig'),
                    )
                ))
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('name', null, array('required' => true))
                ->add('lastName', null, array('required' => true))
                ->add('patronymic')
                ->add('jobTitle', null, array('required' => true))
                ->add('phone', null, array('required' => true))
                ->add('email', null, array('required' => true))
                ->add('avatar')
                ->add('expertGroup', 'sonata_type_model', array(
                    'required'     => false,
                    'by_reference' => false,
                    'multiple'     => true,
                ), array('placeholder' => 'No selected'))
//            ->add('usersExpertGroups', 'sonata_type_model', array(
//                'required'     => false,
//                'by_reference' => true,
//                'multiple'     => true,
//            ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('name')
            ->add('lastName')
            ->add('patronymic')
            ->add('jobTitle')
            ->add('phone')
            ->add('email')
            ->add('avatar')
            ->add('expertGroup')
        ;
    }
}
