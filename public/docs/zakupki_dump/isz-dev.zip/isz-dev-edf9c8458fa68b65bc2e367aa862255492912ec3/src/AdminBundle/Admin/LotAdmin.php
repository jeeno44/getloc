<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class LotAdmin extends Admin
{
    public $baseRouteName = 'LotAdmin';
    public $baseRoutePattern = 'LotAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('statusId')
            ->add('title')
            ->add('number')
            ->add('goals')
            ->add('tasks')
            ->add('actualityJustification')
            ->add('practicalUsage')
            ->add('expectedResults')
            ->add('nmckMethodOther')
            ->add('nmckJustificationOther')
            ->add('nmckJustification')
            ->add('lotCode')
            ->add('description')
            ->add('minRequirements')
            ->add('quantityFollowingPeriod')
            ->add('prepaymentBidPercentage')
            ->add('prepaymentContractPercentage')
            ->add('procurementStartDate')
            ->add('procurementEndDate')
            ->add('orderPublication')
            ->add('contractExecution')
            ->add('changes')
            ->add('justificationItemTasks')
            ->add('requirements1944')
            ->add('addReqJustification')
            ->add('publDiscussion')
            ->add('addInfo721744')
            ->add('contractNumber')
            ->add('contractDate')
            ->add('preferences282944')
            ->add('govRequirements')
            ->add('docRequirements1444')
            ->add('ridRequirements')
            ->add('applicationPostAddress')
            ->add('applicationCourrierAddress')
            ->add('applicationDateTimeStart')
            ->add('applicationDateTimeEnd')
            ->add('applicationVskrAddress')
            ->add('applicationVskrDateTime')
            ->add('applicationRassmotrDateTime')
            ->add('applicationRassmotrAddress')
            ->add('application1stpartReviewDateEnd')
            ->add('auctionDate')
            ->add('auctionPriceReduction')
            ->add('auctionQuantityChange')
            ->add('auctionQuantityIncrease')
            ->add('docClarificationStartDate')
            ->add('docClarificationEndDate')
            ->add('creationDate')
            ->add('planPriceFollowingPeriod')
            ->add('requirement3044')
            ->add('specificationTasks')
            ->add('specificationContent')
            ->add('specificationDocReq')
            ->add('specificationStageContent')
            ->add('specificationAcceptConditions')
            ->add('nmckUrl')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->add('statusId')
            ->add('title')
            ->add('number')
            ->add('_action', 'actions', array(
                'actions' => array(
                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                )
            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('statusId')
                ->add('title')
                ->add('number')
                ->add('goals')
                ->add('tasks')
                ->add('actualityJustification')
                ->add('practicalUsage')
                ->add('expectedResults')
                ->add('nmckMethodOther')
                ->add('nmckJustificationOther')
                ->add('nmckJustification')
                ->add('lotCode')
                ->add('description')
                ->add('minRequirements')
                ->add('quantityFollowingPeriod')
                ->add('prepaymentBidPercentage')
                ->add('prepaymentContractPercentage')
                ->add('procurementStartDate')
                ->add('procurementEndDate')
                ->add('orderPublication')
                ->add('orderTitle')
                ->add('orderNumber')
                ->add('orderDate')
                ->add('contractExecution')
                ->add('changes')
                ->add('justificationItemTasks')
                ->add('requirements1944')
                ->add('addReqJustification')
                ->add('publDiscussion')
                ->add('addInfo721744')
                ->add('contractNumber')
                ->add('contractDate')
                ->add('preferences282944')
                ->add('govRequirements')
                ->add('docRequirements1444')
                ->add('ridRequirements')
                ->add('applicationPostAddress')
                ->add('applicationCourrierAddress')
                ->add('applicationDateTimeStart')
                ->add('applicationDateTimeEnd')
                ->add('applicationVskrAddress')
                ->add('applicationVskrDateTime')
                ->add('applicationRassmotrDateTime')
                ->add('applicationRassmotrAddress')
                ->add('application1stpartReviewDateEnd')
                ->add('auctionDate')
                ->add('auctionPriceReduction')
                ->add('auctionQuantityChange')
                ->add('auctionQuantityIncrease')
                ->add('docClarificationStartDate')
                ->add('docClarificationEndDate')
                ->add('creationDate')
                ->add('planPriceFollowingPeriod')
                ->add('requirement3044')
            ->end()
            ->with('Reference data')
                ->add('common', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('lotDoc', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('marketplace', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('supplier', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('kbk', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('nks', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->add('govProgram', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
            ), array('placeholder' => 'No selected'))
                ->add('subProgramAction', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->add('subProgram', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
            ), array('placeholder' => 'No selected'))
            ->add('SubProgramMainAction', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
            ), array('placeholder' => 'No selected'))
                ->add('procResp', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->add('stage', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
            ), array('placeholder' => 'No selected'))
            ->add('lotDoc', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
            ), array('placeholder' => 'No selected'))
                ->add('expenseType', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('project', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('fcpAction', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->add('fcpActionTask', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
            ), array('placeholder' => 'No selected'))
            ->add('fcpActionSubaction', 'sonata_type_model', array(
                'required'     => false,
                'by_reference' => true,
                'multiple'     => false,
            ), array('placeholder' => 'No selected'))
                ->add('okei', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('procurementType', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('okved', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('okpd', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('nmckJustification2', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('procurementCause', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('rateIndicator', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => true,
                                ), array('placeholder' => 'No selected', 'admin_code' => 'admin.admin.indicator'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('statusId')
            ->add('title')
            ->add('number')
            ->add('goals')
            ->add('tasks')
            ->add('actualityJustification')
            ->add('practicalUsage')
            ->add('expectedResults')
            ->add('nmckMethodOther')
            ->add('nmckJustificationOther')
            ->add('nmckJustification')
            ->add('lotCode')
            ->add('description')
            ->add('minRequirements')
            ->add('quantityFollowingPeriod')
            ->add('prepaymentBidPercentage')
            ->add('prepaymentContractPercentage')
            ->add('procurementStartDate')
            ->add('procurementEndDate')
            ->add('orderPublication')
            ->add('contractExecution')
            ->add('changes')
            ->add('justificationItemTasks')
            ->add('requirements1944')
            ->add('addReqJustification')
            ->add('publDiscussion')
            ->add('addInfo721744')
            ->add('contractNumber')
            ->add('contractDate')
            ->add('preferences282944')
            ->add('govRequirements')
            ->add('docRequirements1444')
            ->add('ridRequirements')
            ->add('applicationPostAddress')
            ->add('applicationCourrierAddress')
            ->add('applicationDateTimeStart')
            ->add('applicationDateTimeEnd')
            ->add('applicationVskrAddress')
            ->add('applicationVskrDateTime')
            ->add('applicationRassmotrDateTime')
            ->add('applicationRassmotrAddress')
            ->add('application1stpartReviewDateEnd')
            ->add('auctionDate')
            ->add('auctionPriceReduction')
            ->add('auctionQuantityChange')
            ->add('auctionQuantityIncrease')
            ->add('docClarificationStartDate')
            ->add('docClarificationEndDate')
            ->add('creationDate')
            ->add('planPriceFollowingPeriod')
            ->add('requirement3044')
        ;
    }
}
