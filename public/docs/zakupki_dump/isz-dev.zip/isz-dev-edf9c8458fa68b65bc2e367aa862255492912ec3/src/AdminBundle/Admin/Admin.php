<?php
namespace AdminBundle\Admin;

use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Route\RouteCollection;

class Admin extends \Sonata\AdminBundle\Admin\Admin
{
    protected $_class;

    public function __construct($code, $class, $baseControllerName)
    {
        parent::__construct($code, $class, $baseControllerName);
        $this->_class = $class;
    }

    /**
     * {@inheritdoc}
     */
    public function prePersist($object)
    {
        $this->getModelManager()->getEntityManager($this->getClass())->beginTransaction();
    }

    /**
     * {@inheritdoc}
     */
    public function postPersist($object)
    {
        $this->getModelManager()->getEntityManager($this->getClass())->commit();
    }

    /**
     * @param MenuItemInterface $menu
     * @param $action
     * @param AdminInterface $childAdmin
     */
    protected function configureTabMenu(MenuItemInterface $menu, $action, AdminInterface $childAdmin = null)
    {

    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        if (method_exists($this->getClass(), 'getVersionStartAt')) {
            if (!$listMapper->has('versionStartAt')) {
                $listMapper->add('versionStartAt', null, ['label' => 'Дата начала версии']);
            }
            if (!$listMapper->has('_action')) {
                $listMapper->add('_action', 'actions', [
                        'actions' => [
                            'show'   => [],
                            'edit'   => [],
                            'delete' => [],
                        ]
                    ]
                );
            }
            $options = $listMapper->get('_action')->getOptions('actions');
            $options['actions']+= [
                'Clone' => array(
                    'template' => 'AdminBundle:CRUD:list__action_clone.html.twig'
                ),
                'Versions' => array(
                    'template' => 'AdminBundle:CRUD:list__action_versions.html.twig'
                ),
            ];
            $listMapper->get('_action')->setOptions($options);
        }
    }

    protected function configureRoutes(RouteCollection $collection)
    {
        if (method_exists($this->getClass(), 'getVersionStartAt')) {
            $collection->add('clone', $this->getRouterIdParameter() . '/clone');
            $collection->add('versions', $this->getRouterIdParameter() . '/versions');
        }
    }

    public function createQuery($context = 'list')
    {
        $query = parent::createQuery($context);
        if (method_exists($this->getClass(), 'getVersionStartAt')) {
            $filter = $this->request->query->get('filter');
            if (!(isset($filter['versionOwnerId']) && isset($filter['versionOwnerId']['value']))) {
                $query->andWhere('o.versionEndAt IS NULL');
            }
        }
        return $query;
    }

    /**
     * {@inheritdoc}
     */
    public function getSubject()
    {
        if ($this->subject === null && $this->request) {
            $id = $this->request->get($this->getIdParameter());
            if (!preg_match('#^[0-9A-Fa-f\-]+$#', $id)) {
                $this->subject = false;
            } else {
                $this->subject = $this->getModelManager()->find($this->_class, $id);
            }
        }

        return $this->subject;
    }

    /**
     * @param \Sonata\DoctrineORMAdminBundle\Datagrid\ProxyQuery $queryBuilder
     * @param string $alias
     * @param string $field
     * @param string $value
     *
     * @return bool|void
     */
    public function getVersionOwnerIdFilter($queryBuilder, $alias, $field, $value)
    {
        if (!$value['value']) {
            return;
        }

        /** @var \Doctrine\ORM\Query\Expr $expr */
        $expr = $queryBuilder->expr();

        $queryBuilder->andWhere($expr->eq($alias.'.versionOwnerId', $expr->literal($value['value'])));

        return true;
    }
}