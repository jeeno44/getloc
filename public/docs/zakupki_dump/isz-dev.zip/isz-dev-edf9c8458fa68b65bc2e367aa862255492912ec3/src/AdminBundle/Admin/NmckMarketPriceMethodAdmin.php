<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class NmckMarketPriceMethodAdmin extends Admin
{
    public $baseRouteName = 'NmckMarketPriceMethodAdmin';
    public $baseRoutePattern = 'NmckMarketPriceMethodAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('coefValue')
            ->add('price')
            ->add('date')
            ->add('information')
            ->add('quantity')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('coefValue')
                ->add('price')
                ->add('date')
                ->add('information')
                ->add('quantity')
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('coefValue')
                ->add('price')
                ->add('date')
                ->add('information')
                ->add('quantity')
                //->add('versionStartAt')
            ->end()
            ->with('Reference data')
                ->add('nmckVariant', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('correspondance', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('procurementType', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('infoSource', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('coefValue')
            ->add('price')
            ->add('date')
            ->add('information')
            ->add('quantity')
            ->add('versionStartAt')
            ->add('versionEndAt')
            ->add('versionOwnerId')
        ;
    }
}
