<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use AnalyticsBundle\Entity\RateIndicator;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;

class RateIndicatorAdmin extends Admin
{
    public $baseRouteName = 'RateIndicatorAdmin';
    public $baseRoutePattern = 'RateIndicatorAdmin';
    static $type = null;

    /**
     * Default Datagrid values
     *
     * @var array
     */
    protected $datagridValues = array(
        '_page'       => 1,            // display the first page (default = 1)
        '_sort_order' => 'ASC', // reverse order (default = 'ASC')
        '_sort_by'    => 'title'  // name of the ordered field
        // (default = the model's id field, if any)

        // the '_sort_by' key can be of the form 'mySubModel.mySubSubModel.myField'.
    );

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('endDate')
            ->add('title')
            ->add('startDate')
            ->add('refValue')
            ->add('minValue')
            ->add('maxValue')
            ->add('parent')
            ->add('versionOwnerId', 'doctrine_orm_callback', [
                'type'     => 'hidden',
                'callback' => array($this, 'getVersionOwnerIdFilter'),
            ])
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->add('endDate')
            ->add('title', 'text', [
                'template' => 'AdminBundle:CRUD:list__field_filter_parent.html.twig',
            ])
            ->add('startDate')
            ->add('refValue')
            ->add('minValue')
            ->add('maxValue')
            ->add('_action', 'actions', array(
                'actions' => array(
                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                )
            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $type = static::$type;
        $formMapper
            ->with('General')
                ->add('endDate')
                ->add('title')
                ->add('type', 'hidden', array('data' => static::$type))
                ->add('startDate')
                ->add('refValue')
                ->add('minValue')
                ->add('maxValue')
                ->add('versionStartAt')
            ->end()
            ->with('Reference data')
                ->add(
                    'govProgram',
                    'sonata_type_model',
                    array(
                        'required'     => false,
                        'by_reference' => true,
                        'multiple'     => false,
                    )
                )
                ->add(
                    'subProgramAction',
                    'sonata_type_model',
                    array(
                        'required'     => false,
                        'by_reference' => true,
                        'multiple'     => false,
                    )
                )
                ->add(
                    'fcp',
                    'sonata_type_model',
                    array(
                        'required'     => false,
                        'by_reference' => true,
                        'multiple'     => false,
                    )
                )
                ->add(
                    'fcpAction',
                    'sonata_type_model',
                    array(
                        'required'     => false,
                        'by_reference' => true,
                        'multiple'     => false,
                    )
                )
                ->add(
                    'okei',
                    'sonata_type_model',
                    array(
                        'required'     => false,
                        'by_reference' => true,
                        'multiple'     => false,
                    )
                )
                ->add(
                    'parent',
                    null,
                    array(
                        'required'      => false,
                        'by_reference'  => true,
                        'multiple'      => false,
                        'query_builder' => function(\Doctrine\ORM\EntityRepository $er) use ($type) {
                            return
                                $er->createQueryBuilder('p')
                                    ->where('p.type = :type')
                                    ->setParameter('type', static::$type);
                        }
                    ), array(
                        'admin_code' => 'admin.admin.' . static::$type,
                    )
                )
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('endDate')
            ->add('title')
            ->add('type', 'choice', array('choices' => RateIndicator::$types_list))
            ->add('startDate')
            ->add('refValue')
            ->add('minValue')
            ->add('maxValue')
        ;
    }

    public function createQuery($context = 'list')
    {
        $query = parent::createQuery($context);
        $filter = $this->request->query->get('filter');
        if (!(isset($filter['parent']) && isset($filter['parent']['value']))) {
            $query->andWhere('o.parent IS NULL');
        }
        return $query;
    }
}
