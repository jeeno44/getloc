<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;

class EventManagementAdmin extends Admin
{
    public $baseRouteName = 'EventManagementAdmin';
    public $baseRoutePattern = 'EventManagementAdmin';

    /**
     * Default Datagrid values
     *
     * @var array
     */
    protected $datagridValues = array(
        '_page'       => 1,
        '_sort_order' => 'DESC', // reverse order (default = 'ASC')
    );

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('statusTypeObject')
            ->add('statusStart')
            ->add('statusEnd')
            ->add('typeDays')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->add('statusTypeObject')
            ->add('statusStart')
            ->add('statusEnd')
            ->add('days')
            ->add('typeDays')
            ->add('_action', 'actions', array(
                'actions' => array(
                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                )
            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('statusTypeObject')
                ->add('statusStart')
                ->add('statusEnd')
                ->add('days', null, array('required' => false))
                ->add('typeDays', null, array('required' => false))
                ->add('comment', null, array('required' => false))
                ->add('options', null, array('required' => false))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('typeObject')
            ->add('id')
            ->add('statusStart')
            ->add('statusEnd')
            ->add('days')
            ->add('typeDays')
            ->add('comment')
            ->add('options')
        ;
    }
}
