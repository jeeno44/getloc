<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class SupplierAdmin extends Admin
{
    public $baseRouteName = 'SupplierAdmin';
    public $baseRoutePattern = 'SupplierAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('fullName')
            ->add('shortName')
            ->add('federalDistrict')
            ->add('factAddress')
            ->add('postAddress')
            ->add('inn')
            ->add('kpp')
            ->add('ogrn')
            ->add('ogrnip')
            ->add('dateOgrn')
            ->add('bik')
            ->add('bankName')
            ->add('bankAccount')
            ->add('corrAccount')
            ->add('okpo')
            ->add('oktmo')
            ->add('phone')
            ->add('email')
            ->add('winner')
            ->add('serialNumber')
            ->add('authority')
            ->add('type')
            ->add('foreignComp')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('fullName')
                ->add('shortName')
                ->add('federalDistrict')
                ->add('factAddress')
                ->add('postAddress')
                ->add('inn')
                ->add('kpp')
                ->add('ogrn')
                ->add('ogrnip')
                ->add('dateOgrn')
                ->add('bik')
                ->add('bankName')
                ->add('bankAccount')
                ->add('corrAccount')
                ->add('okpo')
                ->add('oktmo')
                ->add('phone')
                ->add('email')
                ->add('winner')
                ->add('serialNumber')
                ->add('authority')
                ->add('type')
                ->add('foreignComp')
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('fullName')
                ->add('shortName')
                ->add('federalDistrict')
                ->add('factAddress')
                ->add('postAddress')
                ->add('inn')
                ->add('kpp')
                ->add('ogrn')
                ->add('ogrnip')
                ->add('dateOgrn')
                ->add('bik')
                ->add('bankName')
                ->add('bankAccount')
                ->add('corrAccount')
                ->add('okpo')
                ->add('oktmo')
                ->add('phone')
                ->add('email')
                ->add('winner')
                ->add('serialNumber')
                ->add('authority')
                ->add('type')
                ->add('foreignComp')
                //->add('versionStartAt')
            ->end()
            ->with('Reference data')
                ->add('bankGaurantee', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('head', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('okopf', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('okved', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('fullName')
            ->add('shortName')
            ->add('federalDistrict')
            ->add('factAddress')
            ->add('postAddress')
            ->add('inn')
            ->add('kpp')
            ->add('ogrn')
            ->add('ogrnip')
            ->add('dateOgrn')
            ->add('bik')
            ->add('bankName')
            ->add('bankAccount')
            ->add('corrAccount')
            ->add('okpo')
            ->add('oktmo')
            ->add('phone')
            ->add('email')
            ->add('winner')
            ->add('serialNumber')
            ->add('authority')
            ->add('type')
            ->add('foreignComp')
            ->add('versionStartAt')
            ->add('versionEndAt')
            ->add('versionOwnerId')
        ;
    }
}
