<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Route\RouteCollection;

class ProcurementTypeAdmin extends Admin
{
    public $baseRouteName = 'ProcurementTypeAdmin';
    public $baseRoutePattern = 'ProcurementTypeAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('description')
            ->add('code')
            ->add('coefMaxValue')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields(
            $listMapper
                ->add('description')
                ->add('code')
                ->add('coefMaxValue')
        );
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('description')
                ->add('code')
                ->add('coefMaxValue')
                //->add('versionStartAt')
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('description')
            ->add('code')
            ->add('coefMaxValue')
            ->add('versionStartAt')
            ->add('versionEndAt')
            ->add('versionOwnerId')
        ;
    }
}
