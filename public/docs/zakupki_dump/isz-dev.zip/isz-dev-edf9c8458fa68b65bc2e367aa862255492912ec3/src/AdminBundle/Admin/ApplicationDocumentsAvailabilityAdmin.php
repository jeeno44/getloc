<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;

class ApplicationDocumentsAvailabilityAdmin extends Admin
{
    public $baseRouteName = 'ApplicationDocumentsAvailabilityAdmin';
    public $baseRoutePattern = 'ApplicationDocumentsAvailabilityAdmin';

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('availability')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->add('availability')
            ->add('_action', 'actions', array(
                'actions' => array(
                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                )
            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('availability')
            ->end()
            ->with('Reference data')
                ->add('application', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
                ->add('documents', 'sonata_type_model', array(
                                    'required'     => false,
                                    'by_reference' => true,
                                    'multiple'     => false,
                                ), array('placeholder' => 'No selected'))
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('availability')
        ;
    }
}
