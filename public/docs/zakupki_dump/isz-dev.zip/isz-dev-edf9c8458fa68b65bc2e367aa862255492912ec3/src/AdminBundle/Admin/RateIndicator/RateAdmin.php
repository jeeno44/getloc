<?php

namespace AdminBundle\Admin\RateIndicator;

use AnalyticsBundle\Entity\RateIndicator;
use AdminBundle\Admin\RateIndicatorAdmin;

/**
 * Class RateAdmin
 * @package AdminBundle\Admin\RateIndicator
 */
class RateAdmin extends RateIndicatorAdmin
{
    /**
     * @var string
     */
    public $baseRouteName = 'RateAdmin';

    /**
     * @var string
     */
    public $baseRoutePattern = 'RateAdmin';

    /**
     * @var string
     */
    static $type = RateIndicator::TYPE_RATE;

    /**
     * @param string $context
     * @return \Sonata\AdminBundle\Datagrid\ProxyQueryInterface
     */
    public function createQuery($context = 'list')
    {
        $query = parent::createQuery($context);
        if ($context == 'list') {
            $query->andWhere("o.type='".RateIndicator::TYPE_RATE."'");
        }

        return $query;
    }
}
