<?php

namespace AdminBundle\Admin;

use AdminBundle\Admin\Admin;
use AnalyticsBundle\Entity\Status;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Sonata\AdminBundle\Admin\AdminInterface;

class StatusAdmin extends Admin
{
    public $baseRouteName = 'StatusAdmin';
    public $baseRoutePattern = 'StatusAdmin';

    /**
     * Default Datagrid values
     *
     * @var array
     */
    protected $datagridValues = array(
        '_page'       => 1,
        '_sort_order' => 'DESC', // reverse order (default = 'ASC')
        '_sort_by' => 'typeObject'
    );

    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('typeObject')
            ->add('subSystem')
            ->add('id')
            ->add('title')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->add('typeObject')
            ->add('subSystem')
            ->add('id')
            ->add('title')
            ->add('_action', 'actions', array(
                'actions' => array(
                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                )
            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('id')
                ->add('typeObject', 'choice', [
                    'choices'  => Status::$objectTypeList,
                    'required' => true,
                ])
                ->add('subSystem', 'choice', [
                    'choices'  => Status::$subSystemList,
                    'required' => true,
                ])
                ->add('title')
            ->end()
        ;
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('typeObject')
            ->add('subSystem')
            ->add('id')
            ->add('title')
        ;
    }
}
