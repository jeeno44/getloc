<?php

namespace AdminBundle\Command;

use AnalyticsBundle\Entity\NotifyHistory;
use OldSound\RabbitMqBundle\RabbitMq\Producer;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use AnalyticsBundle\Entity\Notify;
use AnalyticsBundle\Entity\Rules;

class SendNotifyCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('notify:send')
            ->setDescription('Send notification for users');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln('==> Start work script');
        $em = $this->getContainer()->get('doctrine')->getManager('analytics');

        $output->writeln('============================');
        $output->writeln('~ Check entity Lot ~');
        $output->writeln('============================');
        $this->checkItem($output, $em, Rules::TYPE_LOT);

        $output->writeln('============================');
        $output->writeln('~ Check entity Plan ~');
        $output->writeln('============================');
        $this->checkItem($output, $em, Rules::TYPE_PLAN);

        $output->writeln('============================');
        $output->writeln('~ Check entity Protocol2 ~');
        $output->writeln('============================');
        $this->checkItem($output, $em, Rules::TYPE_PROTOCOL);

        $output->writeln('============================');
        $output->writeln('~ Check entity StateContract ~');
        $output->writeln('============================');
        $this->checkItem($output, $em, Rules::TYPE_CONTRACT);
    }

    /**
     * @param OutputInterface $output
     * @param $em
     * @param string $type
     */
    private function checkItem(OutputInterface $output, $em, $type)
    {
        $notifyLots = $em->getRepository('AnalyticsBundle:Notify')->getNotifyByType($type);
        foreach ($notifyLots as $notify) {
            $rules = $notify->getRules();
            $roles = $notify->getRoles();
            $periods = $notify->getPeriods();
            $users = $this->getUsersData($notify, $roles, $em);
            $items = $this->getEntityItems($type, $em, $notify);
            $days = [];
            foreach ($periods as $period) {
                $days[] = $period->getValue();
            }

            if ($rules) {
                foreach ($items as $item) {
                    if ($this->checkNotifyHistory($notify, $em, $type, $item->getId(), $days)) {
                        $sendNotify = true;
                        foreach ($rules as $rule) {
                            $field = $rule->getField();
                            $data = $em
                                ->getRepository('AnalyticsBundle\Entity\\' . $rule->getType())
                                ->getDataByField($field, $item->getId());
                            if ($data) {
                                if (is_a($data[$field], 'DateTime')) {
                                    $val = new \DateTime($rule->getValue());
                                } else {
                                    $val = $rule->getValue();
                                }

                                switch ($rule->getSymbol()) {
                                    case Rules::SYMBOL_MIN:
                                        if (is_a($data[$field], 'DateTime')) {
                                            if (!$this->checkByMinDate($days, $data[$field])) {
                                                $sendNotify = false;
                                            }
                                        } else {
                                            if ($data[$field] >= $val) {
                                                $sendNotify = false;
                                            }
                                        }
                                        break;
                                    case Rules::SYMBOL_MAX:
                                        if (is_a($data[$field], 'DateTime')) {
                                            if (!$this->checkByMaxDate($days, $data[$field])) {
                                                $sendNotify = false;
                                            }
                                        } else {
                                            if ($data[$field] <= $val) {
                                                $sendNotify = false;
                                            }
                                        }
                                        break;
                                    case Rules::SYMBOL_EQUALLY:
                                        if ($data[$field] < $val || $data[$field] > $val) {
                                            $sendNotify = false;
                                        }
                                        break;
                                }
                            }
                        }

                        if ($sendNotify) {
                            $this->notify($output, $users, $notify);
                            $this->addNotifyHistory($notify, $item->getId(), $type, $em);
                        }
                    }
                }

            }
        }

    }

    /**
     * @param OutputInterface $output
     * @param array $users
     * @param Notify $notify
     * @throws Exception
     */
    private function notify(OutputInterface $output, $users, $notify)
    {
        $text = $notify->getSms()->getBody();
        $subject = $notify->getEmail()->getSubject();
        $body = $notify->getEmail()->getBody();
        $sendFrom = $notify->getEmail()->getTitle();

        foreach ($users as $user) {
            $this->getContainer()->get('notify_manager_service')->sendNotify($sendFrom, $user['email'], $subject,
                $body);
            $this->getContainer()->get('notify_manager_service')->sendSms($user['phone'], $text);
            $output->writeln('Send email to '. $user['email']);
            $output->writeln('Send sms to '. $user['phone']);
        }
    }


    /**
     * @param array $notify
     * @param array $roles
     * @param $em
     * @return mixed
     */
    private function getUsersData($notify, $roles, $em)
    {
        $rolesNames = [];
        foreach ($roles as $role) {
            $rolesNames[] = $role->getName();
        }
        $commonId = $notify->getCommon()->getId();
        $expertGroup = $em->getRepository('AnalyticsBundle:ExpertGroup')->findByCommon($commonId);
        $expertGroupId = [];
        foreach ($expertGroup as $group) {
            $expertGroupId[] = $group->getId();
        }

        return $em->getRepository('AnalyticsBundle:UsersExpertGroup')
            ->getEmailByExpertGroup($expertGroupId, $rolesNames);
    }

    /**
     * @param string $type
     * @param $em
     * @param Notify $notify
     * @return mixed
     */
    private function getEntityItems($type, $em, $notify)
    {
        switch ($type) {
            case Rules::TYPE_LOT:
                $items = $em
                    ->getRepository('AnalyticsBundle:Lot')
                    ->findByCommon($notify->getCommon()->getId());
                break;
            case Rules::TYPE_CONTRACT:
                $items = $em
                    ->getRepository('AnalyticsBundle:StateContract')
                    ->getContractByCommonId($notify->getCommon()->getId());
                break;
            case Rules::TYPE_PLAN:
                $items = $em
                    ->getRepository('AnalyticsBundle:Plan')
                    ->findByCommon($notify->getCommon()->getId());
                break;
            case Rules::TYPE_PROTOCOL:
                $items = $em
                    ->getRepository('AnalyticsBundle:Protocol2')
                    ->getContractByCommonId($notify->getCommon()->getId());
                break;
        }

        return $items;
    }

    /**
     * @param array $days
     * @param DateTime $val
     * @return bool
     */
    private function checkByMaxDate($days, $val)
    {
        $result = false;
        foreach ($days as $day) {
            $dateInterval = '+'. $day . ' day';
            $date = new \DateTime();
            $val->modify($dateInterval);
            $format = 'Y-m-d';
            $date1  = \DateTime::createFromFormat($format, $val->format('Y-m-d'));
            $date2  = \DateTime::createFromFormat($format, $date->format('Y-m-d'));

            if ($date1 == $date2) {
                $result = true;
                continue;
            }
        }

        return $result;

    }

    /**
     * @param array $days
     * @param DateTime $val
     * @return bool
     */
    private function checkByMinDate($days, $val)
    {
        $result = false;
        foreach ($days as $day) {
            $dateInterval = '-'. $day . ' day';
            $date = new \DateTime();
            $val->modify($dateInterval);
            $format = 'Y-m-d';
            $date1  = \DateTime::createFromFormat($format, $val->format('Y-m-d'));
            $date2  = \DateTime::createFromFormat($format, $date->format('Y-m-d'));

            if ($date1 == $date2) {
                $result = true;
                continue;
            }
        }

        return $result;
    }

    /**
     * @param string $notify
     * @param $em
     * @param string $type
     * @param string $entity
     * @param array $days
     * @return bool
     */
    private function checkNotifyHistory($notify, $em, $type, $entity, $days)
    {
        $history = $em
            ->getRepository('AnalyticsBundle:NotifyHistory')
            ->findBy(
                [
                    'notify' => $notify,
                    'type' => $type,
                    'entity' => $entity
                ],
                [
                    'createdAt' => 'DESC'
                ],
                1
            );

        if ($history) {
            $date = $history[0]->getCreatedAt();
            $result = $this->checkByMaxDate($days, $date);
        } else {
            $result = true;
        }

        return $result;
    }

    /**
     * @param Notify $notify
     * @param string $entity
     * @param string $type
     * @param $em
     */
    private function addNotifyHistory(Notify $notify, $entity, $type, $em)
    {
        $notifyHistory = new NotifyHistory();
        $notifyHistory->setNotify($notify);
        $notifyHistory->setEntity($entity);
        $notifyHistory->setType($type);

        $em->persist($notifyHistory);
        $em->flush();
    }
}