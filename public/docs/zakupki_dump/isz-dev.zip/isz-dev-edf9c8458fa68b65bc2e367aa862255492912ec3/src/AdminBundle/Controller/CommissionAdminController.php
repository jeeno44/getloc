<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class CommissionAdminController
 * @package AdminBundle\Controller
 */
class CommissionAdminController extends BaseCRUDController
{

}
