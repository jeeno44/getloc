<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class LotAdminController
 * @package AdminBundle\Controller
 */
class LotAdminController extends BaseCRUDController
{

}
