<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class OkogyAdminController
 * @package AdminBundle\Controller
 */
class OkogyAdminController extends BaseCRUDController
{

}
