<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class LotDocAdminController
 * @package AdminBundle\Controller
 */
class LotDocAdminController extends BaseCRUDController
{

}
