<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Class FcpActionAdminController
 * @package AdminBundle\Controller
 */
class FcpActionAdminController extends BaseCRUDController
{
}
