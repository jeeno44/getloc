<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class DefaultCriteriaRatingAdminController
 * @package AdminBundle\Controller
 */
class DefaultCriteriaRatingAdminController extends BaseCRUDController
{

}
