<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class Protocol2CriteriaAdminController
 * @package AdminBundle\Controller
 */
class Protocol2CriteriaAdminController extends BaseCRUDController
{

}
