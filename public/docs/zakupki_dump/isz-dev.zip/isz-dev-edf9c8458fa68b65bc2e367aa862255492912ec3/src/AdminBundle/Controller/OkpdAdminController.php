<?php
namespace AdminBundle\Controller;

use AnalyticsBundle\Entity\Okpd;
use AdminBundle\Controller\CRUDController as BaseCRUDController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\HttpFoundation\Response;

/**
 * Class OkpdAdminController
 * @package AdminBundle\Controller
 */
class OkpdAdminController extends BaseCRUDController
{
    public function cloneAction()
    {
        /** @var Okpd $object */
        $object = $this->admin->getSubject();

        if (!$object) {
            throw new NotFoundHttpException(sprintf('unable to find the object with id : %s', $object->getVersionOwnerId()));
        }

        $clonedObject = clone $object;  // Careful, you may need to overload the __clone method of your object
        // to set its id to null
        $clonedObject->setVersionStartAt(new \DateTime());
        $clonedObject->setVersionEndAt(null);

        $this->admin->create($clonedObject);

        $this->addFlash('sonata_flash_success', 'Cloned successfully');

        return new RedirectResponse($this->admin->generateUrl('list'));
    }

    /**
     * List action
     *
     * @return Response
     *
     * @throws AccessDeniedException If access is not granted
     */
    public function versionsAction()
    {
        /** @var Okpd $object */
        $object = $this->admin->getSubject();

        //$this->admin->getFilterParameters()
        $this->admin->getRequest()->query->set('filter', array(
            'versionOwnerId' => array(
                'value' => $object->getVersionOwnerId(),
            ),
            '_sort_order' => 'DESC', // reverse order (default = 'ASC')
            '_sort_by' => 'versionStartAt',  // name of the ordered field
        ));

        if (false === $this->admin->isGranted('LIST')) {
            throw new AccessDeniedException();
        }

        $datagrid = $this->admin->getDatagrid();
        $formView = $datagrid->getForm()->createView();

        // set the theme for the current Admin Form
        $this->get('twig')->getExtension('form')->renderer->setTheme($formView, $this->admin->getFilterTheme());

        return $this->render($this->admin->getTemplate('list'), array(
            'action'     => 'list',
            'form'       => $formView,
            'datagrid'   => $datagrid,
            'csrf_token' => $this->getCsrfToken('sonata.batch'),
        ));
    }
}
