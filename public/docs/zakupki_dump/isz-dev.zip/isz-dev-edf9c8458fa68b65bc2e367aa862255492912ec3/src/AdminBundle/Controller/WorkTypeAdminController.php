<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class WorkTypeAdminController
 * @package AdminBundle\Controller
 */
class WorkTypeAdminController extends BaseCRUDController
{

}
