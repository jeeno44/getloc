<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class IntermediateEventAdminController
 * @package AdminBundle\Controller
 */
class IntermediateEventAdminController extends BaseCRUDController
{

}
