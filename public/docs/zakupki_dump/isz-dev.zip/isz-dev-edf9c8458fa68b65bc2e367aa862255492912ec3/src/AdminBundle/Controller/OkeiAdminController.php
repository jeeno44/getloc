<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class OkeiAdminController
 * @package AdminBundle\Controller
 */
class OkeiAdminController extends BaseCRUDController
{

}
