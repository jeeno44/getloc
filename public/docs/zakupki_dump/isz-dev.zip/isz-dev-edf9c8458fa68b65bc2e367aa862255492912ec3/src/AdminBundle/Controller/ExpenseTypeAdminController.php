<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class ExpenseTypeAdminController
 * @package AdminBundle\Controller
 */
class ExpenseTypeAdminController extends BaseCRUDController
{

}
