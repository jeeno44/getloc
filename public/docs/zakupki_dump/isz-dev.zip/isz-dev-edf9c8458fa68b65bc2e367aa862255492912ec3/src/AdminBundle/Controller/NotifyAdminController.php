<?php

namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

class NotifyAdminController extends BaseCRUDController
{

}