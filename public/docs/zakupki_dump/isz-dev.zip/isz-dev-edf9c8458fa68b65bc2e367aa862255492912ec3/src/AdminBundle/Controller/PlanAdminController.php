<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class PlanAdminController
 * @package AdminBundle\Controller
 */
class PlanAdminController extends BaseCRUDController
{

}
