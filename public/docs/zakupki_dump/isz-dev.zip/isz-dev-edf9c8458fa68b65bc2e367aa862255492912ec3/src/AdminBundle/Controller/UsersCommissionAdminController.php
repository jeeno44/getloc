<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class UsersCommissionAdminController
 * @package AdminBundle\Controller
 */
class UsersCommissionAdminController extends BaseCRUDController
{

}
