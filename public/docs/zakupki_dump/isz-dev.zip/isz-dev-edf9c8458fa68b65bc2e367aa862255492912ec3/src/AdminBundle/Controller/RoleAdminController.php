<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class RoleAdminController
 * @package AdminBundle\Controller
 */
class RoleAdminController extends BaseCRUDController
{

}
