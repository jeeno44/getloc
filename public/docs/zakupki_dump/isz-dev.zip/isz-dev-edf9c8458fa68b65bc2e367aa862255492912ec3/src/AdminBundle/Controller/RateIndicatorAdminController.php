<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class RateIndicatorAdminController
 * @package AdminBundle\Controller
 */
class RateIndicatorAdminController extends BaseCRUDController
{

}
