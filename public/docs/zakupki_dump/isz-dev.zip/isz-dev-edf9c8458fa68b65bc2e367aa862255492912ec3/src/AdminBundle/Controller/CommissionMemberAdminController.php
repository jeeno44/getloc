<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class CommissionMemberAdminController
 * @package AdminBundle\Controller
 */
class CommissionMemberAdminController extends BaseCRUDController
{

}
