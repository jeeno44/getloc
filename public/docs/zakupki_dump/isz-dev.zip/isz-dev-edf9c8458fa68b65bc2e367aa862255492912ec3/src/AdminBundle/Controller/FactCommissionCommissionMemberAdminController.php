<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class FactCommissionCommissionMemberAdminController
 * @package AdminBundle\Controller
 */
class FactCommissionCommissionMemberAdminController extends BaseCRUDController
{

}
