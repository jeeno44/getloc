<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class FcpAdminController
 * @package AdminBundle\Controller
 */
class FcpAdminController extends BaseCRUDController
{

}
