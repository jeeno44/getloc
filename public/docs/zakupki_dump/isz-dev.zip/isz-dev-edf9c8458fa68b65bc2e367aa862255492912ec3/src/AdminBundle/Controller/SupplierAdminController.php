<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class SupplierAdminController
 * @package AdminBundle\Controller
 */
class SupplierAdminController extends BaseCRUDController
{

}
