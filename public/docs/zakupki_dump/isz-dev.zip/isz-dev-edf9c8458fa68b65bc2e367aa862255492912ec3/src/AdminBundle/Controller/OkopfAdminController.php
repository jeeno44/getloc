<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class OkopfAdminController
 * @package AdminBundle\Controller
 */
class OkopfAdminController extends BaseCRUDController
{

}
