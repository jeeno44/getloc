<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class FinancingLimitsAdminController
 * @package AdminBundle\Controller
 */
class FinancingLimitsAdminController extends BaseCRUDController
{

}
