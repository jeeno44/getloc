<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class CommissionCommissionMemberAdminController
 * @package AdminBundle\Controller
 */
class CommissionCommissionMemberAdminController extends BaseCRUDController
{

}
