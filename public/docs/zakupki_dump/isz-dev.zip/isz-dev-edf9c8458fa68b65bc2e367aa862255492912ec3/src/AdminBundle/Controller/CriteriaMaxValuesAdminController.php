<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class CriteriaMaxValuesAdminController
 * @package AdminBundle\Controller
 */
class CriteriaMaxValuesAdminController extends BaseCRUDController
{

}
