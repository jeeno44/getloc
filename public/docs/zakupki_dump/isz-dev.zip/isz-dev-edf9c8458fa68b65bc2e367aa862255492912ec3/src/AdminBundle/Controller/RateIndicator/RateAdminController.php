<?php
namespace AdminBundle\Controller\RateIndicator;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class RateAdminController
 * @package AdminBundle\Controller\RateIndicator
 */
class RateAdminController extends BaseCRUDController
{

}
