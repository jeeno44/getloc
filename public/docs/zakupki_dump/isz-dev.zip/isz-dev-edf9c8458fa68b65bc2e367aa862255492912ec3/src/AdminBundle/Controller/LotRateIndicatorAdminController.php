<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class LotRateIndicatorAdminController
 * @package AdminBundle\Controller
 */
class LotRateIndicatorAdminController extends BaseCRUDController
{

}
