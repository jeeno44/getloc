<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class InfoSourceAdminController
 * @package AdminBundle\Controller
 */
class InfoSourceAdminController extends BaseCRUDController
{

}
