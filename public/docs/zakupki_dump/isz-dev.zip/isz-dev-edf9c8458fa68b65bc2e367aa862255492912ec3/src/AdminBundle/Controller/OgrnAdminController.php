<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class OgrnAdminController
 * @package AdminBundle\Controller
 */
class OgrnAdminController extends BaseCRUDController
{

}
