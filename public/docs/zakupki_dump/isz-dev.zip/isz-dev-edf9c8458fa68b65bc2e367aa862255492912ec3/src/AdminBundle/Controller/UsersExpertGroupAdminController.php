<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class UsersExpertGroupAdminController
 * @package AdminBundle\Controller
 */
class UsersExpertGroupAdminController extends BaseCRUDController
{

}
