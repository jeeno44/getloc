<?php

namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class GzAdminController
 * @package AdminBundle\Controller
 */
class GzAdminController extends BaseCRUDController
{

}
