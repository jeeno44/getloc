<?php

namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class CriteriaTypeAdminController
 * @package AdminBundle\Controller
 */
class CriteriaTypeAdminController extends BaseCRUDController
{

}
