<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class OkvedAdminController
 * @package AdminBundle\Controller
 */
class OkvedAdminController extends BaseCRUDController
{

}
