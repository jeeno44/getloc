<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class NmckCostMethodAdminController
 * @package AdminBundle\Controller
 */
class NmckCostMethodAdminController extends BaseCRUDController
{

}
