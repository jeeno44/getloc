<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class MarketplaceAdminController
 * @package AdminBundle\Controller
 */
class MarketplaceAdminController extends BaseCRUDController
{

}
