<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class ExpertGroupAdminController
 * @package AdminBundle\Controller
 */
class ExpertGroupAdminController extends BaseCRUDController
{

}
