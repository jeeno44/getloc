<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class ApplicationAdminController
 * @package AdminBundle\Controller
 */
class ApplicationAdminController extends BaseCRUDController
{

}
