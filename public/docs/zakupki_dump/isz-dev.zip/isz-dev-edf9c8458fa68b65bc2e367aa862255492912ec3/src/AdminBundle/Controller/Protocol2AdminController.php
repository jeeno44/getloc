<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class Protocol2AdminController
 * @package AdminBundle\Controller
 */
class Protocol2AdminController extends BaseCRUDController
{

}
