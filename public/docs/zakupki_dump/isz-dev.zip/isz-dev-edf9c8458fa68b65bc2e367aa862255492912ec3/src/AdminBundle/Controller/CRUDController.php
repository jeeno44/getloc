<?php
namespace AdminBundle\Controller;

use AnalyticsBundle\Entity\Okpd;
use Sonata\CoreBundle\Form\Type\EqualType;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\HttpFoundation\Response;

/**
 * Class CRUDController
 * @package AdminBundle\Controller
 */
class CRUDController extends \Sonata\AdminBundle\Controller\CRUDController
{
    /**
     * @return RedirectResponse
     */
    public function cloneAction()
    {
        /** @var Okpd $object */
        $object = $this->admin->getSubject();

        if (!$object) {
            throw new NotFoundHttpException(sprintf('unable to find the object with id : %s', $object->getVersionOwnerId()));
        }

        $clonedObject = clone $object;  // Careful, you may need to overload the __clone method of your object
        // to set its id to null
        $clonedObject->setVersionStartAt(new \DateTime());
        $clonedObject->setVersionEndAt(null);

        //$this->admin->create($clonedObject);

        /** @var \Doctrine\ORM\EntityManager $doctrine */
        $em = $this->container->get('doctrine')->getManager('analytics');
        $em->persist($clonedObject);
        $em->flush();

        $this->addFlash('sonata_flash_success', 'Cloned successfully');

        return new RedirectResponse($this->admin->generateUrl('list'));
    }

    /**
     * List action
     *
     * @return Response
     *
     * @throws AccessDeniedException If access is not granted
     */
    public function versionsAction()
    {
        /** @var Okpd $object */
        $object = $this->admin->getSubject();

        //$this->admin->getFilterParameters()
        $this->admin->getRequest()->query->set('filter', array(
            'versionOwnerId' => array(
                'value' => $object->getVersionOwnerId(),
                'type'  => EqualType::TYPE_IS_EQUAL,
            ),

            '_sort_order' => 'DESC', // reverse order (default = 'ASC')
            '_sort_by' => 'versionStartAt',  // name of the ordered field
        ));

        return parent::listAction();
    }

    /**
     * redirect the user depend on this choice
     * @param object $object
     * @param Request $request = null
     * @return Response
     */
    protected function redirectTo($object, Request $request = null)
    {
        $url = false;
        $requestData = $this->get('request')->request->all();

        if (array_key_exists('btnUpdateAndList', $requestData)) {
            $url = $this->admin->generateUrl('list');
        }
        if (array_key_exists('btnCreateAndList', $requestData)) {
            $url = $this->admin->generateUrl('list');
        }

        if (array_key_exists('btnCreateAndCreate', $requestData)) {
            $params = array();
            if ($this->admin->hasActiveSubClass()) {
                $params['subclass'] = $this->get('request')->get('subclass');
            }
            $url = $this->admin->generateUrl('create', $params);
        }

        if (!$url) {
            $url = $this->admin->generateObjectUrl('edit', $object);
        }

        return new RedirectResponse($url);
    }
}
