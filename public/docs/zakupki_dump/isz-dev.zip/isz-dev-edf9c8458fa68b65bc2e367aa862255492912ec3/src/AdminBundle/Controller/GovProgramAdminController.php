<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class GovProgramAdminController
 * @package AdminBundle\Controller
 */
class GovProgramAdminController extends BaseCRUDController
{

}
