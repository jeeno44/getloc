<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class KbkAdminController
 * @package AdminBundle\Controller
 */
class KbkAdminController extends BaseCRUDController
{

}
