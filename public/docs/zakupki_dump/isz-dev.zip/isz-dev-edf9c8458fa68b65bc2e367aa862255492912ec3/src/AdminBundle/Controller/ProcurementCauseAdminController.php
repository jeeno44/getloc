<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class ProcurementCauseAdminController
 * @package AdminBundle\Controller
 */
class ProcurementCauseAdminController extends BaseCRUDController
{

}
