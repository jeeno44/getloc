<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class ProjectAdminController
 * @package AdminBundle\Controller
 */
class ProjectAdminController extends BaseCRUDController
{

}
