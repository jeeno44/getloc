<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class DocumentsAdminController
 * @package AdminBundle\Controller
 */
class DocumentsAdminController extends BaseCRUDController
{

}
