<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class CommissionRoleAdminController
 * @package AdminBundle\Controller
 */
class CommissionRoleAdminController extends BaseCRUDController
{

}
