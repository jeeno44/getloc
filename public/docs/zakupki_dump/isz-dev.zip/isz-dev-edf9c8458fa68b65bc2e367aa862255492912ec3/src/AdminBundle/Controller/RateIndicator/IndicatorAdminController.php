<?php
namespace AdminBundle\Controller\RateIndicator;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class IndicatorAdminController
 * @package AdminBundle\Controller\RateIndicator
 */
class IndicatorAdminController extends BaseCRUDController
{

}
