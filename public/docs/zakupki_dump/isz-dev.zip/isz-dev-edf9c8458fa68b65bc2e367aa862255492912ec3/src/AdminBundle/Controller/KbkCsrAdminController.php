<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class KbkCsrAdminController
 * @package AdminBundle\Controller
 */
class KbkCsrAdminController extends BaseCRUDController
{

}
