<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class ExpertRoleAdminController
 * @package AdminBundle\Controller
 */
class ExpertRoleAdminController extends BaseCRUDController
{

}
