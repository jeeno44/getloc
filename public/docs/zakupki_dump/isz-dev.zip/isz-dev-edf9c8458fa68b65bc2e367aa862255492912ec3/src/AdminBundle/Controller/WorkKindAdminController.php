<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class WorkKindAdminController
 * @package AdminBundle\Controller
 */
class WorkKindAdminController extends BaseCRUDController
{

}
