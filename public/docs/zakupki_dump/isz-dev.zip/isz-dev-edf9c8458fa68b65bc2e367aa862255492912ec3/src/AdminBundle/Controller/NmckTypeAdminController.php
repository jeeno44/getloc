<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class NmckTypeAdminController
 * @package AdminBundle\Controller
 */
class NmckTypeAdminController extends BaseCRUDController
{

}
