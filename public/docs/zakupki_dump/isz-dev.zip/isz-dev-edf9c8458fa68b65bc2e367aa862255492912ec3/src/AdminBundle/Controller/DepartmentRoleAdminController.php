<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class DepartmentRoleAdminController
 * @package AdminBundle\Controller
 */
class DepartmentRoleAdminController extends BaseCRUDController
{

}
