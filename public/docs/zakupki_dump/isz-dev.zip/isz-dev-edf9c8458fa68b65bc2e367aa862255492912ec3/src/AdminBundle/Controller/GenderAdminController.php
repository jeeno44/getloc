<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class GenderAdminController
 * @package AdminBundle\Controller
 */
class GenderAdminController extends BaseCRUDController
{

}
