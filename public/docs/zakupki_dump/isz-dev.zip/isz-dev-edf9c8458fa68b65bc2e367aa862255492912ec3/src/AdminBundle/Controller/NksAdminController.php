<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class NksAdminController
 * @package AdminBundle\Controller
 */
class NksAdminController extends BaseCRUDController
{

}
