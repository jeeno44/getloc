<?php

namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;
use GuzzleHttp\Message\Request;
use Swagger\Annotations\Response;

class RulesAdminController extends BaseCRUDController
{

}