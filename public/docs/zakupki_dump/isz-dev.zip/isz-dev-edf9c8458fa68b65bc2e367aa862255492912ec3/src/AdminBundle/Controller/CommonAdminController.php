<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class CommonAdminController
 * @package AdminBundle\Controller
 */
class CommonAdminController extends BaseCRUDController
{

}
