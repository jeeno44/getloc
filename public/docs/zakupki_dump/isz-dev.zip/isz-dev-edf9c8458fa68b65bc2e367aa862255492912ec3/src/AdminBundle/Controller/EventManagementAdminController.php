<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class EventManagementAdminController
 * @package AdminBundle\Controller
 */
class EventManagementAdminController extends BaseCRUDController
{

}
