<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class BankGuaranteeAdminController
 * @package AdminBundle\Controller
 */
class BankGuaranteeAdminController extends BaseCRUDController
{

}
