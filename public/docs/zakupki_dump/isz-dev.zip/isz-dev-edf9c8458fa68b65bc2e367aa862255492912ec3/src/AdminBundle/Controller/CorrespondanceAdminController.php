<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class CorrespondanceAdminController
 * @package AdminBundle\Controller
 */
class CorrespondanceAdminController extends BaseCRUDController
{

}
