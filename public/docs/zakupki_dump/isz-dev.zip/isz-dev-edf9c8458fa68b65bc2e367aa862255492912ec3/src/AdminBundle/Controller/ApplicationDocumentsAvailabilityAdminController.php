<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class ApplicationDocumentsAvailabilityAdminController
 * @package AdminBundle\Controller
 */
class ApplicationDocumentsAvailabilityAdminController extends BaseCRUDController
{

}
