<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class Protocol1AdminController
 * @package AdminBundle\Controller
 */
class Protocol1AdminController extends BaseCRUDController
{

}
