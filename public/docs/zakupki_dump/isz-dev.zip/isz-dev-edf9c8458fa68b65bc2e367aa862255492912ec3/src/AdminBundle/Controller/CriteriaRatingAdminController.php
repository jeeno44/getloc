<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class CriteriaRatingAdminController
 * @package AdminBundle\Controller
 */
class CriteriaRatingAdminController extends BaseCRUDController
{

}
