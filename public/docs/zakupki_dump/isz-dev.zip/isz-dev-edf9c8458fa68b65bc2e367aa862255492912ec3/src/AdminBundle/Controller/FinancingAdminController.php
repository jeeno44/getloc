<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class FinancingAdminController
 * @package AdminBundle\Controller
 */
class FinancingAdminController extends BaseCRUDController
{

}
