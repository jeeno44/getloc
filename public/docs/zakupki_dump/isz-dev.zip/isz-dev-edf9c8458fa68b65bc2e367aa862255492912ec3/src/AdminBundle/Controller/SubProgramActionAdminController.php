<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class SubProgramActionAdminController
 * @package AdminBundle\Controller
 */
class SubProgramActionAdminController extends BaseCRUDController
{

}
