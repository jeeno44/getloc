<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class NmckDocAdminController
 * @package AdminBundle\Controller
 */
class NmckDocAdminController extends BaseCRUDController
{

}
