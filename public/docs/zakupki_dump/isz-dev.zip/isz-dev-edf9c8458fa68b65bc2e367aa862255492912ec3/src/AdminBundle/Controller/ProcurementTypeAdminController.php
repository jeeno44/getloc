<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class ProcurementTypeAdminController
 * @package AdminBundle\Controller
 */
class ProcurementTypeAdminController extends BaseCRUDController
{

}
