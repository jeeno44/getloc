<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class NmckVariantAdminController
 * @package AdminBundle\Controller
 */
class NmckVariantAdminController extends BaseCRUDController
{

}
