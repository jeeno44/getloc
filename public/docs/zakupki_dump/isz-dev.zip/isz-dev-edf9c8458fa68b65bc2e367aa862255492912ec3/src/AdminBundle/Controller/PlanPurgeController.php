<?php

namespace AdminBundle\Controller;

use AnalyticsBundle\Entity\Lot;
use AnalyticsBundle\Entity\Plan;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

/**
 * Class PlanPurgeController
 * @package AdminBundle\Controller
 */
class PlanPurgeController extends Controller
{
    /**
     * @return RedirectResponse
     */
    public function purgeAction()
    {
        /** @var \Doctrine\DBAL\Connection $conn */
        $conn = $this->get("doctrine")->getManager("analytics")->getConnection();

        $conn->beginTransaction();

        try {
            $conn
                ->prepare("UPDATE lot SET status_id=:status")
                ->execute([
                    ':status' => Lot::STATUS_DRAFT,
                ]);
            $conn
                ->prepare("UPDATE financing SET year=NULL")
                ->execute();
            $conn
                ->prepare("UPDATE plan SET status_id=:status")
                ->execute([
                    ':status' => Plan::STATUS_DRAFT,
                ]);
            $conn
                ->prepare("TRUNCATE lot_plan")
                ->execute();

            $conn->commit();
        } catch (\Exception $e) {
            $conn->rollBack();
        }

        $this->get("doctrine")->getManager("analytics")->clear();

        $conn = $this->get("doctrine")->getManager("expertise")->getConnection();

        $conn->beginTransaction();

        try {
            $conn
                ->prepare("TRUNCATE expertise_group CASCADE")
                ->execute();

            $conn->commit();
        } catch (\Exception $e) {
            $conn->rollBack();
        }


        return $this->redirect($this->getRequest()->headers->get('referer'));
    }
}
