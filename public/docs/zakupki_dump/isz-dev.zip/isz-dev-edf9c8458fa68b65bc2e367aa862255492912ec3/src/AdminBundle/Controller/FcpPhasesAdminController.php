<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class FcpPhasesAdminController
 * @package AdminBundle\Controller
 */
class FcpPhasesAdminController extends BaseCRUDController
{

}
