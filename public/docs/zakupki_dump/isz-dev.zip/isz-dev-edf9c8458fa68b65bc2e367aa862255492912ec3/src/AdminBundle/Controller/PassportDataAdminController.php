<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class PassportDataAdminController
 * @package AdminBundle\Controller
 */
class PassportDataAdminController extends BaseCRUDController
{

}
