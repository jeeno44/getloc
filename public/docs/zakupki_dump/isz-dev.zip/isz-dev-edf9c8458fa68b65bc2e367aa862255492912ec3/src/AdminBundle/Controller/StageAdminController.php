<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class StageAdminController
 * @package AdminBundle\Controller
 */
class StageAdminController extends BaseCRUDController
{

}
