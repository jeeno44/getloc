<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class NmckMarketPriceMethodAdminController
 * @package AdminBundle\Controller
 */
class NmckMarketPriceMethodAdminController extends BaseCRUDController
{

}
