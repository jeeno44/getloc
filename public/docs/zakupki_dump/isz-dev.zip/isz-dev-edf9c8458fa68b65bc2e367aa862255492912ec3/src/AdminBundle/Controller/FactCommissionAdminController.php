<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class FactCommissionAdminController
 * @package AdminBundle\Controller
 */
class FactCommissionAdminController extends BaseCRUDController
{

}
