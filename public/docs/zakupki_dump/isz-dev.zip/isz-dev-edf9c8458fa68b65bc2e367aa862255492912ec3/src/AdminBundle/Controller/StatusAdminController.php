<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class StatusAdminController
 * @package AdminBundle\Controller
 */
class StatusAdminController extends BaseCRUDController
{

}
