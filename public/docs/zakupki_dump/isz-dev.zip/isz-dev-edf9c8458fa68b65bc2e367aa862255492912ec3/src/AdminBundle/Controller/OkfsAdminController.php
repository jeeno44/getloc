<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class OkfsAdminController
 * @package AdminBundle\Controller
 */
class OkfsAdminController extends BaseCRUDController
{

}
