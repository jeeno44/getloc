<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class KbkExpenseTypeAdminController
 * @package AdminBundle\Controller
 */
class KbkExpenseTypeAdminController extends BaseCRUDController
{

}
