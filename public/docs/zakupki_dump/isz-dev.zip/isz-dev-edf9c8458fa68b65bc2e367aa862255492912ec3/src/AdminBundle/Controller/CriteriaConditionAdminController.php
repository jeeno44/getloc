<?php

namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class CriteriaConditionAdminController
 * @package AdminBundle\Controller
 */
class CriteriaConditionAdminController extends BaseCRUDController
{

}
