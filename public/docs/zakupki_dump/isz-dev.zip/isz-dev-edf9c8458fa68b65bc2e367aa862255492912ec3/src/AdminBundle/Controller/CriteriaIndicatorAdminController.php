<?php
namespace AdminBundle\Controller;

use AdminBundle\Controller\CRUDController as BaseCRUDController;

/**
 * Class CriteriaIndicatorAdminController
 * @package AdminBundle\Controller
 */
class CriteriaIndicatorAdminController extends BaseCRUDController
{

}
