ISZ
========================

Документация по JSON Form доступна по ссылке: [app/Resources/doc/form.md](https://gitlab.gblab.ru/s.kornouhov/isz/blob/master/app/Resources/doc/form.md)

Документация по API доступна по ссылке: [app/Resources/doc/api.md](https://gitlab.gblab.ru/s.kornouhov/isz/blob/master/app/Resources/doc/api.md)

Документация по получению схемы доступна по ссылке: [app/Resources/doc/schema.md](https://gitlab.gblab.ru/s.kornouhov/isz/blob/master/app/Resources/doc/schema.md)