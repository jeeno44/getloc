# Быстрая выкладка проекта без участия @s.kornouhov (или другого ведущего разработчика на проекте) с "мягкой" перезагрузкой консьюмеров
Заходим на сервер (srv1) под пользователем iszgosbookru
## Выкладка alpha
Архивирование, нужно понимать что не будут заархивированы vendor-ы и cache, если не хочется заморочиться в случае возникновения ошибок, то нужно удалить все "--exclude", указанные при архивации кода
```bash
rm -rf ~/arc && \
mkdir ~/arc && cd ~/arc && \
cd /var/www/auth.isz.gosbook.ru/current/ && tar --exclude="./bin/*" --exclude="./app/logs/*" --exclude="./app/cache/*" --exclude="./vendor/*" -zcvf /tmp/auth.isz.gosbook.ru.tar.gz ./ && mv /tmp/auth.isz.gosbook.ru.tar.gz ~/arc/auth.isz.gosbook.ru.tar.gz && \
cd /var/www/expert.isz.gosbook.ru/current/ && tar --exclude="./bin/*" --exclude="./app/logs/*" --exclude="./app/cache/*" --exclude="./vendor/*" -zcvf /tmp/expert.isz.gosbook.ru.tar.gz ./ && mv /tmp/expert.isz.gosbook.ru.tar.gz ~/arc/expert.isz.gosbook.ru.tar.gz && \
cd /var/www/app.isz.gosbook.ru/current/ && tar --exclude="./bin/*" --exclude="./app/logs/*" --exclude="./app/cache/*" --exclude="./vendor/*" -zcvf /tmp/app.isz.gosbook.ru.tar.gz ./ && mv /tmp/app.isz.gosbook.ru.tar.gz ~/arc/app.isz.gosbook.ru.tar.gz && \
cd /var/www/integrations.isz.gosbook.ru/www/ && tar --exclude="./bin/*" --exclude="./app/logs/*" --exclude="./app/cache/*" --exclude="./vendor/*" -zcvf /tmp/integrations.isz.gosbook.ru.tar.gz ./ && mv /tmp/integrations.isz.gosbook.ru.tar.gz ~/arc/integrations.isz.gosbook.ru.tar.gz && \
cd /var/www/isz.gosbook.ru/www/ && tar --exclude="./bin/*" --exclude="./app/logs/*" --exclude="./app/cache/*" --exclude="./vendor/*" -zcvf /tmp/isz.gosbook.ru.tar.gz ./ && mv /tmp/isz.gosbook.ru.tar.gz ~/arc/isz.gosbook.ru.tar.gz && \
cd ~/arc && \
mkdir bd && \
cd bd && \
PGPASSWORD=Vo7nae4eej pg_dump -h localhost -p 5432 -U authiszgosbookru -F p -b -v -f auth.sql authiszgosbookru && \
PGPASSWORD=Poo=sei3Yu pg_dump -h localhost -p 5432 -U iszgosbookru -F p -b -v -f storage.sql analiticsiszgosbookru && \
PGPASSWORD=Poo=sei3Yu pg_dump -h localhost -p 5432 -U iszgosbookru -F p -b -v -f expert.sql expertiszgosbookru && \
PGPASSWORD=Poo=sei3Yu pg_dump -h localhost -p 5432 -U iszgosbookru -F p -b -v -f isz.sql iszgosbookru && \
tar -zcvf /tmp/isz-base.tar.gz ./ && rm *.sql && mv /tmp/isz-base.tar.gz ./dump.tar.gz
```
После этого в домашней директории пользователя появится папка arc, нужно только понимать что в начале скрипта написано удаление директории arc из домашней директории пользователя
```bash
echo "FLUSHALL" | redis-cli && \
cd /var/www/isz.gosbook.ru/www/ && git stash && git pull && git stash apply && composer install && rm -rf /var/www/isz.gosbook.ru/www/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.conf serialrestart storage:* && \
cd /var/www/auth.isz.gosbook.ru/current/ && git stash && git pull && git stash apply && composer install && rm -rf /var/www/auth.isz.gosbook.ru/current/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.conf serialrestart auth:* && \
cd /var/www/integrations.isz.gosbook.ru/www/ && git stash && git pull && git stash apply && composer install && rm -rf /var/www/integrations.isz.gosbook.ru/www/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.conf serialrestart integrations:* && \
cd /var/www/expert.isz.gosbook.ru/current/ && git stash && git pull && git stash apply && composer install && rm -rf /var/www/expert.isz.gosbook.ru/current/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.conf serialrestart expertise:* && \
cd /var/www/app.isz.gosbook.ru/current/ && git stash && git pull && git stash apply && composer install && rm -rf /var/www/app.isz.gosbook.ru/current/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.conf serialrestart app:* && \
cd /var/www/alpha.isz.gosbook.ru/www/ && git reset --hard && git pull
```
Нужно учесть что здесь указано "{color:red}composer install{color}" который может запросить указать какие-то конфигурационные данные, для проектов

Можно выполнить всё сразу, {color:red}*но не факт что всё корректно стянется с гита и заработает*{color}, поэтому можно пройтись по всем директориям проекта и посмотреть как произойдёт git pull что бы там не было конфликтов, для этого из каждой строчки можно взять
```bash
cd /var/www/auth.isz.gosbook.ru/current/ && git stash && git pull && \
cd /var/www/expert.isz.gosbook.ru/current/ && git stash && git pull && \
cd /var/www/app.isz.gosbook.ru/current/ && git stash && git pull && \
cd /var/www/integrations.isz.gosbook.ru/www/ && git stash && git pull && \
cd /var/www/isz.gosbook.ru/www/ && git stash && git pull
```
после этого сделать (если не будет проблем с конфликтами в git-е)
```bash
cd /var/www/auth.isz.gosbook.ru/current/ && git stash apply && composer install && \
cd /var/www/expert.isz.gosbook.ru/current/ && git stash apply && composer install && \
cd /var/www/app.isz.gosbook.ru/current/ && git stash apply && composer install && \
cd /var/www/integrations.isz.gosbook.ru/www/&& git stash apply && composer install && \
cd /var/www/isz.gosbook.ru/www/ && git stash apply && composer install
```
и если конфликтов в git-е не случилось, то можно чистить кеши и перезагружать консьюмеры
```bash
echo "FLUSHALL" | redis-cli && \
rm -rf /var/www/auth.isz.gosbook.ru/current/app/cache/* && \
rm -rf /var/www/isz.gosbook.ru/www/app/cache/* && \
rm -rf /var/www/expert.isz.gosbook.ru/current/app/cache/* && \
rm -rf /var/www/app.isz.gosbook.ru/current/app/cache/* && \
rm -rf /var/www/integrations.isz.gosbook.ru/www/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.conf serialrestart all && \
cd /var/www/alpha.isz.gosbook.ru/www/ && git reset --hard && git pull
```
```bash
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.conf serialrestart all
можно заменить на
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.conf restart all
что является более жёсткой перезагрузкой, но она более надёжна
```









## Выкладка stage



```bash
echo "FLUSHALL" | redis-cli && \
cd /var/www/storage.stage.isz.gosbook.ru/www/ && git stash && git pull && git stash apply && composer install && rm -rf /var/www/storage.stage.isz.gosbook.ru/www/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.stage.conf serialrestart storage:* && \
cd /var/www/auth.stage.isz.gosbook.ru/current/ && git stash && git pull && git stash apply && composer install && rm -rf /var/www/auth.stage.isz.gosbook.ru/current/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.stage.conf serialrestart auth:* && \
cd /var/www/isz.gosbook.ru/ISZ/stage/isz-integrations/current/ && git stash && git pull && git stash apply && composer install && rm -rf /var/www/isz.gosbook.ru/ISZ/stage/isz-integrations/current/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.stage.conf serialrestart integrations:* && \
cd /var/www/expert.stage.isz.gosbook.ru/current/ && git stash && git pull && git stash apply && composer install && rm -rf /var/www/expert.stage.isz.gosbook.ru/current/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.stage.conf serialrestart expert:* && \
cd /var/www/app.stage.isz.gosbook.ru/current/ && git stash && git pull && git stash apply && composer install && rm -rf /var/www/app.stage.isz.gosbook.ru/current/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.stage.conf serialrestart app:* && \
cd /var/www/stage.isz.gosbook.ru/www/ && git reset --hard && git pull
```
Можно выполнить всё сразу, {color:red}*но не факт что всё корректно стянется с гита и заработает*{color}, поэтому можно пройтись по всем директориям проекта и посмотреть как произойдёт git pull что бы там не было конфликтов, для этого из каждой строчки можно взять
```bash
cd /var/www/auth.stage.isz.gosbook.ru/current/ && git stash && git pull && \
cd /var/www/expert.stage.isz.gosbook.ru/current/ && git stash && git pull && \
cd /var/www/app.stage.isz.gosbook.ru/current/ && git stash && git pull && \
cd /var/www/isz.gosbook.ru/ISZ/stage/isz-integrations/current/ && git stash && git pull && \
cd /var/www/storage.stage.isz.gosbook.ru/www/ && git stash && git pull
```
после этого сделать (если не будет проблем с конфликтами в git-е)
```bash
cd /var/www/auth.stage.isz.gosbook.ru/current/ && git stash apply && composer install && \
cd /var/www/expert.stage.isz.gosbook.ru/current/ && git stash apply && composer install && \
cd /var/www/app.stage.isz.gosbook.ru/current/ && git stash apply && composer install && \
cd /var/www/isz.gosbook.ru/ISZ/stage/isz-integrations/current/&& git stash apply && composer install && \
cd /var/www/storage.stage.isz.gosbook.ru/www/ && git stash apply && composer install
```
и если конфликтов в git-е не случилось, то можно чистить кеши и перезагружать консьюмеры
```bash
echo "FLUSHALL" | redis-cli && \
rm -rf /var/www/auth.stage.isz.gosbook.ru/current/app/cache/* && \
rm -rf /var/www/storage.stage.isz.gosbook.ru/www/app/cache/* && \
rm -rf /var/www/expert.stage.isz.gosbook.ru/current/app/cache/* && \
rm -rf /var/www/app.stage.isz.gosbook.ru/current/app/cache/* && \
rm -rf /var/www/isz.gosbook.ru/ISZ/stage/isz-integrations/current/app/cache/* && \
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.stage.conf serialrestart all && \
cd /var/www/stage.isz.gosbook.ru/www/ && git reset --hard && git pull
```
```bash
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.stage.conf serialrestart all
можно заменить на
cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.stage.conf restart all
что является более жёсткой перезагрузкой, но она более надёжна
```