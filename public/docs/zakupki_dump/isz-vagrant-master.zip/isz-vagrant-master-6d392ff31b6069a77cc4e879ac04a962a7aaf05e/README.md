Развертывание ИС Закупки Минобра
========================

Развернуть у себя локально можно через поставляемый Vagrant-образ. Для установки в Linux(Ubuntu) вводим:

``` bash
sudo apt-get install vagrant
sudo apt-get install virtualbox
```

Или на MacOS 

``` bash
brew cask install virtualbox
brew cask install vagrant
brew cask install vagrant-manager
```

Для поставки ПО используется Ansible. Ansible — опенсорсное программное решение для удаленного управления конфигурациями. Интсрукцию по установке можно посмотреть здесь: http://docs.ansible.com/ansible/intro_installation.html#getting-ansible

``` bash
git clone --recursive ssh://git@gitlab.gblab.ru:6056/delelo/isz-vagrant.git
```

Нужно скачать dump баз данных https://cloud.gblab.ru/index.php/s/cuaiyxr87Zd0bQB
пароль - isz123

Затем sql файлы скопировать в папку code/dump

Скопировать содержимое папки code-copy в папку code, там скопируются parameter.yml

Выполнить "composer install" в проектах
isz
isz-application
isz-auth-service
isz-expert
isz-integrations
точно так же нужно выполнить "sudo app/console assets:install --symlink --relative"

Запускаем вагрант:

``` bash
vagrant up
```

Подключаемся по ssh:

``` bash
vagrant ssh
```



http://192.168.1.101:8885/ - проект
http://192.168.1.101:15672/ - по этому адресу админка rabbitmq


Логин / Пароль - для входа в систему
lead_dep / lead_dep


Далее идёт дополнительная информация, которую можно не читать без необходимости
========================

Заливаем дамп БД:
``` sql
-- Под суперпользователем
drop database auth;
drop database expert;
drop database isz;
drop database storage;
CREATE USER iszgosbookru WITH password 'iszgosbookru';
CREATE DATABASE "auth" WITH OWNER "iszgosbookru" ENCODING 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8' TEMPLATE = template0;
CREATE DATABASE "storage" WITH OWNER "iszgosbookru" ENCODING 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8' TEMPLATE = template0;
CREATE DATABASE "isz" WITH OWNER "iszgosbookru" ENCODING 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8' TEMPLATE = template0;
CREATE DATABASE "expert" WITH OWNER "iszgosbookru" ENCODING 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8' TEMPLATE = template0;
GRANT ALL privileges ON DATABASE auth TO iszgosbookru;
GRANT ALL privileges ON DATABASE storage TO iszgosbookru;
GRANT ALL privileges ON DATABASE isz TO iszgosbookru;
GRANT ALL privileges ON DATABASE expert TO iszgosbookru;

CREATE EXTENSION "uuid-ossp";

-- если не будут находится функции uuid то нужно будет выполнить install.sql
```

``` bash
Создание backup-ов
PGPASSWORD=Vo7nae4eej pg_dump -h localhost -p 5432 -U authiszgosbookru -F p -b -v -f auth.sql authiszgosbookru && \
sed -i -e 's/authiszgosbookru/iszgosbookru/g' auth.sql && \
PGPASSWORD=Poo=sei3Yu pg_dump -h localhost -p 5432 -U iszgosbookru -F p -b -v -f storage.sql analiticsiszgosbookru && \
PGPASSWORD=Poo=sei3Yu pg_dump -h localhost -p 5432 -U iszgosbookru -F p -b -v -f expert.sql expertiszgosbookru && \
PGPASSWORD=Poo=sei3Yu pg_dump -h localhost -p 5432 -U iszgosbookru -F p -b -v -f isz.sql iszgosbookru && \
tar -zcvf /tmp/isz-base.tar.gz ./ && rm *.sql && mv /tmp/isz-base.tar.gz ./dump.tar.gz

psql -h localhost -U iszgosbookru -d storage -f storage.sql
psql -h localhost -U iszgosbookru -d isz -f isz.sql
psql -h localhost -U iszgosbookru -d expert -f expert.sql
psql -h localhost -U iszgosbookru -d auth -f auth.sql
```

``` sql
truncate accesstoken cascade;
truncate authcode cascade;
truncate refreshtoken cascade;
truncate client cascade;
insert into client values(21, '5sruj9iyox8o088oco0c4c8scc404o8sokgswog4oks0wgc4cg', 'a:1:{i:0;s:42:"http://192.168.1.101:8885/oauth2/authorize";}', 'o82j7yscgw004ggkgo4084wc0o8gkcosgk44owkwkkssgw0k0', 'a:1:{i:0;s:8:"implicit";}');
insert into client values(11, 'mxb32zc6fi800owkok8gs88c8cos40oo0k0c4oows0owcw0kw', 'a:1:{i:0;s:41:"http://192.168.1.101:8881/login/check-isz";}', '5whqtgarg98oc0kkw0gc8wwkssgkskooo40c8c480gc4cscgc8', 'a:1:{i:0;s:18:"authorization_code";}');
```

Настраиваем сервер авторизации:

``` bash
cd /srv/auth
app/console doctrine:schema:update --force
app/console fos:user:create adminuser --super-admin
app/console api:client:create --redirect-uri=http://127.0.0.1:81/login/check-isz --grant-type=authorization_code
app/console api:client:create --redirect-uri=http://127.0.0.1:81/oauth2/authorize --grant-type= implicit
```

Прописываем в конфигах подсистем актуальные параметры, после этого получаем рабочий проект