#!/usr/bin/env bash

cd isz/

#echo "Выкладка Auth сервера"
#cd ../isz-auth-service/ && mage deploy to:production

echo "Выкладка Storage сервера"
cd ../isz/ && mage deploy to:production

echo "Выкладка Expert сервера"
cd ../isz-expert/ && mage deploy to:production

echo "Выкладка App сервера"
cd ../isz-application/ && mage deploy to:production

echo "Выкладка Integrations сервера"
cd ../isz-integrations/ && mage deploy to:production

#echo "Выкладка ARM сервера"
#cd ../isz-arm/ && mage deploy to:production


# Чистка всех кешей, которые есть в проекте
#echo "FLUSHALL" | redis-cli && \
#rm -rf /var/www/auth.isz.gosbook.ru/current/app/cache/* && \
#rm -rf /var/www/isz.gosbook.ru/www/app/cache/* && \
#rm -rf /var/www/expert.isz.gosbook.ru/current/app/cache/* && \
#rm -rf /var/www/app.isz.gosbook.ru/current/app/cache/* && \
#rm -rf /var/www/integrations.isz.gosbook.ru/www/app/cache/* && \
#cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.conf serialrestart all

# cd ../isz-auth-service/ && git checkout dev && git pull && git checkout master && git pull && git merge dev && git status
# git push && git checkout dev
# cd ../isz/ && git checkout dev && git pull && git checkout master && git pull && git merge dev && git status
# git push && git checkout dev
# cd ../isz-expert/ && git checkout dev && git pull && git checkout master && git pull && git merge dev && git status
# git push && git checkout dev
# cd ../isz-application/ && git checkout dev && git pull && git checkout master && git pull && git merge dev && git status
# git push && git checkout dev
# cd ../isz-integrations/ && git checkout dev && git pull && git checkout master && git pull && git merge dev && git status
# git push && git checkout dev
# cd ../isz-arm/ && git pull && git status
# git push && git checkout dev

# mcedit /var/www/auth.isz.gosbook.ru/current/app/AppKernel.php
# mcedit /var/www/isz.gosbook.ru/www/app/AppKernel.php
# mcedit /var/www/expert.isz.gosbook.ru/current/app/AppKernel.php
# mcedit /var/www/app.isz.gosbook.ru/current/app/AppKernel.php
# mcedit /var/www/integrations.isz.gosbook.ru/www/app/AppKernel.php







# Чистка всех кешей, которые есть в проекте
#echo "FLUSHALL" | redis-cli && \
#rm -rf /var/www/auth.stage.isz.gosbook.ru/current/app/cache/* && \
#rm -rf /var/www/storage.stage.isz.gosbook.ru/www/app/cache/* && \
#rm -rf /var/www/expert.stage.isz.gosbook.ru/current/app/cache/* && \
#rm -rf /var/www/app.stage.isz.gosbook.ru/current/app/cache/* && \
#rm -rf /var/www/isz.gosbook.ru/ISZ/stage/isz-integrations/current/app/cache/* && \
#cd /var/www/isz.gosbook.ru/ && supervisorctl --configuration=/var/www/isz.gosbook.ru/supervisord.stage.conf serialrestart all

# git checkout dev && git pull && git checkout master && git pull && git merge dev && git status
# git push && git checkout dev

# mcedit /var/www/auth.stage.isz.gosbook.ru/current/app/AppKernel.php
# mcedit /var/www/storage.stage.isz.gosbook.ru/www/app/AppKernel.php
# mcedit /var/www/expert.stage.isz.gosbook.ru/current/app/AppKernel.php
# mcedit /var/www/app.stage.isz.gosbook.ru/current/app/AppKernel.php
# mcedit /var/www/isz.gosbook.ru/ISZ/stage/isz-integrations/current/app/AppKernel.php