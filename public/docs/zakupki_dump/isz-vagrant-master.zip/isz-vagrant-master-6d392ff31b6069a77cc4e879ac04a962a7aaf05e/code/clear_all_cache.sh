#!/usr/bin/env bash

echo "Каталог для кеша кода проектов удалён"
sudo rm -rf /tmp/isz

echo "Весь кеш в redis очищен"
echo "FLUSHALL" | redis-cli

echo "Осталось перезагрузить консьюмеры"