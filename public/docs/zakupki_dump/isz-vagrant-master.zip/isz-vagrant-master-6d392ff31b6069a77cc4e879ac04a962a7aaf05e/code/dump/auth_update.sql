truncate accesstoken cascade;
truncate authcode cascade;
truncate refreshtoken cascade;
truncate client cascade;
insert into client values(21, '5sruj9iyox8o088oco0c4c8scc404o8sokgswog4oks0wgc4cg', 'a:1:{i:0;s:42:"http://192.168.1.101:8885/oauth2/authorize";}', 'o82j7yscgw004ggkgo4084wc0o8gkcosgk44owkwkkssgw0k0', 'a:1:{i:0;s:8:"implicit";}');
insert into client values(11, 'mxb32zc6fi800owkok8gs88c8cos40oo0k0c4oows0owcw0kw', 'a:1:{i:0;s:41:"http://192.168.1.101:8881/login/check-isz";}', '5whqtgarg98oc0kkw0gc8wwkssgkskooo40c8c480gc4cscgc8', 'a:1:{i:0;s:18:"authorization_code";}')