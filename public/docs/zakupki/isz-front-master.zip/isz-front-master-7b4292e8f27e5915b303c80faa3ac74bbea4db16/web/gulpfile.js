﻿var gulp = require( 'gulp' );
var concat = require( 'gulp-concat' );
var uglify = require( 'gulp-uglify' );
var jsValidate = require( 'gulp-jsvalidate' );
var scss = require('gulp-scss');
var cleanCSS = require('gulp-clean-css');
var sourcemaps = require('gulp-sourcemaps');


gulp.task( 'default', function () {
    return gulp.src( ['./js/app.js', './js/config.js', './js/common/**/*.js', './js/documents/**/*.js', './js/plans/**/*.js'] )
    .pipe( concat( 'all.js' ) )
    .pipe( uglify() )
    .pipe( gulp.dest( 'dist' ) );
} );

gulp.task( 'default2', function () {
    return gulp.src( ['./js/app.js', './js/config.js', './js/common/**/*.js', './js/documents/**/*.js', './js/plans/**/*.js'] )
    .pipe( jsValidate() );
} );

gulp.task('scss',function () {
    return gulp.src(['./css/app.scss'])
        .pipe(scss({"boundleExec":true}))
        .pipe(gulp.dest('./css/static/css'));

        
})