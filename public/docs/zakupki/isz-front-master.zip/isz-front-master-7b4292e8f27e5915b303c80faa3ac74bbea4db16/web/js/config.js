angular.module('isz').config(['$locationProvider', function ($locationProvider) {
    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });
}])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider
            .when('/', {
                templateUrl: '/js/common/templates/pages/home.html',
                controller: 'HomeCtrl'
            })
            .when('/blocking', {
                templateUrl: '/js/common/templates/pages/blocking.html',
                controller: 'BlockingCtrl'
            })
            // Plans routes Start
            .when('/plans', {
                templateUrl: '/js/plans/templates/pages/plansLots.html',
                controller: 'plansLots'
            })
            .when('/plans/limits', {
                templateUrl: '/js/plans/templates/pages/limits.html',
                controller: 'Limits'
            })
            .when('/plans/my', {
                templateUrl: '/js/plans/templates/pages/mylots.html',
                controller: 'MyLots'
            })
            .when('/plans/current', {
                templateUrl: '/js/plans/templates/pages/current_plan.html',
                controller: 'CurrentPlan'
                // controller: 'NextPlan'
            })
            .when('/plans/next', {
                // templateUrl: '/js/plans/templates/pages/next_plan.html',
                templateUrl: '/js/plans/templates/pages/current_plan.html',
                controller: 'NextPlan'
            })
            .when('/plans/archive', {
                templateUrl: '/js/plans/templates/pages/current_plan.html',
                // templateUrl: '/js/plans/templates/pages/archive_plan.html',
                controller: 'ArchivePlan'
            })
            .when('/plans/lot/:id', {
                templateUrl: '/js/plans/templates/pages/plansLotPage.html',
                controller: 'plansLotPage'
            })
            //Plans routes End

            // Documents routes Start
            .when('/docs', {
                templateUrl: '/js/documents/templates/pages/docsLots.html',
                controller: 'docsLots'
            })
            .when('/docs/my', {
                templateUrl: '/js/documents/templates/pages/docsLots.html',
                controller: 'docsMyLots'
            })
            .when('/docs/lot/:id', {
                templateUrl: '/js/documents/templates/pages/docsLotPage.html',
                controller: 'docsLotPage'
            })
            // Documents routes End

            //Acceptance routes Start
            .when('/acceptance',{
                templateUrl:'/js/acceptance/templates/pages/acceptanceLots.html',
                controller:'acceptanceLots'
            })
            //Acceptance routes End
            .when('/calendar', {
                templateUrl: '/js/common/templates/pages/calendar.html',
                controller: 'Calendar'
            })
            .when('/profile', {
                templateUrl: '/js/common/templates/pages/profile.html',
                controller: 'profile'
            })
            .when('/oauth2/authorize', {
                template: " ",
                controller: ['$location', '$mdDialog', 'appsecurity',
                    function ($location, $mdDialog, appsecurity) {
                        var authKey = /access_token=\w*/.exec($location.$$hash)[0].replace('access_token=', '');
                        appsecurity.setAccessToken(authKey);
                        $location.$$hash = '';

                        var navigateUrl = localStorage.navUrl;

                        if (navigateUrl !== '/' && navigateUrl !== undefined) {

                            appsecurity.getUserInfo().then(function () {
                                $mdDialog.show({
                                    templateUrl: '/js/common/templates/chooseUserRoleDialog.html',
                                    controller: ['$scope', function ($scope) {
                                        $scope.userRoles = appsecurity.userRoles;
                                        $scope.userInfo = appsecurity.userInfo;
                                        $scope.currentRole = appsecurity.currentRole;

                                        $scope.login = function () {
                                            $mdDialog.hide();
                                            if ($scope.personalData) {
                                                localStorage.removeItem('navUrl');
                                                $location.path(navigateUrl);
                                            }
                                        };
                                    }]
                                });
                            })


                        } else {
                            $location.path('/');

                        }
                    }]
            })
            .otherwise({
                redirectTo: '/'
            })
    }])
    .config(['$mdThemingProvider', function ($mdThemingProvider) {
        $mdThemingProvider.theme('indigo');
    }

    ])
    .config(['$mdIconProvider',function ($mdIconProvider) {
        $mdIconProvider
            .defaultIconSet('/css/material-styles/mdi.svg')
    }]);