/**
 * Created by pol on 14.08.2015.
 */
angular.module('isz')
    .directive('lotNmckTab', [function () {
        return {
            restrict: 'E',
            scope: true,
            templateUrl: '/js/plans/directives/lotNmckTab/template/lotNmckTabTemplate.html',
            controller: ['$scope', '$http', '$q','$mdDialog', 'apiService', 'commonVariables', 'appsecurity', 'toastService', 'NmckJustification','uploadFiles',
                function ($scope, $http, $q, $mdDialog,apiService, commonVariables, appsecurity, toastService, NmckJustification,uploadFiles) {

                    $scope.name = 'nmck';

                    appsecurity.getUserInfo().then(getNmckTypes);
                    setLot();
                    function setLot() {
                        if (commonVariables.currentLot) {
                            $scope.lot = commonVariables.currentLot;
                            $scope.$$phase || $scope.$apply();
                        } else {
                            setTimeout(setLot, 100);
                        }
                    }

                    $scope.recalculateLotPricing = function () {
                        $scope.lot.pricing = $scope.lot.getArraySumm($scope.lot.financings || [], 'planPrice');
                    }

                    $scope.uploadDocuments = uploadFiles.uploadDocuments;

                    
                    $scope.downloadFile = function (document) {
                        //window.open('http://isz.gosbook.ru' + document.file, '_blank');
                        if (!$scope.lot.id){
                            window.open( document.full_path, '_blank' );
                        } else {
                            window.open( document.file, '_blank' );
                        }

                    }
                    $scope.removeDoc = function (doc) {
                        var index = $scope.lot.nmckDoc.indexOf(doc);
                        if ($scope.lot.inEditMode) {
                            $http({
                                method: 'DELETE',
                                url: apiService.serverRoute + 'nmckdocs/' + doc.id,
                                headers: appsecurity.getSecurityHeadersForFileUpload()
                            }).then(function (response) {
                                if (response.status < 300) {
                                    $scope.lot.nmckDoc.splice(index, 1);
                                }
                            }, function (response) {
                                toastService.errorResponseShow('Произошла ошибка при удалении документа', response);
                            });
                        } else {
                            $scope.lot.nmckDoc.splice(index, 1);
                        }

                    };
                    $scope.saveFinancings = function () {
                        if ($scope.lot.inEditMode) {
                            var fin=[];
                            $scope.lot.financings.forEach(function (fn) {
                                var tr=angular.merge({},fn);
                                tr.planPrice=fn.planPrice*1;
                                delete tr.id;
                                fin.push(tr);
                            })
                            $scope.lot.patch({financings: fin});
                        }
                    }

                    $scope.saveNmckType = function () {
                        $scope.lot.patch({nmckType: $scope.lot.nmckType.id});
                    };


                    function uploadNmckJustFile($files, $event, $flow) {
                        var def = $q.defer();
                        if ($event.type === 'change' && $event.currentTarget.files.length !== 0) {
                            var formData = new FormData();
                            Array.prototype.forEach.call($event.currentTarget.files, function (f) {
                                formData.append("file", f);
                            })
                            sendReq(formData).then(function(response){
                                def.resolve(response);
                            },function(){
                                def.reject();
                            });

                        }
                        if ($event.type === 'drop' && $event.dataTransfer.files.length !== 0) {
                            var formData = new FormData();
                            for (var i = 0; i < $event.dataTransfer.files.length; i++) {
                                formData.append("file", $event.dataTransfer.files[i]);
                            }
                            sendReq(formData).then(function(response){
                                def.resolve(response);
                            },function(){
                                def.reject();
                            });

                        }
                        function sendReq(formData) {
                            var defer = $q.defer();
                            $http({
                                method: 'POST',
                                url: apiService.filesUpload,
                                data: formData,
                                headers: appsecurity.getSecurityHeadersForFileUpload(),
                                //transformRequest: angular.identity
                            }).then(function (response) {
                                defer.resolve(response);
                            }, function (response) {
                                defer.reject()
                                toastService.errorResponseShow('Произошла ошибка при передаче документа', response);
                            });
                            return defer.promise;
                        }
                        return def.promise;
                    }
                    $scope.addNmckJust = function () {

                        $mdDialog.show( {
                            templateUrl: '/js/plans/templates/nmckJustificationModal.html',
                            controller: ['$scope', function ( $scope ) {
                                var obj = {
                                    justification: '',
                                    price: 0,
                                    comment: '',
                                    url: '',
                                    file:null
                                };
                                $scope.editing=true;
                                $scope.lot=commonVariables.currentLot;
                                $scope.nmckJast = new NmckJustification(obj);
                                $scope.saveNmckJust = function () {

                                    if ($scope.lot.id) {
                                        $scope.nmckJast.create($scope.lot).then(function(){
                                            $scope.lot.nmckJustifications.push($scope.nmckJast);
                                        });
                                    } else {
                                        $scope.lot.nmckJustifications.push($scope.nmckJast);
                                    }
                                    $scope.exit();
                                }
                                $scope.exit = $mdDialog.hide;
                                $scope.removeDoc = function (doc) {
                                    $scope.nmckJast.file=null;
                                };
                                $scope.downloadFile = function (document) {
                                        window.open( document, '_blank' );
                                };
                                $scope.uploadDocuments = function( $files, $event, $flow ){
                                    uploadNmckJustFile($files, $event, $flow).then(function(response){
                                        if (response.data.status && response.data.status==='uploaded' && response.data.files && response.data.files.length){
                                            for (var i=0;i<response.data.files.length;i++)
                                            $scope.nmckJast.file=response.data.files[i].full_path;
                                        }
                                    })
                                };

                            }]
                        } );
                    }
                    $scope.openNmckJustification = function(nmckJast){
                        var editing=($scope.creating || $scope.lot.inEditMode);
                        $mdDialog.show( {
                            templateUrl: '/js/plans/templates/nmckJustificationModal.html',
                            controller: ['$scope', function ( $scope ) {

                                $scope.editing=editing;
                                $scope.lot=commonVariables.currentLot;
                                $scope.nmckJast = nmckJast;
                                $scope.saveNmckJust = function () {

                                    if ($scope.lot.id) {
                                        nmckJast.patch('justification','price','url','comment','file');
                                    }
                                    $scope.exit();
                                }
                                $scope.exit = $mdDialog.hide;
                                $scope.removeDoc = function (doc) {
                                    $scope.nmckJast.file=null;
                                };
                                $scope.downloadFile = function (document) {
                                        window.open( document, '_blank' );
                                };
                                $scope.uploadDocuments = function( $files, $event, $flow ){
                                    uploadNmckJustFile($files, $event, $flow).then(function(response){
                                        if (response.data.status && response.data.status==='uploaded' && response.data.files && response.data.files.length){
                                            for (var i=0;i<response.data.files.length;i++)
                                                $scope.nmckJast.file=response.data.files[i].full_path;
                                        }
                                    })
                                };
                            }]
                        } )
                    };

                    $scope.removeNmckJust = function (nmckJust) {
                        var index = $scope.lot.nmckJustifications.indexOf(nmckJust);
                        if (nmckJust.id){
                            nmckJust.remove().then(function(){
                                $scope.lot.nmckJustifications.splice(index, 1);
                            });
                        } else {
                            $scope.lot.nmckJustifications.splice(index, 1);
                        }

                    }
                    $scope.nmckJustChange = function(nmckJast,field){
                        if (nmckJast.id){
                            nmckJast.patch(field);
                        }
                    };

                    function getNmckTypes() {
                        selectRequest(apiService.nmcktypesSelect)
                            .then(function (response) {
                                if (response.data.length) {
                                    $scope.nmckTypes = response.data.map(function (type) {
                                        return {
                                            id: type.id,
                                            title: type.description
                                        };
                                    });
                                }

                            }, function (response) {
                                toastService.errorResponseShow('Произошла ошибка получении методов определения и обоснования НМЦК', response);
                            })
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });
                    }

                    function selectRequest(url) {
                        // var defer = $q.defer();
                        // $http({
                        //     method: 'GET',
                        //     headers: appsecurity.getSecurityHeaders(),
                        //     url: url
                        // }).then(function (response) {
                        //         defer.resolve(response);
                        //     }, function () {
                        //         $http({
                        //             method: 'GET',
                        //             headers: appsecurity.getSecurityHeaders(),
                        //             url: url
                        //         }).then(function (response) {
                        //             defer.resolve(response);
                        //         }, function (response) {
                        //             defer.reject(response);
                        //         })
                        //     }
                        // )
                        // return defer.promise;
                        function reqWrapper() {
                            var defer = $q.defer();
                            $http({
                                method: 'GET',
                                headers: appsecurity.getSecurityHeaders(),
                                url: url
                            }).then(function (response) {
                                    defer.resolve(response);
                                }, function (response) {
                                    defer.reject(response);

                                }
                            )
                            return defer.promise;

                        }
                        var req=reqWrapper;
                        commonVariables.requestArr.push(req);
                        return req();
                    }
                }]
        }
    }]);