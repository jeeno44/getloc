﻿/**
 * Created by pol on 19.08.2015.
 */
angular.module( 'isz' )
    .directive( 'lotItemPlans', [function () {
        return {
            restrict: 'E',
            templateUrl: '/js/plans/directives/lotItemPlans/lotItemPlansTemplate.html',
            controller: ['$scope', '$location','$timeout', 'appsecurity', 'commonVariables', 'controlsService', 'plansService',
                function ( $scope, $location, $timeout,appsecurity, commonVariables, controlsService, plansService ) {
                 

                    $scope.showFinancings = appsecurity.currentRole.code == 'Rukovoditel_depzak' && $scope.lot.statusId == 'approved';
                    $scope.canControlSection = appsecurity.currentRole.isAllowControlSections( $scope.lot.common );

                    $scope.getStatus = function ( id ) {
                        if ( id ) {
                            var stat = commonVariables.expertsStatuses.filter( function ( st ) {
                                return st.machineName === id;
                            } );
                            return stat[0].title;
                        }
                        return null;
                    };

                    if ( $scope.showFinancings ) {
                        $scope.lot.finByCurrYear = [];
                        fillFinByCurrYears();
                        plansService.addControl( $scope.lot );
                    }

                    $scope.lotClicked = function ( lot ) {
                        if ( appsecurity.currentRole.isAllowReadLot( lot.common ) ) {
                            commonVariables.currentLot = lot;
                            $location.path( '/plans/lot/' + lot.id );
                            commonVariables.lotTitleFilter.value( '' );
                        } else {
                            toastService.show( 'У Вас нет прав доступа для просмотра лота', false );
                        }
                    };
                    
                    $scope.$watch('lot.statusId',function(newVal,oldVal){
                        if (oldVal==="approved" && newVal==="on_agreement") {
                            $scope.showFinancings=false;
                        }
                    })
                 

                    $scope.handleCustom = function ( lot, controlName) {
                        if ( plansService.executeIfControlExists( lot, controlName ) ) {

                            return;
                        }
              
                    }

                    $scope.handle = function ( lot, control ) {
                        commonVariables.currentLot = lot;
                        controlsService.executeCommand(control, lot.id);
                        
                    };

                    function fillFinByCurrYears() {
                        var currYear = new Date(), fin, year;

                        for ( var i = 0; i < 3; i++ ) {
                            year = ( currYear.getFullYear() + i );
                            fin = $scope.lot.financings.filter( function ( fns ) {
                                return fns.year == year;
                            } ) || null;
                            $scope.lot.finByCurrYear[i] = {
                                year: year,
                                finans: fin
                            }
                        }
                    }
                    $scope.$on('$mdMenuOpen',function () {
                       $timeout(function () {
                            // var el=document.querySelector('.md-active.md-open-menu-container');
                            var $el=$('.md-active.md-open-menu-container');
                           var scrHeight=$(window).height();
                           var top=$el.offset().top;
                           var elHeight=$el.outerHeight(true);
                           var offset=scrHeight-top-elHeight;
                           if (offset<0) {
                               $el.css("top",top+offset-5);
                           }

                        },0)

                    })
                }]
        };
    }] );
