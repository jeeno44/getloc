/**
 * Created by pol on 15.08.2015.
 */
angular.module('isz')
    .directive('lotConditionTab', [function () {
        return {
            restrict: 'E',
            scope: true,
            templateUrl: '/js/plans/directives/lotConditionTab/template/lotConditionTabTemplate.html',
            controller: ['$scope', '$http', '$q', 'appsecurity', 'apiService', 'commonVariables', 'toastService',
                function ($scope, $http, $q, appsecurity, apiService, commonVariables, toastService) {

                    $scope.isKotirovka=false;
                    appsecurity.getUserInfo().then(getProcurementTypes);

                    $scope.name = 'procurement';
                    setLot();
                    function setLot() {
                        if (commonVariables.currentLot) {
                            $scope.lot = commonVariables.currentLot;
                            $scope.$$phase || $scope.$apply();
                        } else {
                            setTimeout(setLot, 100);
                        }
                    }

                    $scope.saveProcurementType = function () {
                        $scope.lot.patch({procurementType: $scope.lot.procurementType.id});
                    }

                    function getProcurementTypes() {
                        selectRequest(apiService.procurementtypesSelect)
                            .then(function (response) {
                                if (response.data.length) {
                                    $scope.procurementTypes = response.data.map(function (type) {
                                        return {
                                            id: type.id,
                                            description: type.description
                                        };
                                    });
                                }

                            }, function (response) {
                                toastService.errorResponseShow('Ошибка получения справочника способов определения поставщика', response)
                            })
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });
                    }

                    function selectRequest(url) {
                        // var defer = $q.defer();
                        // $http({
                        //     method: 'GET',
                        //     headers: appsecurity.getSecurityHeaders(),
                        //     url: url
                        // }).then(function (response) {
                        //         defer.resolve(response);
                        //     }, function () {
                        //         $http({
                        //             method: 'GET',
                        //             headers: appsecurity.getSecurityHeaders(),
                        //             url: url
                        //         }).then(function (response) {
                        //             defer.resolve(response);
                        //         }, function (response) {
                        //             defer.reject(response);
                        //         })
                        //     }
                        // )
                        // return defer.promise;
                        function reqWrapper() {
                            var defer = $q.defer();
                            $http({
                                method: 'GET',
                                headers: appsecurity.getSecurityHeaders(),
                                url: url
                            }).then(function (response) {
                                    defer.resolve(response);
                                }, function (response) {
                                    defer.reject(response);

                                }
                            )
                            return defer.promise;

                        }
                        var req=reqWrapper;
                        commonVariables.requestArr.push(req);
                        return req();
                    }

                    //$scope.minPrepaymentBidPercentage = 0;
                    //$scope.maxPrepaymentBidPercentage = 100;

                    $scope.$watch('lot.procurementType', prepaymentBidPercentageSet);
                    $scope.$watch('lot.procurementType', prepaymentContractPercentageSet);
                    $scope.$watch('lot.requirement3044', function () {
                        prepaymentBidPercentageSet(true);
                        prepaymentContractPercentageSet(true);
                    });
                    $scope.$watch('lot.pricing', prepaymentBidPercentageSet);
                    $scope.$watch('lot.pricing', prepaymentContractPercentageSet);
                    $scope.$watch('lot.advancePaymentPercentage', prepaymentContractPercentageSet);


                    function prepaymentBidPercentageSet(fl) {
                        if ($scope.lot && $scope.lot.requirement3044 &&
                            $scope.lot.procurementType && $scope.lot.procurementType.description
                            && ($scope.lot.requirement3044 === 'Нет' || !$scope.lot.requirement3044) && ($scope.lot.inEditMode||$scope.creating)) {
                            switch ($scope.lot.procurementType.description) {
                                case 'Открытый конкурс':
                                    $scope.isKotirovka=false;
                                    if ($scope.lot.pricing) {
                                        if ($scope.lot.pricing<=3000000) {
                                            $scope.lot.prepaymentBidPercentage = 1;
                                            $scope.minPrepaymentBidPercentage = 1;
                                            $scope.maxPrepaymentBidPercentage = 1;
                                            if (fl && $scope.lot.prepaymentBidPercentage !== null && !( ( $scope.lot.prepaymentBidPercentage === 1 ) )) {
                                                $scope.lot.requirement3044 = 'Да';
                                                toastService.show('Размер обеспечения заявки должен быть равен 1%', true);
                                            }
                                        }
                                        if ($scope.lot.pricing>3000000) {
                                            $scope.minPrepaymentBidPercentage = 0.5;
                                            $scope.maxPrepaymentBidPercentage = 5;
                                            if (fl && $scope.lot.prepaymentBidPercentage !== null && !( ( $scope.lot.prepaymentBidPercentage >= 0.5 ) && ( $scope.lot.prepaymentBidPercentage <= 5 ) )) {
                                                $scope.lot.requirement3044 = 'Да';
                                                toastService.show('Размер обеспечения заявки должен быть в диапазоне от 0.5% до 5%', true);
                                            }
                                        }

                                    }
                                    break;
                                case 'Электронный аукцион':
                                    $scope.isKotirovka=false;
                                    if ($scope.lot.pricing) {
                                        if ($scope.lot.pricing > 3000000) {
                                            $scope.minPrepaymentBidPercentage = 0.5;
                                            $scope.maxPrepaymentBidPercentage = 5;
                                        } else {
                                            $scope.lot.prepaymentBidPercentage = 1;
                                            $scope.minPrepaymentBidPercentage = 1;
                                            $scope.maxPrepaymentBidPercentage = 1;
                                        }

                                    }
                                    break;
                                case 'Запрос котировок':
                                    $scope.lot.prepaymentBidPercentage=null;
                                    $scope.isKotirovka=true;
                                    break;
                                default:
                                    $scope.minPrepaymentBidPercentage = 0;
                                    $scope.maxPrepaymentBidPercentage = 100;
                                    $scope.isKotirovka=false;
                            }
                        }
                        if ($scope.lot && $scope.lot.requirement3044 &&
                            $scope.lot.procurementType && $scope.lot.procurementType.description
                            && ($scope.lot.requirement3044 === 'Да') && ($scope.lot.inEditMode||$scope.creating)) {
                            if ($scope.lot.pricing>20000000) {
                                $scope.lot.prepaymentBidPercentage=null;
                                $scope.isKotirovka=true;
                                if (fl ) {
                                    $scope.lot.requirement3044 = 'Нет';
                                    toastService.show('В соответствии с ч.1 ст.30 Закона о контрактной системе при закупках у субъектов малого предпринимательства, социально ориентированных некоммерческих организаций ' +
                                        'начальная (максимальная) цена контракта не должна превышать 20 000 000 (двадцать миллионов) рублей. Скорректируйте введенные данные', true);
                                }
                            } else {
                                switch ($scope.lot.procurementType.description) {
                                    case 'Открытый конкурс':
                                        $scope.isKotirovka=false;
                                        if ($scope.lot.pricing) {
                                            if ($scope.lot.pricing<=20000000) {
                                                $scope.minPrepaymentBidPercentage = 0.5;
                                                $scope.maxPrepaymentBidPercentage = 5;
                                                if (fl && $scope.lot.prepaymentBidPercentage !== null && !( ( $scope.lot.prepaymentBidPercentage >= 0.5 ) && ( $scope.lot.prepaymentBidPercentage <= 5 ) )) {
                                                    $scope.lot.requirement3044 = 'Нет';
                                                    toastService.show('Размер обеспечения заявки должен быть в диапазоне от 0.5% до 5%', true);
                                                }
                                            }


                                        }
                                        break;
                                    case 'Электронный аукцион':
                                        $scope.isKotirovka=false;
                                        if ($scope.lot.pricing) {
                                            if ($scope.lot.pricing <= 3000000) {
                                                $scope.lot.prepaymentBidPercentage = 1;
                                                $scope.minPrepaymentBidPercentage = 1;
                                                $scope.maxPrepaymentBidPercentage = 1;
                                            }
                                            if ($scope.lot.pricing > 3000000 && $scope.lot.pricing <= 20000000) {
                                                $scope.minPrepaymentBidPercentage = 0.5;
                                                $scope.maxPrepaymentBidPercentage = 5;
                                                if (fl && $scope.lot.prepaymentBidPercentage !== null && !( ( $scope.lot.prepaymentBidPercentage >= 0.5 ) && ( $scope.lot.prepaymentBidPercentage <= 5 ) )) {
                                                    $scope.lot.requirement3044 = 'Нет';
                                                    toastService.show('Размер обеспечения заявки должен быть в диапазоне от 0.5% до 5%', true);
                                                }
                                            }

                                        }
                                        break;
                                    case 'Запрос котировок':
                                        $scope.lot.prepaymentBidPercentage=null;
                                        $scope.isKotirovka=true;
                                        break;
                                    default:
                                        $scope.minPrepaymentBidPercentage = 0;
                                        $scope.maxPrepaymentBidPercentage = 100;
                                        $scope.isKotirovka=false;
                                }
                            }


                        }
                    }

                    function prepaymentContractPercentageSet(fl) {
                        //if ($scope.lot && $scope.lot.pricing) {
                        //    if ($scope.lot.pricing <= 50000) {
                        //        $scope.minPrepaymentContractPercentage = 5;
                        //        $scope.maxPrepaymentContractPercentage = 30;
                        //    } else {
                        //        $scope.minPrepaymentContractPercentage = 10;
                        //        $scope.maxPrepaymentContractPercentage = 30;
                        //        if ($scope.lot.advancePaymentPercentage) {
                        //            if ($scope.lot.advancePaymentPercentage >= 10 && $scope.lot.advancePaymentPercentage <= 30) {
                        //                if ($scope.lot.advancePaymentPercentage > $scope.minPrepaymentContractPercentage) {
                        //                    $scope.minPrepaymentContractPercentage = $scope.lot.advancePaymentPercentage
                        //                }
                        //                if ($scope.lot.advancePaymentPercentage > $scope.maxPrepaymentContractPercentage) {
                        //                    $scope.maxPrepaymentContractPercentage = $scope.lot.advancePaymentPercentage;
                        //                }
                        //                if ($scope.lot.prepaymentContractPercentage < $scope.lot.advancePaymentPercentage) {
                        //                    $scope.lot.prepaymentContractPercentage = $scope.lot.advancePaymentPercentage;
                        //                }
                        //            }
                        //            if ($scope.lot.advancePaymentPercentage > 30) {
                        //                $scope.minPrepaymentContractPercentage = $scope.lot.advancePaymentPercentage;
                        //                $scope.maxPrepaymentContractPercentage = $scope.lot.advancePaymentPercentage;
                        //                $scope.lot.prepaymentContractPercentage = $scope.lot.advancePaymentPercentage;
                        //            }
                        //        }
                        //    }
                        //
                        //}
                        if ($scope.lot && $scope.lot.requirement3044 &&
                            $scope.lot.procurementType && $scope.lot.procurementType.description
                            && ($scope.lot.requirement3044 === 'Нет' || !$scope.lot.requirement3044) && ($scope.lot.inEditMode||$scope.creating)) {
                            switch ($scope.lot.procurementType.description) {
                                case 'Открытый конкурс':
                                    $scope.isKotirovka=false;
                                    if ($scope.lot.pricing) {
                                        if ($scope.lot.pricing<=50000000) {

                                            $scope.minPrepaymentContractPercentage = 5;
                                            $scope.maxPrepaymentContractPercentage = 30;
                                            if (fl && $scope.lot.prepaymentContractPercentage !== null && !( ( $scope.lot.prepaymentContractPercentage >= 5 ) && ( $scope.lot.prepaymentContractPercentage <= 30 ) )) {
                                                $scope.lot.requirement3044 = 'Да';
                                                toastService.show('Размер обеспечения контракта должен быть быть в диапазоне от 5% до 30%', true);
                                            }
                                        }
                                        if ($scope.lot.pricing>50000000) {
                                            $scope.minPrepaymentContractPercentage = 10;
                                            $scope.maxPrepaymentContractPercentage = 30;
                                            if (fl && $scope.lot.prepaymentContractPercentage !== null && !( ( $scope.lot.prepaymentContractPercentage >= 10 ) && ( $scope.lot.prepaymentContractPercentage <= 30 ) )) {
                                                $scope.lot.requirement3044 = 'Да';
                                                toastService.show('Размер обеспечения контракта должен быть в диапазоне от 10% до 30%', true);
                                            }
                                        }

                                    }
                                    break;
                                case 'Электронный аукцион':
                                    $scope.isKotirovka=false;
                                    if ($scope.lot.pricing) {
                                        if ($scope.lot.pricing<=50000000) {

                                            $scope.minPrepaymentContractPercentage = 5;
                                            $scope.maxPrepaymentContractPercentage = 30;
                                            if (fl && $scope.lot.prepaymentContractPercentage !== null && !( ( $scope.lot.prepaymentContractPercentage >= 5 ) && ( $scope.lot.prepaymentContractPercentage <= 30 ) )) {
                                                $scope.lot.requirement3044 = 'Да';
                                                toastService.show('Размер обеспечения контракта должен быть быть в диапазоне от 5% до 30%', true);
                                            }
                                        }
                                        if ($scope.lot.pricing>50000000) {
                                            $scope.minPrepaymentContractPercentage = 25;
                                            $scope.maxPrepaymentContractPercentage = 30;
                                            if (fl && $scope.lot.prepaymentContractPercentage !== null && !( ( $scope.lot.prepaymentContractPercentage >= 25 ) && ( $scope.lot.prepaymentContractPercentage <= 30 ) )) {
                                                $scope.lot.requirement3044 = 'Да';
                                                toastService.show('Размер обеспечения контракта должен быть в диапазоне от 25% до 30%', true);
                                            }
                                        }

                                    }
                                    break;
                                case 'Запрос котировок':
                                    $scope.isKotirovka=false;
                                    $scope.lot.prepaymentContractPercentage=null;
                                    $scope.isKotirovka=true;
                                    break;
                                default:
                                    $scope.minPrepaymentContractPercentage = 0;
                                    $scope.maxPrepaymentContractPercentage = 100;
                            }
                        }
                        if ($scope.lot && $scope.lot.requirement3044 &&
                            $scope.lot.procurementType && $scope.lot.procurementType.description
                            && ($scope.lot.requirement3044 === 'Да') && ($scope.lot.inEditMode||$scope.creating)) {
                            if ($scope.lot.pricing>20000000) {
                                $scope.isKotirovka=true;
                                $scope.lot.prepaymentContractPercentage=null
                                if (fl ) {
                                    $scope.lot.requirement3044 = 'Нет';
                                    toastService.show('В соответствии с ч.1 ст.30 Закона о контрактной системе при закупках у субъектов малого предпринимательства, социально ориентированных некоммерческих организаций ' +
                                        'начальная (максимальная) цена контракта не должна превышать 20 000 000 (двадцать миллионов) рублей. Скорректируйте введенные данные', true);
                                }
                            } else {
                                switch ($scope.lot.procurementType.description) {
                                    case 'Открытый конкурс':
                                        if ($scope.lot.pricing) {
                                            if ($scope.lot.pricing<=20000000) {
                                                $scope.minPrepaymentContractPercentage = 5;
                                                $scope.maxPrepaymentContractPercentage = 30;
                                                if (fl && $scope.lot.prepaymentContractPercentage !== null && !( ( $scope.lot.prepaymentContractPercentage >= 5 ) && ( $scope.lot.prepaymentContractPercentage <= 30 ) )) {
                                                    $scope.lot.requirement3044 = 'Нет';
                                                    toastService.show('Размер обеспечения контракта должен быть в диапазоне от 5% до 30%', true);
                                                }
                                            }


                                        }
                                        break;
                                    case 'Электронный аукцион':
                                        if ($scope.lot.pricing) {

                                            if ($scope.lot.pricing <= 20000000) {
                                                $scope.minPrepaymentContractPercentage = 5;
                                                $scope.maxPrepaymentContractPercentage = 30;
                                                if (fl && $scope.lot.prepaymentContractPercentage !== null && !( ( $scope.lot.prepaymentContractPercentage >= 5 ) && ( $scope.lot.prepaymentContractPercentage <= 30 ) )) {
                                                    $scope.lot.requirement3044 = 'Нет';
                                                    toastService.show('Размер обеспечения контракта должен быть в диапазоне от 5% до 30%', true);
                                                }
                                            }

                                        }
                                        if ($scope.lot.advancePaymentPercentage > 30) {
                                            $scope.minPrepaymentContractPercentage = $scope.lot.advancePaymentPercentage;
                                            $scope.maxPrepaymentContractPercentage = $scope.lot.advancePaymentPercentage;
                                            $scope.lot.prepaymentContractPercentage = $scope.lot.advancePaymentPercentage;
                                        }
                                        break;
                                    case 'Запрос котировок':
                                        $scope.lot.prepaymentContractPercentage=null;
                                        $scope.isKotirovka=true;
                                        break;
                                    default:
                                        $scope.minPrepaymentContractPercentage = 0;
                                        $scope.maxPrepaymentContractPercentage = 100;
                                }
                            }


                        }

                    }
                }]
        }
    }]);