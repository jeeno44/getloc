﻿angular.module( 'isz' )
.controller( 'ArchivePlan', ['$scope', 'appsecurity', 'plansService','lotsService', 'controlsService','toastService','commonVariables',
    function ( $scope, appsecurity, plansService,lotsService, controlsService, toastService,commonVariables ) {


    $scope.archivePlans=plansService.archivePlans;
        $scope.commonVariables=commonVariables;
        $scope.revisionsArray=[];

    commonVariables.enterInLotTimeStamp=null;
        commonVariables.currentMenuItem('/plans');
        function flash() {
            $scope.canSignConsolidate = false;

            // plansService.getPlansCommon('current', $scope.rukKoord).then(function () {


                $scope.consolidatedPlan =plansService.consolidatedPlan;
                $scope.plan=$scope.consolidatedPlan;
                if ($scope.consolidatedPlan) {
                    $scope.plansDeps = plansService.consolidatedPlan.plans;
                    $scope.versionPlan={
                        id:$scope.consolidatedPlan.id,
                        created:"текущая"
                    }
                    $scope.revisionsArray.splice[0];
                    $scope.revisionsArray.push($scope.versionPlan);
                    if ($scope.consolidatedPlan.revision.length) {
                        $scope.consolidatedPlan.revisionSort();
                        $scope.consolidatedPlan.revision.forEach(function (rev) {
                            $scope.revisionsArray.push({id:rev.id,created:moment(rev.created).format('DD.MM.YYYY')});
                        });

                    }
                  


                    $scope.consolidatedPlan.controls.forEach(function (control) {
                        if (control&&control.opName&&control.opName==='plan_send_zakupki'){
                            $scope.consolidatedPlan.zakupkiControl=control;
                        }
                        if (control&&control.opName&&control.opName==='plan_consolidate_download_xml') {
                            $scope.consolidatedPlan.downloadDocumentsXML=control;
                        }
                    })
                }
            // });

        }
        $scope.changeRevision = function () {
            plansService.getNewPlansRevision($scope.versionPlan);
        }
        $scope.changeArchiveYear = function () {
            plansService.getNewPlansRevision($scope.selectedPlan).then(function () {
                flash();
            });

        }
        

        appsecurity.getUserInfo().then( function () {
        if (commonVariables.currentSubSystem!=='plans'){
            commonVariables.currentSubSystem='plans';
            appsecurity.currentRole.subsystemChanged();
        }
        $scope.depZakFlag = appsecurity.currentRole.code.indexOf('depzak') !== -1;
        $scope.rukDepZak = appsecurity.currentRole.code.indexOf('Rukovoditel_depzak') !== -1;
       
        $scope.readLot = appsecurity.currentRole.permissions.readLot;
        $scope.readSections = appsecurity.currentRole.permissions.readSections;
        $scope.controlSections = appsecurity.currentRole.permissions.controlSections;
        $scope.readSectionsAll = appsecurity.currentRole.permissions.readSectionsAll;
        $scope.rukKoord = appsecurity.currentRole.code.indexOf('Rukovoditel_koordinator') !== -1;


        $scope.readArchivePlans = appsecurity.currentRole.permissions.readArchivePlans;
        if ( $scope.readArchivePlans ) {

            lotsService.getExpertStatuses().then(function () {

                plansService.getPlansSatauses().then(function () {

                    flash();

                    // plansService.getArchivePlans().then(function () {
                    //     flash();
                    //     if (angular.isArray($scope.archivePlans)){
                    //         $scope.selectedPlan=$scope.archivePlans[0];
                    //     }
                    // });

                })

            })
            
        } else {
            plansService.flash();
            commonVariables.isLoading = false;
            toastService.show( 'У Вас нет прав доступа для просмотра этой страницы', false );
        }
        
    } , function () {
        commonVariables.isLoading = false;
    } );
        $scope.downloadFile = function ( document ) {
            //window.open('http://isz.gosbook.ru'+ document.file, '_blank' );
            window.open( document.file, '_blank' );
        };
        $scope.downloadFileFresh = function(document){
            window.open( document.full_path, '_blank' );
        };
        $scope.controlClick = function ( control ) {
            controlsService.executeCommand( control ).then( function () {
                plansService.getPlansCommon( 'archive' );
            } );
        };
        // $scope.afterExpandClick = function(plan,open){
        //     plan.fillPlanLots();
        // };
}] );