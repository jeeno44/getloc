/**
 * Created by pol on 14.08.2015.
 */
angular.module('isz')
    .directive('lotObjectTab', [function () {
        return {
            restrict: 'E',
            scope: true,
            templateUrl: '/js/plans/directives/lotObjectsTab/template/lotObjectTabTemplate.html',
            controller: ['$scope', '$mdDialog', 'commonVariables', 'stagesService', 'workTypeService', 'toastService', 'Stage',
                function ($scope, $mdDialog, commonVariables, stagesService, workTypeService, toastService, Stage) {

                    var self = this, stageLastValues = {};
                    $scope.stagesBuff = [];
                    setLot();

                    function setLot() {
                        if (commonVariables.currentLot) {
                            $scope.lot = commonVariables.currentLot;

                            $scope.creating
                                ? init()
                                : commonVariables.currentLot.fillAllInfo().then(function () {
                                init();
                            });
                            $scope.$$phase || $scope.$apply();
                        } else {
                            setTimeout(setLot, 100);
                        }
                    }

                    $scope.name = 'object';

                    $scope.startingDates = stagesService.startingDates;
                    $scope.executionTypes = stagesService.executionTypes;

                    $scope.startingWorkDates = workTypeService.startingWorkDates;
                    $scope.executionWorkTypes = workTypeService.executionTypes;

                    $scope.stageCanBeAdded = function (relYearIndex) {
                        var canBeAdded = ( $scope.lot.inEditMode || $scope.creating );

                        if (canBeAdded) {
                            canBeAdded = $scope.lot.stages.length > 0 && $scope.lot.stages.some(function (stage) {
                                    return stage.startYear == relYearIndex - 1;
                                })
                        }

                        return canBeAdded;
                    }

                    $scope.addStage = function () {
                        var stage = stagesService.getNewStage();
                        stage.canAddNewWorkType=true;
                        //if ( $scope.lot.inEditMode ) {
                        //    stage.create( $scope.lot )
                        //}
                        //$scope.lot.stages.push( stage );
                        $scope.stagesBuff.push(stage);
                    }

                    $scope.addWorkType = function (stage, type) {
                        workTypeService.stage = stage;

                        var work = workTypeService.getNewWorkType(type);
                        stage.workTypes.push(work);
                        stage.canAddNewWorkType=false;
                        //if (stage.id) {
                        //    for (var ind = 0; ind < $scope.lot.stages.length; ind++) {
                        //        if ($scope.lot.stages[ind].id === stage.id) {
                        //            break;
                        //        }
                        //    }
                        //}
                        //var workType = workTypeService.getNewWorkType(type);
                        //if ($scope.lot.inEditMode) {
                        //    workType.create().then(function () {
                        //        stage.workTypes.push(workType);
                        //        $scope.lot.stages[ind].workTypes.push(workType)
                        //    });
                        //} else {
                        //    var work = workTypeService.getNewWorkType(type);
                        //    stage.workTypes.push(work);
                        //    replaceLotStages();
                        //}
                    }

                    $scope.executionTypePatch = function (obj, stage) {
                        if (obj.executionType == 1) {
                            obj.executionDateTerm = false;

                        } else {
                            obj.executionDateTerm = true;
                        }
                        if (obj instanceof Stage) {
                            $scope.stageFieldChange(obj, "executionType", true);
                        } else {
                            $scope.workTypeFieldChange(stage, obj, 'executionType');
                            $scope.workTypeFieldChange(stage, obj, 'executionDateTerm');
                            //obj.patch('executionType', 'executionDateTerm');
                        }
                        //obj.patch('executionType', 'executionDateTerm');
                    }


                    $scope.removeStage = function (stage) {
                        $mdDialog.show({
                            templateUrl: '/js/plans/templates/deleteStageModal.html',
                            controller: ['$scope', function ($scope) {
                                $scope.remove = function () {
                                    stagesService.removeStage(stage).then(function () {
                                        init();
                                    });

                                    $mdDialog.hide();

                                }

                                $scope.close = $mdDialog.hide;
                            }]
                        });

                    }

                    $scope.removeWorkType = function (workType, stage) {
                        var index = stage.workTypes.indexOf(workType);
                        stage.workTypes.splice(index, 1);
                        //workType.financingChanged(false, stage);
                        replaceLotStages();

                        if (workType.id) {
                            workType.remove();
                        }
                        stage.canAddNewWorkType=true;

                        //var ind=$scope.lot.stages.indexOf(stage);


                        //var indLot = $scope.lot.stages[ind].workTypes.indexOf(workType);
                        //$scope.lot.stages[ind].workTypes.splice(index, 1);
                        //workType.financingChanged($scope.lot.inEditMode, stage);
                        //if (workType.id) {
                        //    workType.remove();
                        //}
                    }
                    $scope.getStagesFinancingSum = function () {
                        var sumStages = 0;
                        if ($scope.lot && angular.isArray($scope.lot.stages)) {
                            for (var i = 0; i < $scope.lot.stages.length; i++) {
                                if ($scope.lot.stages[i].financing) {
                                    sumStages += parseFloat($scope.lot.stages[i].financing);
                                }
                            }
                        }
                        return sumStages;
                    }

                    function init() {
                        $scope.stagesBuff.splice(0);
                        for (var i = 0; i < $scope.lot.stages.length; i++) {
                            var obj = {}, st;
                            angular.copy($scope.lot.stages[i], obj);
                            st = new Stage(obj);
                            st.canAddNewWorkType=true;
                            stageValidate(st);
                            $scope.stagesBuff.push(st);
                        }
                    }

                    //$scope.stageStartDate;
                    function stageValidate(stage, stageInd, pickerFlag) {
                        var toastStr = "Ошибка при проверке этапа " + (stageInd + 1) + ": ";
                        var toastList = [];

                        var valid = true;
                        //title validate
                        if (!stage.title) {
                            toastList.push("не заполнено название этапа");
                            if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                            return false;
                        }
                        if (!$scope.lot.procurementEndDate) {
                            toastList.push("не указана дата окончания закупок лота");
                            if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                            return false;
                        } else {
                            var procurementEndDate = moment($scope.lot.procurementEndDate);
                        }
                        var startDate;

                        //startYear
                        if (( stage.startYear * 1 ) > 1) {
                            if (stage.startingDate == 1) {
                                toastList.push("несоответствие года выполнения дате начала этапа");
                                if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                return false;
                            }
                            var arr = $scope.lot.stages.filter(function (st) {
                                return ( st.startYear * 1 ) == ( stage.startYear * 1 ) - 1;
                            })
                            if (angular.isDefined(arr) && arr.length) {
                                if (stage.startingDate == 2) {

                                    var draft = [];
                                    draft = $scope.stagesBuff.filter(function (st) {
                                        return st !== stage;
                                    });
                                    //draft.splice(draft.indexOf(stage),1);
                                    var arrCurr = draft.filter(function (st) {
                                        return ( st.startYear * 1 ) === ( stage.startYear * 1 );
                                    });

                                    if (angular.isDefined(arrCurr) && arrCurr.length) {
                                        var maxPrevSatgeDateEl;
                                        maxPrevSatgeDateEl = arrCurr.reduce(function (x, y) {
                                            var xDate, yDate;
                                            if (x.executionDateTerm) {
                                                xDate = moment(x.startDate).add(x.executionTerm, 'days');
                                            } else {
                                                xDate = moment(x.executionDate);
                                            }
                                            if (x.executionDateTerm) {
                                                yDate = moment(y.startDate).add(y.executionTerm, 'days');
                                            } else {
                                                yDate = moment(y.executionDate);
                                            }
                                            return ( xDate > yDate ) ? x : y;
                                        });
                                        if (maxPrevSatgeDateEl.executionDateTerm) {
                                            startDate = moment(maxPrevSatgeDateEl.startDate).add(maxPrevSatgeDateEl.executionTerm, 'days');
                                        } else {
                                            startDate = moment(maxPrevSatgeDateEl.executionDate);
                                        }

                                    } else {
                                        toastList.push("нет предыдущего этапа");
                                        if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                        return false;
                                    }

                                }

                                if (stage.startingDate == 3) {
                                    startDate = new Date(procurementEndDate.year() + ( stage.startYear * 1 ) - 1, 0, 1);
                                    startDate = moment(startDate);
                                }

                                if (stage.startingDate == 4) {
                                    if (!stage.startDate) {
                                        toastList.push("не указана дата начала этапа");
                                        if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                        return false;
                                    } else {
                                        startDate = stage.startDate;
                                        var dd1 = new Date(procurementEndDate.year() + ( stage.startYear * 1 ) - 1, 0, 1);
                                        var dd2 = new Date(procurementEndDate.year() + ( stage.startYear * 1 ), 0, 1);
                                        if (!( moment(stage.startDate) >= dd1 && moment(stage.startDate) < dd2 )) {
                                            toastList.push("несоответствие года выполнения дате начала этапа");
                                            if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                            return false;
                                        }
                                    }
                                    startDate = moment(stage.startDate);
                                }

                            } else {
                                toastList.push("нет предыдущего этапа");
                                if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                return false;
                            }


                        } else {
                            if (stage.startingDate === 1) {
                                startDate = procurementEndDate;
                            }
                            if (stage.startingDate === 2) {
                                var draft = [];
                                draft = $scope.stagesBuff.filter(function (st) {
                                    return st !== stage;
                                });
                                var arrCurr = draft.filter(function (st) {
                                    return ( st.startYear * 1 ) === ( stage.startYear * 1 );
                                });

                                if (angular.isDefined(arrCurr) && arrCurr.length) {
                                    var maxPrevSatgeDateEl;
                                    maxPrevSatgeDateEl = arrCurr.reduce(function (x, y) {
                                        var xDate, yDate;
                                        if (x.executionDateTerm) {
                                            xDate = moment(x.startDate).add(x.executionTerm, 'days');
                                        } else {
                                            xDate = moment(x.executionDate);
                                        }
                                        if (x.executionDateTerm) {
                                            yDate = moment(y.startDate).add(y.executionTerm, 'days');
                                        } else {
                                            yDate = moment(y.executionDate);
                                        }
                                        return ( xDate > yDate ) ? x : y;
                                    });
                                    if (maxPrevSatgeDateEl.executionDateTerm) {
                                        startDate = moment(maxPrevSatgeDateEl.startDate).add(maxPrevSatgeDateEl.executionTerm, 'days');
                                    } else {
                                        startDate = moment(maxPrevSatgeDateEl.executionDate);
                                    }

                                } else {
                                    toastList.push("нет предыдущего этапа");
                                    if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                    return false;
                                }
                            }
                            if (stage.startingDate === 3) {
                                toastList.push("несоответствие года выполнения дате начала этапа");
                                if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                return false;
                            }
                            if (stage.startingDate === 4) {
                                if (!stage.startDate) {
                                    toastList.push("не указана дата начала этапа");
                                    if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                    return false;
                                } else {
                                    if (moment(stage.startDate) < procurementEndDate) {
                                        toastList.push("дата начала этапа должна быть позже даты окончания закупок");
                                        if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                        return false;
                                    } else {
                                        var dd = new Date(procurementEndDate.year() + 1, 0, 1);
                                        if (!( moment(stage.startDate) >= procurementEndDate && moment(stage.startDate) < dd )) {
                                            toastList.push("дата начала этапа должна быть позже даты окончания закупок");
                                            if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                            return false;
                                        }
                                    }
                                }
                                startDate = moment(stage.startDate);
                            }
                        }
                        if (!stage.startDate) {
                            stage.startDate = startDate.toDate();
                        }

                        if (!stage.executionType) {
                            return false;
                        } else {
                            switch (stage.executionType) {
                                case 1:
                                    if (!stage.executionDate) {
                                        toastList.push("не указана дата окончания этапа");
                                        if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                        return false;
                                    } else {
                                        if (moment(stage.executionDate) < startDate) {
                                            toastList.push("дата окончания этапа должна быть позже даты начала этапа");
                                            if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                            return false;
                                        }
                                    }

                                    break;
                                case 2:
                                    if (!stage.executionTerm) {
                                        toastList.push("не указан срок окончания этапа");
                                        if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                        return false;
                                    } else {

                                        var dd = new Date(procurementEndDate.year() + ( stage.startYear * 1 ), 0, 1);
                                        if (moment(stage.startDate).add(stage.executionTerm, 'days') >= dd) {
                                            toastList.push("дата окончания этапа должна быть позже даты начала этапа");
                                            if (!pickerFlag) toastService.showList(toastStr, toastList, false);
                                            return false;
                                        }
                                        var dat = moment(stage.startDate).add(stage.executionTerm, 'days');
                                        stage.executionDate = dat.toDate();
                                    }
                                    break;
                            }
                        }


                        return true;
                    }

                    $scope.stageFieldChange = function (stage, field, pickerFlag) {
                        if (field === 'executionTerm') {
                            var dat = moment(stage.startDate).add(stage.executionTerm, 'days');
                            stage.executionDate = dat.toDate();
                        }
                        if (field==='financing' &&stage.workTypes&&stage.workTypes.length&&(stage.financing!=stage.getWorkTypeFinancingSumm())){
                            toastService.show('Цена по этапу не равна сумме стоимостей работ этапа',false)
                        }
                        stage.canSave = true;

                    };

                    function workTypeValidate(stage, workType) {
                        var toastStr = "Ошибка при проверке работ этапа: ";
                        var toastList = [];
                        if (!workType.title) {
                            toastList.push(" Не заполнено название ТРиУ");
                            toastService.showList(toastStr, toastList, false);
                            return false;
                        }
                        if (!stage.startDate) {
                            return false;
                        }
                        switch (workType.startingDate) {
                            case 1:
                                workType.startDate = stage.startDate;
                                break;
                            case 2:
                                var draft = stage.workTypes.filter(function (wk) {
                                    return wk !== workType;
                                });
                                if (draft && draft.length) {
                                    var maxPrevSatgeDateEl;
                                    maxPrevSatgeDateEl = draft.reduce(function (x, y) {
                                        var xDate, yDate;
                                        if (x.executionDateTerm) {
                                            xDate = moment(x.startDate).add(x.executionTerm, 'days');
                                        } else {
                                            xDate = moment(x.executionDate);
                                        }
                                        if (x.executionDateTerm) {
                                            yDate = moment(y.startDate).add(y.executionTerm, 'days');
                                        } else {
                                            yDate = moment(y.executionDate);
                                        }
                                        return ( xDate > yDate ) ? x : y;
                                    });
                                    if (maxPrevSatgeDateEl.executionDateTerm) {
                                        workType.startDate = moment(maxPrevSatgeDateEl.startDate).add(maxPrevSatgeDateEl.executionTerm, 'days').toDate();
                                    } else {
                                        workType.startDate = maxPrevSatgeDateEl.executionDate;
                                    }

                                } else {
                                    toastList.push(" Нет предыдущей сущности ТРиУ");
                                    toastService.showList(toastStr, toastList, false);
                                    return false;
                                }
                                break;
                            case 3:
                                var dat = new Date(moment(stage.startDate).year(), 0, 1);
                                if (moment(stage.startDate) > dat) {
                                    toastList.push(" Начало ТРиУ не может быть раньше начала этапа");
                                    toastService.showList(toastStr, toastList, false);
                                    return false;
                                } else {
                                    workType.startDate = dat;
                                }
                                break;
                            case 4:
                                if (!workType.startDate) {
                                    toastList.push(" Не указана дата начала ТРиУ");
                                    toastService.showList(toastStr, toastList, false);
                                    return false;
                                }

                                break;

                        }

                        if (workType.executionType) {
                            switch (workType.executionType) {
                                case 1:
                                    if (!workType.executionDate) {
                                        toastList.push(" Не указана дата окончания ТРиУ");
                                        toastService.showList(toastStr, toastList, false);
                                        return;
                                    }
                                    break;
                                case 2:
                                    if (!workType.executionTerm) {
                                        toastList.push(" Не указан срок окончания ТРиУ");
                                        toastService.showList(toastStr, toastList, false);
                                        return;
                                    } else {
                                        var dat = moment(workType.startDate).add(workType.executionTerm, 'days');
                                        if (moment(stage.executionDate) <= dat) {
                                            toastList.push(" Срок окончания ТРиУ превышает дату окончания этапа");
                                            toastService.showList(toastStr, toastList, false);
                                            return false;
                                        } else {
                                            workType.executionDate = dat.toDate();
                                        }
                                    }
                                    break;
                            }
                        } else {
                            toastList.push(" Не указано окончание ТРиУ");
                            toastService.showList(toastStr, toastList, false);
                            return;
                        }


                        return true;
                    }


                    $scope.workTypeFieldChange = function (stage, workType, field) {
                        if (field === 'executionTerm') {
                            var dat = moment(workType.startDate).add(workType.executionTerm, 'days');
                            workType.executionDate = dat.toDate();
                        }
                        if (field==='financing' &&stage.workTypes&&stage.workTypes.length&&(stage.financing!=stage.getWorkTypeFinancingSumm())){
                                toastService.show('Цена по этапу не равна сумме стоимостей работ этапа',false);
                        }
                        workType.canSave = true;
                    };
                    $scope.workTypeSave = function (stage, workType) {

                        var flag = true;

                        for (var i = 0; i < stage.workTypes.length; i++) {
                            //toastStr += ( i + 1 ) + " ";
                            if (!workTypeValidate(stage, stage.workTypes[i])) {
                                flag = false;
                                break;
                            }
                        }
                        if (flag) {
                            if (stage.id) {
                                for (var ind = 0; ind < $scope.lot.stages.length; ind++) {
                                    if ($scope.lot.stages[ind].id === stage.id) {
                                        break;
                                    }
                                }

                                if (workType.id) {
                                    workType.save().then(function () {
                                        for (var ind2 = 0; ind2 < $scope.lot.stages[ind].workTypes.length; ind2++) {
                                            if ($scope.lot.stages[ind].workTypes[ind2].id === workType.id) {
                                                break;
                                            }
                                        }
                                        Object.keys(workType).forEach(function (key) {
                                            $scope.lot.stages[ind].workTypes[ind2][key] = workType[key];
                                        });
                                        toastService.show('ТР(У) успешно сохранен', false);
                                        workType.saved = true;
                                        workType.canSave = false;
                                        stage.canAddNewWorkType=true;
                                        //workType.financingChanged(true, stage);
                                        //$scope.stageFinanacingChange(stage)
                                    });

                                } else {
                                    workType.create().then(function () {
                                        //$scope.lot.stages[ind].workTypes.splice(0);
                                        //stage.workTypes.forEach(function (wk) {
                                        //    $scope.lot.stages[ind].workTypes.push(wk);
                                        //});

                                        workType.canSave = false;
                                        stage.canAddNewWorkType=true;
                                        //workType.financingChanged(true, stage);
                                        //$scope.stageFinanacingChange(stage)
                                        //toastService.show('ТР(У) успешно создан', false);
                                    });

                                }
                            } else {
                                replaceLotStages();
                                toastService.show('ТР(У) успешно добавлен', false);
                                workType.saved = true;
                                workType.canSave = false;
                                stage.canAddNewWorkType=true;
                                //workType.financingChanged(true, stage);
                                //$scope.stageFinanacingChange(stage)
                            }

                        }


                    };

                    $scope.goodFinancing = function (stage, workType, field) {
                        $scope.workTypeFieldChange(stage, workType, field);
                        workType.financing = workType.pricePerUnit * workType.volume;
                        //workType.financingChanged(true, stage);
                        //$scope.stageFinanacingChange(stage)
                    };


                    $scope.stageSave = function (stage) {

                        var flag = true;

                        for (var i = 0; i < $scope.stagesBuff.length; i++) {
                            if (!stageValidate($scope.stagesBuff[i], i)) {
                                flag = false;
                                break;
                            }
                        }
                        if (flag) {
                            if (stage.id) {
                                stage.save().then(function () {

                                    for (var ind = 0; ind < $scope.lot.stages.length; ind++) {
                                        if ($scope.lot.stages[ind].id === stage.id) {
                                            break;
                                        }
                                    }

                                    Object.keys(stage).forEach(function (key) {
                                        $scope.lot.stages[ind][key] = stage[key];
                                    });
                                    toastService.show('Этап успешно сохранен', false);
                                    stage.canSave = false;
                                    stage.saved = true;
                                });


                            } else {
                                if ($scope.lot.id) {
                                    stage.create($scope.lot).then(function () {
                                        $scope.lot.stages.push(stage);
                                        stage.canSave = false;
                                        toastService.show('Этап успешно добавлен', false);
                                    });
                                } else {
                                    replaceLotStages();
                                    toastService.show('Этап успешно сохранен', false);
                                    stage.canSave = false;
                                    stage.saved = true;
                                }
                            }
                        }


                    };
                    $scope.stageFinanacingChange = function (stage) {
                        if (stage.id) {
                            for (var ind = 0; ind < $scope.lot.stages.length; ind++) {
                                if ($scope.lot.stages[ind].id === stage.id) {
                                    break;
                                }
                            }
                            $scope.lot.stages[ind].financing = stage.financing;

                            stage.patch('financing')
                            $scope.lot.stages[ind].patch('financing').then(function(){
                                init();
                            });

                        } else {
                            replaceLotStages();
                        }


                    };
                    function replaceLotStages() {
                        $scope.lot.stages.splice(0);
                        $scope.stagesBuff.forEach(function (st) {
                            $scope.lot.stages.push(st);
                        });
                    }

                }]
        }
    }]);
