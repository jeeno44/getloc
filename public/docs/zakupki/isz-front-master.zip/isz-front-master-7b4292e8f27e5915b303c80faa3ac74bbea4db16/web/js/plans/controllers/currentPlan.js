/**
 * Created by pol on 12.08.2015.
 */
angular.module('isz')
    .controller('CurrentPlan', ['$scope', '$window', '$http', 'appsecurity', 'apiService', 'commonVariables', 'lotsService', 'plansService', 'controlsService', 'toastService', '$mdDialog',
        function ($scope, $window, $http, appsecurity, apiService, commonVariables, lotsService, plansService, controlsService, toastService, $mdDialog) {
            commonVariables.isLoading = true;
            commonVariables.enterInLotTimeStamp = null;
            $scope.commonVariables=commonVariables;
            $scope.menuArray = commonVariables.subsystemArray;

            

            $scope.revisionsArray=[];

            commonVariables.enterInLotTimeStamp=null;
            commonVariables.currentMenuItem('/plans/current');


            function flash() {
                $scope.canSignConsolidate = false;
                // if (!$scope.depZakFlag) {

                    plansService.getPlansCommon('current', $scope.rukKoord).then(function () {
                        // getConsFinancing();
                        commonVariables.isLoading = false;
                        //if (angular.isArray($scope.statusedPlans) && appsecurity.currentRole.code === 'Rukovoditel_koordinator') {
                        //    for (var i = 0; i < $scope.statusedPlans.length; i++) {
                        //        if ($scope.statusedPlans[i].id === 'on_agreement') {
                        //            $scope.canSignConsolidate = true;
                        //            break;
                        //        }
                        //    }
                        //}
                        $scope.consolidatedPlan =plansService.consolidatedPlan;
                        $scope.plan=$scope.consolidatedPlan;
                        if ($scope.consolidatedPlan) {
                            $scope.plansDeps = plansService.consolidatedPlan.plans;
                            $scope.versionPlan={
                                id:$scope.consolidatedPlan.id,
                                created:"текущая"
                            }
                            $scope.revisionsArray.push($scope.versionPlan);
                            if ($scope.consolidatedPlan.revision.length) {
                                $scope.consolidatedPlan.revisionSort()
                                $scope.consolidatedPlan.revision.forEach(function (rev) {
                                    $scope.revisionsArray.push({id:rev.id,created:moment(rev.created).format('DD.MM.YYYY')});
                                });

                            }

                            $scope.consolidatedPlan.controls.forEach(function (control) {
                               
                                if (control&&control.opName&&control.opName==='plan_send_zakupki'){
                                    $scope.consolidatedPlan.zakupkiControl=control;
                                }
                                if (control&&control.opName&&control.opName==='plan_consolidate_download_xml') {
                                    $scope.consolidatedPlan.downloadDocumentsXML=control;
                                }
                            })
                        }
                    }, function () {
                        commonVariables.isLoading = false;
                    });
                // } else {
                //     plansService.getPlansDepzak('current').then(function () {
                //         if (angular.isArray(plansService.plans) && plansService.plans.length) {
                //             commonVariables.currentUserPlan=plansService.plans[0];
                //         }
                //         commonVariables.isLoading = false;
                //     }, function () {
                //         commonVariables.isLoading = false;
                //     });
                // }
            }
            
            $scope.changeRevision = function () {
                plansService.getNewPlansRevision($scope.versionPlan);
            }

            appsecurity.getUserInfo().then(function () {
                if (commonVariables.currentSubSystem!=='plans'){
                    commonVariables.currentSubSystem='plans';
                    appsecurity.currentRole.subsystemChanged();
                }
                $scope.depZakFlag = appsecurity.currentRole.code.indexOf('depzak') !== -1;
                $scope.rukDepZak = appsecurity.currentRole.code.indexOf('Rukovoditel_depzak') !== -1;
                $scope.readCurrentPlan = appsecurity.currentRole.permissions.readCurrentPlan;
                $scope.readLot = appsecurity.currentRole.permissions.readLot;
                $scope.readSections = appsecurity.currentRole.permissions.readSections;
                $scope.controlSections = appsecurity.currentRole.permissions.controlSections;
                $scope.readSectionsAll = appsecurity.currentRole.permissions.readSectionsAll;
                $scope.rukKoord = appsecurity.currentRole.code.indexOf('Rukovoditel_koordinator') !== -1;
                $scope.documentsPackLink = apiService.serverRoute + 'integrations/zakupki_xml/' + appsecurity.currentExpertGroup.common.id;
                $scope.uploadZakupkiLink = apiService.serverRoute + 'integrations/zakupki_xml/upload/' + appsecurity.currentExpertGroup.common.id;


                if (!$scope.readCurrentPlan) {
                    toastService.show('У Вас нет прав доступа для просмотра этой страницы', false);
                    commonVariables.isLoading = false;
                } else {
                    lotsService.getExpertStatuses().then(function () {
                        $scope.statuses = commonVariables.expertsStatuses;

                        $scope.currentPlans = plansService.plans;

                        $scope.statusedPlans = plansService.statusedPlans;
                        

                        plansService.getPlansSatauses().then(flash,function(){

                            commonVariables.isLoading = false;
                        });
                        //flash();

                        $scope.currYears = [];
                        var currYear = new Date();
                        for (var i = 0; i < 3; i++) {
                            $scope.currYears.push(currYear.getFullYear() + i)
                        }
                    },function(){
                        commonVariables.isLoading = false;
                    });
                }




            },function(){
                commonVariables.isLoading = false;
            });
           
            $scope.afterExpandClick = function(plan,open){
                // plan.fillPlanLots();
            }

            $scope.controlClick = function (control) {

                var plan = $scope.plan;
                if (control.opName === 'plan_send_zakupki'){
                    $scope.zakupkiUploadModal();
                }
                else if ( control.opName == 'delegate' ) {
                    $mdDialog.show( {
                        templateUrl: '/js/plans/templates/expertsModal.html',
                        controller: function ($scope, commonVariables, apiService, controlsService) {

                            $scope.selectedExperts = [];
                            $scope.plan = plan;

                            $http({
                                url: apiService.expertsRoute,
                                headers: appsecurity.getSecurityHeaders(),
                                method: 'GET'
                            }).then(function (response) {
                                $scope.experts = response.data;

                            }, function (response) {
                                var str = 'Возникла ошибка при получении данных с сервера. ';
                                toastService.errorResponseShow(str, response);
                            })

                            $scope.send = function () {

                                var body = {
                                    expertList: []
                                };

                                for (var i = 0; i < $scope.selectedExperts.length; i++) {
                                    body.expertList.push($scope.selectedExperts[i].users.id)
                                }

                                controlsService.executeCommand(control, $scope.plan.id, body);

                                $mdDialog.hide();
                            }

                            $scope.exit = $mdDialog.hide;

                            $scope.exists = function (expert) {
                                return $scope.selectedExperts.indexOf(expert) > -1;
                            }

                            $scope.toggle = function (expert) {
                                var idx = $scope.selectedExperts.indexOf(expert);
                                if (idx > -1) $scope.selectedExperts.splice(idx, 1);
                                else $scope.selectedExperts.push(expert);
                            }
                        },
                        locals:{ 'control':control, 'plan': plan}
                    } ).then( function () {

                    } )
                }
                else {
                    if (control.opName === 'plan_consolidate_download_xml'){
                        $scope.ajaxDownloadFile(apiService.baseUrl + control.url, 'Пакет Документов.zip');
                    } else {
                        controlsService.executeCommand(control).then(function () {
                            flash();
                        });
                    }
                }
            }
          

            $scope.ajaxDownloadFile = function(url, fileName){
                var xhr = new XMLHttpRequest();
                xhr.open("GET", url, true);
                xhr.responseType = "blob";
                var headers = appsecurity.getSecurityHeaders();
                xhr.setRequestHeader('X-Access-Token', headers['X-Access-Token']);
                xhr.setRequestHeader('X-Common-Id', headers['X-Common-Id']);
                xhr.setRequestHeader('X-Expert-Group-Id', headers['X-Expert-Group-Id']);
                xhr.setRequestHeader('X-Expert-Role', headers['X-Expert-Role']);
                xhr.setRequestHeader('X-Sub-System', headers['X-Sub-System']);
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4) {
                        var a = document.createElement("a");
                        document.body.appendChild(a);
                        a.style = "display: none";
                        var url = window.URL.createObjectURL(xhr.response);
                        a.href = url;
                        a.download = fileName;
                        a.click();
                        setTimeout(function(){
                            window.URL.revokeObjectURL(url);
                        }, 100)
                    }
                };
                xhr.send(null);
            }


            $scope.downloadFile = function ( document ) {
                //window.open('http://isz.gosbook.ru'+ document.file, '_blank' );
                window.open( document.file, '_blank' );
            }
            $scope.downloadFileFresh = function(document){
                window.open( document.full_path, '_blank' );
            };

            $scope.removeDoc = function (doc) {
                $http({
                    method: 'DELETE',
                    url: apiService.serverRoute + 'plandocs/' + doc.id,
                    headers: appsecurity.getSecurityHeadersForFileUpload()
                }).then(function (response) {
                    if (response.status < 300) {
                        $scope.currentPlans[0].planDocs.splice($scope.currentPlans[0].planDocs.indexOf(doc), 1);
                    }
                }, function (response) {
                    toastService.errorResponseShow('Ошибка удаления файла на сервере.', response)
                });
            };
            $scope.signConsolidate = function () {
                $http({
                    method: 'POST',
                    url: apiService.serverRoute + 'plan/consolidated/sign',
                    headers: appsecurity.getSecurityHeaders(),

                }).then(function (response) {
                    if (response.status < 300) {
                        toastService.show('Консолидированный план подписан', false);
                        flash();
                    } else {
                        toastService.show('Ошибка подписания плана', true);
                    }
                }, function (response) {
                    toastService.errorResponseShow('Ошибка подписания плана.', response)
                });
            }



            $scope.zakupkiUploadModal = function () {
                $mdDialog.show({
                    templateUrl: '/js/plans/templates/zakupkiUploadModal.html',
                    controller: ['$scope', function ($scope) {

                        $scope.ecpInitComplete = false;
                        $scope.ecpCertSelected = null;
                        $scope.ecpInitError = "";
                        $scope.ecpStore = null;
                        $scope.ecpCertUnsignedValue = "";

                        $scope.remove = function () {

                            $mdDialog.hide();
                        }

                        $scope.close = $mdDialog.hide;

                        $scope.applyECP = function(){

                            var foivId = appsecurity.currentExpertGroup.common.id;

                            $http({
                                method: 'GET',
                                url: apiService.serverRoute + 'integrations/zakupki_binary/' + foivId,
                                headers: appsecurity.getSecurityHeaders()
                            }).then(function(result) {
                                var hex = result.data.data;
                                var userCert = $scope.ecpStore.Certificates.Find(CAPICOM_CERTIFICATE_FIND_SHA, $scope.ecpCertSelected.id).Item(1);
                                $scope.ecpSigner.Certificate = userCert;
                                $scope.ecpSignedData.ContentEncoding = CADESCOM_BASE64_TO_BINARY;
                                $scope.ecpSignedData.Content = hex;



                                try {
                                    $scope.ecpCertUnsignedValue = $scope.ecpSignedData.SignCades($scope.ecpSigner, CADESCOM_CADES_BES, true);

                                    console.log($scope.ecpCertUnsignedValue);


                                } catch (err) {
                                    $scope.ecpInitError = "Ошибка создания подписи";
                                }

                                $scope.ecpStore.Close();
                            });

                        }

                        $scope.initECP = function () {

                            if (!$scope.ecpInitComplete) {
                                $scope.ecpStore = ObjCreator("CAPICOM.Store");
                                $scope.ecpSigner = ObjCreator("CAdESCOM.CPSigner");
                                $scope.ecpSignedData = ObjCreator("CAdESCOM.CadesSignedData");

                                if ($scope.ecpStore) {
                                    function formatDate(d) {
                                        try {
                                            d = new Date(d);
                                            return ('0' + d.getDate()).slice(-2) + '.' + ('0' + (d.getMonth() + 1)).slice(-2) + '.' + d.getFullYear();
                                        } catch (e) {
                                            return '';
                                        }
                                    }

                                    $scope.ecpStore.Open(CAPICOM_CURRENT_USER_STORE, CAPICOM_MY_STORE, CAPICOM_STORE_OPEN_MAXIMUM_ALLOWED);

                                    var certCnt = $scope.ecpStore.Certificates.Count;

                                    if (certCnt > 0) {
                                        for (var i = 1; i <= certCnt; i++) {
                                            var cert = $scope.ecpStore.Certificates.Item(i);
                                            $scope.ecpCertList = [];
                                            $scope.ecpCertList.push({'id' : cert.Thumbprint, 'name': cert.GetInfo(6) + ' (' + formatDate(cert.ValidFromDate) + ' - ' + formatDate(cert.ValidToDate) + ')'});
                                        }
                                    } else {
                                        $scope.ecpInitError = "На Вашем ПК неустановлена квалифицированная электронная подпись";
                                    }
                                } else {
                                    $scope.ecpInitError = "Ваш броузер или устарел или неустановленн КриптоПро";
                                }
                            }

                            return false;
                        }
                    }]
                });

            }


            $scope.getDocumentsPacket = function () {
                var foivId = appsecurity.currentExpertGroup.common.id;
                var headers = {
                    "Content-Type": "application/zip"
                }
                $http({
                    method: 'GET',
                    url: apiService.serverRoute + 'integrations/zakupki_xml/' + foivId,
                    headers: appsecurity.getSecurityHeaders()
                }).then(function (response) {

                }, function (response) {
                    toastService.errorResponseShow('Ошибка получения пакетов документа.', response)
                });
            }
            function getConsFinancing() {
                $scope.consFinancing = [0, 0, 0];
                $scope.statusedPlans.forEach(function (status) {
                    status.plansByStatus.forEach(function (plan) {
                        $scope.consFinancing[0] += plan.financing;
                        $scope.consFinancing[1] += plan.financing1;
                        $scope.consFinancing[2] += plan.financing2;
                    });
                });
            }

        }]);