/**
 * Created by pol on 14.08.2015.
 */
angular.module( 'isz' )
    .directive('lotGoalTab',['$mdDialog',function($mdDialog){
        return {
            restrict: 'E',
            templateUrl: '/js/plans/directives/lotGoalTab/template/lotGoalTabTemplate.html',
            controller: ['$scope','commonVariables',function($scope,commonVariables){
                $scope.name = 'goal';
                setLot();

                function setLot() {
                    if ( commonVariables.currentLot ) {
                        $scope.lot = commonVariables.currentLot;
                        $scope.$$phase || $scope.$apply();
                    } else {
                        setTimeout( setLot, 100 );
                    }
                }
                $scope.openRequirements1944Info = function(){
                    $mdDialog.show( {
                        templateUrl: '/js/plans/templates/requirements1944InfoModal.html',
                        controller: ['$scope', function ( $scope ) {
                            $scope.exit = $mdDialog.hide;
                        }]
                    } );
                }
                $scope.openInfo721744 = function(){
                    $mdDialog.show( {
                        templateUrl: '/js/plans/templates/Info721744Modal.html',
                        controller: ['$scope', function ( $scope ) {
                            $scope.exit = $mdDialog.hide;
                        }]
                    } );
                }
            }]
        }
    }]);
