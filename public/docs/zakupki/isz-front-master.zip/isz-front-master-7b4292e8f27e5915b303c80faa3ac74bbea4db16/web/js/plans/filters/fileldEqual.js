angular.module( 'isz' ).filter( 'fieldEqual', ['commonVariables', function ( commonVariables ) {

    return function ( items,parent, key, equal ) {
        return ( items || [] ).filter( function ( item ) {
            return item[parent][key] == equal;
        } );
    }
}] );