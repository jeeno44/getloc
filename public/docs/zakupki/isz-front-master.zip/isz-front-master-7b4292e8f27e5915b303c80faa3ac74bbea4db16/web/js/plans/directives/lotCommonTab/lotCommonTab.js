﻿/**
 * Created by pol on 14.08.2015.
 */
angular.module('isz')
    .directive('lotCommonTab', [function () {

        return {
            restrict: 'E',
            scope: true,
            templateUrl: '/js/plans/directives/lotCommonTab/template/lotCommonTabTemplate.html',
            controller: ['$scope', '$http', '$timeout', '$q', 'apiService', 'appsecurity', 'commonVariables', 'toastService', 'lazyLoadSelectService',
                function ($scope, $http, $timeout, $q, apiService, appsecurity, commonVariables, toastService, lazyLoadSelectService) {

                    appsecurity.getUserInfo().then(getAllSelectData);

                    function getAllSelectData() {

                        selectRequest(apiService.expensetypesSelect).then(function (response) {
                            $scope.expensetypesSelect = response.data;
                        }, function (response) {
                            toastService.errorResponseShow('Ошибка получения данных справочника направлений расходов', response);
                        })
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });
                    }

                    $scope.name = 'common';
                    $scope.commentsZIndexCounter = 0;

                    function replaceLotKbkSections(respArr, field) {
                        if (respArr.length && $scope.lot[field] && !angular.isObject($scope.lot[field])) {
                            var objArr = respArr.filter(function (sect) {
                                return sect.id == $scope.lot[field];
                            });
                            if (objArr && objArr.length == 1) {
                                $scope.lot[field] = objArr[0];
                            }
                        }
                    }

                    setLot();
                    function setLot() {
                        if (commonVariables.currentLot) {
                            $scope.lot = commonVariables.currentLot;
                            $scope.$$phase || $scope.$apply();
                        } else {
                            setTimeout(setLot, 100);
                        }
                    }

                    $scope.requireTabCounter = 0;
                    $scope.$on('requiredCounterChanged', function (event, number) {
                        $scope.requireTabCounter += number;
                    });

                    $scope.addArrayFieldElement = function(field){
                        var autoChild = document.getElementById(field+'Auto').firstElementChild;
                        var el = angular.element(autoChild);

                        var selectedField='selected'+field.slice(0,1).toUpperCase()+field.slice(1);
                        if ($scope[selectedField]) {
                            el.scope().$mdAutocompleteCtrl.clear();

                            for (var i = 0; i < $scope.lot[field].length; i++) {
                                if ($scope.lot[field][i].id == $scope[selectedField].id) {
                                    toastService.show('Эта опция уже добавлена', true);
                                    return;
                                }
                            }

                            delete $scope[selectedField].$$mdSelectId;

                            $scope.lot[field].unshift($scope[selectedField]);
                            $scope[selectedField] = undefined;

                            if ($scope.lot.inEditMode) {
                                var mapper = $scope.lot[field].map(function (code) {
                                    return {id: code.id};
                                })
                                var obj={};
                                obj[field]=mapper;
                                $scope.lot.patch(obj);
                            }


                        }
                        closeFunc();

                        function closeFunc(){

                            if (el && el.scope().$mdAutocompleteCtrl && !el.scope().$mdAutocompleteCtrl.hidden) {
                                el.scope().$mdAutocompleteCtrl.hidden=true;
                            } else {
                                setTimeout(closeFunc,10);
                            }
                        }

                    }

                    $scope.removeArrayFieldElement=  function(obj,field){
                        var index = $scope.lot[field].indexOf(obj);
                        $scope.lot[field].splice(index, 1);

                        if ($scope.lot.inEditMode) {
                            var obj={};
                            obj[field]=$scope.lot[field];
                            $scope.lot.patch(obj);
                        }
                    }



                    $scope.saveOkei = function () {
                        if ($scope.lot.okei && $scope.lot.okei.id) {
                            $scope.lot.patch({okei: $scope.lot.okei.id});
                        }

                    }
                    $scope.saveExpenseType = function () {
                        $scope.lot.patch({expenseType: $scope.lot.expenseType.id});
                    }
                    //$scope.saveKbk = function () {
                    //    $scope.lot.patch({kbk: $scope.lot.kbk.id});
                    //}

                    //$scope.saveKbkSection = function () {
                    //    if ($scope.lot.kbkSection && $scope.lot.kbkSection.id) {
                    //        $scope.lot.patch({kbkSection: $scope.lot.kbkSection.id}).then(function () {
                    //            var arr = $scope.lot.kbkSection.title.split(' - ');
                    //            $scope.lot.kbkSection.code = arr[0];
                    //        });
                    //    }
                    //
                    //}
                    //$scope.saveKbkCsr = function () {
                    //    if ($scope.lot.kbkCsr && $scope.lot.kbkCsr.id) {
                    //        $scope.lot.patch({kbkCsr: $scope.lot.kbkCsr.id}).then(function () {
                    //            var arr = $scope.lot.kbkCsr.title.split(' - ');
                    //            $scope.lot.kbkCsr.code = arr[0];
                    //        });
                    //    }
                    //
                    //}



                    function selectRequest(url) {
                        // var defer = $q.defer();
                        // $http({
                        //     method: 'GET',
                        //     headers: appsecurity.getSecurityHeaders(),
                        //     url: url
                        // }).then(function (response) {
                        //         defer.resolve(response);
                        //     }, function () {
                        //         $http({
                        //             method: 'GET',
                        //             headers: appsecurity.getSecurityHeaders(),
                        //             url: url
                        //         }).then(function (response) {
                        //             defer.resolve(response);
                        //         }, function (response) {
                        //             defer.reject(response);
                        //         })
                        //     }
                        // )
                        // return defer.promise;
                        function reqWrapper() {
                            var defer = $q.defer();
                            $http({
                                method: 'GET',
                                headers: appsecurity.getSecurityHeaders(),
                                url: url
                            }).then(function (response) {
                                    defer.resolve(response);
                                }, function (response) {
                                    defer.reject(response);

                                }
                            )
                            return defer.promise;

                        }
                        var req=reqWrapper;
                        commonVariables.requestArr.push(req);
                        return req();
                    }

                    $scope.lazyLoad = lazyLoadSelectService.lazyLoad;
                    $scope.unbindSelect = lazyLoadSelectService.unbindSelect;
                    $scope.autocomleteSearch = function(query,field,title){
                        var result = [], defer = $q.defer();
                        if (query) {
                            query = encodeURIComponent(query.replace("%20", "+"));
                            selectRequest(apiService[field+'sSelect'] + '?filters[title]=' + query + '&limit=100').then(function (response) {
                                if (angular.isArray(response.data)) {
                                    for (var i = 0; i < response.data.length; i++) {
                                        result.push(response.data[i]);
                                    }
                                }
                                //result = response.data;
                                defer.resolve(result);
                            }, function (response) {
                                toastService.errorResponseShow('Ошибка получения данных справочника '+title, response);
                                defer.reject();
                            })
                                .then(function () {
                                    commonVariables.requestArr.pop();
                                });
                        }

                        return defer.promise;
                    }


                    $scope.autocompleteLostFocus = function(id){
                        var input=document.querySelector('#'+id+" input");
                        var inpEl=angular.element(input);
                        inpEl.one('blur',function(e){
                            var autoChild = document.getElementById(id).firstElementChild;
                            var el = angular.element(autoChild);
                            el.scope().$mdAutocompleteCtrl.loading=false;
                        })
                    }

                }]
        }
    }]);
