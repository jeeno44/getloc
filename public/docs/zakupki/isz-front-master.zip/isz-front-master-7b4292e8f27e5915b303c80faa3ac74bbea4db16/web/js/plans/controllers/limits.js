﻿angular.module( 'isz' )
.controller( 'Limits', ['$scope', 'limitsServiсe', 'appsecurity', 'toastService','commonVariables',
    function ( $scope, limitsServiсe, appsecurity, toastService,commonVariables ) {
        commonVariables.enterInLotTimeStamp=null;
        $scope.commonVariables=commonVariables;
        commonVariables.currentMenuItem('/plans/limits');
        $scope.currLimit = limitsServiсe.currLimit;
        $scope.nextLimit = limitsServiсe.nextLimit;

        var year = new Date();
        $scope.currYear = year.getFullYear();
        $scope.nextYear = $scope.currYear + 1;
        limitsServiсe.clearLimits();

        appsecurity.getUserInfo().then( function () {
            if (commonVariables.currentSubSystem!=='plans'){
                commonVariables.currentSubSystem='plans';
                appsecurity.currentRole.subsystemChanged();
            }

            $scope.readLimits = appsecurity.currentRole.permissions.readLimits;
            if ( !$scope.readLimits ) {
                commonVariables.isLoading = false;
                toastService.show( 'У Вас нет прав доступа для просмотра этой страницы', false );
            } else {

                limitsServiсe.getLimits( $scope.currYear ).then( function () {
                    commonVariables.isLoading = false;
                } );
            }
        } );


    }] );