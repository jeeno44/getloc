/**
 * Created by pol on 22.08.2015.
 */
angular.module('isz')
    .factory('PlanFactory', ['$http', '$q', 'apiService', 'appsecurity', 'commonVariables', 'LotFactory', 'lotsService', 'toastService',
        function ($http, $q, apiService, appsecurity, commonVariables, LotFactory, lotsService, toastService) {
            function PlanFactory(opts) {
                this.id = opts.id;
                this.comment = opts.comment || null;
                this.commentDate = opts.commentDate || null;
                this.common = opts.common || null;
                if (opts.controls && opts.controls.entity) {
                    this.controls = opts.controls.entity;
                } else {
                    this.controls = [];
                }


                this.financing = opts.financing //this.getFinancing(0,opts);
                this.financing1 = opts.financing1 //this.getFinancing(1,opts);
                this.financing2 = opts.financing2 //this.getFinancing(2,opts);
                this.pricing = opts.financing || 0 + opts.financing1 || 0 + opts.financing2 || 0;
                this.planDocs = opts.planDocs || null;
                this.statusId = opts.statusId;
                this.type = opts.type;
                this.year = opts.year;
                this.lots = [];
                this.lotsStart = opts.lots || [];
                this.planPDF = {};
                this.planExcel = {};
                this.revision = opts.revision || [];
                this.plans = opts.plans || [];
                this.lotsForShow = []
                this.query = {
                    limit: 5,
                    page: 1
                }

            }

            PlanFactory.prototype = {
                fillPlanLots: function (cons) {
                    var defer = $q.defer();

                    var self = this;

                    if (this.lotsStart.length > 0) {
                        this.lotsStart.forEach(function (lot) {
                            var ob = new LotFactory(lot.data);
                            ob.lotType = lot.type;
                            self.lots.push(ob);
                        })
                        //this.lots = this.lotsStart.map(function (lot) {
                        //    return new LotFactory(lot);
                        //});
                        defer.resolve();

                    } else {
                        if (this.lots.length > 0) {
                            defer.resolve();
                        } else {
                            lotsService.getLotsCurrentPlan(this.id, true, false).then(function () {
                                lotsService.startLots.forEach(function (lot) {
                                    self.lots.push(lot);
                                });
                                //self.lots = lotsService.startLots;
                                defer.resolve();
                            }, function () {

                                defer.reject();
                            });
                        }

                    }
                    return defer.promise;
                },
                fillAllInfo: function (onlyFill) {
                    var plan = this, pl, self = this;
                    var defer = $q.defer();

                    function fill() {
                        plan.id = pl.id;
                        plan.comment = pl.comment;
                        plan.commentDate = pl.commentDate;
                        plan.common = pl.common;
                        plan.userExpertise = pl.userExpertise;
                        plan.documentsPackLink = apiService.serverRoute + 'integrations/zakupki_xml/' + plan.id;
                        plan.controls.splice(0);
                        if (pl.controls && angular.isArray(pl.controls)) {
                            for (var i = 0; i < pl.controls.length; i++) {
                                plan.controls.push(pl.controls[i]);
                            }
                        } else if (pl.controls && pl.controls.entity && pl.controls.entity.length) {
                            for (var i = 0; i < pl.controls.entity.length; i++) {
                                plan.controls.push(pl.controls.entity[i]);
                            }
                        }
                        plan.financing = pl.financing || 0;//plan.getFinancing(0,pl);
                        plan.financing1 = pl.financing1 || 0; //plan.getFinancing(1,pl);
                        plan.financing2 = pl.financing2 || 0; //plan.getFinancing(2,pl);
                        plan.pricing = pl.financing + pl.financing1 + pl.financing2;
                        plan.planDocs = pl.planDocs || [];
                        plan.statusId = pl.statusId;
                        plan.statusTitle = self.getStatusTitle(pl.statusId);
                        plan.type = pl.type;
                        plan.year = pl.year;
                        plan.lotsStart = pl.lotsStart || [];

                        plan.lots.splice(0);
                        if (angular.isArray(plan.lotsStart) && plan.lotsStart.length) {

                            for (var i = 0; i < plan.lotsStart.length; i++) {
                                /**
                                 * @todo: убрать
                                 */
                                // if (i % 2==0) {
                                //     plan.lotsStart[i].type='added';
                                // }
                                // if (i % 3==0) {
                                //     plan.lotsStart[i].type='removed';
                                // }

                                /**
                                 * end
                                 */
                                var ob = new LotFactory(plan.lotsStart[i].data);
                                ob.lotType = plan.lotsStart[i].type;

                                plan.lots.push(ob);

                            }
                            plan.hasFilteredLots=true;

                        }
                        plan.getLotsForShow();
                        if (angular.isArray(pl.revision)) {
                            plan.revision.splice(0);
                            for (var i = 0; i < pl.revision.length; i++) {
                                plan.revision.push(pl.revision[i]);
                            }
                        }
                        if (angular.isArray(pl.plans)) {
                            plan.plans.splice(0);
                            for (var i = 0; i < pl.plans.length; i++) {
                                var depPlan = new PlanFactory({id: pl.plans[i].id});
                                depPlan.fillAllInfo();
                                plan.plans.push(depPlan);
                            }
                        }


                        plan.revision = pl.revision || [];
                        plan.revisionSort();
                    }

                    if (!onlyFill) {
                        selectRequest(apiService.baseUrl + '/api/plans/' + this.id).then(function (response) {
                                if (response.status === 204) {
                                    toastService.show('Нет данных по запросу', false);
                                }
                                pl = response.data;
                                pl.lotsStart = pl.lots || [];
                                fill();
                                defer.resolve();

                            }, function () {
                                toastService.errorResponseShow('Произошла ошибка при получения плана департамента', response);
                                defer.reject()
                            })
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });

                    } else {
                        pl = angular.merge({}, this);
                        fill();
                        defer.resolve();
                    }
                    return defer.promise;
                },
                revisionSort: function () {
                    var plan = this;
                    if (angular.isArray(plan.revision) && plan.revision.length) {
                        plan.revision.sort(function (a, b) {
                            var a_created = moment(a.created).toDate();
                            var b_created = moment(b.created).toDate();
                            if (a_created < b_created) {
                                return 1;
                            } else if (a_created > b_created) {
                                return -1;
                            } else {
                                return 0;
                            }
                        })
                    }
                },
                getStatusTitle: function (id) {
                    if (id) {
                        var stat = commonVariables.plansStatuses.filter(function (st) {
                            return st.id === id;
                        });
                        return (stat[0] === undefined) ? id : stat[0].title;
                    } else {
                        return null;
                    }
                },
                getPlanPDF: function () {
                    var self = this,
                        defer = $q.defer();

                    //selectRequest(apiService.planPdf + this.id).then(function (response) {
                    //    if (response.data) {
                    //        self.planPDF = response.data;
                    //    }
                    //    defer.resolve();
                    //} , function ( response ) {
                    //    self.planPDF = {};
                    //    toastService.errorResponseShow('Произошла ошибка при получении PDF документа', response);
                    //    defer.resolve();
                    //} );
                    //selectRequest(apiService.serverRoute+'download_plan/pdf/' + this.id).then(function (response) {
                    //    if (response.data) {
                    //        self.planPDF = response.data;
                    //    }
                    //    defer.resolve();
                    //} , function ( response ) {
                    //    self.planPDF = {};
                    //    toastService.errorResponseShow('Произошла ошибка при получении PDF документа', response);
                    //    defer.resolve();
                    //} );
                    self.planPDF = {
                        file: "pdd.pdf",
                        full_path: apiService.serverRoute + 'download_plan/pdf/' + self.id
                    };
                    defer.resolve();

                    return defer.promise;
                },
                getPlanExcel: function () {
                    var self = this,
                        defer = $q.defer();

                    //selectRequest(apiService.planExcel + this.id).then(function (response) {
                    //    if (response.data) {
                    //        self.planExcel = response.data;
                    //    }
                    //    defer.resolve();
                    //} ).catch( function ( response ) {
                    //    self.planExcel = {};
                    //    toastService.errorResponseShow('Произошла ошибка при получении XLS документа', response);
                    //    defer.resolve();
                    //} );
                    self.planExcel = {
                        file: "excel.xls",
                        full_path: apiService.serverRoute + 'download_plan/excel/' + self.id
                    };
                    defer.resolve()
                    return defer.promise;
                },
                getFinancing: function (id, opts) {
                    var fin;
                    switch (id) {
                        case 0:
                            if (opts.financing && opts.financing1 && opts.financing2) {
                                fin = opts.financing;
                            }
                            if (opts.financing && opts.financing1 && !opts.financing2)
                                fin = 0;
                            break;
                        case 1:
                            if (opts.financing && opts.financing1 && opts.financing2) {
                                fin = opts.financing1;
                            }
                            if (opts.financing && opts.financing1 && !opts.financing2)
                                fin = opts.financing;
                            break;
                        case 2:
                            if (opts.financing && opts.financing1 && opts.financing2) {
                                fin = opts.financing2;
                            }
                            if (opts.financing && opts.financing1 && !opts.financing2)
                                fin = opts.financing1;

                    }
                    return fin;
                },
                getLotsForShow: function () {
                    var plan = this;
                    plan.lotsForShow.splice(0);
                    if (isNaN(plan.query.page)) {
                        plan.query.page = 0;
                    }
                    if (plan.lots && plan.lots.length) {
                        if (plan.query.page === 0) plan.query.page = 1;
                        for (var j = plan.query.limit * (plan.query.page - 1); j < (plan.query.limit * plan.query.page > plan.lots.length ? plan.lots.length : plan.query.limit * plan.query.page); j++) {
                            plan.lotsForShow.push(plan.lots[j]);
                        }
                    }

                },
                ajaxDownloadFile: function (url, fileName) {
                    var xhr = new XMLHttpRequest();
                    xhr.open("GET", url, true);
                    xhr.responseType = "blob";
                    var headers = appsecurity.getSecurityHeaders();
                    xhr.setRequestHeader('X-Access-Token', headers['X-Access-Token']);
                    xhr.setRequestHeader('X-Common-Id', headers['X-Common-Id']);
                    xhr.setRequestHeader('X-Expert-Group-Id', headers['X-Expert-Group-Id']);
                    xhr.setRequestHeader('X-Expert-Role', headers['X-Expert-Role']);
                    xhr.setRequestHeader('X-Sub-System', headers['X-Sub-System']);
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState == 4) {
                            var a = document.createElement("a");
                            document.body.appendChild(a);
                            a.style = "display: none";
                            var url = window.URL.createObjectURL(xhr.response);
                            a.href = url;
                            a.download = fileName;
                            a.click();
                            setTimeout(function () {
                                window.URL.revokeObjectURL(url);
                            }, 100)
                        }
                    };
                    xhr.send(null);
                }
            };
            function selectRequest(url) {
                //return $http({
                //    method: 'GET',
                //    headers: appsecurity.getSecurityHeaders(),
                //    url: url
                //})

                // var defer = $q.defer();
                // $http({
                //     method: 'GET',
                //     headers: appsecurity.getSecurityHeaders(),
                //     url: url
                // }).then(function (response) {
                //         defer.resolve(response);
                //     }, function () {
                //        defer.reject();
                //     }
                // )
                // return defer.promise;
                function reqWrapper() {
                    var defer = $q.defer();
                    $http({
                        method: 'GET',
                        headers: appsecurity.getSecurityHeaders(),
                        url: url
                    }).then(function (response) {
                            defer.resolve(response);
                        }, function (response) {
                            defer.reject(response);

                        }
                    )
                    return defer.promise;

                }

                var req = reqWrapper;
                commonVariables.requestArr.push(req);
                return req();
            }


            return PlanFactory;
        }]);
