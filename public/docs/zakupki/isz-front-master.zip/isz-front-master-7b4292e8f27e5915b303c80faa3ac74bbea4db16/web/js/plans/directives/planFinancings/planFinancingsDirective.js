﻿angular.module( 'isz' ).directive( 'planFinancings', ['plansService',
    function ( plansService ) {

        return {
            templateUrl: '/js/plans/directives/planFinancings/planFinancingsTemplate.html',
            replace: true,
            scope: {
                lot: '=lot'
            },
            controller: ['$scope', function ( $scope ) {

                $scope.fins = [];

                [].push.apply( $scope.fins, getFins() );

                function getFins() {
                    return ( $scope.lot.financings || [] ).filter( function ( fin ) {
                        return angular.isNumber( fin.planPrice );
                    } );
                }
            }],
            link: function ( scope, element, attributes ) {
                element.on( 'click', function ( event ) {                 
                    event.stopPropagation();
                } );
            }
        }
    }] )