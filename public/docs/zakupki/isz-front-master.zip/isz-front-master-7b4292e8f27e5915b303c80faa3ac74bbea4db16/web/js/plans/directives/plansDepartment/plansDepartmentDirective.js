/**
 * Created by pol on 05.04.2016.
 */
angular.module('isz').directive('plansDepartment',function () {
    return {
        restrict:'E',
        templateUrl:'/js/plans/directives/plansDepartment/plansDepartmentTemplate.html',
        replace:false,
        controller:['$scope',function ($scope) {
            $scope.getLots = function (page,limit,plan) {
                if (plan && plan.getLotsForShow) plan.getLotsForShow();
            }
            if ($scope.plan&&$scope.plan.id) {
                $scope.departmentSortOptions={
                    orderChanged: function (event) {
                    },
                    containment:'#listForSort'+$scope.plan.id,
                    scrollableContainer:'#listForSort'+$scope.plan.id
                }
            }
            $scope.liftCategory = function ( to, from ) {
                if ( to === from ) {
                    return;
                }

                var categoryToLift = $scope.plansDeps.splice( from, 1 ),
                    categoriesEnding = $scope.plansDeps.splice( to, $scope.plansDeps.length - to );

                categoriesEnding.unshift( categoryToLift[0] );

                [].push.apply( $scope.plansDeps, categoriesEnding );
            };

        }]
    }
})