/**
 * Created by pol on 12.08.2015.
 */
angular.module( 'isz' )
    .controller( 'MyLots', ['$scope', 'appsecurity', 'commonVariables', 'toastService', 'lotsService', '$location',
        function ( $scope, appsecurity, commonVaribales, toastService, lotsService, $location ) {

            $scope.commonVariables=commonVaribales;
            commonVaribales.currentMenuItem('/plans/my');
            $scope.statusedLots = lotsService.lots;
            if (commonVaribales.currentSubSystem!=='plans'){
                commonVaribales.currentSubSystem='plans';
                appsecurity.currentRole.subsystemChanged();
            }
            commonVaribales.enterInLotTimeStamp=null;
            canAddField();
            function canAddField() {
                if ( appsecurity.currentRole ) {
                    //$scope.canAdd = appsecurity.currentRole.permissions.createLot || appsecurity.currentRole.permissions.createAllLots;
                    $scope.canAdd = appsecurity.currentRole.permissions.createLot;
                    $scope.$$phase || $scope.$apply();
                } else {
                    setTimeout( canAddField, 100 );
                }
            }



            $scope.getStatus = function ( id ) {
                var stat = commonVaribales.expertsStatuses.filter( function ( st ) {
                    return st.machineName === id;
                } );
                return stat[0].title;
            };

            $scope.statusSortOptions={
                orderChanged: function (event) {
                },
            }

            $scope.liftCategory = function ( to, from ) {
                if ( to === from ) {
                    return;
                }

                var categoryToLift = $scope.statusedLots.splice( from, 1 ),
                    categoriesEnding = $scope.statusedLots.splice( to, $scope.statusedLots.length - to );

                categoriesEnding.unshift( categoryToLift[0] );

                [].push.apply( $scope.statusedLots, categoriesEnding );
            };

            $scope.currYears = [];
            var currYear = new Date();
            for ( var i = 0; i < 3; i++ ) {
                $scope.currYears.push( currYear.getFullYear() + i )
            }

            $scope.addLot = function () {
                $location.path( 'plans/lot/new' );
            };

            $scope.updateLotsList = function(){
                commonVaribales.isLoading = true;
                appsecurity.getUserInfo().then( function () {
                    if (commonVaribales.currentSubSystem!=='plans'){
                        commonVaribales.currentSubSystem='plans';
                        appsecurity.currentRole.subsystemChanged();
                    }

                    lotsService.cleanLots();
                    $scope.readLot = appsecurity.currentRole.permissions.readLot;
                    $scope.readSections = appsecurity.currentRole.permissions.readSections;
                    $scope.controlSections = appsecurity.currentRole.permissions.controlSections;
                    $scope.readSectionsAll = appsecurity.currentRole.permissions.readSectionsAll;

                    $scope.readMyLots = appsecurity.currentRole.permissions.readMyLots;
                    $scope.controlMyLots = appsecurity.currentRole.permissions.controlMyLots;

                    if ( !$scope.readMyLots ) {
                        commonVaribales.isLoading = false;
                        toastService.show( 'У Вас нет прав доступа для просмотра этой страницы', false );
                    } else {
                        commonVaribales.myDepartments = appsecurity.expertGroups.map( function ( gr ) {
                            return gr.common.id;
                        } );
                        lotsService.forceSync().then( function () {
                            lotsService.getMyLots();
                            commonVaribales.isLoading = false;
                        } , function () {
                            commonVaribales.isLoading = false;
                        } );
                    }
                } , function () {
                    commonVaribales.isLoading = false;
                } );
            }
            $scope.updateLotsList();

        }] );
