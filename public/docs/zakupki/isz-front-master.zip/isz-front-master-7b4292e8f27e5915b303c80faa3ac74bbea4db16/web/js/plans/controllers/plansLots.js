﻿angular.module( 'isz' ).controller( 'plansLots', ['$scope', 'appsecurity', 'commonVariables', 'toastService', 'lotsService', 'plansService',
    function ( $scope, appsecurity, commonVaribales, toastService, lotsService, plansService ) {
        $scope.commonVariables=commonVaribales;

        $scope.statusedLots = lotsService.lots;
        commonVaribales.enterInLotTimeStamp=null;
        commonVaribales.currentMenuItem('/plans');

        $scope.planType = plansService.planType;
        $scope.getStatus = function ( id ) {
            if ( id ) {
                var stat = commonVaribales.expertsStatuses.filter( function ( st ) {
                    return st.machineName === id;
                } );
                return stat[0].title;
            } else {
                return null;
            }
        }
        $scope.$on( 'planTypeChange', function () {
            $scope.planType = plansService.planType;
            fillYears();
        } );

        $scope.updateLotsList=function(){
            commonVaribales.isLoading = true;
            appsecurity.getUserInfo().then( function () {
                if (commonVaribales.currentSubSystem!=='plans'){
                    commonVaribales.currentSubSystem='plans';
                    appsecurity.currentRole.subsystemChanged();
                }
                $scope.readLot = appsecurity.currentRole.permissions.readLot;
                $scope.readSections = appsecurity.currentRole.permissions.readSections;
                $scope.controlSections = false;
                $scope.readSectionsAll = appsecurity.currentRole.permissions.readSectionsAll;


                if ( !$scope.readSections && !$scope.readSectionsAll ) {
                    commonVaribales.isLoading = false;
                    toastService.show( 'У Вас нет прав доступа для просмотра этой страницы', false );
                } else {
                    lotsService.getLots( true ).then( function () {
                        lotsService.separateByFcpAction();
                        commonVaribales.isLoading = false;
                    } ,function () {
                        commonVaribales.isLoading = false;
                    });
                }

            },function () {
                commonVaribales.isLoading = false;
            } );



        }
        $scope.currYears = [];
        var currYearsOrig = [],
            k = $scope.planType === 'current' ? 0 : 1;
        var currYear = new Date();

        for ( var i = 0; i < 3; i++ ) {
            currYearsOrig[i] = currYear.getFullYear() + i;
            $scope.currYears[i] = currYearsOrig[i] + k;
        }
        function fillYears() {
            var k = $scope.planType === 'current' ? 0 : 1;

            for ( var i = 0; i < 3; i++ ) {
                $scope.currYears[i] = currYearsOrig[i] + k;
            }
        }

        $scope.updateLotsList();
    }] );