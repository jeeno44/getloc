/**
 * Created by pol on 03.04.2016.
 */
angular.module('isz').directive('plansFilter',function () {
    return {
        restrict: 'E',
        templateUrl:'/js/plans/directives/plansFilter/plansFilterTemplate.html',
        controller: ['$scope','commonVariables',function($scope,commonVariables){
           
            $scope.commonVariables=commonVariables;
        }]
    }
})
