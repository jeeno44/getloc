﻿angular.module( 'isz' )
.service( 'stageSumWorks', [function () {
        this.stagePrice=0;
        this.worksPrices=[];
        var self=this;
        this.validateSum = function(){
            var sum = 0;
            for ( var i = 0; i < this.worksPrices.length; i++ ) {
                sum += this.worksPrices[i];
            }
            return sum > this.stagePrice;
        }
}] );