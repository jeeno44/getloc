﻿angular.module( 'isz' ).directive( 'requiredField', ['counterService', 'toastService','$timeout', function ( counterService, toastService,$timeout ) {

    return {
        restrict: 'A',
        require: 'ngModel',
        compile: function ( tElement ) {
            if ( tElement.is( 'input' ) || tElement.is( 'textarea' ) ) {
                tElement.after( '<span class="noncontainer_require_asterisk">*</span>' )
            }
           return postLink;
        }
    };

    function postLink( scope, element, attrs, ngModelCtrl ) {
        var counterIncrased,
            watchListener,
            lastValidValue;

            incrase();
            ngModelCtrl.$viewChangeListeners.push( viewValueChanged );

            watchListener = scope.$watch( function () {
                return ngModelCtrl.$viewValue;
            }, viewValueChanged );

            scope.$on( 'remainingRequiredFields', function ( event, count ) {
                if ( counterIncrased ) {
                    count.blank++;
                    count.emptyFields.push(element[0].attributes['ng-model'].value );
                }
                //counterIncrased && count.blank++;
            } );

            scope.$on( '$destroy', function () {
                watchListener();
                decrase();
            } );

            subscribeOnEvents();


        function subscribeOnEvents() {
            if ( scope.lot ) {
                if ( scope.lot.inEditMode ) {
                    if ( element.is( 'input' ) || element.is( 'textarea' ) ) {
                        element.on( 'focus', function () {
                            lastValidValue = ngModelCtrl.$viewValue;
                        } );

                        element.on( 'change', function () {
                            if ( ngModelCtrl.$viewValue ) {
                                scope.lot.patch( attrs.ngModel.split( '.' )[1] );
                            } else {
                                ngModelCtrl.$setViewValue( lastValidValue );
                                ngModelCtrl.$render();
                                toastService.show( 'Это поле обязательно для заполнения.', true );
                            }
                        } );
                    }
                }
            } else {
                $timeout( subscribeOnEvents, 100 );
            }
        }



        function viewValueChanged() {
            ngModelCtrl.$viewValue ? decrase() : incrase();
        }

        function incrase() {
            if ( !counterIncrased ) {
                counterService.notify( 1, scope.name );
                counterIncrased = true;
            }
        }

        function decrase() {
            if ( counterIncrased ) {
                counterService.notify( -1, scope.name );
                counterIncrased = false;
            }
        }
    }

}] );

angular.module( 'isz' ).directive( 'counterOutput', ['counterService','$timeout', function ( counterService,$timeout ) {

    return {
        restrict: 'A',
        link: function ( scope, element, attrs ) {
            var requireTabCounter = 0;

            element.addClass( 'hide on_edit_show' );

                counterService.addListener( function ( num, tabName ) {
                    if ( attrs.counterOutput == 'toolbar' || tabName == attrs.counterOutput ) {
                        element.text( requireTabCounter += num );
                        if ( requireTabCounter ) {
                            element.removeClass( 'hide' );
                        } else {
                            element.addClass( 'hide' );
                        }
                    }
                } );


        }
    };
}] );

angular.module( 'isz' ).service( 'counterService', [function () {

    this.listeners = [];

    this.addListener = function ( fn ) {
        this.listeners.push( fn );
    }

    this.resetListeners = function () {
        this.listeners.length = 0;
    }

    this.notify = function () {
        for ( var i = this.listeners.length; i--; ) {
            this.listeners[i].apply( null, arguments );
        }
    }
}] );

