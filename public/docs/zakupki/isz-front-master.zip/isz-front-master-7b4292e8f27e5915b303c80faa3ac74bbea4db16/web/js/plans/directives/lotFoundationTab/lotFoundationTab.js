/**
 * Created by pol on 14.08.2015.
 */
angular.module( 'isz' )
    .directive( 'lotFoundationTab', [function () {
        return {
            restrict: 'E',
            scope: true,
            templateUrl: '/js/plans/directives/lotFoundationTab/template/lotFoundationTabTemplate.html',
            controller: ['$scope', 'commonVariables', '$http','$q', 'apiService', 'appsecurity', 'toastService', 'lazyLoadSelectService','uploadFiles',
                function ( $scope, commonVariables, $http, $q, apiService, appsecurity, toastService, lazyLoadSelectService,uploadFiles ) {

                    appsecurity.getUserInfo().then( setLot );

                    var self = this, fcpLastValues = {},subProgramLastValue={},kbkLastValues={}, fcp = {}, subprogram = {},govProgram={},kbk={},priznak={};

                    $scope.name = 'foundation';
                    $scope.forChoice=false;
                    $scope.nextKbkVisible = false;
                    $scope.currentRateFilter='';


                    $scope.saveIfFullyFilled = function () {

                        if ( !( $scope.lot.inEditMode || $scope.creating ) ) {
                            return;
                        }
                        var kbkToExtend=angular.extend( {}, kbk );
                        delete kbkToExtend.completelyFilled;
                        if ( $scope.foundationOptions.programEvent == 'программное' ) {

                            if ( !$scope.foundationOptions.govProgramBuffer.govProgram ) return;

                            if ( $scope.foundationOptions.govProgramBuffer.program == 'фцп' ) {
                                var fcpToExtend = angular.extend( {}, fcp );
                                delete fcpToExtend.completelyFilled;

                                //delete fcpToExtend.fcp;

                                if ( fcp.completelyFilled&&kbk.completelyFilled && ( !isSameEntities( fcpToExtend ) || !isSameEntities( { govProgram: $scope.foundationOptions.govProgramBuffer.govProgram } ) ) ) {
                                    $scope.lot.govProgram = $scope.foundationOptions.govProgramBuffer.govProgram.govProgram;
                                    angular.extend( $scope.lot, fcpToExtend );

                                    angular.extend( $scope.lot, kbkToExtend );
                                    setNull( $scope.lot, 'subProgram', 'subProgramMainAction', 'subProgramAction', 'orderTitle', 'orderNumber', 'orderDate', 'lotDoc' );
                                    setNull( subprogram, 'subProgram', 'subProgramMainAction', 'subProgramAction' );
                                    setNull( $scope.foundationOptions.nonProgramBuffer, 'orderTitle', 'orderNumber', 'orderDate' );
                                    $scope.lot.rateIndicator.splice(0);
                                    if ( $scope.lot.inEditMode ) {

                                        $scope.lot.patch( 'govProgram','fcp', 'fcpActionTask', 'fcpAction', 'fcpActionSubaction', 'subProgram', 'subProgramMainAction', 'subProgramAction', 'orderTitle', 'orderNumber', 'orderDate', 'lotDoc','kbkSection','kbkFlowDirection','kbkExpenseType' )
                                            .then( function () {
                                                toastService.show( 'Государственная программа успешно сохранена' );
                                                $scope.lot.patch({rateIndicator:[]});
                                                $scope.currentRateFilter='&filters[govProgram]='+ govProgram.govProgram.id +'&filters[fcp]='+fcp.fcp.id;
                                                selectRates();
                                                selectIndicators();
                                            } );
                                    } else {

                                        $scope.currentRateFilter='&filters[govProgram]='+ govProgram.govProgram.id +'&filters[fcp]='+fcp.fcp.id;
                                        selectRates();
                                        selectIndicators();
                                    }
                                }
                            } else {
                                var subprogramToExtend = angular.extend( {}, subprogram );
                                delete subprogramToExtend.completelyFilled;

                                if ( kbk.completelyFilled&&subprogram.completelyFilled&&( !isSameEntities( subprogram ) || !isSameEntities( { govProgram: $scope.foundationOptions.govProgramBuffer.govProgram } ) )
                                    && subprogram.subProgram && subprogram.subProgramMainAction ) {
                                    $scope.lot.govProgram = $scope.foundationOptions.govProgramBuffer.govProgram.govProgram;
                                    angular.extend( $scope.lot, subprogramToExtend );
                                    angular.extend( $scope.lot, kbkToExtend );
                                    setNull( $scope.lot, 'fcpActionTask', 'fcpAction', 'fcpActionSubaction', 'orderTitle', 'orderNumber', 'orderDate', 'lotDoc' );
                                    setNull( fcp, 'fcpActionTask', 'fcpAction', 'fcpActionSubaction', 'fcp' );
                                    setNull( $scope.foundationOptions.nonProgramBuffer, 'orderTitle', 'orderNumber', 'orderDate' );
                                    $scope.lot.rateIndicator.splice(0);
                                    if ( $scope.lot.inEditMode ) {

                                        $scope.lot.patch( 'govProgram','fcp', 'fcpActionTask', 'fcpAction', 'fcpActionSubaction', 'subProgram', 'subProgramMainAction', 'subProgramAction', 'orderTitle', 'orderNumber', 'orderDate', 'lotDoc','kbkSection','kbkFlowDirection','kbkExpenseType' )
                                            .then( function () {
                                                toastService.show( 'Государственная программа успешно сохранена' );
                                                $scope.lot.patch({rateIndicator:[]});
                                                $scope.currentRateFilter='&filters[govProgram]='+ govProgram.govProgram.id;
                                                selectRates();
                                                selectIndicators();
                                            } )
                                    } else {

                                        $scope.currentRateFilter='&filters[govProgram]='+ govProgram.govProgram.id;
                                        selectRates();
                                        selectIndicators();
                                    }
                                }
                            }

                        } else {
                            if ( $scope.foundationOptions.nonProgramBuffer.orderTitle &&
                                kbk.completelyFilled &&
                                $scope.foundationOptions.nonProgramBuffer.orderNumber &&
                                $scope.foundationOptions.nonProgramBuffer.orderDate &&
                                // $scope.foundationOptions.govProgramBuffer.govProgram.govProgram &&
                                $scope.foundationOptions.govProgramBuffer.kbk.kbkSection) {

                                angular.extend( $scope.lot, $scope.foundationOptions.nonProgramBuffer );
                                angular.extend( $scope.lot, kbkToExtend );
                                setNull(govProgram,'govProgram');
                                setNull( $scope.lot,'govProgram', 'fcp', 'fcpActionTask', 'fcpAction', 'fcpActionSubaction', 'subProgram', 'subProgramMainAction', 'subProgramAction', 'nks' );
                                setNull( subprogram, 'subProgram', 'subProgramMainAction', 'subProgramAction' );
                                setNull( fcp, 'fcpActionTask', 'fcpAction', 'fcpActionSubaction', 'fcp' );
                                // setNull(kbk,'kbkFlowDirection','kbkExpenseType');
                                $scope.lot.rateIndicator.splice(0);
                                $scope.foundationOptions.govProgramBuffer.govProgram = null;
                                // $scope.lot.govProgram = $scope.foundationOptions.govProgramBuffer.govProgram.govProgram;
                                $scope.lot.kbkSection=$scope.foundationOptions.govProgramBuffer.kbk.kbkSection;
                                if ( $scope.lot.inEditMode ) {
                                    $scope.lot.patch({rateIndicator:[]});
                                    $scope.lot.patch( 'govProgram','fcp', 'fcpActionTask', 'fcpAction', 'fcpActionSubaction', 'subProgram', 'subProgramMainAction', 'subProgramAction', 'orderTitle', 'orderNumber', 'orderDate',  'nks','kbkSection','kbkFlowDirection','kbkExpenseType' )
                                        .then( function () {
                                            toastService.show( 'Внепрограммное мероприятие успешно сохранено' );
                                        } );
                                }
                            }

                        }
                    }
                    $scope.govProgramChanged = function(onlyFill){
                        $scope.forChoice=false;
                        // if (!govProgram.govProgram) {
                        //     $scope.foundationOptions.programEvent='внепрограммное';
                        // } else {
                        //     $scope.foundationOptions.programEvent='программное';
                        // }
                        
                        if ( govProgram.govProgram && ( fcpLastValues.govProgramm != govProgram.govProgram.id ) ) {
                            fcpLastValues.govProgramm = govProgram.govProgram.id;

                            if ( onlyFill ) {
                                if ( fcp.fcp ) $scope.fcp_programmChanged( onlyFill );
                                if (subprogram.subProgram) {
                                    $scope.subprogramChanged(onlyFill);
                                }
                            } else {

                                setNull( fcp, 'fcp','fcpAction', 'fcpActionTask', 'fcpActionSubaction' );
                                setNull( subprogram, 'subProgram','subProgramAction', 'subProgramMainAction' );
                                setNull(kbk,'kbkSection','kbkFlowDirection','kbkExpenseType');
                                setNull(fcpLastValues,'programm','task','action','subaction');
                                setNull(subProgramLastValue,'subprogram','subProgramMainAction','subProgramAction');
                                setNull(kbkLastValues,'kbkFlowDirection','kbkExpenseType');
                                kbk.completelyFilled=false;
                                fcp.completelyFilled = false;
                                subprogram.completelyFilled=false;

                                $scope.nextKbkVisible=false;
                            }

                          
                        }
                    }
                    function selectFcp(){
                        var defer = $q.defer();
                        selectRequest( apiService.fcpsSelect  +'?filters[kbkSection]='+ kbk.kbkSection.id+'&filters[govProgram]='+ govProgram.govProgram.id)
                            .then( function ( response ) {
                                $scope.fcpsSelect = response.data;
                                defer.resolve();
                            }, function ( response ) {
                                defer.reject();
                                toastService.errorResponseShow( 'Ошибка получения ФЦП госпрограммы', response );
                            } )
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });
                        return defer.promise;
                    }
                    function selectSubprogram(){
                        var defer = $q.defer();
                        selectRequest( apiService.subProgramSelect +'filters[kbkSection]='+ kbk.kbkSection.id+'&filters[govProgram]='+ govProgram.govProgram.id).then( function ( response ) {
                            $scope.subProgramSelect = response.data;
                            defer.resolve();
                        }, function ( response ) {
                            defer.reject();
                            toastService.errorResponseShow( 'Ошибка получения подпрограмм', response );
                        } )
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });
                        return defer.promise;
                    }

                    $scope.fcp_programmChanged = function ( onlyFill ) {
                        if ( fcp.fcp && ( fcpLastValues.programm != fcp.fcp.id ) ) {
                            fcpLastValues.programm = fcp.fcp.id;

                            if ( onlyFill ) {
                                if ( fcp.fcpActionTask ) $scope.fcp_taskChanged( onlyFill );
                            } else {
                                setNull( fcp, 'fcpAction', 'fcpActionTask', 'fcpActionSubaction' );
                                setNull(kbk,'kbkFlowDirection','kbkExpenseType');
                                setNull(fcpLastValues,'task','action','subaction');
                                setNull(kbkLastValues,'kbkFlowDirection','kbkExpenseType');
                                kbk.completelyFilled=false;
                                fcp.completelyFilled = false;
                            }
                            if (fcp.fcp.is_children) {
                                selectRequest( apiService.fcpActionTaskSelect + fcp.fcp.id )
                                    .then( function ( response ) {
                                        $scope.fcpActionTaskSelect = response.data;
                                    }, function ( response ) {
                                        toastService.errorResponseShow( 'Ошибка получения задач госпрограммы', response );
                                    } )
                                    .then(function () {
                                        commonVariables.requestArr.pop();
                                    });
                            } else {
                                fcp.completelyFilled = true;
                                if ( !onlyFill ) $scope.saveIfFullyFilled();
                            }
                            $scope.nextKbkVisible=true;
                            priznak.program='fcp';
                            priznak.id=fcp.fcp.id;
                            selectKbkFlowDirection(onlyFill);
                        }
                    }
                    function selectKbkFlowDirection(pr){
                        var url
                        if ( $scope.foundationOptions.programEvent==='внепрограммное'){
                            url=apiService.kbkFlowDirectionSelect  +'?filters[kbkSection]='+ kbk.kbkSection.id;
                        } else {
                            url=apiService.kbkFlowDirectionSelect  +'?filters[kbkSection]='+ kbk.kbkSection.id+'&filters[govProgram]='+ govProgram.govProgram.id+'&fliters['+priznak.program+']='+priznak.id;
                        }

                        selectRequest( url)
                            .then( function ( response ) {
                                $scope.flowDirectionSelect = response.data;
                                if (!$scope.flowDirectionSelect.length) {
                                    toastService.show('Для данного раздела КБК нет направлений расходов КБК',false);
                                }
                            }, function ( response ) {
                                toastService.errorResponseShow( 'Ошибка получения направлений расходов КБК', response );
                            } )
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });
                    }
                    $scope.kbkFlowDirectionChanged = function(onlyFill){
                        if (kbk.kbkFlowDirection&&(kbkLastValues.kbkFlowDirection!=kbk.kbkFlowDirection.id)){
                            kbkLastValues.kbkFlowDirection=kbk.kbkFlowDirection.id;
                            if (!onlyFill){
                                setNull(kbk,'kbkExpenseType');

                                setNull(kbkLastValues,'kbkExpenseType');
                                kbk.completelyFilled=false;
                            }
                        }

                    }
                    $scope.fcp_taskChanged = function ( onlyFill ) {
                        if ( fcp.fcpActionTask && ( fcpLastValues.task != fcp.fcpActionTask.id ) ) {
                            fcpLastValues.task = fcp.fcpActionTask.id;

                            if ( onlyFill ) {
                                if ( fcp.fcpAction ) $scope.fcp_actionChanged( onlyFill );
                            } else {
                                setNull( fcp, 'fcpAction', 'fcpActionSubaction' );
                                setNull(fcpLastValues,'action','subaction');

                                fcp.completelyFilled = false;
                            }
                            if (fcp.fcpActionTask.is_children) {
                                selectRequest( apiService.fcpActionSelect + fcp.fcpActionTask.id )
                                    .then( function ( response ) {
                                        $scope.fcpActionSelect = [];
                                        if ( angular.isArray( response.data ) && response.data.length ) {
                                            $scope.fcpActionSelect = response.data;
                                        }
                                    }, function ( response ) {
                                        toastService.errorResponseShow( 'Ошибка получения мероприятий госпрограммы', response );
                                    } )
                                    .then(function () {
                                        commonVariables.requestArr.pop();
                                    });
                            } else {
                                fcp.completelyFilled = true;
                                if ( !onlyFill ) $scope.saveIfFullyFilled();
                            }
                            //selectRequest( apiService.fcpActionSelect + fcp.fcpActionTask.id )
                            //    .then( function ( response ) {
                            //        $scope.fcpActionSelect = [];
                            //        if ( angular.isArray( response.data ) && response.data.length ) {
                            //            $scope.fcpActionSelect = response.data;
                            //        } else {
                            //            fcp.completelyFilled = true;
                            //            if ( !onlyFill ) $scope.saveIfFullyFilled();
                            //        }
                            //    }, function ( response ) {
                            //        toastService.errorResponseShow( 'Ошибка получения мероприятий госпрограммы', response );
                            //    } );
                        }

                    }
                    $scope.fcp_actionChanged = function ( onlyFill ) {
                        if ( fcp.fcpAction && ( fcpLastValues.action != fcp.fcpAction.id ) ) {
                            fcpLastValues.action = fcp.fcpAction.id;

                            if ( onlyFill ) {
                                $scope.fcp_subactionChanged( onlyFill );
                            } else {
                                fcp.fcpActionSubaction = null;
                                setNull(fcpLastValues,'subaction');

                                fcp.completelyFilled = false;
                            }
                            if (fcp.fcpAction.is_children) {
                                selectRequest( apiService.fcpActionSubactionSelect + fcp.fcpAction.id )
                                    .then( function ( response ) {
                                        $scope.fcpActionSubactionSelect = [];
                                        if ( angular.isArray( response.data ) && response.data.length ) {
                                            $scope.fcpActionSubactionSelect = response.data;
                                        }
                                    }, function ( response ) {
                                        toastService.errorResponseShow( 'Ошибка получения подмероприятий госпрограммы', response );
                                    } )
                                    .then(function () {
                                        commonVariables.requestArr.pop();
                                    });
                            } else {
                                fcp.completelyFilled = true;
                                if ( !onlyFill ) $scope.saveIfFullyFilled();
                            }


                        }
                    }
                    $scope.fcp_subactionChanged = function ( onlyFill ) {
                        if ( fcp.fcpActionSubaction && ( fcpLastValues.subaction != fcp.fcpActionSubaction.id ) ) {
                            fcpLastValues.subaction = fcp.fcpActionSubaction.id;
                            fcp.completelyFilled = true;
                            if ( !onlyFill ) $scope.saveIfFullyFilled();
                        }
                    }
                    $scope.subprogramChanged = function(onlyFill){
                        if (subprogram.subProgram &&(subProgramLastValue.subprogram != subprogram.subProgram.id)) {
                            subProgramLastValue.subprogram = subprogram.subProgram.id;
                            if (onlyFill) {
                                if (subprogram.subProgramMainAction) {
                                    $scope.subProgramMainActionChanged(onlyFill)
                                }
                            } else {
                                setNull(subprogram,'subProgramAction', 'subProgramMainAction');
                                subprogram.completelyFilled=false;
                                setNull(kbk,'kbkFlowDirection','kbkExpenseType');
                                kbk.completelyFilled=false;

                                setNull(subProgramLastValue,'subProgramMainAction','subProgramAction');
                                setNull(kbkLastValues,'kbkFlowDirection','kbkExpenseType');
                            }
                            selectRequest( apiService.subProgramMainActionSelect +'filters[kbkSection]='+ kbk.kbkSection.id+'&filters[govProgram]='+ govProgram.govProgram.id+
                            '&filters[parent]='+subprogram.subProgram.id).then( function ( response ) {
                                $scope.subProgramMainActionSelect = response.data;
                            }, function ( response ) {
                                toastService.errorResponseShow( 'Ошибка получения основных мероприятий подпрограммы', response );
                            } )
                                .then(function () {
                                    commonVariables.requestArr.pop();
                                });
                        }
                    }
                    $scope.subProgramMainActionChanged = function(onlyFill){
                        if (subprogram.subProgramMainAction &&(subProgramLastValue.subProgramMainAction != subprogram.subProgramMainAction.id)) {
                            subProgramLastValue.subProgramMainAction = subprogram.subProgramMainAction.id;
                            if (onlyFill) {
                                if (subprogram.subProgramAction) {
                                    $scope.subProgramActionChanged(onlyFill)
                                }
                            } else {
                                setNull(subprogram,'subProgramAction');
                                subprogram.completelyFilled=false;
                                setNull(kbk,'kbkFlowDirection','kbkExpenseType');
                                kbk.completelyFilled=false;
                                setNull(subProgramLastValue,'subProgramAction');
                                setNull(kbkLastValues,'kbkFlowDirection','kbkExpenseType');


                            }
                            if (subprogram.subProgramMainAction.is_children) {
                                selectRequest( apiService.subProgramActionSelect +'&filters[parent]='+subprogram.subProgramMainAction.id).then( function ( response ) {
                                    $scope.subProgramActionSelect = response.data;
                                }, function ( response ) {
                                    toastService.errorResponseShow( 'Ошибка получения мероприятий подпрограммы', response );
                                } )
                                    .then(function () {
                                        commonVariables.requestArr.pop();
                                    });
                            } else {
                                subprogram.completelyFilled=true;
                                if (!onlyFill) $scope.saveIfFullyFilled();
                            }
                            $scope.nextKbkVisible=true;
                            priznak.program='subProgramAction';
                            priznak.id=subprogram.subProgramMainAction.id
                            selectKbkFlowDirection(onlyFill);
                        }
                    }
                    $scope.subProgramActionChanged = function(onlyFill){
                        if (subprogram.subProgramAction && (subProgramLastValue.subProgramAction != subprogram.subProgramAction.id)) {
                            subProgramLastValue.subProgramAction=subprogram.subProgramAction.id;
                            subprogram.completelyFilled=true;
                            if (!onlyFill) $scope.saveIfFullyFilled();
                        }
                    }

                    $scope.addRateIndicator = function ( type ) {
                        $scope.unbindSelect();
                        for ( var i = 0; i < $scope.lot.rateIndicator.length; i++ ) {
                            if ( $scope.lot.rateIndicator[i].rateIndicator.id == $scope.selectedRatesIndicators[type].value ) {
                                toastService.show( 'Эта опция уже добавлена', true );
                                return;
                            }
                        }

                        $scope.selectedRatesIndicators[type].type = type;
                        $scope.lot.rateIndicator.unshift( {rateIndicator:$scope.selectedRatesIndicators[type]} );
                        $scope.selectedRatesIndicators[type] = null;

                        if ( $scope.lot.inEditMode ) {
                            var mapper = $scope.lot.rateIndicator.map( function ( code ) {
                                return { rateIndicator: code.rateIndicator.id };
                            } )

                            $scope.lot.patch( { rateIndicator: mapper } );
                        }
                    }
                    $scope.removeRateIndicator = function ( model ) {
                        for ( var i = $scope.lot.rateIndicator.length; i--; ) {
                            if ( $scope.lot.rateIndicator[i].rateIndicator.id == model.rateIndicator.id ) {
                                break;
                            }
                        }
                        $scope.lot.rateIndicator.splice( i, 1 );
                        if ( $scope.lot.inEditMode ) {
                            //$scope.lot.patch( { rateIndicator: $scope.lot.rateIndicator } );
                            var mapper = $scope.lot.rateIndicator.map( function ( code ) {
                                return { rateIndicator: code.rateIndicator.id };
                            } )

                            $scope.lot.patch( { rateIndicator: mapper } );
                        }
                    }

                    function getAllSelectData() {

                        if (!$scope.creating &&kbk.kbkSection&&kbk.kbkSection.id) {

                                    if ($scope.foundationOptions.programEvent==='внепрограммное') {
                                        $scope.nextKbkVisible=true;
                                        selectKbkFlowDirection();

                                    } else {
                                        if (kbk.kbkSection&&kbk.kbkSection.id&&govProgram.govProgram&&govProgram.govProgram.id &&fcp.fcp&&fcp.fcp.id) {
                                            selectRequest( apiService.fcpsSelect  +'?filters[kbkSection]='+ kbk.kbkSection.id+'&filters[govProgram]='+ govProgram.govProgram.id)
                                                .then( function ( response ) {
                                                    $scope.fcpsSelect = response.data;
                                                    //$scope.fcp_programmChanged(true);
                                                }, function ( response ) {
                                                    toastService.errorResponseShow( 'Ошибка получения ФЦП госпрограммы', response );
                                                } )
                                                .then(function () {
                                                    commonVariables.requestArr.pop();
                                                });

                                            selectRequest( apiService.fcpActionTaskSelect + fcp.fcp.id )
                                                .then( function ( response ) {
                                                    $scope.fcpActionTaskSelect = response.data;

                                                }, function ( response ) {
                                                    toastService.errorResponseShow( 'Ошибка получения задач госпрограммы', response );
                                                } )
                                                .then(function () {
                                                    commonVariables.requestArr.pop();
                                                });
                                            //rates & indicators
                                            $scope.currentRateFilter='&filters[govProgram]='+ govProgram.govProgram.id +'&filters[fcp]='+fcp.fcp.id;
                                            selectRates();
                                            selectIndicators();
                                            if (fcp.fcpActionTask&&fcp.fcpActionTask.id){
                                                selectRequest( apiService.fcpActionSelect + fcp.fcpActionTask.id )
                                                    .then( function ( response ) {
                                                        $scope.fcpActionSelect = [];
                                                        if ( angular.isArray( response.data ) && response.data.length ) {
                                                            $scope.fcpActionSelect = response.data;
                                                        }
                                                    }, function ( response ) {
                                                        toastService.errorResponseShow( 'Ошибка получения мероприятий госпрограммы', response );
                                                    } )
                                                    .then(function () {
                                                        commonVariables.requestArr.pop();
                                                    });
                                                if (fcp.fcpAction&&fcp.fcpAction.id){
                                                    selectRequest( apiService.fcpActionSubactionSelect + fcp.fcpAction.id )
                                                        .then( function ( response ) {
                                                            $scope.fcpActionSubactionSelect = [];
                                                            if ( angular.isArray( response.data ) && response.data.length ) {
                                                                $scope.fcpActionSubactionSelect = response.data;
                                                            }
                                                        }, function ( response ) {
                                                            toastService.errorResponseShow( 'Ошибка получения подмероприятий госпрограммы', response );
                                                        } )
                                                        .then(function () {
                                                            commonVariables.requestArr.pop();
                                                        });
                                                }
                                            }
                                        }

                                        if (kbk.kbkSection&&kbk.kbkSection.id&&govProgram.govProgram&&govProgram.govProgram.id &&subprogram.subProgram&&subprogram.subProgram.id){
                                            selectSubprogram();
                                            //rates & indicators
                                            $scope.currentRateFilter='&filters[govProgram]='+ govProgram.govProgram.id;
                                            selectRates();
                                            selectIndicators();

                                            if (subprogram.subProgramMainAction&&subprogram.subProgramMainAction.id){
                                                selectRequest( apiService.subProgramActionSelect +'&filters[parent]='+subprogram.subProgramMainAction.id).then( function ( response ) {
                                                    $scope.subProgramActionSelect = response.data;
                                                }, function ( response ) {
                                                    toastService.errorResponseShow( 'Ошибка получения мероприятий подпрограммы', response );
                                                } )
                                                    .then(function () {
                                                        commonVariables.requestArr.pop();
                                                    });

                                            }
                                        }
                                        $scope.saveKbkSection(true);
                                        $scope.fcp_programmChanged(true);
                                        $scope.subprogramChanged(true);
                                        setFcpLastValues();
                                    }

                                // })
                                // .then(function(){
                                //     $scope.fcp_programmChanged(true);
                                //     $scope.subprogramChanged(true);
                                //     setFcpLastValues();
                                // });

                        }
                    }

                    function selectRates(){
                        selectRequest( apiService.rateSelect+ $scope.currentRateFilter).then( function ( response ) {
                            $scope.rateSelect = response.data;
                        }, function ( response ) {
                            toastService.errorResponseShow( 'Ошибка получения показателей', response );
                        } )
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });
                    }
                    function selectIndicators(){
                        selectRequest( apiService.indicatorSelect+$scope.currentRateFilter ).then( function ( response ) {
                            $scope.indicatorSelect = response.data;
                        }, function ( response ) {
                            toastService.errorResponseShow( 'Ошибка получения индикаторов', response );
                        } )
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });
                    }
                    $scope.uploadDocuments = uploadFiles.uploadDocuments;
                    
                    $scope.removeDoc = function ( doc ) {
                        var index = $scope.lot.lotDoc.indexOf( doc );
                        if ( $scope.lot.inEditMode ) {
                            $http( {
                                method: 'DELETE',
                                url: apiService.serverRoute + 'lotdocs/' + doc.id,
                                headers: appsecurity.getSecurityHeadersForFileUpload()
                            } ).then( function ( response ) {
                                if ( response.status < 300 ) {

                                    $scope.lot.lotDoc.splice( index, 1 );
                                }
                            }, function ( response ) {
                                toastService.errorResponseShow( 'Произошла ошибка при удалении документа', response );
                            } );

                        } else {
                            $scope.lot.lotDoc.splice( index, 1 );
                        }
                    };
                    $scope.downloadFile = function ( document ) {
                        //window.open( 'http://isz.gosbook.ru' + document.file, '_blank' );
                        //window.open( document.file, '_blank' );
                        if (!$scope.lot.id){
                            window.open( document.full_path, '_blank' );
                        } else {
                            window.open( document.file, '_blank' );
                        }
                    }
                    //setLot();

                    function setLot() {
                        if ( commonVariables.currentLot ) {
                            $scope.lot = commonVariables.currentLot;

                            if ( !angular.isArray( $scope.lot.rateIndicator ) ) {
                                $scope.lot.rateIndicator = [];
                            }

                            if ( !angular.isArray( $scope.lot.lotDoc ) ) {
                                $scope.lot.lotDoc = [];
                            }

                            $scope.creating
                                ? init()
                                : commonVariables.currentLot.fillAllInfo().then( function(){
                                    init();
                            } );
                            $scope.$$phase || $scope.$apply();
                        } else {
                            setTimeout( setLot, 100 );
                        }
                    }


                    function init() {
                        fcp = {

                            fcp: $scope.lot.fcp|| ($scope.lot.fcpActionTask && angular.extend( {}, $scope.lot.fcpActionTask.fcp )),
                            fcpActionTask: $scope.lot.fcpActionTask,
                            fcpAction: $scope.lot.fcpAction,
                            fcpActionSubaction: $scope.lot.fcpActionSubaction,
                            completelyFilled: false
                        };
                        govProgram ={
                            govProgram:$scope.lot.govProgram
                        };
                        subprogram = {
                            subProgram: $scope.lot.subProgram,
                            subProgramMainAction: $scope.lot.subProgramMainAction,
                            subProgramAction: $scope.lot.subProgramAction,
                            completelyFilled:false
                        };
                        kbk = {
                            kbkSection:$scope.lot.kbkSection,
                            kbkFlowDirection:$scope.lot.kbkFlowDirection,
                            kbkExpenseType:$scope.lot.kbkExpenseType,
                            completelyFilled:false
                        };

                        $scope.foundationOptions = {
                            programEvent: ( $scope.creating || $scope.lot.govProgram )
                               ? 'программное'
                               : 'внепрограммное',
                            // programEvent:null,
                            govProgramBuffer: {
                                program: $scope.lot.subProgram ? 'подпрограмма' : 'фцп',
                                govProgram: govProgram,
                                subprogram: subprogram,
                                fcp: fcp,
                                kbk:kbk
                            },
                            nonProgramBuffer: {
                                orderTitle: $scope.lot.orderTitle,
                                orderNumber: $scope.lot.orderNumber,
                                orderDate: $scope.lot.orderDate
                            }

                        };
                        // if (!$scope.creating){
                        //     if ( $scope.lot.govProgram&& $scope.lot.govProgram.id){
                        //         $scope.foundationOptions.programEvent='программное';
                        //     } else {
                        //         $scope.foundationOptions.programEvent='внепрограммное';
                        //     }
                        // }

                        $scope.selectedRatesIndicators = {
                            rate: null,
                            indicator: null
                        }
                        getAllSelectData();
                    }

                    function isSameEntities( obj ) {
                        return Object.keys( obj ).every( function ( key ) {
                            return ( obj[key] && $scope.lot[key] && obj[key].id == $scope.lot[key].id )
                                || obj[key] == $scope.lot[key];
                        } )
                    }

                    function setNull( context ) {
                        var args = [].slice.call( arguments, 1 );
                        for ( var i = args.length; i--; ) {
                            context[args[i]] = null;
                        }
                    }

                    function setFcpLastValues() {
                        fcpLastValues.govProgram = govProgram.govProgram&&govProgram.govProgram.id;
                        fcpLastValues.programm = fcp.fcp && fcp.fcp.id;
                        fcpLastValues.task = fcp.fcpActionTask && fcp.fcpActionTask.id;
                        fcpLastValues.action = fcp.fcpAction && fcp.fcpAction.id;
                        fcpLastValues.subaction = fcp.fcpActionSubaction && fcp.fcpActionSubaction.id;
                        subProgramLastValue.subprogram=subprogram.subProgram&&subprogram.subProgram.id;
                        subProgramLastValue.subProgramMainAction=subprogram.subProgramMainAction&&subprogram.subProgramMainAction.id;
                        subProgramLastValue.subProgramAction=subprogram.subProgramAction&&subprogram.subProgramAction.id;
                        kbkLastValues.kbkSection=kbk.kbkSection&&kbk.kbkSection.id;
                        kbkLastValues.kbkFlowDirection=kbk.kbkFlowDirection&&kbk.kbkFlowDirection.id;
                        kbkLastValues.kbkExpenseType=kbk.kbkExpenseType&&kbk.kbkExpenseType.id;
                        if (kbkLastValues.kbkFlowDirection && kbkLastValues.kbkExpenseType) {
                            kbk.completelyFilled=true;
                        }
                    }

                    function selectRequest( url ) {
                        // var defer = $q.defer();
                        // $http({
                        //     method: 'GET',
                        //     headers: appsecurity.getSecurityHeaders(),
                        //     url: url
                        // }).then(function(response){
                        //         defer.resolve(response);
                        //     },function(){
                        //         $http({
                        //             method: 'GET',
                        //             headers: appsecurity.getSecurityHeaders(),
                        //             url: url
                        //         }).then(function(response){
                        //             defer.resolve(response);
                        //         }, function(response){
                        //             defer.reject(response);
                        //         })
                        //     }
                        // )
                        // return defer.promise;
                        function reqWrapper() {
                            var defer = $q.defer();
                            $http({
                                method: 'GET',
                                headers: appsecurity.getSecurityHeaders(),
                                url: url
                            }).then(function (response) {
                                    defer.resolve(response);
                                }, function (response) {
                                    defer.reject(response);

                                }
                            )
                            return defer.promise;

                        }
                        var req=reqWrapper;
                        commonVariables.requestArr.push(req);
                        return req();
                    }

                    $scope.lazyLoad = lazyLoadSelectService.lazyLoad;
                    $scope.unbindSelect = lazyLoadSelectService.unbindSelect;

                    $scope.saveKbkSection = function (onliFill) {

                           if (kbk.kbkSection&&(kbkLastValues.kbkSection!=kbk.kbkSection.id)) {
                                kbkLastValues.kbkSection!=kbk.kbkSection.id;

                               if (!onliFill) {
                                   setNull( fcp, 'fcp','fcpAction', 'fcpActionTask', 'fcpActionSubaction' );
                                   setNull( subprogram, 'subProgram','subProgramAction', 'subProgramMainAction' );
                                   setNull(kbk,'kbkFlowDirection','kbkExpenseType');
                                   setNull(fcpLastValues,'govProgram','programm','task','action','subaction');
                                   setNull(subProgramLastValue,'subprogram','subProgramMainAction','subProgramAction');
                                   setNull(kbkLastValues,'kbkFlowDirection','kbkExpenseType');
                                   // $scope.foundationOptions.programEvent=null;
                                   fcp.completelyFilled = false;
                                   subprogram.completelyFilled=false;
                                   kbk.completelyFilled=false;
                               }
                                //var arr = $scope.lot.kbkSection.title.split(' - ');
                                //$scope.lot.kbkSection.code = arr[0];
                                // setNull(govProgram,'govProgram');

                                $scope.forChoice=false;
                                if ( $scope.foundationOptions.programEvent==='внепрограммное') {
                                    $scope.nextKbkVisible=true;
                                    selectKbkFlowDirection();
                                } else {
                                    $scope.nextKbkVisible=false;


                                    // if (govProgram.govProgram.is_fcp && !govProgram.govProgram.is_subprogram ) {
                                    //     $scope.foundationOptions.govProgramBuffer.program='фцп';
                                    //     selectFcp();
                                    // }
                                    // if (!govProgram.govProgram.is_fcp && govProgram.govProgram.is_subprogram) {
                                    //     $scope.foundationOptions.govProgramBuffer.program='подпрограмма';
                                    //     selectSubprogram();
                                    // }

                                    if ((!govProgram.govProgram.is_fcp && !govProgram.govProgram.is_subprogram)||(govProgram.govProgram.is_fcp && govProgram.govProgram.is_subprogram)) {
                                        // $scope.forChoice=true;
                                        var q1=selectFcp();
                                        var q2=selectSubprogram();
                                        $q.all([q1,q2]).then(function () {
                                            if ($scope.fcpsSelect.length && $scope.subProgramSelect.length) {
                                                $scope.forChoice=true;
                                            }
                                            if ($scope.fcpsSelect.length && !$scope.subProgramSelect.length) {
                                                $scope.foundationOptions.govProgramBuffer.program='фцп';
                                            }
                                            if (!$scope.fcpsSelect.length && $scope.subProgramSelect.length) {
                                                $scope.foundationOptions.govProgramBuffer.program='подпрограмма';
                                            }

                                        })
                                        
                                    }
                                }

                                // selectRequest( apiService.govProgramsSelect+'?filters[kbkSection]='+ kbk.kbkSection.id).then( function ( response ) {
                                //     $scope.govProgramsSelect = response.data;
                                // }, function ( response ) {
                                //     toastService.errorResponseShow( 'Ошибка получения госпрограмм', response );
                                // } )
                                //     .then(function () {
                                //         commonVariables.requestArr.pop();
                                //     });
                            }

                    }
                    $scope.govProgramSearch = function (query) {
                        var result = [], defer = $q.defer();
                        if (query) {
                            query = encodeURIComponent(query.replace("%20", "+"));
                            selectRequest(apiService.govProgramsSelect + '?filters[title]=' + query + '&limit=100').then(function (response) {
                                if (angular.isArray(response.data)) {
                                    for (var i = 0; i < response.data.length; i++) {
                                        result.push(response.data[i]);
                                    }
                                }
                                defer.resolve(result);
                            }, function (response) {
                                toastService.errorResponseShow('Ошибка получения данных справочника госпрограмм', response);
                                defer.reject();
                            })
                                .then(function () {
                                    commonVariables.requestArr.pop();
                                });
                        }
                        return defer.promise;
                    };
                    $scope.kbkSectionSearch = function (query) {
                        var result = [], defer = $q.defer(),govProgramFilter='',queryStr='';
                        if ( $scope.foundationOptions.programEvent==='программное' &&govProgram.govProgram.id){
                            govProgramFilter='&filters[govProgram]='+ govProgram.govProgram.id;
                        }
                        if (query) {
                            query = encodeURIComponent(query.replace("%20", "+"));
                            queryStr='?filters[title]=' + query+'&limit=100';

                        } else {
                            queryStr='?limit=10';
                        }
                        selectRequest(apiService.kbkSectionSelect + queryStr+govProgramFilter).then(function (response) {
                                if (angular.isArray(response.data)) {
                                    for (var i = 0; i < response.data.length; i++) {
                                        var ob=response.data[i];
                                        if (ob.number) {
                                            ob.title=ob.number+' - '+ob.title;
                                        }

                                        result.push(ob);
                                    }
                                }
                                defer.resolve(result);
                            }, function (response) {
                                toastService.errorResponseShow('Ошибка получения данных справочника разделов КБК', response);
                                defer.reject();
                            })
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });
                        return defer.promise;
                    };
                    $scope.saveKbkExpenseType = function () {
                        //if ($scope.lot.kbkExpenseType && $scope.lot.kbkExpenseType.id) {
                        //    $scope.lot.patch({kbkExpenseType: $scope.lot.kbkExpenseType.id}).then(function () {
                        //        var arr = $scope.lot.kbkExpenseType.title.split(' - ');
                        //        $scope.lot.kbkExpenseType.code = arr[0];
                        //    });
                        //}
                        if (kbk.kbkExpenseType&&(kbkLastValues.kbkExpenseType!=kbk.kbkExpenseType.id)) {
                            kbkLastValues.kbkExpenseType=kbk.kbkExpenseType.id;
                            kbk.completelyFilled=true;
                            $scope.saveIfFullyFilled();
                        }
                    }
                    $scope.kbkExpenseTypeSearch = function (query) {
                        var result = [], defer = $q.defer(),url;
                        if (query) {
                            query = encodeURIComponent(query.replace("%20", "+"));
                            if ( $scope.foundationOptions.programEvent==='внепрограммное') {
                                url=apiService.kbkExpenseTypeSelect+'?filters[title]=' + query + '&limit=100';

                            } else {
                                url=apiService.kbkExpenseTypeSelect + '?filters[title]=' + query + '&limit=100'+'&filters[kbkSection]='+ kbk.kbkSection.id+'&filters[govProgram]='+ govProgram.govProgram.id+'&fliters['+priznak.program+']='+priznak.id;
                            }

                            selectRequest(url).then(function (response) {
                                if (angular.isArray(response.data)) {

                                    for (var i = 0; i < response.data.length; i++) {
                                        var ob=response.data[i];
                                         // ob.title=ob.code+' - '+ob.title;
                                        result.push(ob);
                                    }
                                }
                                defer.resolve(result);
                            }, function (response) {
                                toastService.errorResponseShow('Ошибка получения данных справочника Видов расходов КБК', response);
                                defer.reject();
                            })
                                .then(function () {
                                    commonVariables.requestArr.pop();
                                });
                        }
                        return defer.promise;
                    };
                    $scope.kbkKosguSearch = function (query) {
                        var result = [], defer = $q.defer(),queryStr='',queryStr='';
                        if (query) {
                            query = encodeURIComponent(query.replace("%20", "+"));
                            queryStr='?filters[title]=' + query+'&limit=100';
                        } else {
                            queryStr='?limit=10';
                        }
                        selectRequest(apiService.kbkKosguSelect + queryStr).then(function (response) {
                                if (angular.isArray(response.data)) {
                                    for (var i = 0; i < response.data.length; i++) {
                                        var ob,pattern=/\d* - */,splitArr=[];
                                        ob=response.data[i];
                                        splitArr=ob.title.split(' - ',2);
                                        if (splitArr.length>1) {
                                            ob.code=splitArr[0];
                                            ob.title=splitArr[1];
                                        }

                                        result.push(ob);
                                    }
                                }
                                defer.resolve(result);
                            }, function (response) {
                                toastService.errorResponseShow('Ошибка получения данных справочника КОСГУ КБК', response);
                                defer.reject();
                            })
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });

                        return defer.promise;
                    };
                    $scope.saveKbkKosgu = function () {
                        if ($scope.lot.kbkKosgu && $scope.lot.kbkKosgu.id) {
                            $scope.lot.patch({kbkKosgu: $scope.lot.kbkKosgu.id}).then(function () {
                                // var arr = $scope.lot.kbkKosgu.title.split(' - ');
                                // $scope.lot.kbkKosgu.code = arr[0];
                            });
                        }
                    }
                    $scope.foundationTypeChanged = function () {
                        if ($scope.foundationOptions.programEvent==='программное') {
                            setNull(kbk,'kbkSection','kbkFlowDirection','kbkExpenseType');
                        } else {
                            setNull(govProgram,'govProgram');
                            setNull( fcp, 'fcp','fcpAction', 'fcpActionTask', 'fcpActionSubaction' );
                            setNull( subprogram, 'subProgram','subProgramAction', 'subProgramMainAction' );
                            setNull(kbk,'kbkSection','kbkFlowDirection','kbkExpenseType');
                            setNull(fcpLastValues,'govProgram','programm','task','action','subaction');
                            setNull(subProgramLastValue,'subprogram','subProgramMainAction','subProgramAction');
                            setNull(kbkLastValues,'kbkFlowDirection','kbkExpenseType');
                            // $scope.foundationOptions.programEvent=null;
                            fcp.completelyFilled = false;
                            subprogram.completelyFilled=false;
                            kbk.completelyFilled=false;
                            $scope.forChoice=false;
                        }
                        $scope.nextKbkVisible=false;
                    }

                }]
        }
    }] );
