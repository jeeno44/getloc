/**
 * Created by pol on 14.04.2016.
 */
angular.module( 'isz' ).filter( 'plansDepsLots', ['commonVariables', function ( commonVariables ) {

    return function ( items ) {
        var arr=['original'];
        if (commonVariables.newLotsFilter) {
            arr.push('added');
        }
        if (commonVariables.changedLotsFilter) {
            arr.push('removed');
        }
        return ( items || [] ).filter( function ( item ) {
            return item.lotType&&arr.indexOf(item.lotType)>-1;
        } );
    }
}] );