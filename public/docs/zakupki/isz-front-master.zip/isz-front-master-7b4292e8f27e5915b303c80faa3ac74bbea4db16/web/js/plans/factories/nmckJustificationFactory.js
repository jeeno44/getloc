/**
 * Created by pol on 28.10.2015.
 */
angular.module('isz').factory('NmckJustification',['$http','$q','apiService','appsecurity','toastService',
function($http,$q,apiService,appsecurity,toastService){
    function NmckJustification (opts){
        this.id = opts.id;
        this.justification=opts.justification;
        this.price=  opts.price||0;
        this.url=opts.url;
        this.comment = opts.comment;
        this.file = opts.file;

    };
    NmckJustification.prototype = {
        create: function ( lot ) {
            var nmckJust = this,
                defer = $q.defer();

            nmckJust.lot = lot.id;

            $http( {
                method: 'POST',
                url: apiService.nmckJustRoute,
                data: nmckJust,
                headers: appsecurity.getSecurityHeaders()
            } ).then( function ( response ) {
                nmckJust.id = response.data.id;
                defer.resolve();
            }, function ( response ) {
                toastService.errorResponseShow('Ошибка при создании обоснования НМЦК на сервере.',response);
                defer.reject();
            } )

            return defer.promise;
        },
        patch: function () {
            var nmckJust = this,
                objToSave = {};

            [].forEach.call( arguments, function ( key ) {
                if ( angular.isString( key ) && key in nmckJust &&
                    ( !angular.isObject( nmckJust[key] ) || angular.isDate( nmckJust[key] ) )&&angular.isDefined(nmckJust[key]) ) {
                    objToSave[key] = nmckJust[key];
                }
            } );

            if ( Object.keys( objToSave ).length>0 ) {
                $http( {
                    method: 'PATCH',
                    data: objToSave,
                    url: apiService.nmckJustRoute + '/' + nmckJust.id,
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {

                }, function ( response ) {
                    toastService.errorResponseShow('Ошибка при изменении этапа.',response);
                } );
            }
        },
        remove: function () {
            var defer = $q.defer();
            $http( {
                method: 'DELETE',
                url: apiService.nmckJustRoute + '/' + this.id,
                headers: appsecurity.getSecurityHeaders()
            } ).then( function ( response ) {
                defer.resolve();
            }, function ( response ) {
                toastService.errorResponseShow('Ошибка при удалении этапа',response)
                defer.reject();
            } );
            return defer.promise;
        },
    };
    return NmckJustification;
}]);
