angular.module('isz').controller('plansLotPage', ['$location', '$scope', '$mdDialog', '$location', '$q', '$timeout', 'commonVariables', 'lotsService', 'appsecurity', 'controlsService', 'commonVariables', 'counterService', 'toastService', 'translate',
    function ($location, $scope, $mdDialog, $location, $q, $timeout, commonVariables, lotsService, appsecurity, controlsService, commonVariables, counterService, toastService, translate) {
        $scope.commonVariables=commonVariables;
        commonVariables.isLoading = true;
        $scope.dealOpen=false;

        if (commonVariables.currentSubSystem!=='plans'){
            commonVariables.currentSubSystem='plans';
            appsecurity.currentRole.subsystemChanged();
        }

        var content = angular.element(document.querySelector('.plans-lot-page'));
        content.addClass('view_mode');
        $scope.inShowComments = false;
        $scope.inShowRootComment = true;

        counterService.resetListeners();

        $scope.today = moment();

        $scope.toggleEditMode = function () {
            content.toggleClass('view_mode').toggleClass('edit_mode');
            $scope.lot.toggleEditMode();
        }

        $scope.toggleShowComments = function () {
            $scope.inShowComments = !$scope.inShowComments;
            content.toggleClass('show_comments');
        }

        $scope.commentRoot = function () {
            $mdDialog.show({
                templateUrl: '/js/common/templates/commentsModal.html',
                controller: 'commentsModal',
                locals: {
                    'fieldId': 'root',
                    'titleRu': 'Комментарий к лоту'
                }
            }).then(function () {
                $scope.$broadcast('commentsUpdates', 'root');
            });
        }

        $scope.executeControlCommand = function (control) {
            commonVariables.isLoading = true;
            controlsService.executeCommand(control, $scope.lot.id, false, true).then(function () {
                $location.path('/plans/my');
                commonVariables.isLoading = false;
                //$scope.commentRoot();
            }, function () {
                commonVariables.isLoading = false;
                //$scope.commentRoot();
            });
        };
        appsecurity.getUserInfo().then(function () {
            if (commonVariables.currentSubSystem!=='plans'){
                commonVariables.currentSubSystem='plans';
                appsecurity.currentRole.subsystemChanged();
            }
                var pathArr = $location.$$path.split('/'),
                    curId = pathArr[pathArr.length - 1];

                if (curId == 'new') {
                    content.addClass('edit_mode').removeClass('view_mode');
                    $scope.lot = commonVariables.currentLot = lotsService.getNewLot();
                    $scope.lot.creationDate = moment()._d;

                    commonVariables.isLoading = false;
                    $scope.creating = true;

                } else {
                    content.addClass('view_mode');
                    if (!commonVariables.currentLot) {
                        lotsService.getCurrentByIdNew(curId).then(afterSetCurrentLot,function(){
                            commonVariables.isLoading = false;
                        });
                    } else {
                        afterSetCurrentLot();
                    }



                }
            //lotsService.getLots().then(function () {
            //
            //    var pathArr = $location.$$path.split('/'),
            //        curId = pathArr[pathArr.length - 1];
            //
            //    if (curId == 'new') {
            //        content.addClass('edit_mode').removeClass('view_mode');
            //        $scope.lot = commonVariables.currentLot = lotsService.getNewLot();
            //        $scope.lot.creationDate = moment()._d;
            //
            //        commonVariables.isLoading = false;
            //        $scope.creating = true;
            //
            //    } else {
            //        content.addClass('view_mode');
            //        if (!commonVariables.currentLot) {
            //            lotsService.getCurrentById(curId);
            //        }
            //
            //        var q1 = commonVariables.currentLot.fillAllInfo();
            //        var q2 = commonVariables.currentLot.getCriteriaIndicators();
            //        var q3 = commonVariables.currentLot.getCriteriaMaxValues();
            //        //commonVariables.isLoading = false;
            //        $q.all([q1, q2, q3]).then(function () {
            //            $scope.lot = commonVariables.currentLot;
            //            commonVariables.enterInLotTimeStamp = new Date();
            //            $scope.showCommentControl = Boolean(Object.keys($scope.lot.commentControls).length);
            //            $scope.isEditable = appsecurity.currentRole.isAllowEditLot(commonVariables.currentLot.common)
            //                && commonVariables.currentLot.canEdit;
            //
            //            commonVariables.isLoading = false;
            //        }, function () {
            //            commonVariables.isLoading = false;
            //        });
            //    }
            //}, function () {
            //    commonVariables.isLoading = false;
            //});

        }, function () {
            commonVariables.isLoading = false;
        });
        function afterSetCurrentLot(){
            var q1 = commonVariables.currentLot.fillAllInfo();
            //var q2 = commonVariables.currentLot.getCriteriaIndicators();
            //var q3 = commonVariables.currentLot.getCriteriaMaxValues();
            //commonVariables.isLoading = false;
            $q.all([q1]).then(function () {
                $scope.lot = commonVariables.currentLot;
                commonVariables.enterInLotTimeStamp = new Date();
                $scope.showCommentControl = Boolean(Object.keys($scope.lot.commentControls).length);
                $scope.isEditable = appsecurity.currentRole.isAllowEditLot(commonVariables.currentLot.common)
                    && commonVariables.currentLot.canEdit;

                commonVariables.isLoading = false;
            }, function () {
                commonVariables.isLoading = false;
            });
        }


        $scope.createLot = function () {
            var count = {
                blank: 0,
                emptyFields: []
            };

            $scope.$broadcast('remainingRequiredFields', count);
            if (count.blank) {
                var title = 'Необходимо заполнить обязательные поля:',
                    fieldArr = [];
                for (var i = 0; i < count.emptyFields.length; i++) {
                    fieldArr.push(translate.requiredFieldName('ru', count.emptyFields[i]));
                }

                toastService.showList(title, fieldArr, true);
            } else {

                for (var i = 0; i < 3; i++) {
                    var financing = commonVariables.currentLot.financings[i];
                    var stagesSum = getStageFinancingSumByYear(i + 1);

                    if (stagesSum == 0) {
                        continue;
                    }

                    if (!financing.planPrice) {
                        toastService.show('Стоимость планового финансирования должна быть заполнена ', true);
                        return;
                    } else if (financing.planPrice < stagesSum) {
                        toastService.show('Плановое финансирование не может быть меньше суммы финансирования этапов', true);
                        return;
                    }
                }

                commonVariables.isLoading = true;
                commonVariables.currentLot.create().then(function () {
                    lotsService.startLots.push(commonVariables.currentLot);
                    commonVariables.isLoading = false;
                    $location.path('/plans/my');
                }, function (response) {
                    commonVariables.isLoading = false;

                });
            }
        }


        function getStageFinancingSumByYear(year) {
            var sum = 0;
            for (var i = 0; i < commonVariables.currentLot.stages.length; i++) {
                if (commonVariables.currentLot.stages[i].startYear == year) {
                    sum += commonVariables.currentLot.stages[i].getWorkTypeFinancingSumm();
                }
            }

            return sum;
        }
        $scope.tabClicked = function(){
            $scope.$broadcast('lotTabClicked');
        }
        $scope.openDeal = function () {
            $scope.$$childTail.dealOpen=true;
        }
        $scope.closeDeal = function () {
            $scope.$$childTail.dealOpen=false;

        }
    }]);

