﻿angular.module( 'isz' ).factory( 'Stage', ['WorkTypeFactory', 'appsecurity', 'apiService', '$http', '$q', 'toastService',
    function ( WorkTypeFactory, appsecurity, apiService, $http, $q, toastService ) {

        function Stage( opts ) {
            this.id = opts.id;
            this.acceptanceDate = opts.acceptanceDate;
            this.executionDate = opts.executionDate;
            this.executionDateTerm = opts.executionDateTerm;
            this.executionTerm = opts.executionTerm;
            this.executionType = opts.executionType;
            this.financing = opts.financing || 0;
            this.place = opts.place;
            this.reportingDocsDate = opts.reportingDocsDate;
            this.reportingDocsRequirement = opts.reportingDocsRequirement;
            this.stageResults = opts.stageResults;
            this.startDate = opts.startDate;
            this.startYear = opts.startYear;
            this.startingDate = opts.startingDate;
            this.title = opts.title;
            this.workTypes = [];
            this.actDate=opts.actDate;
            this.nmckJustification=opts.nmckJustification||null;

            if ( angular.isArray( opts.workTypes ) ) {
                for ( var i = 0; i < opts.workTypes.length; i++ ) {
                    this.workTypes.push( new WorkTypeFactory( opts.workTypes[i] ) );
                }
            }
        }

        Stage.prototype = {
            create: function ( lot ) {
                var stage = this,
                    defer = $q.defer();

                stage.lot = lot.id;

                $http( {
                    method: 'POST',
                    url: apiService.stageRoute,
                    data: stage,
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {
                    stage.id = response.data.id;
                    defer.resolve();
                }, function ( response ) {
                    toastService.errorResponseShow('Ошибка при создании этапа на сервере.',response);
                    defer.reject();
                } )

                return defer.promise;
            },
            patch: function () {
                var stage = this,
                    objToSave = {};

                var defer = $q.defer();
                [].forEach.call( arguments, function ( key ) {
                    if ( angular.isString( key ) && key in stage &&
                        ( !angular.isObject( stage[key] ) || angular.isDate( stage[key] ) )&&angular.isDefined(stage[key]) ) {
                        objToSave[key] = stage[key];
                    }
                } );

                if ( Object.keys( objToSave ).length>0 ) {
                    $http( {
                        method: 'PATCH',
                        data: objToSave,
                        url: apiService.stageRoute + '/' + stage.id,
                        headers: appsecurity.getSecurityHeaders()
                    } ).then( function ( response ) {
                        defer.resolve();
                    }, function ( response ) {
                        defer.reject();
                        toastService.errorResponseShow('Ошибка при изменении этапа.',response);
                    } );
                }
                return defer.promise;
            },
            save: function(){
                var defer = $q.defer();
                var stage=this;
                $http({
                    method:'PUT',
                    url: apiService.stageRoute+'/'+stage.id,
                    data:stage,
                    headers:appsecurity.getSecurityHeaders()
                }).then(function(response){
                    defer.resolve();
                },function(response){
                    toastService.errorResponseShow('Ошибка при сохранении этапа.',response);
                    defer.reject()
                });
                return defer.promise;
            },
            remove: function () {
                var defer = $q.defer();
                $http( {
                    method: 'DELETE',
                    url: apiService.stageRoute + '/' + this.id,
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {
                    defer.resolve();
                }, function ( response ) {
                    toastService.errorResponseShow('Ошибка при удалении этапа',response)
                    defer.reject();
                } );
                return defer.promise;
            },
            getWorkTypeFinancingSumm: function () {
                var sumWorks = 0;
                for ( var i = 0; i < this.workTypes.length; i++ ) {
                    if ( this.workTypes[i].financing ) {
                        sumWorks += parseFloat( this.workTypes[i].financing );
                    }
                }
                return sumWorks;
            }
        }

        return Stage;
    }] );