/**
 * Created by pol on 12.08.2015.
 */
angular.module( 'isz' )
    .controller( 'NextPlan', ['$scope', '$http', 'appsecurity', 'apiService', 'commonVariables', 'lotsService', 'plansService', 'controlsService','toastService',
        function ( $scope, $http, appsecurity, apiService, commonVariables, lotsService, plansService, controlsService, toastService ) {
            commonVariables.isLoading = true;
            $scope.commonVariables=commonVariables;
            commonVariables.enterInLotTimeStamp=null;
            commonVariables.currentMenuItem('/plans/next');
            $scope.plansDeps = plansService.plans;

            $scope.revisionsArray=[];


            function flash() {

                plansService.getPlansCommon('next', $scope.rukKoord).then(function () {
                    // getConsFinancing();
                    commonVariables.isLoading = false;

                    $scope.consolidatedPlan =plansService.consolidatedPlan;
                    $scope.plan=$scope.consolidatedPlan;
                    if ($scope.consolidatedPlan) {
                        $scope.versionPlan={
                            id:$scope.consolidatedPlan.id,
                            created:"текущая"
                        }
                        $scope.revisionsArray.push($scope.versionPlan);
                        if ($scope.consolidatedPlan.revision.length) {
                            $scope.consolidatedPlan.revisionSort();
                            $scope.consolidatedPlan.revision.forEach(function (rev) {
                                $scope.revisionsArray.push({id:rev.id,created:moment(rev.created).format('DD.MM.YYYY')});
                            });

                        }


                        $scope.consolidatedPlan.controls.forEach(function (control) {
                            if (control&&control.opName&&control.opName==='plan_send_zakupki'){
                                $scope.consolidatedPlan.zakupkiControl=control;
                            }
                            if (control&&control.opName&&control.opName==='plan_consolidate_download_xml') {
                                $scope.consolidatedPlan.downloadDocumentsXML=control;
                            }
                        })
                        // var currYear = new Date();
                        for (var i = 0; i < 3; i++) {
                            $scope.currYears.push($scope.consolidatedPlan.year + i)
                        }
                    }
                }, function () {
                    commonVariables.isLoading = false;
                });
            }
           

            $scope.changeRevision = function () {
                plansService.getNewPlansRevision($scope.versionPlan);
            }

            appsecurity.getUserInfo().then( function () {
                if (commonVariables.currentSubSystem!=='plans'){
                    commonVariables.currentSubSystem='plans';
                    appsecurity.currentRole.subsystemChanged();
                }
                $scope.depZakFlag = appsecurity.currentRole.code.indexOf( 'depzak' ) !== -1;
                $scope.rukDepZak = appsecurity.currentRole.code.indexOf( 'Rukovoditel_depzak' ) !== -1;
                $scope.rukKoord = appsecurity.currentRole.code.indexOf('Rukovoditel_koordinator') !== -1;

                lotsService.getExpertStatuses().then( function () {
                    $scope.statuses = commonVariables.expertsStatuses;

                    $scope.currentPlans = plansService.plans;
                    $scope.statusedPlans = plansService.statusedPlans;
                    plansService.getPlansSatauses().then(function () {
                        flash();
                        // plansService.getArchivePlans().then(flash);
                    })
                    //flash();
                },function(){
                    commonVariables.isLoading = false;
                } );

                $scope.currYears = [];


                $scope.readProjectedPlan = appsecurity.currentRole.permissions.readProjectedPlan;
                $scope.readLot = appsecurity.currentRole.permissions.readLot;
                $scope.readSections = appsecurity.currentRole.permissions.readSections;
                $scope.controlSections = appsecurity.currentRole.permissions.controlSections;
                $scope.readSectionsAll = appsecurity.currentRole.permissions.readSectionsAll;
                if ( !$scope.readProjectedPlan && !$scope.readSectionsByGroup ) {
                    toastService.show( 'У Вас нет прав для просмотра этой страницы', false );
                }
            } );

            $scope.controlClick = function ( control ) {
                controlsService.executeCommand( control ).then( function () {
                    flash();
                } );
            };
            

            $scope.removeDoc = function ( doc ) {
                $http( {
                    method: 'DELETE',
                    url: apiService.serverRoute + 'plandocs/' + doc.id,
                    headers: appsecurity.getSecurityHeadersForFileUpload()
                } ).then( function ( response ) {
                    if ( response.status < 300 ) {
                        $scope.currentPlans[0].planDocs.splice( $scope.currentPlans[0].planDocs.indexOf( doc ), 1 );
                    }
                } ,function(response){
                    toastService('Ошибка удаления файла',response)
                });
            };
            $scope.downloadFile = function ( document ) {
                //window.open('http://isz.gosbook.ru'+ document.file, '_blank' );
                window.open( document.file, '_blank' );
            }
            $scope.downloadFileFresh = function(document){
                window.open( document.full_path, '_blank' );
            };

            $scope.afterExpandClick = function(plan,open){
                // plan.fillPlanLots();
            };

            function getConsFinancing() {
                $scope.consFinancing = [0, 0, 0];
                $scope.statusedPlans.forEach( function ( status ) {
                    status.plansByStatus.forEach( function ( plan ) {
                        $scope.consFinancing[0] += plan.financing;
                        $scope.consFinancing[1] += plan.financing1;
                        $scope.consFinancing[2] += plan.financing2;
                    } );
                } );
            }

            function getYears() {
                var year = new Date().getFullYear() + 1;
                for ( var i = 0; i < 3; i++ ) {
                    $scope.currYears.push( year + i );
                }
            }
        }] );