﻿angular.module('isz').service('limitsServiсe', ['$http', '$q', 'apiService', 'appsecurity', 'toastService',
    function ($http, $q, apiService, appsecurity, toastService) {
        this.currLimit = [];
        this.nextLimit = [];
        this.currDeps = [];
        this.nextDeps = [];
        var self = this;

        this.clearLimits = function () {
            self.currLimit.length = 0;
            self.nextLimit.length = 0;
        };
        this.getLimits = function (year) {

            var defer = $q.defer();

            var q1 = getFoiv();
            var q2 = getDepsLimit(year, true);
            var q3 = getDepsLimit(year + 1, false);

            $q.all([q1, q2, q3]).then(function () {
                if (self.currDeps.length) createTree1(true);
                if (self.currDeps.length) createTree1(false);

                defer.resolve();
            }, function () {
                //toastService.show('Невозможно получить данные', false);
                defer.reject();
            });

            return defer.promise;
        };


        function getDepsLimit(year, fl) {
            var defer = $q.defer();
            self.currDeps.length = 0;
            self.nextDeps.length = 0;
            selectRequest(apiService.limit + '?filters[year]=' + year)
                .then(function (response) {
                    if (response.data) {
                        for (dep in response.data) {
                            if (fl) {
                                self.currDeps.push(response.data[dep]);
                            } else {
                                self.nextDeps.push(response.data[dep]);
                            }
                        }
                    }

                    defer.resolve();
                }, function (response) {
                    toastService.errorResponseShow('Ошибка получения лимитов ' + year + '-' + (year + 3) + 'годов', response);
                    defer.reject();
                })
                .then(function () {
                    commonVariables.requestArr.pop();
                });
            return defer.promise;
        }

        function getFoiv() {
            var defer = $q.defer();
            self.currLimit.splice(0);
            self.nextLimit.splice(0);
            selectRequest(apiService.serverRoute + 'commons?filters[type]=foiv')
                .then(function (response) {
                    if (response.data && response.data.length) {
                        self.currLimit.push(response.data[0]);
                        self.nextLimit.push(response.data[0]);
                    }
                    ;
                    defer.resolve();
                }, function (response) {
                    toastService.errorResponseShow('Ошибка получения министерства', response);
                    defer.reject();
                })
                .then(function () {
                    commonVariables.requestArr.pop();
                });

            return defer.promise;
        }

        function createTree1(fl) {
            var origArr;
            if (fl) {
                origArr = self.currDeps;
            } else {
                origArr = self.nextDeps;
            }

            var depsArr = [];
            var minFin = {
                financing: 0,
                financing1: 0,
                financing2: 0
            };

            var depsMap = [];
            origArr.forEach(function (dep) {
                if (depsMap.indexOf(dep.common.id) == -1) {
                    depsMap.push(dep.common.id);
                }


                minFin.financing += dep.financing;
                minFin.financing1 += dep.financing1;
                minFin.financing2 += dep.financing2;
            });
            depsArr = depsMap.map(function (dep) {
                return {
                    id: dep,
                    actions: []
                }
            });
            depsArr.forEach(function (dep) {
                var actMap = [], actsArr = [];
                var draftAct = origArr.filter(function (act) {
                    return act.common.id === dep.id;
                });
                dep.financing = 0;
                dep.financing1 = 0;
                dep.financing2 = 0;
                draftAct.forEach(function (act) {
                    var id;

                    if (act.fcpAction) {
                        id = act.fcpAction.id;
                    } else {
                        id = act.subProgramAction.id;
                    }

                    if (actMap.indexOf(id) == -1) {
                        actMap.push(id);
                    }
                    dep.title = act.common.fullName;

                    dep.financing += act.financing;
                    dep.financing1 += act.financing1;
                    dep.financing2 += act.financing2;
                });
                var actsArr = actMap.map(function (act) {
                    return {
                        id: act,
                        kbks: []
                    };
                });
                dep.actions = actsArr;
                dep.actions.forEach(function (act) {
                    act.financing = 0;
                    act.financing1 = 0;
                    act.financing2 = 0;
                    var kbkMap = [];
                    var draftKbk = draftAct.filter(function (kbk) {
                        if (kbk.fcpAction) {
                            return kbk.fcpAction.id === act.id;
                        } else {
                            return kbk.subProgramAction.id === act.id;
                        }
                    });
                    draftKbk.forEach(function (kbk) {
                        if (kbk.kbk&&kbk.kbk.id&& kbkMap.indexOf(kbk.kbk.id) == -1) {
                            kbkMap.push(kbk.kbk.id);
                        }
                        act.title = ( kbk.fcpAction ) ? kbk.fcpAction.title : kbk.subProgramAction.title;
                        act.financingTypeNum = ( kbk.fcpAction ) ? kbk.fcpAction.financingTypeNum : kbk.subProgramAction.financingTypeNum;
                        act.financing += kbk.financing;
                        act.financing1 += kbk.financing1;
                        act.financing2 += kbk.financing2;
                    });
                    act.kbks = kbkMap.map(function (kbk) {
                        return {id: kbk};
                    });
                    act.kbks.forEach(function (kbk) {
                        kbk.financing = 0;
                        kbk.financing1 = 0;
                        kbk.financing2 = 0;
                        var draftEnd = draftKbk.filter(function (end) {
                            return end.kbk.id === kbk.id;
                        });
                        draftEnd.forEach(function (end) {
                            kbk.code = end.kbk.code;
                            kbk.title = end.kbk.title;
                            kbk.financing += end.financing;
                            kbk.financing1 += end.financing1;
                            kbk.financing2 += end.financing2;

                        });

                    });


                });
            });


            minFin.deps = depsArr;
            if (fl) {
                self.currLimit[0] = angular.extend({}, minFin, self.currLimit[0]);
            } else {
                self.nextLimit[0] = angular.extend({}, minFin, self.nextLimit[0]);
            }


        }

        function selectRequest(url) {
            // var defer = $q.defer();
            // $http({
            //     method: 'GET',
            //     headers: appsecurity.getSecurityHeaders(),
            //     url: url
            // }).then(function (response) {
            //         defer.resolve(response);
            //     }, function () {
            //         $http({
            //             method: 'GET',
            //             headers: appsecurity.getSecurityHeaders(),
            //             url: url
            //         }).then(function (response) {
            //             defer.resolve(response);
            //         }, function (response) {
            //             defer.reject(response);
            //         })
            //     }
            // )
            // return defer.promise;
            function reqWrapper() {
                var defer = $q.defer();
                $http({
                    method: 'GET',
                    headers: appsecurity.getSecurityHeaders(),
                    url: url
                }).then(function (response) {
                        defer.resolve(response);
                    }, function (response) {
                        defer.reject(response);

                    }
                )
                return defer.promise;

            }
            var req=reqWrapper;
            commonVariables.requestArr.push(req);
            return req();
        }
    }]);