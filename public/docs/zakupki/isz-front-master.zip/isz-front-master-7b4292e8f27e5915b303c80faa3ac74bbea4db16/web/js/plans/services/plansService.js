﻿/**
 * Created by pol on 23.08.2015.
 */
angular.module('isz')
    .service('plansService', ['$http', '$q', 'PlanFactory', 'appsecurity', 'apiService', 'commonVariables', 'toastService', 'lotsService',
        function ($http, $q, PlanFactory, appsecurity, apiService, commonVariables, toastService, lotsService) {

            var self = this;

            this.archivePlans = [];
            this.plans = [];
            this.statusedPlans = [];
            this.planType = 'current';
            this.consolidatedPlan = {};

            var controls = [];
            this.executeIfControlExists = function (lot, controlName) {
                return false;
            }
            /*
             @deprecated: @todo: Теперь делается через workflow
             var controls = ['add_to_plan', 'remove_from_plan'];

             this.executeIfControlExists = function (lot, controlName) {
             switch (controlName) {
             case controls[0]:
             addLotToPlan(lot);

             return true;
             case controls[1]:

             removeLotFromPlan(lot);

             return true;
             }
             return false;
             }*/
            this.flash = function () {
                this.plans.splice(0);
            };

            this.getPlansCommon = function (planType, cons) {
                var defer = $q.defer(), self = this;
                this.plans.splice(0);
                var path;
                // if (cons) {
                //     path=apiService.onAgreeKoordPlans + planType + '/expertise?order_by[year]=DESC';
                // } else {
                //     path=apiService.planCommon + planType + '&order_by[year]=DESC';
                // }

                path = apiService.planCommon + planType;
                selectRequest(path).then(function (response) {
                        if (response.status===204){
                            toastService.show('Нет данных по запросу', false);
                        }
                        var pl = response.data, qAll = [];
                        if (angular.isArray(pl)) {
                            self.consolidatedPlan = new PlanFactory(pl[0]);
                        } else {
                            self.consolidatedPlan = new PlanFactory(pl);
                        }
                        self.constructConsolidatedPlan(cons);
                        defer.resolve();
                    }, function (response) {
                        toastService.errorResponseShow('Произошла ошибка при получении планов', response);
                        defer.reject();
                    })
                    .then(function () {
                        commonVariables.requestArr.pop();
                    });
                return defer.promise;
            };
            this.getNewPlansRevision = function (revision) {
                var defer = $q.defer();
                self.consolidatedPlan.id = revision.id;
                self.consolidatedPlan.fillAllInfo().then(function () {
                    defer.resolve();
                }, function () {
                    defer.reject()
                });
                return defer.promise;
            }

            this.getPlansDepzak = function (planType) {
                this.plans.length = 0;
                var defer = $q.defer();
                selectRequest(apiService.serverRoute + 'plan/' + planType + '/expertise').then(function (response) {
                        var pl = response.data;
                        commonVariables.planCurrentYear = pl.year;
                        var p = new PlanFactory(pl);

                        self.getPlansSatauses().then(function () {
                            var tt = commonVariables.plansStatuses.filter(function (st) {
                                return st.id === p.statusId;
                            });
                            p.statusTitle = tt.length ? tt[0].title : '';
                        })


                        p.getPlanPDF();
                        p.getPlanExcel();
                        p.fillPlanLots().then(function () {
                            var sum = 0;


                            var dat = new Date();
                            var delta = (planType === 'current' ? 0 : 1);
                            var currYear = dat.getFullYear() + delta;
                            var currYearsFin = [0, 0, 0];


                            p.lots.forEach(function (lot) {
                                sum += lot.pricing;
                                lot.financings.forEach(function (fin) {
                                    for (var i = 0; i < 3; i++) {
                                        if (fin.year === (currYear + i)) {
                                            currYearsFin[i] += (fin.planPrice || 0);
                                        }
                                    }

                                });

                            });
                            p.currYearsFin = currYearsFin;
                            p.allPricing = sum;
                            self.plans.push(p);

                            defer.resolve();
                        }, function () {

                            defer.reject();
                        });

                    }, function (response) {
                        toastService.errorResponseShow('Произошла ошибка при получении планов', response);
                        defer.reject();
                    })
                    .then(function () {
                        commonVariables.requestArr.pop();
                    });
                return defer.promise;
            };

            this.getArchivePlans = function (cons) {
                var defer = $q.defer();
                var self = this;
                self.archivePlans.splice(0);
                var path;
                // if (cons) {
                //     path=apiService.onAgreeKoordPlans +  'archive/expertise?order_by[year]=DESC';
                // } else {
                //     path=apiService.planCommon + 'archive&order_by[year]=DESC';
                // }
                path = apiService.planCommon + 'archive';
                selectRequest(path).then(function (response) {
                        if (response.status === '204') {
                            toastService.show('Нет данных по запросу', false);
                        }
                        if (angular.isArray(response.data)) {
                            response.data.sort(function (a, b) {
                                return b.year - a.year;
                            });
                            for (var i = 0; i < response.data.length; i++) {
                                self.archivePlans.push(response.data[i]);
                            }

                            // if (cons) {
                            self.consolidatedPlan = new PlanFactory(self.archivePlans[0]);
                            self.constructConsolidatedPlan(cons);
                            // }
                            defer.resolve();
                        } else {
                            defer.reject();
                        }

                    })
                    .then(function () {
                        commonVariables.requestArr.pop();
                    })
                return defer.promise;

            }
            this.constructConsolidatedPlan = function (cons) {


                self.consolidatedPlan.getPlanPDF();
                self.consolidatedPlan.getPlanExcel();
                // self.plans.splice(0);
                // if (angular.isArray(self.consolidatedPlan.plans)) {
                //     self.consolidatedPlan.plans.forEach(function (pl) {
                //         self.plans.push(pl);
                //     })
                // }
                // self.plans=self.consolidatedPlan.plans;
                self.consolidatedPlan.fillAllInfo(cons);

                var t = 2;

            }
            this.getStatusedPlans = function (planType, cons) {
                var defer = $q.defer();
                this.plans.splice(0);
                this.statusedPlans.length = 0;

                var statuses = commonVariables.plansStatuses;

                var obj;
                self.getPlansCommon(planType, cons).then(function () {
                    //statuses.forEach(function (status, index) {
                    //    obj = {
                    //        id: status.id,
                    //        title: status.title,
                    //        plansByStatus: self.plans.filter(function (plan) {
                    //            return plan.statusId === status.id;
                    //        })
                    //    };
                    //    if (obj.plansByStatus.length) {
                    //        obj.hasFilteredPlans = true;
                    //        self.statusedPlans.push(obj);
                    //    }
                    //});

                    self.plans.forEach(function (pl) {
                        pl.statusTitle = statuses.filter(function (st) {
                            return pl.statusId === st.id;
                        })[0].title;

                    });
                    obj = {
                        plansByStatus: self.plans
                    };
                    self.statusedPlans.push(obj);
                    defer.resolve();

                }, function () {
                    defer.reject();
                });


                return defer.promise;

            }

            this.addControl = function (lot) {
                /*
                 @deprecated: @todo: Теперь делается через workflow
                 if (!lot.plan.length) {
                 lot.customControls.push({
                 value: 'Добавить в план',
                 name: controls[0]
                 });
                 }
                 else {
                 lot.customControls.push({
                 value: 'Удалить из плана',
                 name: controls[1]
                 });
                 }*/
            }

            /*
             @deprecated: @todo: Теперь делается через workflow
             function addLotToPlan(lot) {
             $http({
             method: 'POST',
             headers: appsecurity.getSecurityHeaders(),
             url: apiService.plans,
             data: {
             lotId: lot.id,
             plan: self.planType
             }
             }).then(function (response) {
             lot.plan = response.data.plan;
             changeControl(lot);
             }, function (response) {
             toastService.errorResponseShow('Ошибка добавления лота в план', response);
             });
             }

             function removeLotFromPlan(lot) {
             $http({
             method: 'DELETE',
             headers: appsecurity.getSecurityHeaders(),
             url: apiService.plan,
             data: {
             lotId: lot.id,
             plan: self.planType
             }
             }).then(function (response) {
             lot.plan.length = 0;
             lot.fillAllInfo().then(function(){
             lot.customControls.length = 0;
             //changeControl(lot);
             })

             }, function (response) {
             toastService.errorResponseShow('Ошибка удаления лота из плана', response);
             });
             }*/

            function changeControl(lot) {
                lot.customControls.length = 0;
                lot.configureCustomControls();
                // self.addControl(lot);  @deprecated: @todo: Теперь делается через workflow
            }

            this.getPlansSatauses = function () {
                var defer = $q.defer();
                if (commonVariables.plansStatuses.length) {
                    defer.resolve();
                } else {
                    selectRequest(apiService.plansStatuses).then(function (response) {
                            if (response.data.length) {
                                for (var i = 0; i < response.data.length; i++) {
                                    commonVariables.plansStatuses.push(response.data[i]);
                                }
                            }
                            defer.resolve()
                        }, function (response) {
                            defer.reject();
                            toastService.errorResponseShow('Ошибка получения статусов планов', response);
                        }
                        )
                        .then(function () {
                            commonVariables.requestArr.pop();
                        });
                }
                return defer.promise;
            }
            function selectRequest(url) {
                //return $http( {
                //    method: 'GET',
                //    headers: appsecurity.getSecurityHeaders(),
                //    url: url
                //} )
                // var defer = $q.defer();
                // $http({
                //     method: 'GET',
                //     headers: appsecurity.getSecurityHeaders(),
                //     url: url
                // }).then(function (response) {
                //         defer.resolve(response);
                //     }, function () {
                //        defer.reject();
                //     }
                // )
                // return defer.promise;
                function reqWrapper() {
                    var defer = $q.defer();
                    $http({
                        method: 'GET',
                        headers: appsecurity.getSecurityHeaders(),
                        url: url
                    }).then(function (response) {
                            defer.resolve(response);
                        }, function (response) {
                            defer.reject(response);

                        }
                    )
                    return defer.promise;

                }

                var req = reqWrapper;
                commonVariables.requestArr.push(req);
                return req();
            }
        }]);
