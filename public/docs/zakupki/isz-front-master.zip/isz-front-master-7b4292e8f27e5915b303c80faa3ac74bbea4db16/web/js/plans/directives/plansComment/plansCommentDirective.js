﻿angular.module( 'isz' ).directive( 'plansComment', [function () {

    return {
        restrict: 'E',
        replace: false,
        templateUrl: '/js/plans/directives/plansComment/plansCommentTemplate.html',
        controller: ['$scope', function ( $scope ) {

        }]
    };
}] )