/**
 * Created by pol on 10.11.2015.
 */
angular.module('isz').directive('navigatorElement',function(){
    return {
        restrict:"E",
        replace:true,
        scope:{
            item:'='
        },
        templateUrl:'/js/common/directives/navigatorElement/navigatorElementTemplate.html',
        link:function(scope, element, attrs ){
            //var t= scope.item.subsystem.name;
        }
    }
});
