angular.module( 'isz' ).service( 'calendarService', ['lotsService', 'translate',
    function ( lotsService, translate ) {

        var self = this;

        this.eventDates = [];



        var dayEvents = [];
        function DayEvent( m_day ) {
            this.date = m_day;
            this.existedTypes = [];
            this.events = {};
        }

        DayEvent.prototype.addReference = function ( name, calendarLot ) {
            if ( this.existedTypes.indexOf( name ) == -1 ) {
                this.existedTypes.push( name );
                this.events[name] = {
                    attr: 'event-' + name.replace( /[A-Z].*/, '' ),
                    nameRu: translate.calendar.events( 'ru', name ),
                    count: 0,
                    references: []
                };
            }

            this.events[name].references.push( {
                lotId: calendarLot.id,
                lotNumber: calendarLot.number || 'Нет значения',
                statusRu: translate.status( 'ru', calendarLot.statusId )
            } );
            this.events[name].count += 1;
        }

        var date = moment().format( 'L' ).split( '.' ).map( parseFloat ).reverse();

        this.getObservedDate = function () {
            return moment( date.join( '/' ) );
        }

        this.getDaysRange = function ( dateType, isGantView ) {
            var monthDays, daysRange = [];

            switch ( dateType ) {
                case 'Месяц':
                    var i = 0;

                    monthDays = daysInMonth( date[1], date[0] );
                    for ( i = 1; i <= monthDays; i++ ) {
                        daysRange.push( generateDate( date[0], date[1], i ) );
                    }

                    if ( !isGantView ) {
                        var daysToDisplayFromPrevMonth = moment( date[0] + '/' + date[1] + '/1' ).get( 'day' ) - 1,
                            daysInPrevMonth = daysInMonth( date[1] - 1, date[0] );

                        if ( daysToDisplayFromPrevMonth === -1 ) {
                            daysToDisplayFromPrevMonth = 6;
                        }

                        for ( ; daysToDisplayFromPrevMonth > 0; daysToDisplayFromPrevMonth-- ) {
                            daysRange.unshift( generateDate( date[0], date[1] - 1, daysInPrevMonth, true ) );
                            daysInPrevMonth -= 1;
                        }
                        for ( i = 1; daysRange.length % 7 ; i++ ) {
                            daysRange.push( generateDate( date[0], date[1] + 1, i, true ) );
                        }
                    }
                    break;
                case 'Неделя':
                    var w = getStartEndDaysOfWeek(),
                        from = Number( w.start.format( 'D' ) ),
                        to = Number( w.end.format( 'D' ) );

                    if ( from > to ) {
                        monthDays = daysInMonth( w.start.get( 'month' ) + 1, w.start.get( 'year' ) );
                        while ( from <= monthDays ) {
                            daysRange.push( generateDate( date[0], w.start.get( 'month' ) + 1, from ) );
                            from += 1;
                        }
                        from = 1;
                    }

                    while ( from <= to ) {
                        daysRange.push( generateDate( date[0], w.end.get( 'month' ) + 1, from ) );
                        from += 1;
                    }
                    break;
                case 'День':
                    daysRange.push( { date: moment( date.join( '/' ) ) } );
            }

            return daysRange;
        }

        this.getDateDisplay = function ( dateType ) {
            var dateMoment = moment( date.join( '/' ) );

            switch ( dateType ) {
                case 'Год':
                    return date[0] + ' год';
                case 'Месяц':
                    return dateMoment.format( 'MMMM YYYY' );
                case 'Неделя':
                    var w = getStartEndDaysOfWeek(),
                        onBoundary = w.start.get( 'month' ) !== w.end.get( 'month' );

                    return w.start.format( 'MMMM D' ) + '-' +
                                w.end.format( onBoundary ? 'D MMMM' : 'D' );
                case 'День':
                    return dateMoment.format( 'LL' );
            }
        }

        this.changeDate = function ( dateType, shift ) {
            var maxMonthDays;

            switch ( dateType ) {
                case 'Год':
                    date[0] += shift;
                    break;

                case 'Месяц':
                    var lastDayInMonth = date[2] == daysInMonth( date[1], date[0] );
                    date[1] += shift;
                    if ( date[1] > 12 ) {
                        date[1] = 1;
                        this.changeDate( 'Год', 1 );
                    } else if ( date[1] === 0 ) {
                        date[1] = 12;
                        this.changeDate( 'Год', -1 );
                    }

                    maxMonthDays = daysInMonth( date[1], date[0] );
                    if ( date[2] > maxMonthDays || lastDayInMonth ) {
                        date[2] = maxMonthDays;
                    }

                    break;

                case 'Неделя':
                    shift *= 7;
                    // throw
                case 'День':
                    maxMonthDays = daysInMonth( date[1], date[0] );
                    date[2] += shift;
                    if ( date[2] > maxMonthDays ) {
                        date[2] -= maxMonthDays;
                        this.changeDate( 'Месяц', 1 );
                    } else if ( date[2] <= 0 ) {
                        date[2] += daysInMonth( date[1] == 1 ? 12 : date[1], date[0] );
                        this.changeDate( 'Месяц', -1 );
                    }
            }
        }

        this.changeDateTo = function ( dateType, to ) {
            if ( dateType === 'Месяц' ) {
                date[1] = to;
            } else if ( moment.isMoment( to ) ) {
                date = to.format( 'L' ).split( '.' ).reverse().map( parseFloat );
            }
        }

        function generateDate( year, month, day, outOfMonth ) {
            return {
                date: moment( year + '/' + month + '/' + day ),
                day: day,
                outOfMonth: outOfMonth || false
            }
        }

        function getStartEndDaysOfWeek() {
            var dateString = date.join( '/' );
            return {
                start: moment( dateString ).startOf( 'isoWeek' ),
                end: moment( dateString ).endOf( 'isoWeek' )
            };
        }

        function daysInMonth( month, year ) {
            return new Date( year, month, 0 ).getDate();
        }

        this.organizeData = function ( lots ) {
            if (angular.isArray(lots)) {
                dayEvents.length = 0;
                lots.forEach( function ( item ) {
                    addReferenceToDay( item.creationDate, 'creation', item );
                    addReferenceToDay( item.contractDate, 'contract', item );
                    addReferenceToDay( item.procurementStartDate, 'procurementStart', item );
                    addReferenceToDay( item.procurementEndDate, 'procurementEnd', item );
                    if ( item.expertiseData ) {
                        addReferenceToDay( item.expertiseData.timeStart, 'expertiseStart', item );
                        addReferenceToDay( item.expertiseData.timeEnd, 'expertiseEnd', item );
                    }
                } );
            }

        }

        this.associateEvents = function ( days ) {
            days.forEach( function ( day ) {
                angular.extend( day, self.getEventByDate( day.date ) );
            } )
        }

        function addReferenceToDay( date, eventName, calendarLot ) {
            var m_date = moment( date || null );
            if ( m_date.isValid() ) {
                var dayEvent = self.getEventByDate( m_date )
                if ( angular.isUndefined( dayEvent ) ) {
                    dayEvents.push( dayEvent = new DayEvent( m_date ) );
                }
                dayEvent.addReference( eventName, calendarLot );
            }
        }

        this.getEventByDate = function ( date ) {
            for ( var i = 0; i < dayEvents.length; i++ ) {
                if ( dayEvents[i].date.isSame( date, 'day' ) ) {
                    return dayEvents[i];
                }
            }
        }
    }] );