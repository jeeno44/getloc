﻿angular.module( 'isz' )
.directive( 'navbarHistory', [function () {
    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/navbarHistory/navbarHistoryTemplate.html',
        controller: ['$scope',function ($scope) {
            $scope.buttClick = function () {

            };
        }],
    };
}] );