﻿angular.module( 'isz' ).service( 'dateLogger', ['translate', 'toastService', function ( translate, toastService ) {

    var messages = {
        datesUndefined: 'Вы должны сначала заполнить: ',
        notLaterThan: 'Указываемая дата должна быть позже: ',
        notEarlierThan: 'Указываемая дата должна быть раньше: ',
    };

    this.isLater = function ( date, dependencies, names ) {
        var fieldNames = getNamesEqual( names ),
            notSatisfy = [];

        if ( !moment.isMoment( date ) ) {
            date = moment( date );
        }

        if ( angular.isDefined( dependencies ) ) {
            dependencies.forEach( function ( dependence, index ) {
                if ( dependence
                    && !date.isAfter( dependence, 'day' )
                    && !date.isSame( dependence, 'day' ) ) {
                    notSatisfy.push( fieldNames[index] );
                }
            } );

            log( notSatisfy, messages.notLaterThan );
        }

        return !notSatisfy.length;
    }
    this.isMore=function ( date, dependencies, names ) {
        var fieldNames = getNamesEqual( names ),
            notSatisfy = [];

        if ( !moment.isMoment( date ) ) {
            date = moment( date );
        }

        if ( angular.isDefined( dependencies ) ) {
            dependencies.forEach( function ( dependence, index ) {
                if ( dependence && !date.isAfter( dependence, 'day' )) {
                    notSatisfy.push( fieldNames[index] );
                }
            } );

            log( notSatisfy, messages.notLaterThan );
        }

        return !notSatisfy.length;
    }
    this.isLaterMinute = function ( date, dependencies, names ) {
        var fieldNames = getNamesEqual( names ),
            notSatisfy = [];

        if ( !moment.isMoment( date ) ) {
            date = moment( date );
        }

        if ( angular.isDefined( dependencies ) ) {
            dependencies.forEach( function ( dependence, index ) {
                if ( dependence
                    && !date.isAfter( dependence, 'minute' )
                     ) {
                    notSatisfy.push( fieldNames[index] );
                }
            } );

            log( notSatisfy, messages.notLaterThan );
        }

        return !notSatisfy.length;
    }

    this.isBefore = function ( date, dependencies, names ) {
        var fieldNames = getNamesEqual( names ),
            notSatisfy = [];

        if ( !moment.isMoment( date ) ) {
            date = moment( date );
        }

        if ( angular.isDefined( dependencies ) ) {

            dependencies.forEach( function ( dependence, index ) {
                if ( dependence
                    && !date.isBefore( dependence, 'day' )
                    && !date.isSame( dependence, 'day' ) ) {
                    notSatisfy.push( fieldNames[index] );
                }
            } );

            log( notSatisfy, messages.notEarlierThan );
        }

        return !notSatisfy.length;
    }
    this.isLess= function ( date, dependencies, names ) {
        var fieldNames = getNamesEqual( names ),
            notSatisfy = [];

        if ( !moment.isMoment( date ) ) {
            date = moment( date );
        }

        if ( angular.isDefined( dependencies ) ) {

            dependencies.forEach( function ( dependence, index ) {
                if ( dependence
                    && !date.isBefore( dependence, 'day' )) {
                    notSatisfy.push( fieldNames[index] );
                }
            } );

            log( notSatisfy, messages.notEarlierThan );
        }

        return !notSatisfy.length;
    }
    this.isBeforeMinute = function ( date, dependencies, names ) {
        var fieldNames = getNamesEqual( names ),
            notSatisfy = [];

        if ( !moment.isMoment( date ) ) {
            date = moment( date );
        }

        if ( angular.isDefined( dependencies ) ) {

            dependencies.forEach( function ( dependence, index ) {
                if ( dependence
                    && !date.isBefore( dependence, 'minute' )
                    ) {
                    notSatisfy.push( fieldNames[index] );
                }
            } );

            log( notSatisfy, messages.notEarlierThan );
        }

        return !notSatisfy.length;
    }
    function getNamesEqual( names ) {
        if ( names ) {
            var temp=names.slice(1,names.length-1);
            return temp.split(',');
            //return names.split( ',' )
            //            .map( function ( name ) {
            //                //return ( /\w+/.exec( name ) || [] )[0];
            //                return ( /\w+($|(?=\]))/.exec( name ) || [] )[0];
            //            } );
        }
    }

    function log( names, msg ) {
        var namesRu = names.map( function ( name ) {
            return translate.dates( 'ru', name );
        } );

        if ( namesRu.length ) {
            toastService.show( msg + namesRu.join( ', ' ) );
        }
    }

}] )