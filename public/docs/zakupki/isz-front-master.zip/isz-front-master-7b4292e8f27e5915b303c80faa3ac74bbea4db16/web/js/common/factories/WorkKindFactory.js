﻿angular.module( 'isz' ).factory( 'WorkKindFactory', ['$http', '$q', 'apiService', 'appsecurity', 'toastService',
    function ( $http, $q, apiService, appsecurity, toastService ) {

    function WorkKindFactory( opts, workTypeId ) {
        this.id = opts.id;
        this.title = opts.title || '';
        this.qualitativeChar = opts.qualitativeChar || '';
        this.results = opts.results || '';
        this.nameOis = opts.nameOis || '';
        this.volumeOis = opts.volumeOis || '';
        this.license = opts.license || '';
        this.gosAccred = opts.gosAccred;
        this.rightsOis = opts.rightsOis;
        this.npa = opts.npa;
        this.warranty = opts.warranty;
        this.specRequirements = opts.specRequirements;
        this.workType = workTypeId;
    }

    WorkKindFactory.prototype = {
        update: function () {
            var workKind = this;
            $http( {
                method: 'PUT',
                url: apiService.workKindsRoute + '/' + workKind.id,
                data: workKind,
                headers: appsecurity.getSecurityHeaders()
            } ).then( function ( response ) {
                toastService.show( 'Работа/услуга успешно обновлена', false );
            }, function ( response ) {
                var str='Возникла ошибка при обновлении Работы/услуги. ';
                toastService.errorResponseShow(str,response);
            } );
        },
        create: function () {
            var defer = $q.defer();
            var workKind = this;
            $http( {
                method: 'POST',
                url: apiService.workKindsRoute,
                data: workKind,
                headers: appsecurity.getSecurityHeaders()
            } ).then( function ( response ) {
                workKind.id = response.data.id;
                toastService.show( 'Работа/услуга успешно добавлена', false );
                defer.resolve();
            }, function ( response ) {
                var str='Возникла ошибка при добавлении Работы/услуги. ';
                toastService.errorResponseShow(str,response);
                defer.reject();
            } );

            return defer.promise;
        },
        remove: function () {
            var workKind = this;
            var defer = $q.defer();
            $http( {
                method: 'DELETE',
                url: apiService.workKindsRoute + '/' + workKind.id,
                headers: appsecurity.getSecurityHeaders()
            } ).then( function ( response ) {
                toastService.show( 'Работа/услуга успешно удалена', false );
                defer.resolve();
            }, function ( response ) {
                var str='Возникла ошибка при удалении Работы/услуги. ';
                toastService.errorResponseShow(str,response);
                defer.reject();
            } )

            return defer.promise;
        },
        patch: function () {
            var workKind = this,
                objToSave = {};

            [].forEach.call( arguments, function ( key ) {
                if ( angular.isString( key ) && key in workKind &&
                    ( !angular.isObject( workKind[key] ) || angular.isDate( workKind[key] ) ) ) {
                    objToSave[key] = workKind[key];
                }
            } );

            

            if ( Object.keys( objToSave ).length ) {
                objToSave.workType = this.workType;
                $http( {
                    method: 'PATCH',
                    data: objToSave,
                    url: apiService.workKindsRoute + '/' + workKind.id,
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {

                }, function ( response ) {
                    var str='Произошла ошибка при обновлении вида работ. ';
                    toastService.errorResponseShow(str,response);
                } );
            }
        }
    }

    return WorkKindFactory;
}] )