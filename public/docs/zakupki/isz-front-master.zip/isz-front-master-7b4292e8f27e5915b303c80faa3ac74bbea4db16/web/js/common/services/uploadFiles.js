/**
 * Created by pol on 27.04.2016.
 */
angular.module('isz').service('uploadFiles',['$http','appsecurity','apiService','LotFactory','PlanFactory',
    function ($http,appsecurity,apiService,LotFactory,PlanFactory) {

    this.uploadDocuments = function ($files, $event, $flow,entity,field) {
        if ( $event.type === 'change' && $event.currentTarget.files.length !== 0 ) {
            var formData = new FormData();
            Array.prototype.forEach.call( $event.currentTarget.files, function ( f ) {
                formData.append( "file", f );
            } )
            sendReq( formData );

        }
        if ( $event.type === 'drop' && $event.dataTransfer.files.length !== 0 ) {
            var formData = new FormData();
            for ( var i = 0; i < $event.dataTransfer.files.length; i++ ) {
                formData.append( "file", $event.dataTransfer.files[i] );
            }
            sendReq( formData );
        }
        function sendReq( formData ) {
            $http( {
                method: 'POST',
                url: apiService.filesUpload,
                data: formData,
                headers: appsecurity.getSecurityHeadersForFileUpload()
            } ).then( function ( response ) {
                for ( var i = 0; i < response.data.files.length; i++ ) {
                    entity[field].push( {
                        file: response.data.files[i].path,
                        full_path: response.data.files[i].full_path,
                        name: response.data.files[i].filename
                    } );
                }

                    var dataObj={}; dataObj[field]=[];
                    entity[field].forEach(function (fl) {
                        dataObj[field].push(fl)
                    })

                    var url;
                    if ((entity instanceof LotFactory)&&entity['id']) {
                        url=apiService.lotsRoute + '/' + entity['id']
                    }
                    if (url) {
                        $http( {
                            method: 'PATCH',
                            data: dataObj,
                            url: url,
                            headers: appsecurity.getSecurityHeaders()
                        } ).then( function ( response ) {
                            if ( response.data && response.data[field] && response.data[field].length ) {
                                entity[field].splice( 0 );
                                response.data[field].forEach( function ( doc ) {
                                    entity[field].push( doc );
                                } )
                            }

                        }, function ( response ) {

                            toastService.errorResponseShow( 'Произошла ошибка при сохранении документа', response );
                        } );
                    }
                    //$scope.lot.patch({lotDoc: $scope.lot.lotDoc});

            }, function ( response ) {
                toastService.errorResponseShow( 'Произошла ошибка при передаче документа', response );
            } )

        }
    }
}])