﻿angular.module( 'isz' ).directive( 'pagePreLoader', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/pagePreLoader/pagePreLoaderTemplate.html',
        controller: ['$scope', 'commonVariables', function ( $scope, commonVariables ) {
            $scope.$watch( 'commonVariables.isLoading', function ( value ) {
                $scope.show = value;
            } );
        }]
    }

}] )