/**
 * Created by pol on 03.03.2016.
 */
angular.module( 'isz' )
    .filter( 'statusFilter', ['commonVariables', function (commonVariables) {
        return function (items) {
            var itemsToReturn=[];
            if (commonVariables.statusFilter.length>0) {
                itemsToReturn = items.filter( function (item) {
                    return commonVariables.statusFilter.indexOf( item.statusId ) !== -1;
                } );
            } else {
                itemsToReturn = items;
            }
            return itemsToReturn;
        }

    }] )