﻿angular.module( 'isz' ).factory( 'Observer', function () {

    function Observe( value ) {
        this.lastValue = value;
        this.handlers = [];
    }

    Observe.prototype = {
        subscribe: function ( fn ) {
            this.handlers.push( fn );
        },
        unsubscribe: function ( fn ) {
            this.handlers = this.handlers.filter( function ( item ) {
                return item !== fn;
            } );
        },
        value: function ( value ) {
            if ( value === undefined ) {
                return this.lastValue;
            }
            this.lastValue = value;
            this.handlers.forEach( function ( fn ) {
                fn( value );
            } );
        }
    }

    return Observe;
} );