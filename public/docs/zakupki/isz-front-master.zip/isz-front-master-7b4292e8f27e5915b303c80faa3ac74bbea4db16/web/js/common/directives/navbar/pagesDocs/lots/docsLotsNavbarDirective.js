﻿angular.module( 'isz' ).directive( 'docsLotsNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/pagesDocs/lots/docsLotsNavbarTemplate.html',
        controller: ['$scope', 'appsecurity', function ( $scope, appsecurity ) {

            if ( !appsecurity.hasOwnProperty( 'currentRole' ) ) {
                appsecurity.getUserInfo().then( function () {
                    $scope.permissions = appsecurity.currentRole.permissions;
                    $scope.expertGroup = appsecurity.currentExpertGroup;
                } );
            } else {
                $scope.permissions = appsecurity.currentRole.permissions;
                $scope.expertGroup = appsecurity.currentExpertGroup;
            }
        }]
    }
}] )