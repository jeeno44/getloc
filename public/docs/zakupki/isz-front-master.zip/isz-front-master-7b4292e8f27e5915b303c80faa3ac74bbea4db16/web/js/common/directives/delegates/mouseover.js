angular.module( 'isz' ).directive( 'delegateMouseover', function () {
    
    
    return {
        restrict: 'A',
        replace: false,
        link: function ( scope, $element, attrs ) {
            var delegateOptions = scope.$eval( attrs.delegateMouseover );

            $element.on( 'mouseover', function ( evt ) {
                if ( angular.element( evt.target ).is( delegateOptions.selector ) ) {
                    delegateOptions.handler( evt );
                }
            } );
        }
    }
} );

angular.module( 'isz' ).directive( 'delegateClick', function () {

    return {
        restrict: 'A',
        replace: false,
        link: function ( scope, $element, attrs ) {
            var delegateOptions = scope.$eval( attrs.delegateClick );

            $element.on( 'click', function ( evt ) {
                var $parent = angular.element( evt.target ),
                    digestIsFired = !!scope.$$phase;

                if ( !digestIsFired ) {
                    scope.$$postDigest( function () { digestIsFired = true; } );
                }

                while ( !$parent.is( $element ) ) {
                    if ( $parent.is( delegateOptions.selector ) ) {
                        delegateOptions.handler( evt );
                        break;
                    }
                    $parent = $parent.parent();
                }

                if ( !digestIsFired ) {
                    scope.$apply();
                }
            } );
        }
    }
} );
