﻿angular.module('isz').directive('navbarCalendar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/navbarCalendar/navbarCalendarTemplate.html',
        controller: ['$scope', 'roleChangedEventService', 'appsecurity', '$location',
            function ($scope, roleChangedEventService, appsecurity, $location) {
                roleChangedEventService.listen(function () {
                    $scope.permissions = appsecurity.currentRole.permissions;
                });
                $scope.buttCalendarClick = function () {
                    $location.path('/calendar');
                }
            }]
    }
}])