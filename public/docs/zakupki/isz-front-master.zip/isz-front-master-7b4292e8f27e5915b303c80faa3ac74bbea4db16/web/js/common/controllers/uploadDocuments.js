﻿angular.module( 'isz' ).controller( 'UploadDocuments', ['$scope', '$http', '$mdDialog', 'appsecurity', 'controlsService', 'apiService', 'lot', 'control','uploadFiles',
    function ( $scope, $http, $mdDialog, appsecurity, controlsService, apiService, lot, control, uploadFiles ) {

        $scope.currentRole = appsecurity.currentRole;
        $scope.userInfo = appsecurity.userInfo;

        $scope.serverUrl = apiService.baseUrl;
        $scope.lotDoc = lot.lotDoc;
        $scope.uploadDocuments  = uploadFiles.uploadDocuments;
        

        $scope.removeDocument = function ( lotDoc ) {
            $http( {
                method: 'DELETE',
                url: apiService.lotDocsUpdate + "/" + lotDoc.id,
                headers: appsecurity.getSecurityHeaders(),
            } ).then( function ( response ) {
                var index = lot.lotDoc.indexOf( lotDoc );
                lot.lotDoc.splice( index, 1 );
            },
            function ( response ) {
                toastService.errorResponseShow('Ошибка при удалении файла. ',response);
            } );
        }

        $scope.send = function () {
            controlsService.executeCommand( control, lot.id );
            $mdDialog.hide( lot.lotDoc );
        }

        $scope.exit = function () {
            $mdDialog.hide( lot.lotDoc );
        };
    }] )