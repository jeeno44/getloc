angular.module( 'isz' ).service( 'appsecurity', ['$location', '$http', '$q', 'apiService', 'UserGroup', 'roleChangedEventService', 'UserRole', 'commonVariables','serverVariables','toastService',
function ( $location, $http, $q, apiService, UserGroup, roleChangedEventService, UserRole, commonVariables,serverVariables,toastService ) {

    var self = this;
    this.userInfo;
    this.commonId;
    this.expertGroups = [];
    this.userRoles = [];

    var qArr=[];

    this.currentExpertGroup;
    this.currentRole;
    this.subsystem = commonVariables.currentSubSystem == 'docs' ? 'fp_documents' : 'fp_planirovanie';

    this.getAccessToken = function () {
        return localStorage["__at__"];
    }

    this.changeCommon = function () {
        UserRole.prototype.common = self.currentExpertGroup.common;
    }

    Visibility.change(function (e, state) {
        if (state == 'visible') {
            if (localStorage["__at__"] !== undefined && sessionStorage["__at__"] !== undefined) {
                if (localStorage["__at__"] != sessionStorage["__at__"]) {
                    toastService.showList('Вы вошли под другим пользователем, Вам необходимо обновить страницу!', true);
                } else {
                    sessionStorage["__at__"] = localStorage["__at__"];
                }
            }
        }
    });

    this.generateExpertiseQueryString = function ( id, params ) {
        return [
            'entytyId=' + id,
            'entytyType=lot',
            'op=' + params.op,
            'id=' + params.id
        ].join( '&' );
    }

    this.getSecurityHeadersExpertise = function () {
        var subsystem = commonVariables.currentSubSystem == 'docs' ? 'fp_documents' : 'fp_planirovanie';
        return {
            "X-Expert-Group-Id": '96c43b82-c019-4db2-a3f1-94145d8bc01c',
            'X-Expert-Role': 'Specialist_depzak',
            //'X-User-Id': '9df288d1-1cc9-4e9d-befb-71c7da229b5e',
            "X-Sub-System": subsystem
        }
    }

    this.getSecurityHeaders = function () {
        var subsystem = commonVariables.currentSubSystem == 'docs' ? 'fp_documents' : 'fp_planirovanie';
        return {
            "X-Access-Token": self.getAccessToken(),
            "X-Expert-Group-Id": self.currentExpertGroup.id,
            "X-Common-Id": self.currentExpertGroup.common.id,
            // "X-Common-Id": self.commonId,
            "X-Sub-System": subsystem,
            'X-Expert-Role': self.currentRole.code,
            //'X-User-Id': self.userInfo.id,
            'content-type': 'application/json; charset=utf-8',
            'Accept': 'application/json;version=1.0'

        }
    }

    this.getSecurityHeadersForFileUpload = function () {
        var subsystem = commonVariables.currentSubSystem == 'docs' ? 'fp_documents' : 'fp_planirovanie';
        return {
            "Content-Type": undefined,
            "X-Access-Token": self.getAccessToken(),
            "X-Expert-Group-Id": self.currentExpertGroup.id,
            // "X-Common-Id": self.commonId,
            "X-Common-Id": self.currentExpertGroup.common.id,
            //"X-Sub-System": "fp_documents",
            "X-Sub-System": subsystem,
            'X-Expert-Role': self.currentRole.code
        }
    }

    this.getSecurityHeadersLotCreation = function () {
        return {
            "X-Access-Token": self.getAccessToken(),
            "X-Expert-Group-Id": self.currentExpertGroup.id,
            "X-Common-Id": self.currentExpertGroup.common.id,
            // "X-Common-Id": self.commonId,
            "X-Sub-System": "fp_planirovanie",
            'X-Expert-Role': self.currentRole.code,
            "X-Form-Id": "front_Lot"
            //"X-User-Id": "1d03f765-fdaa-4b64-9f88-a772eba12e51"
        }
    }

    this.checkAccessToken = function () {
        return localStorage["__at__"] == undefined;
    }

    this.setAccessToken = function ( token ) {
        localStorage["__at__"] = token;
        sessionStorage["__at__"] = token;
    }

    this.getUserInfo = function () {
        var defer = $q.defer();

        if ( angular.isDefined( self.userInfo ) ) {
            defer.resolve();
        } else {
            if (qArr.length==0) {
                apiService.init().then(function(){
                    $http( {
                        method: 'GET',
                        url: apiService.userInfoRoute + '?access_token=' + self.getAccessToken()
                    } ).then( function ( response ) {
                        if (!(response.data.user_info
                            &&response.data.user_info.groupRoles
                            &&response.data.user_info.groupRoles.length
                            &&response.data.groups.length)) {
                            $location.path('/blocking');
                            for (var i=0; i<qArr.length;i++){
                                qArr[i].reject();
                            }
                            qArr.splice(0);
                        } else {
                            response.data.user_info.groupRoles.map( function ( role ) {
                                return new UserGroup( role );
                            }).sort(function(a,b){
                                return a.weight-b.weight;
                            });
                            response.data.user_info.expertGroup.forEach(function(gr){
                                self.expertGroups.push(gr);
                            })
                            self.commonId=response.data.commonId;
                            if ( !self.userRoles.length ) {
                                Array.prototype.push.apply( self.userRoles,
                                    response.data.groups.map( function ( item ) {
                                        return new UserRole( item );
                                    } ) );
                            }
                            //self.userRoles = response.data.groups.map( function ( item ) {
                            //    return new UserRole( item );
                            //} );
                            var localStorageRole = localStorage.getItem( "role" );
                            var expertGroupId = localStorage.getItem( "expertGroup" );

                            for ( var i = 0; i < self.userRoles.length; i++ ) {
                                if ( self.userRoles[i].code == localStorageRole ) {
                                    self.currentRole = self.userRoles[i];
                                    break;
                                }

                                if ( i == self.userRoles.length - 1 ) {
                                    self.currentRole = self.userRoles[0];
                                }
                            }

                            for ( var i = 0; i < self.expertGroups.length; i++ ) {
                                if ( self.expertGroups[i].id == expertGroupId ) {
                                    self.currentExpertGroup = self.expertGroups[i];
                                    break;
                                }

                                if ( i == self.expertGroups.length - 1 ) {
                                    self.currentExpertGroup = self.expertGroups[0];
                                }
                            }
                            commonVariables.currentUserRole=self.currentRole;
                            commonVariables.currentExpertGroup=self.currentExpertGroup;

                            self.changeCommon();
                            roleChangedEventService.roleChangeTrigger(self.currentRole);

                            self.userInfo = response.data.user_info;
                            for (var i=0; i<qArr.length;i++){
                                qArr[i].resolve();
                            }
                            qArr.splice(0);
                        }


                        //defer.resolve();
                    }, function ( response ) {
                        var str='Ошибка получения данных пользователя. ';
                        toastService.errorResponseShow(str,response);
                        for (var i=0; i<qArr.length;i++){
                            qArr[i].reject();
                        }
                        qArr.splice(0);
                        //defer.reject();
                        //console.log( response );
                    } );

                });
            }
            qArr.push(defer);

        }


        return defer.promise;
    }
}] );

