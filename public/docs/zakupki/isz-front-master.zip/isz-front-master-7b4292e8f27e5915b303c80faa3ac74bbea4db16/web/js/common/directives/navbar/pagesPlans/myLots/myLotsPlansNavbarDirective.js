﻿angular.module( 'isz' ).directive( 'plansMylotsNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/pagesPlans/myLots/myLotsPlansNavbarTemplate.html',
        controller: ['$scope', '$location', 'roleChangedEventService', 'appsecurity',
         function ( $scope, $location, roleChangedEventService, appsecurity ) {

             if ( !appsecurity.hasOwnProperty( 'currentRole' ) ) {
                 appsecurity.getUserInfo().then( function () {
                     $scope.permissions = appsecurity.currentRole.permissions;
                     $scope.expertGroup = appsecurity.currentExpertGroup;
                 } );
             } else {
                 $scope.permissions = appsecurity.currentRole.permissions;
                 $scope.expertGroup = appsecurity.currentExpertGroup;
             }
                       
         }]
    }
}] )