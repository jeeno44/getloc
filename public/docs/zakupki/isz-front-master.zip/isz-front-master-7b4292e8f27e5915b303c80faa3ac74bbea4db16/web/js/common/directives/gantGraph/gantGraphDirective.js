angular.module( 'isz' ).directive( 'gantGraph', ['$compile', 'gantView', '$parse', function ( gantView ) {

    return {
        restrict: 'EA',
        link: function ( scope, $graph ) {
            scope.$on( 'forceRedraw', forceRedraw );
            $graph.attr( scope.eventInRange.attr, '' );

            function forceRedraw() {
                var segment = ( 100 / scope.days.length ).toFixed( 4 ),
                    to = ( scope.eventInRange.to || scope.eventInRange.from ) + 1,
                    styles = { marginLeft: '', width: '' };

                $graph.text( scope.eventInRange.title + ' ' + scope.eventInRange.dateDisplay );

                if ( scope.eventInRange.from != 1 ) {
                    styles.marginLeft = segment * ( scope.eventInRange.from - 1 ) + '%';
                }
                if ( to < scope.days.length ) {
                    styles.width = segment * ( to - scope.eventInRange.from ) + '%';
                }

                $graph.css( styles );
            }
        }
    }
}] );