﻿angular.module( 'isz' ).directive( 'leftMenu', function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/leftMenu/leftMenuTemplate.html',
        controller:['$scope','$mdSidenav','commonVariables','appsecurity',function($scope,$mdSidenav,commonVariables,appsecurity){
            $scope.subsystemArray = commonVariables.subsystemArray;
          
            $scope.closeMenu = function(subsystem){
                if (commonVariables.currentSubSystem!==subsystem.name){
                    commonVariables.currentSubSystem=subsystem.name;
                    appsecurity.currentRole.subsystemChanged();
                }
                $mdSidenav('left-sidenav').close();
            }
            // $scope.$on('subsystemCangeEvent',function () {
            //     commonVariables.setMenuItemVisibility();
            // })
        }]
    }

} )