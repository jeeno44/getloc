﻿angular.module( 'isz' ).directive( 'plansLotNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/pagesPlans/lot/lotPlansNavbarTemplate.html',
        controller: ['$scope','$mdDialog', 'appsecurity', function ( $scope,$mdDialog, appsecurity ) {
            if ( !appsecurity.hasOwnProperty( 'currentRole' ) ) {
                appsecurity.getUserInfo().then( function () {
                    $scope.permissions = appsecurity.currentRole.permissions;
                } );
            } else {
                $scope.permissions = appsecurity.currentRole.permissions;
            }

            $scope.openNavigatorModal = function () {
                $mdDialog.show( {
                    templateUrl: '/js/common/templates/navigatorModalTemplate.html',
                    controller: 'navigatorController',
                    clickOutsideToClose: true
                } )
            }
        }]
    }
}] )