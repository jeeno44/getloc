﻿angular.module( 'isz' ).directive( 'plansArchiveNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/pagesPlans/archivePlan/archivesPlansNavbarTemplate.html',
        controller: ['$scope', '$location', 'roleChangedEventService', 'appsecurity',
            function ( $scope, $location, roleChangedEventService, appsecurity ) {
                
                if ( !appsecurity.hasOwnProperty( 'currentRole' ) ) {
                    appsecurity.getUserInfo().then( function () {
                        $scope.permissions = appsecurity.currentRole.permissions;
                        $scope.depZakFlag = appsecurity.currentRole.code.indexOf( 'Rukovoditel_depzak' ) !== -1;
                        $scope.expertGroup = appsecurity.currentExpertGroup;
                    } );
                } else {
                    $scope.permissions = appsecurity.currentRole.permissions;
                    $scope.depZakFlag = appsecurity.currentRole.code.indexOf( 'Rukovoditel_depzak' ) !== -1;
                    $scope.expertGroup = appsecurity.currentExpertGroup;
                }

            }]
    }
}] )