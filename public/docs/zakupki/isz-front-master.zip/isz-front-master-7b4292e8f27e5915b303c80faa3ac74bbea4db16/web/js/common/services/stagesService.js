﻿angular.module('isz').service('stagesService', ['$q', 'Stage', 'commonVariables',
    function ($q, Stage, commonVariables) {
        this.editFlag=false;
        this.getNewStage = function () {
            if (this.editFlag) {
                return this.currentStage;
            }
            var stage = new Stage({});
            stage.startingDate = 1;
            stage.startYear = 1;
            stage.executionType=1;
            return stage;
        }

        this.startingDates = [
            {
                name: "С даты подписания государственного контракта",
                value: 1
            },
            {
                name: "С даты окончания предыдущего этапа",
                value: 2
            },
            {
                name: "С 01/01",
                value: 3
            },
            {
                name: "С даты, определенной пользователем",
                value: 4
            }
        ];
        this.creatingStage = false;
        this.currentStage;

        this.executionTypes = [
            {
                name: "Дата окончания этапа",
                value: 1
            },
            {
                name: "Срок окончания этапа",
                value: 2
            }
        ];

        this.removeStage = function (stage) {
            var defer = $q.defer();
            //var qArr=[];

            //define other stage in currernt year
            var arrCurrYear = commonVariables.currentLot.stages.filter(function (st) {
                return st.startYear === stage.startYear;
            });

            if (!(angular.isArray(arrCurrYear) && arrCurrYear.length > 1)) {
                var arrLaterYear = commonVariables.currentLot.stages.filter(function (st) {
                    return st.startYear > stage.startYear;
                });
                if (angular.isArray(arrLaterYear) && arrLaterYear.length) {

                    arrLaterYear.forEach(function (st) {
                        var ind = commonVariables.currentLot.stages.indexOf(st);
                        if (st.id) {
                            st.remove()
                        }
                        commonVariables.currentLot.stages.splice(ind, 1);
                    })
                }
            }
            var index = commonVariables.currentLot.stages.indexOf(stage);
            if (stage.id) {
                stage.remove().then(function () {
                    commonVariables.currentLot.stages.splice(index, 1);
                    defer.resolve();
                }, function () {
                    defer.reject();
                });
            } else {
                commonVariables.currentLot.stages.splice(index, 1);
                defer.resolve();
            }


            return defer.promise;
        }

    }]);