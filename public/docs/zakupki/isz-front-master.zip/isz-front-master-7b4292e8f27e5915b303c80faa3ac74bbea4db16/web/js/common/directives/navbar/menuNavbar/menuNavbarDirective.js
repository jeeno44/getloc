﻿angular.module( 'isz' ).directive( 'menuNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/menuNavbar/menuNavbarTemplate.html',
        replace: true,
        controller:['$scope','commonVariables',function($scope,commonVariables){
            $scope.subsystemArray = commonVariables.subsystemArray;
        }]
    }


}] )