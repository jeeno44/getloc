﻿angular.module('isz').factory('LotFactory', ['$http', '$q', '$timeout', 'apiService', 'appsecurity', 'CriteriaRatingFactory', 'toastService', 'criteriaHelperService', 'Document', 'commentsService', 'Stage', 'commonVariables', 'NmckJustification',
    function ($http, $q, $timeout, apiService, appsecurity, CriteriaRatingFactory, toastService, criteriaHelperService, Document, commentsService, Stage, commonVariables, NmckJustification) {

        var subEntities = ['expenseType', 'kbkCsr', 'kbkExpenseType', 'kbkKosgu', 'kbkSection', 'kbkFlowDirection', 'marketplace', 'nmckType', 'okei', 'fcpActionTask', 'fcpAction', 'fcpActionSubaction', 'procurementType', 'subProgram', 'subProgramMainAction', 'subProgramAction', 'govProgram', 'fcp', 'criteriaCondition'];
        var mappedEntities = ['okved', 'okpd', 'rateIndicator'];
        // var mappedEntities = ['okved', 'okpd'];

        var qArr = [];

        function LotFactory(opts) {
            this.actualityJustification = opts.actualityJustification || null;
            this.addInfo721744 = opts.addInfo721744 || null;
            this.addReqJustification = opts.addReqJustification || null;
            this.advancePaymentPercentage = opts.advancePaymentPercentage || null;
            this.contractExecution = opts.contractExecution || null;
            this.expectedResults = opts.expectedResults || null;
            this.goals = opts.goals || null;
            this.justificationItemTasks = opts.justificationItemTasks || null;
            //this.kbk = opts.kbk || null;
            this.kbkCsr = opts.kbkCsr || null;
            this.kbkExpenseType = opts.kbkExpenseType || null;
            this.kbkKosgu = opts.kbkKosgu || null;
            this.kbkSection = opts.kbkSection || null;
            this.kbkFlowDirection = opts.kbkFlowDirection || null;

            this.nmckComment = opts.nmckComment || null;
            this.nmckJustification = opts.nmckJustification || null;
            this.nmckJustificationOther = opts.nmckJustificationOther || null;
            this.nmckPrice = opts.nmckPrice || null;
            this.nmckType = opts.nmckType || null;
            this.okei = opts.okei || null;
            this.orderPublication = opts.orderPublication || null;
            this.practicalUsage = opts.practicalUsage || null;
            this.prepaymentBidPercentage = opts.prepaymentBidPercentage || null;
            this.prepaymentContractPercentage = opts.prepaymentContractPercentage || null;
            this.procurementEndDate = opts.procurementEndDate || null;
            this.quantity = opts.quantity || null;
            this.requirement3044 = opts.requirement3044 || null;
            this.requirements1944 = opts.requirements1944 || null;
            this.tasks = opts.tasks || null;
            this.plan = opts.plan;
            this.id = opts.id;
            this.title = opts.title;
            this.procurementStartDate = opts.procurementStartDate;
            this.procResp = opts.procResp;
            this.creationDate = opts.creationDate;
            this.statusId = opts.statusId;
            this.iszNumber = opts.iszNumber || null;

            this.specificationTasks = opts.specificationTasks || null;
            this.specificationContent = opts.specificationContent || null;
            this.specificationDocReq = opts.specificationDocReq || null;
            this.specificationStageContent = opts.specificationStageContent || null;
            this.specificationAcceptConditions = opts.specificationAcceptConditions || null;

            this.marketplace = opts.marketplace || null;
            this.applicationRassmotrDateTime = opts.applicationRassmotrDateTime || null;
            this.applicationRassmotrAddress = opts.applicationRassmotrAddress || null;
            this.application1stpartReviewDateEnd = opts.application1stpartReviewDateEnd || null;
            this.auctionDate = opts.auctionDate || null;
            this.docClarificationStartDate = opts.docClarificationStartDate || null;
            this.docClarificationEndDate = opts.docClarificationEndDate || null;
            this.auctionPriceReduction = opts.auctionPriceReduction || null;
            this.auctionQuantityChange = opts.auctionQuantityChange || null;
            this.auctionQuantityIncrease = opts.auctionQuantityIncrease || null;
            if (opts.isOneSupplier) {
                this.isOneSupplier = "Да";
            } else {
                this.isOneSupplier = "Нет";
            }
            if (opts.isUseCulturalHeritage) {
                this.isUseCulturalHeritage = "Да";
            } else {
                this.isUseCulturalHeritage = "Нет";
            }


            this.getFinYears(opts.financings);
            this.getAction(opts);
            this.formFinancings(opts.financings);

            this.pricing = this.getArraySumm(this.financings || [], 'planPrice');

            this.number = opts.number || '';
            this.stages = [];
            this.rateIndicator = [];
            if (angular.isArray(opts.rateIndicator)) {
                for (var i = 0; i < opts.rateIndicator.length; i++) {
                    this.rateIndicator.push(opts.rateIndicator[i]);
                }
            }

            if (angular.isArray(opts.stages)) {
                for (var i = 0; i < opts.stages.length; i++) {
                    this.stages.push(new Stage(opts.stages[i]));
                }
            } else if (angular.isObject(opts.stages) && !angular.isDate(opts.stages)) {
                this.stages = opts.stages;
            }
            this.nmckJustifications = [];
            if (angular.isArray(opts.nmckJustifications)) {
                for (var i = 0; i < opts.nmckJustifications.length; i++) {
                    this.nmckJustifications.push(new NmckJustification(opts.nmckJustifications[i]));
                }
            }

            if (opts.govProgram) {
                this.govProgram = opts.govProgram;
            }
            this.criteriaRatings = [];
            this.criteriaValues = [];
            this.totalPrice = 0;

            this.expenseType = opts.expenseType || null;
            this.procurementType = opts.procurementType || null;

            this.common = opts.common;
            this.fcpActionTask = opts.fcpActionTask;
            this.fcpAction = opts.fcpAction;
            this.fcpActionSubaction = opts.fcpActionSubaction;
            this.fcp = opts.fcp;
            this.govProgram = opts.govProgram;

            this.subProgram = opts.subProgram;
            this.subProgramMainAction = opts.subProgramMainAction;
            this.subProgramAction = opts.subProgramAction;
            this.haveAllInfo = false;
            this.hasAllInfo = false;
            this.criteriaErrors = [];
            this.controls = [];
            this.criteria = [];
            this.responsibleForNotification=opts.responsibleForNotification;
            this.configreControls(opts.controls || {});
            this.configureCustomControls();

            //1020459
            var docsKD = [];
            var docsORDER = [];
            var docsNOTICE = [];

            if (opts.documentFreshDoc !== undefined) {

                for (var d in opts.documentFreshDoc) {

                    if (opts.documentFreshDoc[d].docType == 'kd') {
                        docsKD.push(opts.documentFreshDoc[d]);
                    }

                    if (opts.documentFreshDoc[d].docType == 'order') {
                        docsORDER.push(opts.documentFreshDoc[d]);
                    }

                    if (opts.documentFreshDoc[d].docType == 'notice') {
                        docsNOTICE.push(opts.documentFreshDoc[d]);
                    }
                }
            }

            this.KDDocument = new Document('kd', 'КД', docsKD);
            this.TaskDocument = new Document('order', 'Задание', docsORDER);
            this.NoticeDocument = new Document('notice', 'Извещение', docsNOTICE);

            this.lotDoc = [];
            if (angular.isArray(opts.lotDoc)) {
                for (var i = 0; i < opts.lotDoc.length; i++) {
                    this.lotDoc.push(opts.lotDoc[i]);
                }
            }

            this.settings;
            this.settingsExists = false;

            this.inEditMode = false;
            this.commentControls = {};
            this.comments = opts.comments;
            this.minRequirements = opts.minRequirements;
            this.okved = [];
            if (opts.okved) {
                for (var i = 0; i < opts.okved.length; i++) {
                    this.okved.push(opts.okved[i]);
                }
            }
            this.okpd = [];

            if (opts.okpd) {
                for (var i = 0; i < opts.okpd.length; i++) {
                    this.okpd.push(opts.okpd[i]);
                }
            }

            this.nmckDoc = [];
            if (angular.isArray(opts.nmckDoc)) {
                for (var i = 0; i < opts.nmckDoc.length; i++) {
                    this.nmckDoc.push(opts.nmckDoc[i]);
                }
            }
            this.externalSource = opts.externalSource;
            if (this.externalSource) {
                if (opts.dfcpId) {
                    this.externalSourceType = {
                        name: 'ДФЦП',
                        id: opts.dfcpId
                    };
                } else {
                    this.externalSourceType = {
                        name: 'ССТП',
                        id: opts.sstpId
                    };
                }
            }
            this.expertData = opts.expertData;
            this.orderTitle = opts.orderTitle || null;
            this.orderNumber = opts.orderNumber || null;
            this.orderDate = opts.orderDate || null;
            this.nks = opts.nks || null;
            this.changedLot = opts.changedLot;
            this.ria = opts.ria || [];
            this.placingInEisDepartment=opts.placingInEisDepartment;
            this.placingInEisEmail=opts.placingInEisEmail;
            this.placingInEisJobTitle=opts.placingInEisJobTitle;
            this.placingInEisPersonFamily=opts.placingInEisPersonFamily;
            this.placingInEisPersonName=opts.placingInEisPersonName;
            this.placingInEisPersonPatronomic=opts.placingInEisPersonPatronomic;
            this.placingInEisPhone=opts.placingInEisPhone;
            this.gz=opts.gz||[];

        }

        LotFactory.prototype = {
            create: function () {

                var lot = this,
                    lotToSend=setupFieldsForCreate(new LotFactory(this)),
                    defer = $q.defer();

                Object.keys(lot).forEach(function(key){
                    if (lot[key]==='Да') {
                        lotToSend[key]=true;
                    }
                    if (lot[key]==='Нет') {
                        lotToSend[key]=false;
                    }
                });


                $http({
                    method: 'POST',
                    headers: appsecurity.getSecurityHeadersLotCreation(),
                    url: apiService.createLot,
                    data: lotToSend
                }).then(function (response) {
                    lot.id = response.data.id;
                    lot.statusId = response.data.statusId;
                    lot.common = response.data.common;
                    defer.resolve();
                }, function (response) {
                    var str = 'Ошибка при создании лота. ';
                    toastService.errorResponseShow(str, response);
                    defer.reject();
                });

                return defer.promise;
            },

            patch: function () {
                var defer = $q.defer();
                if (this.inEditMode) {
                    var lot = this,
                        objToSave = {};

                    if (angular.isObject(arguments[0]) && !angular.isDate(arguments[0])) {
                        objToSave = arguments[0];
                    } else {
                        [].forEach.call(arguments, function (key) {
                            if (angular.isString(key) && key in lot) {

                                if (!angular.isObject(lot[key]) || angular.isDate(lot[key])) {
                                    objToSave[key] = lot[key];
                                } else if (subEntities.indexOf(key)) {
                                    objToSave[key] = lot[key] ? lot[key].id : null;
                                }
                                if (objToSave[key] === 'Да') objToSave[key] = true;
                                if (objToSave[key] === 'Нет') objToSave[key] = false;
                            }
                        });
                    }

                    // Сделано для задачи https://tasks.gblab.ru/browse/ISZAKUPKI-1590
                    if (objToSave.financings && angular.isArray(objToSave.financings)) {
                        objToSave.financings = objToSave.financings.filter(function(financing){
                            console.log(financing);
                            return (Math.ceil(financing.planPrice) !== 0) ;
                        });
                    }

                    if (Object.keys(objToSave).length) {
                        $http({
                            method: 'PATCH',
                            data: objToSave,
                            url: apiService.lotsRoute + '/' + lot.id,
                            headers: appsecurity.getSecurityHeaders()
                        }).then(function (response) {
                            defer.resolve(response);
                            // возврашаем массив из 3 годов
                        }, function (response) {
                            var str = 'Произошла ошибка при обновлении лота. ';
                            toastService.errorResponseShow(str, response);
                            defer.reject();
                            //toastService.show('Произошла ошибка при обновлении лота', true);
                        });
                    }
                } else {
                    defer.resolve();
                }

                return defer.promise;
            },

            put: function (data) {
                var defer = $q.defer();
                $http({
                    method: 'PUT',
                    headers: appsecurity.getSecurityHeaders(),
                    url: apiService.serverRoute + 'lots/' + this.id,
                    data: data//angular.extend( setupFieldsForCreate( new LotFactory( this ) ), data )
                }).then(function (response) {
                    defer.resolve(response);
                    toastService.show('Информация успешно сохранена', false);
                }, function (response) {
                    defer.reject();
                    var str = 'Произошла ошибка при сохранении информации. ';
                    toastService.errorResponseShow(str, response);
                });
                return defer.promise;
            },
            informCardSave: function () {

                var lot = this;
                var objGz=angular.merge({},lot.gz[0]);
                delete objGz.id;

                var objToSend = {
                    docRequirements1444: lot.docRequirements1444,
                    govRequirements: lot.govRequirements,
                    preferences282944: lot.preferences282944,
                    //applicationPostAddress: lot.applicationPostAddress,
                    //applicationcourrieraddress: lot.applicationcourrieraddress,
                    //applicationDateTimeStart: lot.applicationDateTimeStart,
                    //applicationDateTimeEnd: lot.applicationDateTimeEnd,
                    applicationVskrAddress: lot.applicationVskrAddress,
                    applicationVskrDateTime: lot.applicationVskrDateTime,
                    docRequirements: lot.docRequirements,
                    gz:[objGz],
                    applicationPostAddress: lot.applicationPostAddress,
                    applicationDateTimeStart: lot.applicationDateTimeStart,
                    applicationDateTimeEnd: lot.applicationDateTimeEnd,
                    docClarificationStartDate:lot.docClarificationStartDate,
                    docClarificationEndDate:lot.docClarificationEndDate,
                };

                $http({
                    method: 'PATCH',
                    headers: appsecurity.getSecurityHeaders(),
                    url: apiService.serverRoute + 'lots/' + lot.id,
                    data: objToSend
                }).then(function (response) {
                    toastService.show('Информационная карта закупки успешно сохранена', false);
                }, function (response) {
                    var str = 'Произошла ошибка при сохранении информационной карты закупки. ';
                    toastService.errorResponseShow(str, response);
                });
            },
            noticeSave: function () {
                var lot = this;
                var objToSend = {
                    applicationPostAddress: lot.applicationPostAddress,
                    applicationCourrierAddress: lot.applicationCourrierAddress,
                    applicationDateTimeStart: lot.applicationDateTimeStart,
                    applicationDateTimeEnd: lot.applicationDateTimeEnd,
                    applicationVskrAddress: lot.applicationVskrAddress,
                    applicationVskrDateTime: lot.applicationVskrDateTime,
                    applicationRassmotrDateTime: lot.applicationRassmotrDateTime,
                    applicationRassmotrAddress: lot.applicationRassmotrAddress,
                    kdMethodProvision:lot.kdMethodProvision,
                    kdDateTimeStartProvision:lot.kdDateTimeStartProvision,
                    kdDateTimeEndProvision:lot.kdDateTimeEndProvision,
                    kdPlaceProvision:lot.kdPlaceProvision,
                    kdOrderProvision:lot.kdOrderProvision,
                    placingInEisDepartment:lot.placingInEisDepartment,
                    placingInEisEmail:lot.placingInEisEmail,
                    placingInEisJobTitle:lot.placingInEisJobTitle,
                    placingInEisPersonFamily:lot.placingInEisPersonFamily,
                    placingInEisPersonName:lot.placingInEisPersonName,
                    placingInEisPersonPatronomic:lot.placingInEisPersonPatronomic,
                    placingInEisPhone:lot.placingInEisPhone,
                    docClarificationEndDate:lot.docClarificationEndDate

                //responsibleForNotification:lot.responsibleForNotification
                };

                $http({
                    method: 'PATCH',
                    headers: appsecurity.getSecurityHeaders(),
                    url: apiService.serverRoute + 'lots/' + lot.id,
                    data: objToSend
                }).then(function (response) {
                    lot.noticePartShow=lot.getNoticePartShow();
                    toastService.show('Извещение успешно сохранено', false);
                }, function (response) {
                    var str = 'Произошла ошибка при сохранении извещения';
                    toastService.errorResponseShow(str, response);
                });
            },
            fillAllInfo: function () {
                var defer = $q.defer(),
                    lot = this;


                lot.inEditMode = false;

                if (lot.hasAllInfo) {
                    defer.resolve();
                } else {
                    if (qArr.length == 0) {
                        selectRequest(apiService.lotsRoute + '/' + lot.id)
                            .then(function (response) {
                                if (response.status===204){
                                    toastService.show('Нет данных по запросу', false);
                                }
                                lot.hasAllInfo = true;
                                lot.common = response.data.common || null;
                                if (angular.isArray(response.data.lotDoc)) {
                                    for (var i = 0; i < response.data.lotDoc.length; i++) {
                                        lot.lotDoc.push(response.data.lotDoc[i]);
                                    }
                                }

                                if (angular.isArray(response.data.stages)) {
                                    lot.stages = response.data.stages.map(function (stage) {
                                        return new Stage(stage);
                                    })
                                }

                                if (angular.isArray(response.data.okved)) {
                                    for (var i = 0; i < response.data.okved.length; i++) {
                                        lot.okved.unshift(response.data.okved[i]);
                                    }
                                }

                                if (angular.isArray(response.data.okpd)) {

                                    for (var i = 0; i < response.data.okpd.length; i++) {
                                        lot.okpd.unshift(response.data.okpd[i]);
                                    }
                                }

                                if (angular.isArray(response.data.nmckJustifications)) {

                                    lot.nmckJustifications = response.data.nmckJustifications.map(function (nmckJust) {
                                        return new NmckJustification(nmckJust);
                                    })
                                }

                                lot.okei = response.data.okei || null;

                                //lot.kbk = response.data.kbk || null;
                                //if (!lot.id){
                                //    lot.id=response.data.id;
                                //}
                                lot.kbkCsr = response.data.kbkCsr || null;
                                lot.kbkExpenseType = response.data.kbkExpenseType || null;
                                lot.kbkKosgu = response.data.kbkKosgu || null;
                                lot.kbkSection = response.data.kbkSection || null;
                                lot.kbkFlowDirection = response.data.kbkFlowDirection || null;

                                lot.govProgram = response.data.govProgram || null;

                                lot.fcpAction = response.data.fcpAction || null;
                                lot.fcpActionTask = response.data.fcpActionTask || null;
                                lot.fcpActionSubaction = response.data.fcpActionSubaction || null;
                                lot.fcp = response.data.fcp || null;

                                lot.configreControls(response.data.controls || {});


                                lot.goals = response.data.goals || null;
                                //if (!lot.totalPrice) lot.totalPrice = 0;
                                lot.totalPrice = lot.getArraySumm(lot.stages || [], 'financing')
                                lot.tasks = response.data.tasks || null;
                                lot.title = response.data.title || null;

                                lot.actualityJustification = response.data.actualityJustification || null;

                                lot.practicalUsage = response.data.practicalUsage || null;

                                lot.expectedResults = response.data.expectedResults || null;
                                lot.externalSource = response.data.externalSource || null;
                                //lot.externalSource=true;
                                lot.readOnlyFields = {};
                                if (lot.externalSource) {
                                    if (response.data.dfcpId) {
                                        lot.externalSourceType = {
                                            name: 'ДФЦП',
                                            id: response.data.dfcpId
                                        };
                                        for (var i = 0; i < commonVariables.readOnlyFields.dfcp.length; i++) {
                                            lot.readOnlyFields[commonVariables.readOnlyFields.dfcp[i]] = true;
                                        }
                                    } else {
                                        lot.externalSourceType = {
                                            name: 'ССТП',
                                            id: response.data.sstpId
                                        };
                                        for (var i = 0; i < commonVariables.readOnlyFields.sstp.length; i++) {
                                            lot.readOnlyFields[commonVariables.readOnlyFields.sstp[i]] = true;
                                        }
                                    }
                                }

                                lot.justificationItemTasks = response.data.justificationItemTasks || null;

                                lot.requirements1944 = response.data.requirements1944 || null;
                                lot.procurementEndDate = response.data.procurementEndDate || null;
                                lot.procurementStartDate = response.data.procurementStartDate || null;
                                lot.procResp = response.data.procResp;
                                lot.creationDate = response.data.creationDate;
                                lot.addInfo721744 = response.data.addInfo721744 || null;
                                lot.minRequirements = response.data.minRequirements || null;
                                lot.advancePaymentPercentage = response.data.advancePaymentPercentage || 0;
                                lot.expenseType = response.data.expenseType || null;
                                lot.procurementType = response.data.procurementType || null;

                                lot.formFinancings(response.data.financings);
                                lot.pricing = lot.getArraySumm(lot.financings || [], 'planPrice');
                                lot.number = response.data.number || '';


                                if (angular.isArray(response.data.nmckDoc)) {
                                    for (var i = 0; i < response.data.nmckDoc.length; i++) {
                                        var item = response.data.nmckDoc[i];
                                        item.title = item.file.slice(item.file.lastIndexOf('/') + 1);
                                        lot.nmckDoc.push(item);
                                    }
                                }

                                lot.rateIndicator = response.data.rateIndicator || [];

                                lot.nmckType = response.data.nmckType || null;

                                lot.nmckJustification = response.data.nmckJustification || null;

                                lot.nmckJustificationOther = response.data.nmckJustificationOther || null;

                                lot.nmckPrice = response.data.nmckPrice || null;

                                lot.nmckComment = response.data.nmckComment || null;

                                lot.quantity = response.data.quantity || null;

                                lot.nks = response.data.nks || null;

                                if (response.data.requirement3044) {
                                    lot.requirement3044 = "Да";
                                } else {
                                    lot.requirement3044 = "Нет";
                                }
                                ;
                                lot.orderPublication = response.data.orderPublication || null;
                                lot.contractExecution = response.data.contractExecution || null;
                                lot.prepaymentBidPercentage = response.data.prepaymentBidPercentage || null;
                                lot.prepaymentContractPercentage = response.data.prepaymentContractPercentage || null;
                                lot.addReqJustification = response.data.addReqJustification || null;
                                lot.orderTitle = response.data.orderTitle || null;
                                lot.orderNumber = response.data.orderNumber || null;
                                lot.orderDate = response.data.orderDate || null;

                                lot.subProgram = response.data.subProgram || null;
                                lot.subProgramAction = response.data.subProgramAction || null;
                                lot.subProgramMainAction = response.data.subProgramMainAction || null;
                                lot.getAction(response.data);

                                commentsService.fillCommentControls(lot, response.data);

                                lot.docRequirements1444 = response.data.docRequirements1444;
                                lot.docRequirements = response.data.docRequirements;

                                if (lot.docRequirements) {
                                    lot.docRequirementsRadio = true;
                                } else {
                                    lot.docRequirementsRadio = false;
                                }

                                lot.govRequirements = response.data.govRequirements;
                                lot.preferences282944 = response.data.preferences282944;

                                lot.applicationPostAddress = response.data.applicationPostAddress || '';
                                lot.applicationCourrierAddress = response.data.applicationCourrierAddress || '';
                                lot.applicationDateTimeStart = response.data.applicationDateTimeStart;
                                lot.applicationDateTimeEnd = response.data.applicationDateTimeEnd;
                                lot.statusId = response.data.statusId;
                                lot.applicationVskrAddress = response.data.applicationVskrAddress;
                                lot.applicationVskrDateTime = response.data.applicationVskrDateTime;
                                lot.kdMethodProvision = response.data.kdMethodProvision;
                                lot.kdDateTimeStartProvision = response.data.kdDateTimeStartProvision;
                                lot.kdDateTimeEndProvision = response.data.kdDateTimeEndProvision;
                                lot.kdPlaceProvision = response.data.kdPlaceProvision;
                                lot.kdOrderProvision = response.data.kdOrderProvision;


                                for (var i = 0; i < commonVariables.expertsStatuses.length; i++) {
                                    if (lot.statusId === commonVariables.expertsStatuses[i].machineName) {
                                        lot.statusTitle = commonVariables.expertsStatuses[i].title;
                                    }
                                }
                                lot.iszNumber = response.data.iszNumber || null;
                                lot.criteriaMaxValues = response.data.criteriaCondition && response.data.criteriaCondition.id;
                                //lot.criteriaValues = [];
                                //lot.criteriaRatings = [];
                                lot.criteria = response.data.criteria;

                                if (response.data.isOneSupplier) {
                                    lot.isOneSupplier = "Да";
                                } else {
                                    lot.isOneSupplier = "Нет";
                                }
                                if (response.data.isUseCulturalHeritage) {
                                    lot.isUseCulturalHeritage = "Да";
                                } else {
                                    lot.isUseCulturalHeritage = "Нет";
                                }

                                lot.specificationTasks = response.data.specificationTasks || null;
                                lot.specificationContent = response.data.specificationContent || null;
                                lot.specificationDocReq = response.data.specificationDocReq || null;
                                lot.specificationStageContent = response.data.specificationStageContent || null;
                                lot.specificationAcceptConditions = response.data.specificationAcceptConditions || null;

                                lot.marketplace = response.data.marketplace || null;
                                lot.applicationRassmotrDateTime = response.data.applicationRassmotrDateTime || null;
                                lot.applicationRassmotrAddress = response.data.applicationRassmotrAddress || null;
                                lot.application1stpartReviewDateEnd = response.data.application1stpartReviewDateEnd || null;
                                lot.auctionDate = response.data.auctionDate || null;
                                lot.docClarificationStartDate = response.data.docClarificationStartDate || null;
                                lot.docClarificationEndDate = response.data.docClarificationEndDate || null;

                                lot.placingInEisDepartment=response.data.placingInEisDepartment;
                                lot.placingInEisEmail=response.data.placingInEisEmail;
                                lot.placingInEisJobTitle=response.data.placingInEisJobTitle;
                                lot.placingInEisPersonFamily=response.data.placingInEisPersonFamily;
                                lot.placingInEisPersonName=response.data.placingInEisPersonName;
                                lot.placingInEisPersonPatronomic=response.data.placingInEisPersonPatronomic;
                                lot.placingInEisPhone=response.data.placingInEisPhone;


                                lot.costCriteria = [];
                                lot.noncostCriteria = [];
                                lot.criteria = response.data.criteria || [];
                                lot.responsibleForNotification = response.data.responsibleForNotification;

                                if (response.data.auctionPriceReduction) {
                                    lot.auctionPriceReduction = "Да";
                                } else {
                                    lot.auctionPriceReduction = "Нет";
                                }
                                if (response.data.auctionQuantityChange) {
                                    lot.auctionQuantityChange = "Да";
                                } else {
                                    lot.auctionQuantityChange = "Нет";
                                }
                                if (response.data.auctionQuantityIncrease) {
                                    lot.auctionQuantityIncrease = "Да";
                                } else {
                                    lot.auctionQuantityIncrease = "Нет";
                                }
                                lot.expertData = response.data.marketplace || null;

                                if (angular.isArray(response.data.ria)) {
                                    if (response.data.ria.length) {
                                        for (var i = 0; i < response.data.ria.length; i++) {
                                            lot.ria.push(response.data.ria[i]);
                                        }
                                    } else {
                                        lot.ria.push({id: 0, name: null, volume: null});
                                    }

                                }


                                //lot.isOneSupplier = response.data.isOneSupplier || null;
                                //lot.isUseCulturalHeritage = response.data.isUseCulturalHeritage || null;
                                lot.configureCustomControls();
                                lot.limitValuesChanged(true);
                                lot.noticePartShow=lot.getNoticePartShow();
                                var docsKD = [];
                                var docsORDER = [];
                                var docsNOTICE = [];

                                if (response.data.documentFreshDoc !== undefined) {

                                    for (var d in response.data.documentFreshDoc) {

                                        if (response.data.documentFreshDoc[d].docType == 'kd') {
                                            docsKD.push(response.data.documentFreshDoc[d]);
                                        }

                                        if (response.data.documentFreshDoc[d].docType == 'order') {
                                            docsORDER.push(response.data.documentFreshDoc[d]);
                                        }

                                        if (response.data.documentFreshDoc[d].docType == 'notice') {
                                            docsNOTICE.push(response.data.documentFreshDoc[d]);
                                        }
                                    }
                                }

                                lot.KDDocument = new Document('kd', 'КД', docsKD);
                                lot.TaskDocument = new Document('order', 'Задание', docsORDER);
                                lot.NoticeDocument = new Document('notice', 'Извещение', docsNOTICE);
                                if  (angular.isArray(response.data.gz)&&response.data.gz.length){
                                    for (var i=0;i<response.data.gz.length;i++){
                                        lot.gz.push(response.data.gz[i])
                                    }
                                    if (lot.gz[0].gzAgreementExtraName||lot.gz[0].gzAgreementExtraPosition) {
                                        lot.gzAgreementExtraRadio = true;
                                    } else {
                                        lot.gzAgreementExtraRadio = false;
                                    }
                                } else {
                                    lot.gzAgreementExtraRadio = false;
                                }


                                for (var i = 0; i < qArr.length; i++) {
                                    qArr[i].resolve()
                                }
                                qArr.splice(0);
                                //defer.resolve();
                            }, function (response) {
                                var str = 'Произошла ошибка при запросе данных лота с сервера. ';
                                toastService.errorResponseShow(str, response);
                                for (var i = 0; i < qArr.length; i++) {
                                    qArr[i].reject();

                                }
                                qArr.splice(0);
                                //defer.reject();
                            })
                            .then(function () {
                                commonVariables.requestArr.pop();
                            });

                    }
                    qArr.push(defer);
                }
                return defer.promise;
            },
            getCriteriaIndicators: function (force) {
                var defer = $q.defer();
                var lot = this;
                if (force) {
                    lot.criteriaRatings.splice(0);
                }

                if (lot.criteriaRatings.length) {
                    defer.resolve();
                } else {
                    if (lot.currentCondition && lot.currentCondition.criteriaMaxValues && lot.currentCondition.criteriaMaxValues.length) {
                        var qArr = [];
                        for (var i = 0; i < lot.currentCondition.criteriaMaxValues.length; i++) {
                            qArr[i] = lot.getCriteriaByType(lot.currentCondition.criteriaMaxValues[i].criteriaType.id)
                        }
                        $q.all(qArr).then(function () {
                            lot.costCriteria = lot.criteriaRatings.filter(function (crt) {
                                return crt.criteriaType && crt.criteriaType.title && crt.criteriaType.title === 'Стоимостные критерии оценки';
                            });

                            lot.noncostCriteria = lot.criteriaRatings.filter(function (crt) {
                                return crt.criteriaType && crt.criteriaType.title && crt.criteriaType.title === 'Нестоимостные критерии оценки';
                            });
                            defer.resolve;
                        }, function () {
                            defer.reject;
                        })

                    } else {
                        defer.reject;
                    }

                }
                return defer.promise;
            },
            getCriteriaMaxValues: function () {
                var lot = this;

                var defer = $q.defer();
                selectRequest(apiService.criteriaMaxValuesRoute)
                    .then(function (response) {
                        if (angular.isArray(response.data)) {
                            angular.merge(lot.criteriaValues, response.data);
                            //angular.copy(lot.criteriaValues, response.data);
                            //lot.criteriaValues.push(response.data[0]);
                        }

                        lot.limitValuesChanged();
                        defer.resolve();
                    }, function (response) {
                        var str = 'Произошла ошибка при запросе данных лота с сервера. ';
                        toastService.errorResponseShow(str, response);
                        defer.reject();
                    })
                    .then(function () {
                        commonVariables.requestArr.pop();
                    });

                return defer.promise;
            },
            getNoticePartShow: function () {
                var lot=this;
                if (lot.applicationPostAddress) return true;
                if (lot.applicationcourrieraddress) return true;
                if (lot.applicationDateTimeEnd) return true;
                if (lot.applicationVskrAddress) return true;
                if (lot.applicationVskrDateTime) return true;
                if (lot.applicationRassmotrDateTime) return true;
                if (lot.applicationRassmotrAddress) return true;
                if (lot.responsibleForNotification) return true;


                return false;
            },
            getArraySumm: function (arr, key) {
                var mappedPrice = arr.map(function (object) {
                    return key in object
                        ? parseFloat(object[key]) || 0
                        : 0;
                });

                return mappedPrice.reduce(function (fullSum, price) {
                    return fullSum += price;
                }, 0);
            },
            recalculateTotalPrice: function () {
                var self = this;

                //this.totalPrice = this.stages.reduce(function (totalPrice, stage) {
                //    return totalPrice += self.getArraySumm(stage.workTypes, 'financing');
                //}, 0);
                this.totalPrice = self.getArraySumm(this.stages || [], 'financing');
            },
            recalculate: function () {
                this.criteriaRatingsTotalPercents = this.getArraySumm(this.criteriaRatings, 'value');
                criteriaHelperService.validateCriteriaRatings(this);
            },
            constructCriteriaRating: function (criteriaRating) {
                return new CriteriaRatingFactory(criteriaRating || {});
            },
            createCriteriaRating: function (criteriaRating) {
                var defer = $q.defer(),
                    lot = this;

                $http({
                    method: 'POST',
                    url: apiService.criteriaRatingsRoute,
                    data: criteriaRating,
                    headers: appsecurity.getSecurityHeaders()
                }).then(function (response) {
                    criteriaRating.id = response.data.id;
                    lot.criteriaRatings.push(criteriaRating);
                    defer.resolve(criteriaRating);
                }, function (response) {
                    var str = 'Произошла ошибка при создании критерия рейтинга. ';
                    toastService.errorResponseShow(str, response);
                })

                return defer.promise;
            },
            limitValuesChanged: function (skipAutoAssign) {
                var i = this.criteriaValues.length;
                var lot = this;

                while (i--) {
                    if (this.criteriaValues[i].id === this.criteriaMaxValues) {

                        this.criteriaCostMinValue = this.criteriaValues[i].criteriaMaxValues[0].minValue;
                        this.criteriaCostMaxValue = this.criteriaValues[i].criteriaMaxValues[0].maxValue;
                        this.currentCondition = this.criteriaValues[i];
                        this.criteriaNonCostMinValue = this.criteriaValues[i].criteriaMaxValues[1].minValue;
                        this.criteriaNonCostMaxValue = this.criteriaValues[i].criteriaMaxValues[1].maxValue;
                        this.criteriaMinValue = this.criteriaValues[i].minValue;
                        break;
                    }
                }
                if (this.inEditMode) {
                    this.getCriteriaIndicators(true);
                } else {

                    var crts = lot.criteria.filter(function (crt) {
                        return !crt.criteriaIndicator;
                    });
                    crts = crts.map(function (crt) {
                        return {
                            id: crt.criteriaRating.id,
                            title: crt.criteriaRating.title,
                            criteriaType: crt.criteriaRating.criteriaType,
                            criteriaIndicators: crt.criteriaRating.criteriaIndicators,
                            value: crt.value
                        };
                    });
                    var inds = lot.criteria.filter(function (crt) {
                        return crt.criteriaIndicator;
                    });
                    inds.forEach(function (ind) {
                        for (var i = 0; i < crts.length; i++) {
                            if (crts[i].id === ind.criteriaRating.id) {
                                for (var j = 0; j < crts[i].criteriaIndicators.length; j++) {
                                    if (ind.criteriaIndicator.id === crts[i].criteriaIndicators[j].id) {
                                        crts[i].criteriaIndicators[j].content = ind.content;
                                        crts[i].criteriaIndicators[j].indicatorValue = ind.value;
                                        break;
                                    }
                                }
                            }
                        }
                    });

                    [].push.apply(lot.criteriaRatings, crts.map(lot.constructCriteriaRating));

                    var criteriaRatingsTmp = lot.criteriaRatings;
                    lot.criteriaRatings = criteriaRatingsTmp.filter(function (item) {
                        for (var i in criteriaRatingsTmp) {
                            if (criteriaRatingsTmp[i].id == item.id) {
                                console.log(item);
                                return true;
                            }
                        }
                        return false;
                    })


                    lot.costCriteria = lot.criteriaRatings.filter(function (crt) {
                        return crt.criteriaType && crt.criteriaType.title && crt.criteriaType.title === 'Стоимостные критерии оценки';
                    });
                    lot.noncostCriteria = lot.criteriaRatings.filter(function (crt) {
                        return crt.criteriaType && crt.criteriaType.title && crt.criteriaType.title === 'Нестоимостные критерии оценки';
                    });

                }


                //if (i == -1) {
                //    this.criteriaMinValue = 100;
                //}
                //if (this.criteriaRatings.length == 3 && !skipAutoAssign) {
                //    this.criteriaRatings[0].value = this.criteriaMinValue;
                //    this.criteriaRatings[1].value = Math.ceil(( 100 - this.criteriaMinValue ) / 2);
                //    this.criteriaRatings[2].value = Math.floor(( 100 - this.criteriaMinValue ) / 2);
                //}

                criteriaHelperService.validateCriteriaRatings(this);
            },

            //newSaveOrUpdateCriteriaRatings: function () {
            //
            //    this.criteriaRatings.forEach(function (rating) {
            //        if (rating.id != null && rating.id != undefined && rating.id != "") {
            //            rating.update();
            //        } else {
            //            rating.create();
            //        }
            //    });
            //},

            saveCriteriaRatings: function () {
                var criteria = [];
                this.criteriaRatings.forEach(function (crt) {
                    var ob = {
                        criteriaRating: crt.id,
                        value: crt.value
                    };
                    if (ob.value) {
                        criteria.push(ob);
                    }

                });

                var inds = [];
                this.criteriaRatings.forEach(function (crt) {
                    crt.criteriaIndicators.forEach(function (ind) {
                        var ob1 = {
                            criteriaRating: crt.id,
                            criteriaIndicator: ind.id,
                            value: ind.indicatorValue,
                            content: ind.indicatorContent
                        };
                        if (ob1.value) {
                            criteria.push(ob1);
                        }
                    });
                });
                // console.log(JSON.stringify(criteria));
                $http({
                    method: 'PATCH',
                    headers: appsecurity.getSecurityHeaders(),
                    url: apiService.serverRoute + 'lots/' + this.id,
                    data: {
                        criteria: criteria,
                        criteriaCondition: this.criteriaMaxValues
                    }
                }).then(function (response) {
                    toastService.show('Значения успешно сохранены', false);
                }, function (response) {
                    var str = 'Произошла ошибка при сохранении критерия рейтинга. ';
                    toastService.errorResponseShow(str, response);
                });

                //this.criteriaRatings.forEach(function (rating) {
                //    rating.update();
                //});
            },
            saveCriteriaIndicators: function (criteria) {
                $http({
                    method: 'PATCH',
                    headers: appsecurity.getSecurityHeaders(),
                    url: apiService.serverRoute + 'lots/' + this.id,
                    data: {
                        criteria: criteria.criteriaIndicators.map(function (ind) {
                                return {
                                    criteriaRating: criteria.id,
                                    criteriaIndicator: ind.id,
                                    value: ind.indicatorValue,
                                    content: ind.indicatorContent
                                };
                            }
                        )
                    }
                }).then(function (response) {
                    toastService.show('Значения успешно сохранены', false);
                }, function (response) {
                    var str = 'Произошла ошибка при сохранении критерия рейтинга. ';
                    toastService.errorResponseShow(str, response);
                });
            },
            configreControls: function (controls) {
                this.controls.length = 0;
                this.canEdit = false;


                if (!controls.entity) {
                    return;
                }

                for (var i = 0; i < controls.entity.length; i++) {
                    if (controls.entity[i].opName == 'edit') {
                        this.canEdit = true;
                    } else {
                        controls.entity[i].icon = 'keyboard_arrow_right';
                        switch (controls.entity[i].opName) {
                            case 'send_to_completion':
                                controls.entity[i].icon = 'keyboard_arrow_left';
                                break;
                            case 'confirm':
                                controls.entity[i].icon = 'done';
                                break;
                            case 'delete':
                                controls.entity[i].icon = 'delete';
                                break;
                            case 'send_to_approve':
                                controls.entity[i].icon = 'keyboard_arrow_right';
                                break;
                            case 'send_to_monitor':
                                controls.entity[i].icon = 'keyboard_arrow_right';
                                break;
                            case 'confirm_coordinator':
                                controls.entity[i].icon = 'keyboard_arrow_right';
                                break;
                            case 'send_to_coordinator':
                                controls.entity[i].icon = 'keyboard_arrow_right';
                                break;
                            case 'delegate':
                                controls.entity[i].icon = 'person';
                                break;
                            case 'posted_coordinator':
                                controls.entity[i].icon = 'publish';
                                controls.entity[i].value = 'Разместить в ЕИС';
                                break;
                            case 'make_data_notice':
                                controls.entity[i].icon = 'note_add';
                                controls.entity[i].value = 'Внести данные по извещению';
                                break;
                            case 'edit_data_notice':
                                controls.entity[i].icon = 'note_add';
                                controls.entity[i].value = 'Изменить данные по извещению';
                                break;
                            default:
                                controls.entity[i].icon = 'keyboard_arrow_left';
                                break;
                        }
                        this.controls.unshift(controls.entity[i]);
                    }
                }
            },
            formFinancings: function (financings) {
                if (!angular.isArray(financings)) financings = [];

                this.financings = [];

                for (var i = 0; i < 3; i++) {
                    this.financings.push(
                        financings[i]
                        || {
                            advancePaymentPercentage: undefined,
                            contractPrice: undefined,
                            contractQuantity: undefined,
                            factPrice: undefined,
                            factQuantity: undefined,
                            planPrice: undefined,
                            planQuantity: undefined,
                            publicationPrice: undefined,
                            publicationQuantity: undefined,
                            relYear: 1 + i,
                            year: new Date().getFullYear() + i
                        });
                }

            },
            getFinYears: function (finnacings) {
                this.finYears = '';
                if (angular.isArray(finnacings)) {
                    var yearArrs = finnacings.map(function (fin) {
                        return (fin.year) * 1;
                    });
                    var min = yearArrs.reduce(function (x, y) {
                        return (x < y) ? x : y;
                    }, yearArrs[0]);
                    var max = yearArrs.reduce(function (x, y) {
                        return (x > y) ? x : y;
                    }, 0);

                    if (max == min) {
                        this.finYears = max;
                    } else {
                        this.finYears = min + '-' + max;
                    }
                }
            },
            getAction: function (opts) {

                if (opts.fcpAction) {
                    this.action = opts.fcpAction;
                    return;
                }
                if (opts.fcpActionTask) {
                    this.action = opts.fcpActionTask;
                    return;
                }
                if (opts.subProgramAction) {
                    this.action = opts.subProgramAction;
                    return;
                }
                if (opts.subProgramMainAction) {
                    this.action = opts.subProgramMainAction;
                    return;
                }
                if (opts.subProgramActionTask) {
                    this.action = opts.subProgramActionTask;
                    return;
                }
                this.action = null;
            },
            configureCustomControls: function () {
                this.customControls = [];

                if (commonVariables.currentSubSystem == 'docs') {
                    this.customControls.push({
                        value: 'Скачать Документы',
                        name: 'download_documents',
                        icon: 'file_download'
                    });
                    // if (commonVariables.currentExpertGroup.expertRoleName === 'monitor' && this.statusId === 'on_agreement_monitor') {
                    //    //if (commonVariables.currentExpertGroup.expertRoleName==='monitor') {
                    //    this.noteControlShow = true;
                    //    this.customControls.push({
                    //        value: 'Внести данные по извещению',
                    //        name: 'make_data_notice',
                    //        icon: 'note_add'
                    //    });
                    // }
                }

            },
            toggleEditMode: function () {
                this.inEditMode = !this.inEditMode;
            },
            getFormsSettings: function () {

                var defer = $q.defer();

                if (this.settingsExists) {
                    defer.resolve();
                } else {
                    var lot = this;
                    this.settingsExists = true;
                    selectRequest(apiService.formsRoute + lot.id)
                        .then(function (response) {

                            $http({
                                method: 'GET',
                                url: '/formSettingsCommon.json'
                            }).then(function (response2) {
                                lot.settings = response2.data[response.data.edit.formId];
                                if (!lot.settings) {
                                    lot.settings = response2.data["FCPRO-openconcurs"];
                                }
                                console.log(lot.settings, response.data.edit.formId);
                                //lot.settings = response2.data["FCPRO1-eauction"]
                                defer.resolve();
                            }, function (response2) {
                                var str = 'Произошла ошибка при запросе отображения лота. ';
                                toastService.errorResponseShow(str, response2);
                                defer.reject();
                            });

                        }, function (response) {
                            toastService.show('Произошла ошибка при запросе отображения лота', true);
                            defer.reject();
                        })
                        .then(function () {
                            commonVariables.requestArr.pop();
                        });
                }

                return defer.promise;
            },

            getCriteriaByType: function (type) {
                var defer = $q.defer();
                var lot = this;
                selectRequest(apiService.criteriaRatingsRoute + '?filters[criteriaType][]=' + type)
                    .then(function (response) {
                        if (angular.isArray(response.data)) {
                            [].push.apply(lot.criteriaRatings, response.data.map(lot.constructCriteriaRating));
                        }

                        //lot.criteriaRatingsTotalPercents = 0;
                        //criteriaHelperService.validateCriteriaRatings(lot);
                        defer.resolve();
                    }, function (response) {
                        var str = 'Произошла ошибка при запросе данных лота с сервера. ';
                        toastService.errorResponseShow(str, response);
                        defer.resolve();
                    })
                    .then(function () {
                        commonVariables.requestArr.pop();
                    });
                return defer.promise;
            }


        }

        function setupFieldsForCreate(lot) {

            subEntities.forEach(function (subEntity) {
                if (lot[subEntity]) lot[subEntity] = lot[subEntity].id;
            });

            mappedEntities.forEach(function (mappedEntity) {
                if (lot[mappedEntity].length) {

                    if (mappedEntity == "rateIndicator") {
                        lot[mappedEntity] = lot[mappedEntity].map(function (entity) {
                            return {rateIndicator: entity.rateIndicator.id};
                        })
                    } else {
                        lot[mappedEntity] = lot[mappedEntity].map(function (entity) {
                            return {id: entity.id};
                        })
                    }

                } else {
                    lot[mappedEntity] = null;
                }
            });

            for (var i = 0; i < lot.stages.length; i++) {

                var workTypes = lot.stages[i].workTypes;

                if (workTypes.length > 0) {
                    lot.stages[i].workTypes = {
                        labour: [],
                        good: []
                    };

                    for (var a = 0; a < workTypes.length; a++) {
                        lot.stages[i].workTypes[workTypes[a].type].push(workTypes[a]);
                    }
                }
            }

            // Сделано для задачи https://tasks.gblab.ru/browse/ISZAKUPKI-1590
            lot.financings = lot.financings.filter(function(financing){
                return (Math.ceil(financing.planPrice) !== 0) ;
            });


            console.log(lot.rateIndicator);


            return lot;
        }

        function selectRequest(url) {
            // var defer = $q.defer();
            // $http({
            //     method: 'GET',
            //     headers: appsecurity.getSecurityHeaders(),
            //     url: url
            // }).then(function (response) {
            //         defer.resolve(response);
            //     }, function () {
            //         $http({
            //             method: 'GET',
            //             headers: appsecurity.getSecurityHeaders(),
            //             url: url
            //         }).then(function (response) {
            //             defer.resolve(response);
            //         }, function (response) {
            //             defer.reject(response);
            //         })
            //     }
            // )
            // return defer.promise;
            function reqWrapper() {
                var defer = $q.defer();
                $http({
                    method: 'GET',
                    headers: appsecurity.getSecurityHeaders(),
                    url: url
                }).then(function (response) {
                        defer.resolve(response);
                    }, function (response) {
                        defer.reject(response);

                    }
                )
                return defer.promise;

            }
            var req=reqWrapper;
            commonVariables.requestArr.push(req);
            return req();
        }


        return LotFactory;
    }]);