/**
 * Created by pol on 17.08.2015.
 */
angular.module('isz')
    .directive('textExpand', ['$timeout', '$compile', function ($timeout, $compile) {
        return {
            restrict: 'E',
            scope: {
                inputValue: '=',

            },
            templateUrl: '/js/common/directives/textExpand/template/textExpandTemplate.html',
            link: function (scope, element, $attrs) {
                var elHeight = $attrs.hasOwnProperty('lines') ? Number($attrs.lines) : 4;
                scope.child = $attrs.hasOwnProperty('child');
                scope.moreFlag = true;
                scope.lessFlag = true;
                scope.lessValue = "";
                scope.originalValue = '';
                scope.isChanged = false;
                scope.isVisible = false;
                scope.ttt = {};
                var el = element[0].querySelector('.tr-text');

                el.style.overflow = 'hidden';
                function ee(newValue){
                    scope.isVisible = !newValue;

                    if (!newValue && scope.isChanged) {
                        lineCounter();
                    }

                }

                scope.$parent.$watch('creating||lot.inEditMode', ee);
                //scope.$parent.$parent.$watch('creating||lot.inEditMode', ee);

                //lineCounter();
                //el.style.maxHeight = ( elHeight + ( elHeight - 1 ) * 0.35 ) + 'em';
                scope.$watch('inputValue', function (newVal, oldVal) {
                    if (newVal != oldVal) {
                        scope.isChanged = true;
                    } else {
                        scope.isChanged = false;
                    }
                    if (scope.isVisible && scope.isChanged) {
                        lineCounter();
                    }
                });
                function ee2(){
                    if (scope.isVisible && scope.isChanged) {
                        lineCounter();
                    }
                }
                scope.$on('lotTabClicked', ee2);
                //scope.$parent.$on('lotTabClicked', ee2);

                scope.originalText = "";


                function lineCounter() {

                    scope.moreFlag = true;
                    scope.lessFlag = true;
                    $timeout(function () {
                        var lessDiv = false;
                        if (scope.inputValue != "" && el.textContent != "" && el.getBoundingClientRect().height > 0) {

                            var comStyles = window.getComputedStyle(el);
                            var lessEl = element[0].querySelector('.less-text');

                            var lines = 0;
                            var wordsArr = el.textContent.split(' ');

                            lessEl.innerHTML = "";
                            for (var i = 0; i < wordsArr.length; i++) {

                                lessEl.innerHTML += (wordsArr[i] + " ");
                                if (lessEl.getBoundingClientRect().height > 0 && lessEl.getBoundingClientRect().height > (parseFloat(comStyles.lineHeight) * elHeight)) {
                                    var sumEnd = '';

                                    var j = i;
                                    while (sumEnd.length < 15) {
                                        sumEnd += (wordsArr[j] + " ");
                                        j--;
                                    }
                                    lessEl.textContent = lessEl.textContent.slice(0, lessEl.textContent.length - sumEnd.length - 1) + '...';
                                    angular.element(el).append($compile('<span class="text-expand-span" ng-click="lessClick()"> Свернуть</span>')(scope));
                                    angular.element(lessEl).append($compile('<span class="text-expand-span" ng-click="moreClick()"> Развернуть</span>')(scope));
                                    scope.moreFlag = true;
                                    scope.lessFlag = false;
                                    lessDiv = true;

                                    break;
                                }
                            }
                            scope.isChanged = false;

                        }
                        if (!lessDiv) {
                            scope.moreClick();
                        }
                    }, 100);

                }


                scope.moreClick = function () {
                    //el.style.maxHeight = 'none';
                    scope.moreFlag = false;
                    scope.lessFlag = true;
                }
                scope.lessClick = function () {
                    //el.style.maxHeight = ( elHeight + ( elHeight - 1 ) * 0.35 ) + 'em';
                    scope.moreFlag = true;
                    scope.lessFlag = false;
                }
            },
            replace: true

        }
    }]);