﻿angular.module( 'isz' ).service( 'navigationService', ['commonVariables',
    function ( commonVariables ) {

        this.rememberUrl = function ( url ) {
            var navHistory = localStorage.navHistory ? JSON.parse( localStorage.navHistory ) : [];
            navHistory.unshift( url );
            localStorage.navHistory = JSON.stringify( navHistory );
        }

        this.getPreviousUrl = function () {
            var navHistory = JSON.parse( localStorage.navHistory );
            if ( navHistory.length > 1 ) {
                var urlToReturn = navHistory[1];
                navHistory.splice( 0, 2 );
                return urlToReturn !== '/oauth2/authorize' ? urlToReturn : '/' + commonVariables.currentSubSystem;
            }

            return '/' + commonVariables.currentSubSystem;
        }

        this.clearAll = function () {
            localStorage.removeItem( 'navHistory' );
        }
    }] );