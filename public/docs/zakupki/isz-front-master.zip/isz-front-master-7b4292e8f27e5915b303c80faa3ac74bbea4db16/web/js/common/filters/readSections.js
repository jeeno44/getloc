angular.module( 'isz' ).filter( 'readSections', ['appsecurity', function ( appsecurity ) {
    return function ( lots ) {
        if (angular.isArray(lots)){
            return appsecurity.currentRole.isAllowReadAllSections()
                ? lots
                : lots.filter( function ( lot ) {
                return appsecurity.currentRole.isAllowReadSectionByGroup( lot.common );
            } );
        } else {
            return lots;
        }
    }
}] );