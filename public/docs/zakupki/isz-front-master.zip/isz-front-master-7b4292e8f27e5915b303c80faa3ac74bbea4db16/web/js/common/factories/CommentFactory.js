﻿angular.module( 'isz' ).factory( 'CommentFactory', [function () {

    function Comment( opts ) {
        this.value = opts.value;

        this.id = opts.id;
        this.comment = opts.comment;
        this.tempComment = '';
        this.author = opts.author;

        if ( opts.time_created ) {
            this.timeCreated = moment( opts.time_created).format( 'DD.MM.YYYY HH:mm' );
        }
        if ( opts.author ) {
            this.initials = this.getInitials();
        }
    }

    Comment.prototype = {
        resetComment: function () {
            this.tempComment = this.comment;
        },
        getInitials: function () {
            var namesArr = this.author.name.split( ' ' );
            var initials = '';
            if ( namesArr[0] ) {
                initials += namesArr[0].charAt( 0 ) + '. ';
            }
            if ( namesArr[1] ) {
                initials += namesArr[1].charAt( 0 ) + '. ';
            }
            return initials;
        }
    };

    return Comment;
}] )