﻿angular.module( 'isz' )
.filter( 'localCurrency', [function () {
    return function ( input, symbol ) {
            if ( !input || typeof input !=='number' ) {
                return input;
            }
        input=input/1000;
        /**
         * Number.prototype.format(decimals,fixed,integer)
         *
         * @param  decimals: length of decimal
         * @param  integer: length of sections
         * @param  fixed:  auto length of decimal
         */
        Number.prototype.format = function(decimals,fixed,integer) {
            (function(RGX) {
                numberFloatPart = function(num) {
                    return +(+num).toExponential().replace(RGX, function(m, neg, num, dot, offset) {
                        var zeroes = Array(Math.abs(offset) + 2).join('0');
                        num = (zeroes + num + (dot ? '' : '.') + zeroes).split('.');
                        var t=neg + '.' + num.join('');
                        return +(t.slice(+offset + num[0].length));
                    });
                };
            })(/(-?)(\d+(\.?)\d*)e(.+)/);

            var floatPart = numberFloatPart(this);

            if(floatPart >0 && decimals ==0)
            {
                if(fixed)
                    floatPart = numberFloatPart(this).toFixed(fixed);
                decimals =floatPart.toString().length -2;
            }

            var re = '\\d(?=(\\d{' + (integer || 3) + '})+' + (decimals > 0 ? '\\.' : '$') + ')';
            return this.toFixed(Math.max(0, ~~decimals)).replace(new RegExp(re, 'g'), '$& ');
        };

        // input=Math.round(input*100)/100;
        // var floatPart=input%1000;
        // var intPart=(input-floatPart)/1000;
        // floatPart=Math.round(floatPart*100);
        // //input = ('' + Math.round(input/1000)).split('').reverse();
        // intPart = ('' +intPart).split('').reverse();
        // var output = [];
        // for ( var i = 0; i <intPart.length; i++ ) {
        //
        //     if ( (i %3) ===0 && i!==0) {
        //         output.push( ' ' );
        //     }
        //     output.push( intPart[i] );
        // }
        // if ( !symbol ) {
        //     symbol = '';
        // }
        // floatPart=floatPart+'';
        //
        // //if (floatPart.indexOf('.')>-1){
        // //    floatPart=floatPart.splice(floatPart.indexOf('.'),1);
        // //}
        // if (floatPart.length<5){
        //     for (var i=floatPart.length;i<5;i++){
        //         floatPart+='0';
        //     }
        // }
        //
        // output= output.reverse().join('') + symbol+'.'+floatPart;
        return input.format(5);
    }
}] );