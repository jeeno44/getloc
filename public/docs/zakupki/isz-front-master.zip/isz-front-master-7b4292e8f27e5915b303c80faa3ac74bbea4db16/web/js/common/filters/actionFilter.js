﻿angular.module( 'isz' )
    .filter( 'actionFilter', ['commonVariables', function (commonVariables) {
        return function (items) {
            var itemsToReturn=[];
            if (commonVariables.fcpActionsFilter.length>0) {
                itemsToReturn = items.filter( function (item) {
                    return commonVariables.fcpActionsFilter.indexOf( item.fcpAction.id ) !== -1;
                } );
            } else {
                itemsToReturn = items;
            }
            return itemsToReturn;
        }

    }] )