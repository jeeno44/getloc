﻿angular.module( 'isz' ).factory( 'CommentControl', ['$http', '$q', 'appsecurity', 'toastService', 'CommentFactory', 'apiService',
    function ( $http, $q, appsecurity, toastService, CommentFactory, apiService ) {

        function CommentControl( opts ) {
            this.fieldId = opts.fieldId;
            this.expertiseUser = opts.expertiseUser;
            this.show = opts.show||true;
            this.url = opts.url;

            this.comments = []
        }
        CommentControl.prototype = {
            create: function ( comment ) {
                var control = this,defer=$q.defer();
                $http( {
                    method: 'POST',
                    url: apiService.baseUrl + this.url,
                    headers: appsecurity.getSecurityHeaders(),
                    data: {
                        fieldId: control.fieldId,
                        expertiseUser: control.expertiseUser,
                        value: '',
                        comment: comment.comment,
                        show: control.show
                    }
                } ).then( function ( response ) {
                    comment.id = response.data.id;
                    comment.timeCreated = moment( response.data.timeCreated ).format( 'DD.MM.YYYY HH:mm' );
                    appsecurity.getUserInfo().then( function () {
                        comment.author = appsecurity.userInfo;
                        comment.author.userId = comment.author.id;
                        comment.author.userRole=appsecurity.currentRole.code;
                        comment.initials = comment.getInitials();
                        control.comments.unshift( comment );
                       
                        defer.resolve();
                    });
                }, function ( response ) {
                    var str='Не удалось создать комментарий. ';
                    toastService.errorResponseShow(str,response);
                    defer.resolve();
                } );
                return defer.promise;
            },
            update: function ( comment ) {
                var control = this;
                $http( {
                    method: 'PUT',
                    url: apiService.baseUrl + this.url + '/' + comment.id,
                    headers: appsecurity.getSecurityHeaders(),
                    data: {
                        fieldId: control.fieldId,
                        expertiseUser: control.expertiseUser,
                        value: '',
                        comment: comment.comment,
                        show: control.show
                    }
                } ).then( function ( response ) {
                    toastService.show( 'Комментарий обновлен', false );
                }, function ( response ) {
                    var str='Не удалось обновить комментарий. ';
                    toastService.errorResponseShow(str,response);
                } )
            },
            addComments: function ( comments ) {
                for ( var i = 0; i < comments.length; i++ ) {
                    this.comments.unshift( new CommentFactory( comments[i] ) );
                }
                if (this.comments.length){
                    this.comments.sort(function (a,b){
                        var a_created= moment(a.timeCreated, 'DD.MM.YYYY HH:mm' ).toDate(),
                            b_created= moment(b.timeCreated, 'DD.MM.YYYY HH:mm' ).toDate();
                        if (a_created<b_created){
                            return 1;
                        } else if (a_created> b_created){
                            return -1;
                        } else {
                            return 0;
                        }
                    })
                }
            }
        };
        return CommentControl;
    }] )