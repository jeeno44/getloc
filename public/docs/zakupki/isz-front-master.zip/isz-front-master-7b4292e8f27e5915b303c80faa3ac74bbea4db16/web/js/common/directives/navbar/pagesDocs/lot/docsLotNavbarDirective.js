﻿angular.module( 'isz' ).directive( 'docsLotNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/pagesDocs/lot/docsLotNavbarTemplate.html',
        controller: ['$scope', '$mdDialog', 'commonVariables', 'appsecurity',
            function ( $scope, $mdDialog, commonVariables, appsecurity ) {
                $scope.commonVariables = commonVariables;
                $scope.expertGroup = appsecurity.currentExpertGroup;
                if ( !appsecurity.hasOwnProperty( 'currentRole' ) ) {
                    appsecurity.getUserInfo().then( function () {
                        $scope.permissions = appsecurity.currentRole.permissions;
                    } );
                } else {
                    $scope.permissions = appsecurity.currentRole.permissions;
                }
                $scope.openDocumentsModal = function () {
                    $mdDialog.show( {
                        templateUrl: '/js/documents/templates/downloadDocumentsModal.html',
                        controller: 'DownloadDocuments',
                        locals: {
                            lotId: commonVariables.currentLot.id
                        }
                    } )
                }
                $scope.openNoticeModal = function(){
                   commonVariables.canOpenNotice=true;
                };

                $scope.openNavigatorModal = function () {
                    $mdDialog.show( {
                        templateUrl: '/js/common/templates/navigatorModalTemplate.html',
                        controller: 'navigatorController',
                        clickOutsideToClose: true

                    } )
                }
            }]
    }
}] )