/**
 * Created by pol on 10.11.2015.
 */
angular.module( 'isz' ).directive( 'docsMylotsNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/pagesDocs/myLots/docsMyLotsNavbarTemplate.html',
        controller: ['$scope', 'appsecurity', function ( $scope, appsecurity ) {
            $scope.expertGroup = appsecurity.currentExpertGroup;
            if ( !appsecurity.hasOwnProperty( 'currentRole' ) ) {
                appsecurity.getUserInfo().then( function () {
                    $scope.permissions = appsecurity.currentRole.permissions;
                    $scope.expertGroup = appsecurity.currentExpertGroup;
                } );
            } else {
                $scope.permissions = appsecurity.currentRole.permissions;
                $scope.expertGroup = appsecurity.currentExpertGroup;
            }
        }]
    }
}] )