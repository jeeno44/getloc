﻿angular.module( 'mdlInit', [] )
.directive( 'mdlLayout', ['$timeout', '$rootScope', function ( $timeout, $rootScope ) {
    return {
        restrict: 'A',
        link: {
            post: function ( scope, tElement ) {
                $timeout( function () {
                    tElement[0].removeAttribute( 'mdl-layout' );
                    new window.MaterialLayout( tElement[0] );
                }, 100 );
            }
          

        }
    }
}] )
.directive( 'mdlRadio', [function () {
    return {
        restrict: 'A',
        link: {
            post:function ( scope, tElement ) {
                $timeout(function(){
                    tElement[0].removeAttribute( 'mdl-radio' );
                    new window.MaterialRadio( tElement[0] );
                },0)

            }
        }

    }
}] )
.directive( 'mdlTextfield', [function () {
    return {
        restrict: 'A',
        link: function ( scope, tElement ) {
            //tElement[0].removeAttribute( 'mdl-textfield' );
            new window.MaterialTextfield( tElement[0] );
        }
    }
}] )

;