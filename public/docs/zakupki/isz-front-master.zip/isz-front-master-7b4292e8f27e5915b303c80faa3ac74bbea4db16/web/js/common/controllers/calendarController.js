﻿angular.module( 'isz' ).controller( 'Calendar', ['$scope', '$http','$q', 'appsecurity', 'calendarService', 'commonVariables', 'gantView', 'translate', 'toastService','apiService',
    function ( $scope, $http,$q, appsecurity, calendarService, commonVariables, gantView, translate, toastService,apiService ) {

        var $calendar = angular.element( document.querySelector( '.calendar' ) ),
            eventsSelectCompressed = false;
        commonVariables.enterInLotTimeStamp=null;
        function Month( index ) {
            this.name = moment( '1970/' + index + '/1' ).format( 'MMMM' );
            this.index = index;
            this.events = [];
        }

        Month.prototype.addEvent = function ( eventType, statusEn ) {
            var i = this.events.length;

            while ( i-- ) {
                if ( this.events[i].type == eventType ) {
                    this.events[i].count += 1;

                    this.events[i].countByStatuses[statusEn]
                        ? this.events[i].countByStatuses[statusEn] += 1
                        : this.events[i].countByStatuses[statusEn] = 1;

                    break;
                }
            }

            if ( i == -1 ) {
                var monthEvents = {
                    count: 1,
                    title: translate.calendar.events( 'ru', eventType ),
                    type: eventType,
                    countByStatuses: {}
                };
                monthEvents.countByStatuses[statusEn] = 1;
                this.events.push( monthEvents );
            }
        }

        function fillMonths() {
            $scope.months = [];
            for ( var i = 0; i < 12; $scope.months.push( new Month( ++i ) ) );
        }


        $scope.noEventsMessage = 'В этом диапазоне нет событий';

        $scope.gantView = false;
        $scope.toggleGantView = function () {
            $scope.gantView = !$scope.gantView;
            $scope.calendarViewTypeChanged();
            $calendar.toggleClass( 'gant' ).toggleClass( 'normal' );
        }

        $scope.calendarViewTypes = ['День', 'Неделя', 'Месяц', 'Год'];
        $scope.dateViewIndex = 1;

        $scope.statuses = [];
        $scope.selectedStatuses = [];
        $scope.selectedEvents = [];


        $scope.redraw = function () {
            $scope.$$postDigest( function () {
                $scope.$broadcast( 'forceRedraw' );
            } );
        }

        $scope.shiftDate = function ( shift ) {
            calendarService.changeDate( $scope.calendarViewTypes[$scope.dateViewIndex], shift );
            $scope.calendarViewTypeChanged();
        }


        $scope.showToast = function ( evt ) {
            var target = angular.element( evt.target ),
                originWidth = target.css( 'width' ),
                diff = target[0].scrollWidth - parseInt( getComputedStyle( target[0] ).width );

            if ( diff > 1 ) {
                target.css( {
                    'width': target[0].scrollWidth + 10 + 'px',
                    'transform': 'translateX(' + ( -diff / 2 - 5 ) + 'px)'
                } )

                target.one( 'mouseleave', function () {
                    target.css( {
                        'width': originWidth,
                        'transform': ''
                    } );
                } )
            }
        }

        $scope.calendarViewTypeChanged = function () {
            var timeRange = $scope.calendarViewTypes[$scope.dateViewIndex];

            $scope.dateDisplay = calendarService.getDateDisplay( timeRange );
            $scope.isGeneralizedView = $scope.dateViewIndex % 3 == 0;

            $calendar.attr( 'time-range', timeRange );

            switch ( $scope.dateViewIndex ) {
                case 0:
                    $scope.gantLotsFiltered = gantView.getFilteredGantLots( calendarService.getDaysRange( timeRange ), timeRange );
                    $scope.noEvents = !$scope.gantLotsFiltered.length;
                    break;
                case 1: //throw
                case 2:
                    $scope.days = calendarService.getDaysRange( timeRange, $scope.gantView );
                    if ( $scope.gantView ) {
                        $scope.gantLotsFiltered = gantView.getFilteredGantLots( $scope.days, timeRange );
                        $scope.noEvents = !$scope.gantLotsFiltered.length;
                    } else {
                        calendarService.associateEvents( $scope.days );
                        $scope.noEvents = !$scope.days.some( function ( day ) { return angular.isDefined( day.events ); } );
                    }
                    $scope.redraw();
                    break;
                case 3:
                    var year = calendarService.getObservedDate().year() - 0;
                    $scope.months.forEach( function ( month ) {
                        month.events.length = 0;
                        gantView.fillMonthEvents( year, month );
                    } );
            }

            changeEventsSelect();
        }

        $scope.detalize = function ( event ) {
            var dateType, date, scope;

            if ( $scope.dateViewIndex == 3 ) {
                scope = angular.element( event.target ).scope();
                dateType = 'Месяц';
                date = scope.month.index;
            } else {
                scope = angular.element( event.target.parentNode ).scope();
                dateType = 'День';
                date = scope.day ? scope.day.date : moment();
            }

            $scope.dateViewIndex = $scope.calendarViewTypes.indexOf( dateType );
            calendarService.changeDateTo( dateType, date );
            $scope.calendarViewTypeChanged();
        }
        appsecurity.getUserInfo().then( function () {
            fillMonths();
            getCalendarInfo();
        }, function () {
            //toastService.show( 'Ошибка получения данных пользователя', true );
        } );

        $scope.shiftDate( 0 );

        function changeEventsSelect() {
            var prevCompressValue = eventsSelectCompressed;

            eventsSelectCompressed = Boolean( $scope.dateViewIndex == 0 || ( $scope.gantView && $scope.dateViewIndex != 3 ) );

            $scope.events = eventsSelectCompressed
                ? ['Создание', 'Контракт', 'Закупки', 'Экспертиза'] // for day, week gant, month gant
                : ['Создание', 'Контракт', 'Начало закупок', 'Конец закупок', 'Начало экспертизы', 'Окончание экспертизы'];

            if ( prevCompressValue !== eventsSelectCompressed ) {
                $scope.selectedEvents = $scope.selectedEvents.filter( function ( event ) {
                    return event == 'Создание' || event == 'Контракт';
                } );
            }
        }

        function getCalendarInfo() {
            commonVariables.isLoading = true;
            //$http( {
            //    url: 'http://app.isz.gosbook.ru/api/calendar',
            //    method: 'GET',
            //    headers: appsecurity.getSecurityHeaders()
            //} )
            selectRequest(apiService.baseUrl+'/api/calendar')
           .then( function ( response ) {
                calendarService.organizeData( response.data );
                gantView.formGantLots( response.data );
                commonVariables.isLoading = false;
                fillRuStatuses( response.data );
                $scope.calendarViewTypeChanged();
            }, function ( response ) {
                commonVariables.isLoading = false;

                var str='Произошла ошибка при запросе данных по календарю. ';
                toastService.errorResponseShow(str,response);

            } )
                .then(function () {
                    commonVariables.requestArr.pop();
                });


            //$http( {
            //    url: 'http://app.isz.gosbook.ru/api/logmessages',
            //    method: 'GET',
            //    headers: appsecurity.getSecurityHeaders()
            //} ).success( function ( response ) {
            //
            //}, function ( response ) {
            //
            //} );


        }

        function fillRuStatuses( calendarLots ) {
            var statusRu;

            $scope.statuses = [];

            calendarLots.forEach( function ( calendarLot ) {
                statusRu = translate.status( 'ru', calendarLot.statusId );
                if ( statusRu && $scope.statuses.indexOf( statusRu ) == -1 ) {
                    $scope.statuses.push( statusRu );
                }
            } );
        }
        function selectRequest(url) {
            // var defer = $q.defer();
            // $http({
            //     method: 'GET',
            //     headers: appsecurity.getSecurityHeaders(),
            //     url: url
            // }).then(function (response) {
            //         defer.resolve(response);
            //     }, function () {
            //         $http({
            //             method: 'GET',
            //             headers: appsecurity.getSecurityHeaders(),
            //             url: url
            //         }).then(function (response) {
            //             defer.resolve(response);
            //         }, function (response) {
            //             defer.reject(response);
            //         })
            //     }
            // )
            // return defer.promise;
            function reqWrapper() {
                var defer = $q.defer();
                $http({
                    method: 'GET',
                    headers: appsecurity.getSecurityHeaders(),
                    url: url
                }).then(function (response) {
                        defer.resolve(response);
                    }, function (response) {
                        defer.reject(response);

                    }
                )
                return defer.promise;

            }
            var req=reqWrapper;
            commonVariables.requestArr.push(req);
            return req();
        }

    }] );