angular.module( 'isz' ).directive( 'calendarDetails', ['commonVariables', function ( commonVariables ) {

    var body = angular.element( document.body );

    return {
        restrict: 'EA',
        replace: true,
        templateUrl: '/js/common/directives/calendarDetails/template/calendarDetails.html',
        scope: {
            day: '=',
            container: '=',
            ordinal: '=',
            view: '=',
            allowedevents: '=',
            allowedstatuses: '='
        },
        link: function ( scope, element ) {
            scope.subsystem = commonVariables.currentSubSystem;
            scope.dateDisplay = scope.day.date.format( 'DD MMMM, dddd' );

            setElementPositionAndDimension();
            subscribeEvents();

            function setElementPositionAndDimension() {
                var containerRect = scope.container[0].getBoundingClientRect(),
                    css = {};

                if ( scope.ordinal < 5 ) {
                    element.addClass( 'segment-indent-' + scope.ordinal )
                           .addClass( 'segment-' + ( 7 - scope.ordinal ) );
                } else {
                    element.addClass( 'segment-' + ( scope.ordinal - 1 ) )
                           .addClass( 'left_side' );
                }

                // rewrite it
                css.top = '55px';
                if ( scope.view == 2 ) {
                    scope.$$postDigest( function () {
                        var elementRect = element[0].getBoundingClientRect();
                        element.css( 'marginTop', containerRect.top - elementRect.top +
                                                    -( elementRect.height - containerRect.height ) / 2 + 'px' );
                    } );
                }

                element.css( css );
                scope.container.addClass( 'detailed' );
            }

            function subscribeEvents() {
                element.on( 'mouseup', function ( evt ) {
                    evt.stopPropagation();
                } )

                body.one( 'mouseup', function () {
                    scope.container.removeClass( 'detailed' );
                    scope.$destroy();
                    element.remove();
                } );
            }

        }
    }
}] );