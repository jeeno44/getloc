﻿angular.module('isz').service('workTypeService', ['WorkTypeFactory', function (WorkTypeFactory) {

    var self = this;
    this.editFlag=false;
    this.currentWork;

    //this.getNewWorkType = function () {
    //    var workType = new WorkTypeFactory({});
    //    workType.startingDate = 1;
    //    workType.executionType = 1;
    //    if (this.stage.id) {
    //        workType.stage = self.stage.id;
    //    }
    //    return workType;
    //}

    this.startingWorkDates = [
        {
            name: "С даты начала этапа",
            value: 1
        },
        {
            name: "С даты окончания выполнения (оказания) предыдущей работы (услуги)/поставки товара",
            value: 2
        },
        {
            name: "С 01/01",
            value: 3
        },
        {
            name: "С даты, определенной пользователем",
            value: 4
        }
    ];

    this.executionTypes = [
        {
            name: "Дата окончания выполнения работ / оказания услуг",
            value: 1
        },
        {
            name: "Срок окончания выполнения работ / оказания услуг",
            value: 2
        }
    ];

    this.creatingWorkType = false;

    // stage for new work type
    this.stage;
    this.getNewWorkType = function (type) {
        if (this.editFlag) {
            return this.currentWork;
        } else {
            if (!type) type='labour';
        }

        var workType = new WorkTypeFactory({});
        workType.startingDate = 1;
        workType.startDate = this.stage.startDate;
        workType.executionType = 1;
        workType.type = type;
        if (this.stage.id) {
            workType.stage = self.stage.id;
        }

        return workType;
    }

}])