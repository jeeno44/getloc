﻿angular.module( 'isz' ).directive( 'profileNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/pagesDocs/profile/profileNavbarTemplate.html',
        controller: [function () {

        }]
    }

}] )