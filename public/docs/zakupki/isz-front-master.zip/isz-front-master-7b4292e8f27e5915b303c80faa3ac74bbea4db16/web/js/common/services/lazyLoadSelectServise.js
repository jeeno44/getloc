angular.module('isz')
.service('lazyLoadSelectService',['$http','$timeout','apiService','appsecurity',function($http,$timeout,apiService,appsecurity){
        this.lazyLoad = function (arr,request,filters) {
            $timeout(function () {
                var step = 20;

                var el = document.querySelector('.md-select-menu-container md-content');
                var elm = angular.element(el);
                var raw = elm[0],isLoading=false;

                elm.bind('scroll', function () {
                    if (raw.scrollTop + raw.offsetHeight >= raw.scrollHeight) {
                        loadNextPortion(arr.length,step);
                    }
                });
            }, 200);
            function loadNextPortion(offset,step){
                var pref=apiService[request].indexOf('?')===-1 ? '?':'&';
                var flt=filters||'';
                selectRequest(apiService[request]+pref+'offset='+offset+'&limit='+step+flt).then(function(response){
                    if  (angular.isArray(response.data) && response.data.length){
                        for (var i=0;i<response.data.length;i++){
                            arr.push(response.data[i]);
                        }
                    }

                },function(response){
                    toastService.errorResponseShow('Произошла ошибка при получении данных справочника',response);
                });
            }
        };

        this.unbindSelect = function(){
            var el = document.querySelector('.md-select-menu-container md-content');
            var elm = angular.element(el);
            elm.unbind('scroll');
        };
        function selectRequest(url) {
            return $http({
                method: 'GET',
                headers: appsecurity.getSecurityHeaders(),
                url: url
            })
        }
    }]);