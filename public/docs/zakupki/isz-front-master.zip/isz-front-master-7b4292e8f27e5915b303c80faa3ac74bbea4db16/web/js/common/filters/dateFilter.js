angular.module( 'isz' ).filter( 'moment', [function () {
    return function ( dateStr, dateFormat ) {
        return moment( dateStr ).format( dateFormat || 'LL' );
    }
}] );