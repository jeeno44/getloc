﻿angular.module( 'isz' ).factory( 'UserRole', ['$rootScope','commonVariables', function ( $rootScope,commonVariables ) {

    function UserRole( opts ) {
        //var mappedPermissions = opts.permissions.filter( function ( permission ) { return permission.subsystem == 'Все' || permission.subsystem == 'ФП "Документы"'; } )
        //    .map( function ( permission ) { return permission.code } );

        //  this.expertRole = opts.expertRole;
        this.name = opts.name;
        this.code = opts.code;
        this.perms = {
            docs: [],
            all: [],
            plans: [],
            acceptance:[]
        };
        this.expertGroup=opts.expertGroup||[];

        for ( var i = 0; i < opts.permissions.length; i++ ) {
            switch ( opts.permissions[i].subsystem ) {
                case 'Все':
                    this.perms.all.push( opts.permissions[i] );
                    break;
                case 'ФП "Документы"':
                    this.perms.docs.push( opts.permissions[i] );
                    break;
                case 'ФП "Планирование"':
                    this.perms.plans.push( opts.permissions[i] );
            }
        }

        this.subsystem = commonVariables.currentSubSystem;

        this.permissions = {

            // // Просматривать страницу профайла
            // //readProfile: mappedPermissions.indexOf( "read_profile" ) !== -1, // +++
            // readProfile: this.isAllow( 'read_profile' ),
            //
            // // Править на странице профайла
            // //editProfile: mappedPermissions.indexOf( 'edit_profile' ) !== -1, // +++
            // editProfile: this.isAllow( 'edit_profile' ),
            //
            // // Просматривать страницу календаря
            // readCalendar: this.isAllow( 'read_calendar' ), // +++
            //
            // // Править на странице календаря
            // controlCalendar: this.isAllow( 'control_calendar' ),
            //
            // // Можно переходить на страницу лота для просмотра
            // readLot: this.isAllow( this.subsystem === 'docs' ? 'documents_read_lot' : 'read_lot' ), // +++
            // //readPlanLot:this.isAllow('read_lot'),
            //
            // // На странице лота можно править лот
            // editLot: this.isAllow( this.subsystem === 'docs' ? 'documents_edit_lot' : 'edit_lot' ), // +++
            // //editPlanLot: this.isAllow('edit_lot'),
            //
            // // На главной странице просматривать секции
            // readSections: this.isAllow( this.subsystem === 'docs' ? 'documents_read_section_documents' : 'find_all_lots' ), // +++
            //
            // // На главной странице у каждого лота видеть контролы
            // controlSections: this.isAllow( 'documents_control_section_documents' ), // +++
            //
            // // На главной странице просмотр через поиск
            // readSectionsAll: this.isAllow( this.subsystem === 'docs' ? 'documents_read_section_all_documents' : 'find_all_lots' ),
            //
            // readLotByGroup: this.isAllow( 'documents_read_lot_his_group' ), // +++
            // editLotByGroup: this.isAllow( 'documents_edit_lot_in_his_group' ), // +++
            // readSectionsByGroup: this.isAllow( 'documents_read_section_documents_in_his_group' ), // +++
            // controlSectionsByGroup: this.isAllow( 'documents_control_section_documents_in_his_group' ), // +++
            // readSectionsAllByGroup: this.isAllow( 'documents_read_section_all_documents_in_his_group' ),
            //
            // editAllLots: this.isAllow( 'edit_all_lots' ),
            // readCurrentPlan: this.isAllow( 'read_current_plan' ),
            // readProjectedPlan: this.isAllow( 'read_projected_plan' ),
            // controlProjectedPlan: this.isAllow( 'control_projected_plan' ),
            // readArchivePlans: this.isAllow( 'read_archive_plans' ),
            // controlArchivePlans: this.isAllow( 'control_archive_plans' ),
            // readLimits: this.isAllow( 'read_limits' ),
            // editLimits: this.isAllow( 'edit_limits' ),
            // expertizeLot: this.isAllow( 'expertize_lot' ),
            // createLot: this.isAllow( 'create_lot' ),
            // readMyLots: this.isAllow( 'read_my_lots' ),
            // controlMyLots: this.isAllow( 'control_my_lots' ),
            // createAllLots: this.isAllow( 'create_all_lots' ),
            // createLimits: this.isAllow( 'create_limits' ),
        };
        this.updatePermissons();
    }

    UserRole.prototype = {
        isAllowReadLot: function ( common ) {
            return this.permissions.readLot ||
                ( this.permissions.readLotByGroup && common.id === this.common.id );
        },
        isAllowReadAllSections: function () {
            return this.permissions.readSections;
        },
        isAllowReadSectionByGroup: function ( common ) {
            return this.isAllowReadAllSections() ||
                this.permissions.readSectionsByGroup && common.id === this.common.id;
        },
        isAllowEditLot: function ( common ) {
            return this.permissions.editLot ||
                ( this.permissions.editLotByGroup && common.id === this.common.id );
        },
        isAllowControlSections: function ( common ) {
            return this.permissions.controlSections ||
                ( this.permissions.controlSectionsByGroup && common.id === this.common.id );
        },
        isAllow: function ( perm ) {
            var flag = false;
            for ( var i = 0; i < this.perms.all.length; i++ ) {
                if ( this.perms.all[i].code === perm ) {
                    flag = true;
                    break;
                }
            }
            if ( !flag ) {
                for ( var i = 0; i < this.perms[this.subsystem].length; i++ ) {
                    if ( this.perms[this.subsystem][i].code === perm ) {
                        flag = true;
                        break;
                    }
                }
            }
            return flag;
        },
        subsystemChanged:function () {
            this.subsystem = commonVariables.currentSubSystem;
            this.updatePermissons();
            // $rootScope.$broadcast('subsystemCangeEvent');
        },
        updatePermissons:function () {
            this.permissions.readProfile= this.isAllow( 'read_profile' );

            this.permissions.editProfile= this.isAllow( 'edit_profile' );

            this.permissions.readCalendar= this.isAllow( 'read_calendar' );

            // Править на странице календаря
            this.permissions.controlCalendar= this.isAllow( 'control_calendar' );

            // Можно переходить на страницу лота для просмотра
            this.permissions.readLot= this.isAllow( this.subsystem === 'docs' ? 'documents_read_lot' : 'read_lot' ); // +++
            //readPlanLot:this.isAllow('read_lot'),

            // На странице лота можно править лот
            this.permissions.editLot= this.isAllow( this.subsystem === 'docs' ? 'documents_edit_lot' : 'edit_lot' ); // +++
            //editPlanLot: this.isAllow('edit_lot'),

            // На главной странице просматривать секции
            this.permissions.readSections= this.isAllow( this.subsystem === 'docs' ? 'documents_read_section_documents' : 'find_all_lots' ); // +++

            // На главной странице у каждого лота видеть контролы
            this.permissions.controlSections= this.isAllow( 'documents_control_section_documents' ); // +++

            // На главной странице просмотр через поиск
            this.permissions.readSectionsAll= this.isAllow( this.subsystem === 'docs' ? 'documents_read_section_all_documents' : 'find_all_lots' );

            this.permissions.readLotByGroup= this.isAllow( 'documents_read_lot_his_group' ); // +++
            this.permissions.editLotByGroup= this.isAllow( 'documents_edit_lot_in_his_group' ); // +++
            this.permissions.readSectionsByGroup= this.isAllow( 'documents_read_section_documents_in_his_group' ); // +++
            this.permissions.controlSectionsByGroup= this.isAllow( 'documents_control_section_documents_in_his_group' ); // +++
            this.permissions.readSectionsAllByGroup= this.isAllow( 'documents_read_section_all_documents_in_his_group' );

            this.permissions.editAllLots= this.isAllow( 'edit_all_lots' );
            this.permissions.readCurrentPlan= this.isAllow( 'read_current_plan' );
            this.permissions.readProjectedPlan= this.isAllow( 'read_projected_plan' );
            this.permissions.controlProjectedPlan= this.isAllow( 'control_projected_plan' );
            this.permissions.readArchivePlans= this.isAllow( 'read_archive_plans' );
            this.permissions.controlArchivePlans= this.isAllow( 'control_archive_plans' );
            this.permissions.readLimits= this.isAllow( 'read_limits' );
            this.permissions.editLimits= this.isAllow( 'edit_limits' );
            this.permissions.expertizeLot= this.isAllow( 'expertize_lot' );
            this.permissions.createLot= this.isAllow( 'create_lot' );
            this.permissions.readMyLots= this.isAllow( 'read_my_lots' );
            this.permissions.controlMyLots= this.isAllow( 'control_my_lots' );
            this.permissions.createAllLots= this.isAllow( 'create_all_lots' );
            this.permissions.createLimits= this.isAllow( 'create_limits' );
        }


    };

    return UserRole;
}] );