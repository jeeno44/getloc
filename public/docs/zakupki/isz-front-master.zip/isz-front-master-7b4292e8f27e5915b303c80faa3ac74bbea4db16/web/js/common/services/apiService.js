angular.module( 'isz' ).service( 'apiService', ['$q','serverVariables',function ($q,serverVariables) {
    //this.baseUrl = 'http://app.isz.gosbook.ru';
    var self = this;
    this.init = function(){
      var   defer = $q.defer();
        if (angular.isDefined(self.baseUrl)){
            defer.resolve();
        } else {
            serverVariables.getSettings().then(function(){
                self.baseUrl = serverVariables.serverSettings.baseUrl;
                self.serverRoute = self.baseUrl + '/api/';
                // self.lotsRoute = self.serverRoute + 'docs/expertise';
                self.lotsRoute = self.serverRoute + 'lots/expertise';
                self.userInfoRoute = self.serverRoute + 'auth/verify';
                self.expertiseExecute = self.serverRoute + 'expertises/executes';
                self.criteriaRatingsRoute = self.serverRoute + 'criteria/ratings';
                self.criteriaIndicatorsRoute = self.serverRoute + 'criteria/indicators';
                self.criteriaMaxValuesRoute = self.serverRoute + 'criteria/conditions';
                self.stageRoute = self.serverRoute + 'stages';
                self.nmckJustRoute=self.serverRoute + 'nmckjustifications';
                self.workTypesRoute = self.serverRoute + 'worktypes';
                self.workKindsRoute = self.serverRoute + 'workkinds';
                self.historyRoute = self.serverRoute + 'logmessages?filters[entityId]=';
                self.formsRoute = self.baseUrl + '/forms/';
                self.expertsRoute = self.serverRoute + 'expertises/experts';
                self.filesUpload = self.serverRoute + 'files';
                self.lotDocsUpdate = self.serverRoute + 'lotdocs';
                //self.expertsStatuses = self.serverRoute + 'expertisestatuses';
                self.expertsStatuses = self.serverRoute + 'statuses/select.json?limit=100&filters[typeObject]=lot';
                self.plansStatuses = self.serverRoute + 'statuses/select.json?limit=100&filters[typeObject]=plan&filters[subSystem]=fp_planirovanie';
                //self.okvedsSelect = self.serverRoute + 'okveds/select?limit=10000';
                //self.okpdsSelect = self.serverRoute + 'okpds/select?limit=10000';
                self.okeisSelect = self.serverRoute + 'okeis/select';
                //self.expensetypesSelect = self.serverRoute + 'expensetypes/select?limit=10000';
                //self.procurementtypesSelect = self.serverRoute + 'procurementtypes/select?limit=10000';
                //self.nmcktypesSelect = self.serverRoute + 'nmcktypes/select?limit=10000';
                //self.kbksSelect = self.serverRoute + 'kbks/select?limit=10000';
                //self.govProgramsSelect = self.serverRoute + 'govprograms/select?limit=10000'
                //self.fcpsSelect = self.serverRoute + 'fcps/select?limit=10000';

                self.okvedsSelect = self.serverRoute + 'okveds/select';
                self.okpdsSelect = self.serverRoute + 'okpds/select';
                //self.okeisSelect = self.serverRoute + 'okeis/select';
                self.expensetypesSelect = self.serverRoute + 'expensetypes/select';
                self.procurementtypesSelect = self.serverRoute + 'procurementtypes/select';
                self.nmcktypesSelect = self.serverRoute + 'nmcktypes/select';
                self.kbksSelect = self.serverRoute + 'kbks/select';
                self.govProgramsSelect = self.serverRoute + 'govprograms/select'
                //self.govProgramsSelect = self.serverRoute + 'govprograms'
                self.fcpsSelect = self.serverRoute + 'fcps/select';

                //self.fcpActionTaskSelect = self.serverRoute + 'fcpactions/select?filters[type]=task&filters[fcp]=';
                self.fcpActionTaskSelect = self.serverRoute + 'fcpactions/select?filters[type][]=task&filters[type][]=other&filters[fcp]=';
                //self.fcpActionSelect = self.serverRoute + 'fcpactions/select?filters[type]=action&filters[parent]=';
                self.fcpActionSelect = self.serverRoute + 'fcpactions/select?filters[type][]=action&filters[type][]=other&filters[parent]=';
                //self.fcpActionSubactionSelect = self.serverRoute + 'fcpactions/select?filters[type]=subaction&filters[parent]=';
                self.fcpActionSubactionSelect = self.serverRoute + 'fcpactions/select?filters[type][]=subaction&filters[type][]=other&filters[parent]=';
                self.rateSelect = self.serverRoute + 'rateindicators/select?filters[type]=rate&order_by[title]=ASC&limit=10000';
                self.indicatorSelect = self.serverRoute + 'rateindicators/select?filters[type]=indicator&order_by[title]=ASC';
                self.createLot = self.serverRoute + 'lots';
                //self.subProgramSelect = self.serverRoute + 'subprogramactions/select?filters[type]=subprogram&order_by[title]=ASC';
                self.subProgramSelect = self.serverRoute + 'subprogramactions/select?&filters[type][]=subprogram&filters[type][]=other';
                self.subProgramMainActionSelect = self.serverRoute + 'subprogramactions/select?filters[type][]=mainaction&filters[type][]=other';
                //self.subProgramActionSelect = self.serverRoute + 'subprogramactions/select?filters[type]=action&order_by[title]=ASC';
                self.subProgramActionSelect = self.serverRoute + 'subprogramactions/select?filters[type][]=action&filters[type][]=other';
                // self.planCommon = self.serverRoute + 'plan/common/expertise?filters[type]=';
                self.planCommon = self.serverRoute+'plans/common/';
                self.currentPlanCommon = self.serverRoute + 'plan/common/expertise?filters[type]=current';
                self.currentPlanDepzak = self.serverRoute + 'plan/current/expertise';
                self.statusesSelect = self.serverRoute + 'statuses/select.json';
                self.lotsCurrentPlan = self.serverRoute + 'plans/';

                self.planExcel = self.serverRoute + 'plan/excel?planId=';
                self.planPdf = self.serverRoute + 'plan/pdf?planId=';
                self.planDocs = self.serverRoute + 'plandocs';

                self.plans = self.serverRoute + 'lots/plans';
                self.plan = self.serverRoute + 'lot/plan';

                self.limit = self.serverRoute + 'financinglimits';

                self.kbkSectionSelect = self.serverRoute+'kbksections/select';
                self.kbkCsrSelect = self.serverRoute+'kbkcsrs/select';
                self.kbkExpenseTypeSelect = self.serverRoute+'kbkexpensetypes/select';
                self.kbkKosguSelect = self.serverRoute+'kbkkosgus/select';
                self.kbkFlowDirectionSelect=self.serverRoute+'kbk/flowdirections/select';

                self.marketplaceSelect = self.serverRoute+'marketplaces/select';

                self.onAgreeKoordPlans = self.serverRoute+'plan/onagreement/';
                self.userLotsRoute = self.serverRoute+'userlots/';

                self.getRouteForDocument = function ( lotId ) {
                    return self.baseUrl+'/doc/1019975/' + lotId + '/generate';
                }

                self.getLotHistoryRoute = function ( lotId, fieldTitle ) {

                    var fieldParameter = '&filters[entityField]=' + fieldTitle;
                    if ( !fieldTitle ) {
                        fieldParameter = '';
                    }

                    return self.historyRoute + lotId + fieldParameter;
                }
                defer.resolve();
            },function(){
                defer.reject();
            });
        }
        return defer.promise;
    };



} ]);