angular.module( 'isz' ).service( 'gantView', ['translate', function ( translate ) {

    var gantLots = [],
        self = this;

    function modifyForDataOutput( copiedGantLots, days, view ) {
        console.time( 'modifyForDataOutput' )
        var range = {};

        copiedGantLots.forEach( function ( gantLot ) {
            gantLot.eventsInRange.length = 0;
            gantLot.eventsOutOfRange.length = 0;

            gantLot.events.forEach( function ( event ) {
                range = self.getDatesRangeForEvent( days, event, view );
                // to Event.proto
                if ( angular.isDefined( range.from ) ) {
                    gantLot.eventsInRange.push( angular.extend( event, range ) );
                } else {
                    gantLot.eventsOutOfRange.push( event );
                }
            } );
        } );

        console.timeEnd( 'modifyForDataOutput' )
        return copiedGantLots;
    }

    this.formGantLots = function ( lots ) {
        gantLots = lots.map( function ( lot ) { return new GantLot( lot ); } );
    }

    this.getFilteredGantLots = function ( days, view ) {
        var filteredGantLots = [];

        switch ( days.length ) {
            case 1:
                filteredGantLots = gantLots.filter( function ( gantLot ) {
                    return gantLot.hasEventAtDay( days[0].date );
                } );
                break;
            case 7:
                var beforeMonday = days[0].date.clone().subtract( 1, 'day' ),
                    afterSunday = days[6].date.clone().add( 1, 'day' );

                filteredGantLots = gantLots.filter( function ( gantLot ) {
                    return gantLot.hasEventAtRange( beforeMonday, afterSunday );
                } );
                break;
            default:
                filteredGantLots = gantLots.filter( function ( gantLot ) {
                    return gantLot.hasEventAtMonth( days[0].date );
                } );

        }

        return modifyForDataOutput( filteredGantLots, days, view );
    }

    this.fillMonthEvents = function ( year, month ) {
        var m_month = moment( year + '/' + month.index + '/1' ),
            i = 0;

        gantLots.filter( function ( gantLot ) { return gantLot.hasEventAtMonth( m_month ); } )
                .forEach( function ( gantLot ) {
                    gantLot.getEventsInMonth( m_month ).forEach( function ( event ) {
                        if ( event.isRange ) {
                            month.addEvent( event.type + 'Start', gantLot.statusId );
                            month.addEvent( event.type + 'End', gantLot.statusId );
                        } else {
                            month.addEvent( event.type, gantLot.statusId );
                        }
                    } );
                } );
    }

    this.getDatesRangeForEvent = function ( days, event, view ) {
        var firstDate = days[0].date.clone().subtract( 1, 'day' ),
            lastDate = days[days.length - 1].date.clone().add( 1, 'day' ),
            datesRange = {};

        if ( event.m_start.isBefore( lastDate ) ) {
            if ( event.m_end ) {
                if ( event.m_end.isAfter( firstDate ) ) {
                    datesRange.from = event.m_start.isAfter( firstDate )
                                        ? event.m_start
                                        : 1;

                    datesRange.to = event.m_end.isBefore( lastDate )
                                        ? event.m_end
                                        : lastDate.subtract( 1, 'day' );
                }
            } else if ( event.m_start.isAfter( firstDate ) ) {
                datesRange.from = event.m_start;
            }
        }

        if ( datesRange.from ) {
            if ( moment.isMoment( datesRange.from ) ) {
                datesRange.from = view === 'Месяц'
                                    ? datesRange.from.date()
                                    : datesRange.from.isoWeekday();
            }

            if ( moment.isMoment( datesRange.to ) ) {
                datesRange.to = view === 'Месяц'
                                    ? datesRange.to.date()
                                    : datesRange.to.isoWeekday();
            }
        }

        return datesRange;
    }

    function GantLot( lot ) {
        this.id = lot.id;
        this.title = lot.title;
        this.statusId = lot.statusId;
        this.statusRu = translate.status( 'ru', this.statusId );
        this.number = lot.number || 'Нет значения';
        this.departmentName = lot.common.fullName;
        this.procResp=lot.procResp.name+' '+lot.procResp.lastName;
        this.eventsInRange = [];
        this.eventsOutOfRange = [];

        this.dates = {};
        this.events = [];

        var momentDate = moment( lot.creationDate || null );
        if ( momentDate.isValid() ) {
            this.addDate( momentDate );
            this.addEvent( 'creationDate', momentDate );
        }

        momentDate = moment( lot.contractExecution || null );
        if ( momentDate.isValid() ) {
            this.addDate( momentDate );
            this.addEvent( 'contractExecution', momentDate );
        }

        momentDate = moment( lot.procurementStartDate || null );
        if ( momentDate.isValid() ) {
            this.addDate( momentDate, moment( lot.procurementEndDate || new Date() ) );
            this.addEvent( 'procurementStartDate', momentDate, moment( lot.procurementEndDate ) );
        }

        momentDate = moment( lot.expertiseData && (lot.expertiseData.timeStart || null) );
        if ( momentDate.isValid() ) {
            this.addDate( momentDate, moment( lot.expertiseData.timeEnd || new Date() ) );
            this.addEvent( 'expertiseData', momentDate, moment( lot.expertiseData.timeEnd ) );
        }
    }

    GantLot.prototype = {
        addEvent: function ( key, m_start, m_end ) {
            // add Event factory
            var hasEndDate = moment.isMoment( m_end ) && m_end.isValid(),
                event = {
                    key: key,
                    title: translate.calendar.events( 'ru', key ),
                    isRange: key == 'procurementStartDate' || key == 'expertiseData',
                    m_start: m_start,
                    m_end: hasEndDate ? m_end : null,
                    dateDisplay: m_start.format( 'LL' ),
                    type: key.replace( /[A-Z].*/, '' ),
                    from: undefined,
                    to: undefined
                };
            event.attr = 'event-' + event.type;
            this.events.push( event );

            if ( event.isRange ) {
                // !!!!! check range event, each date must came as object with all info about themself
                // add common info for range events, like procurementStartDate/procurementEndDate = procurement
                event.title = translate.calendar.events( 'ru', event.type );
                if ( hasEndDate ) {
                    event.dateDisplay += ' - ' + event.m_end.format( 'LL' );
                } else {
                    event.dateDisplay += ' - до сих пор';
                    event.m_end = moment();

                }
            }
        },
        addDate: function ( m_start, m_end ) {
            var m_start_clone = m_start.clone();

            if ( m_end && m_end.isValid() && m_end.isAfter( m_start_clone ) ) {
                var hasYearDiff = Boolean( m_end.diff( m_start_clone, 'year' ) );
                this.fillYear( m_start_clone.year(), m_start_clone.month(), hasYearDiff ? 11 : m_end.month() );

                while ( hasYearDiff && m_start_clone.add( 1, 'year' ) ) {
                    hasYearDiff = Boolean( m_end.diff( m_start_clone, 'year' ) );
                    this.fillYear( m_start_clone.year(), 0, hasYearDiff ? 11 : m_end.month() );
                }
            } else {
                this.fillYear( m_start_clone.year(), m_start_clone.month() );
            }
        },
        fillYear: function ( year, from, to ) {
            if ( !angular.isString( year ) ) {
                year += '';
            }
            if ( angular.isUndefined( this.dates[year] ) ) {
                this.dates[year] = new Array( 12 );
            }
            if ( !angular.isNumber( to ) ) {
                to = from;
            }
            while ( from < 12 && to >= from ) {
                this.dates[year][from] = true;
                from += 1;
            }
        },
        hasEventAtDay: function ( date ) {
            return this.hasEventAtMonth( date )
                && this.events.some( function ( event ) {
                    return date.isSame( event.m_start, 'day' ) || date.isSame( event.m_end, 'day' )
                        || ( date.isAfter( event.m_start ) && date.isBefore( event.m_end ) );
                } );
        },
        hasEventAtRange: function ( date1, date2 ) {
            var length = this.events.length;

            while ( length-- ) {
                if ( this.events[length].m_start.isBetween( date1, date2, 'day' ) ) {
                    return true;
                }

                if ( this.events[length].m_end ) {
                    if ( this.events[length].m_end.isBetween( date1, date2, 'day' ) ||
                        ( this.events[length].m_start.isBefore( date1 ) && this.events[length].m_end.isAfter( date2 ) ) ) {
                        return true;
                    }
                }
            }
        },
        hasEventAtMonth: function ( date ) {
            var year = date.year() + '';
            return year in this.dates && this.dates[year][date.month()];
        },
        getEventsInMonth: function ( date ) {
            var events = [];

            if ( this.hasEventAtMonth( date ) ) {
                events = this.events.filter( function ( event ) {
                    if ( event.m_end ) {
                        return date.isSame( event.m_start, 'month' ) || date.isSame( event.m_end, 'month' )
                            || date.isBetween( event.m_start, event.m_end, 'month' );
                    } else {
                        return date.isSame( event.m_start, 'month' );
                    }
                } )
            }

            return events;

        }
    }

}] )