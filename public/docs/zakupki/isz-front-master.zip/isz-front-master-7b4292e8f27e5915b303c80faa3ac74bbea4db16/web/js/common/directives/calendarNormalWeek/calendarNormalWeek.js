angular.module( 'isz' ).directive( 'calendarNormalWeek', ['$compile', 'translate', function ( $compile, translate ) {

    function highlightToday( date ) {
        return date.isSame( moment(), 'day' )
            ? ' calendar_today'
            : '';
    }

    function getEventMarkup( event, references, toDisplay ) {
        var innerMarkup = '';

        while ( toDisplay-- ) {
            innerMarkup += '<div class="calendar_reference dotdotdot">' + references[toDisplay].lotNumber + '</div>';
        }

        return [
            '<div class="calendar_event">',
                '<div class="calendar_event_name">' + event.nameRu + ' : ' + references.length + '</div>',
                innerMarkup,
            '</div>'
        ].join( '' )
    }

    function getEventsMarkup( day, types, allowedStatuses ) {
        var markup = '<div class="calendar_events' + highlightToday( day.date ) + '">';

        if ( types.length ) {
            var options, i, toDisplay, event, references, refsLength;

            options = generateDayMarkupOptions( day )

            types.sort( function ( type1, type2 ) {
                return day.events[type1].count > day.events[type2].count ? 1 : -1;
            } );

            for ( i = 0; i < types.length; i++ ) {
                event = day.events[types[i]];

                references = allowedStatuses.length
                            ? event.references.filter( function ( refer ) {
                                return allowedStatuses.indexOf( refer.statusRu ) > -1;
                            } )
                            : event.references;

                refsLength = references.length;

                if ( refsLength <= options.amountToShow ) {
                    options.residue += options.amountToShow - refsLength;
                    toDisplay = refsLength;
                } else {
                    if ( refsLength <= options.residue ) {
                        toDisplay = refsLength;
                        options.residue -= refsLength;
                    } else {
                        toDisplay = options.amountToShow + options.residue;
                        options.residue = 0;
                    }
                }

                markup += getEventMarkup( event, references, toDisplay );
            }
        }

        return markup + '</div>';
    }

    function generateDayMarkupOptions( day ) {
        var eventsLength = day.existedTypes.length;

        return {
            residue: 0,
            amountToShow: Math.floor(( 582 - eventsLength * 54 ) / ( eventsLength * 18 ) )
        };
    }

    return {
        restrict: 'EA',
        replace: false,
        link: function ( scope, $element, attrs ) {
            scope.$on( 'forceRedraw', forceRedraw );

            function forceRedraw() {
                var types = scope.day.existedTypes || [],
                    markup = '<div class="calendar_date">' +
                             scope.day.date.format( 'dddd, DD MMM' ) +
                             '</div>';

                if ( scope.selectedEvents.length ) {
                    types = types.filter( function ( type ) {
                        return scope.selectedEvents.indexOf( translate.calendar.events( 'ru', type ) ) > -1;
                    } );
                }

                $element.html( markup + getEventsMarkup( scope.day, types, scope.selectedStatuses ) );

                if ( types.length ) {
                    var dateiledBtn = $compile( '<md-button>Детальнее</md-button>' )( scope );

                    scope.container = $element;

                    dateiledBtn.on( 'click', function () {
                        $element.parent().append( $compile( '<div calendar-details day="day" container="container" ordinal="$index + 1" view="dateViewIndex"  allowedevents="selectedEvents" allowedstatuses="selectedStatuses"> ' )( scope ) );
                    } );

                    $element[0].querySelector( '.calendar_events' ).appendChild( dateiledBtn[0] );
                }

            }

        }
    }
}] );