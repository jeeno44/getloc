angular.module( 'isz' ).service( 'toastService', ['$mdToast', function ( $mdToast ) {

    var toastposition = {
        bottom: false,
        top: true,
        left: false,
        right: true
    };

    var getToastPosition = function () {
        return Object.keys( toastposition )
          .filter( function ( pos ) { return toastposition[pos]; } )
          .join( ' ' );
    };

    this.show = function ( message, isError ) {
        //setTimeout(function(){
            //var dialog = document.querySelector('.md-dialog-container1');
            //if (!dialog){
                $mdToast.show( {
                    controller: ['$scope', function ( $scope ) {
                        $scope.message = message;
                        $scope.isError = isError;
                        $scope.closeToast = function () {
                            $mdToast.hide();
                        }
                    }],
                    templateUrl: '/js/common/templates/toast.html',
                    hideDelay: 6000,
                    position: getToastPosition()
                } );
            //}
        //},500);

    };
    this.showList = function ( title, list, isError ) {
        $mdToast.show( {
            controller: ['$scope', function ( $scope ) {
                
                $scope.title = title;
                $scope.list = list;
                $scope.isError = isError;
                $scope.closeToast = function () {
                    $mdToast.hide();
                }
            }],
            templateUrl: '/js/common/templates/toastList.html',
            hideDelay: 6000,
            position: getToastPosition()
        } );
    };
    this.errorResponseShow = function ( str, response ) {
        var list = [];

        if  (response&&response.data && response.data.message) {
            if (response.data.message.error){
                if (angular.isArray(response.data.message.error)){
                    for (var st in response.data.message.error){
                        //str+=(' '+st);
                        list.push( st );
                    }
                } else {
                    //str+=(' '+response.data.message.error);
                    list.push( response.data.message.error );
                }
            } else {
                //str+=(' '+response.data.message);
                list.push( response.data.message);
            }
        }
        this.showList(str,list,true);
    }


}] );