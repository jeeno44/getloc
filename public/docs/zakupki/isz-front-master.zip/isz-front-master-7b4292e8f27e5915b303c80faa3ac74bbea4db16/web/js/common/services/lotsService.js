angular.module('isz').service('lotsService', ['$http', '$q', '$location', 'apiService', 'appsecurity', 'LotFactory', 'commonVariables', 'toastService','AcceptanceLotFactory',
    function ($http, $q, $location, apiService, appsecurity, LotFactory, commonVariables, toastService) {

        var self = this,
            hasLots = false,
            myDepartments = [];

        this.fcpActions = [];
        this.lots = [];
        this.startLots = [];

        this.getExpertStatuses = function () {
            var defer = $q.defer();

            var subsystemName;
            switch (commonVariables.currentSubSystem) {
                case 'plans':
                    subsystemName='fp_planirovanie';
                    break;
                case 'docs':
                    subsystemName='fp_documents';
            }
            //if (commonVariables.expertsStatuses && commonVariables.expertsStatuses.length) {
            //    defer.resolve()
            //    return defer.promise;
            //}
            selectRequest(apiService.expertsStatuses+'&filters[subSystem]='+subsystemName)
                .then(function (response) {

                    if (response.data) {
                        var draftArr = response.data.map(function (d) {
                            return {
                                machineName: d.id,
                                title: d.title,
                            };
                        });
                        //crutch
                        var fl=false;
                        draftArr.forEach(function(d){
                            if (d.machineName=='on_agreement') {
                                fl=true;
                            }
                        });
                        if (!fl) {
                            draftArr.push({
                                machineName: 'on_agreement',
                                title: 'Запланирован',
                            });
                        }

                        draftArr.forEach(function (status) {
                            switch (status.machineName) {
                                case 'on_agreement':
                                    status.weight = 1;
                                    break;
                                case 'approved':
                                    status.weight = 2;
                                    break;
                                case 'draft':
                                    status.weight = 3;
                                    break;
                                default:
                                    status.weight = 4;

                            }
                        });
                        draftArr.sort(function (a, b) {
                            return a.weight > b.weight;
                        });
                        commonVariables.expertsStatuses = draftArr;

                    }

                    defer.resolve();
                }, function (response) {
                    toastService.errorResponseShow('Произошла ошибка при получении данных справочника', response);
                    defer.reject();
                })
                    .then(function () {
                        commonVariables.requestArr.pop();
                    });

            return defer.promise;
        }
        function getLotsRequest() {
            var defer = $q.defer();
            selectRequest(apiService.lotsRoute + '?order_by[creationDate]=DESC&limit=10000')
                .then(function (response) {

                    defer.resolve(response.data);
                }, function (response) {
                    toastService.errorResponseShow('Произошла ошибка при получении лотов', response);
                    defer.reject();
                })
                .then(function () {
                    commonVariables.requestArr.pop();
                });
            return defer.promise;
        }
        function getUserLotsRequest(userid) {
            var defer = $q.defer();
            selectRequest(apiService.userLotsRoute+userid + '?order_by[creationDate]=DESC&limit=10000')
                .then(function (response) {
                    defer.resolve(response.data);
                }, function (response) {
                    toastService.errorResponseShow('Произошла ошибка при получении лотов', response);
                    defer.reject();
                })
                .then(function () {
                    commonVariables.requestArr.pop();
                });
            return defer.promise;
        }

        this.getLots = function (force) {
            var self = this;

            var defer = $q.defer();

            if (hasLots && !force) {
                self.getExpertStatuses().then(function(){
                    fillDeprtmentsFiltersArray(self.startLots)
                    fillFcpActionsArray(self.startLots);
                    defer.resolve();
                })
            } else {
                hasLots = true;
                $q.all([self.getExpertStatuses(), getLotsRequest()]).then(function (arguments) {
                    self.startLots.splice(0);
                    if (arguments[1].length > 0) {
                        for (var i = 0; i < arguments[1].length; i++) {
                            self.startLots.push(new LotFactory(arguments[1][i]));
                        }
                        fillDeprtmentsFiltersArray(self.startLots)
                        fillFcpActionsArray(self.startLots);
                    } else {
                        toastService.show('Нет данных для отображения на странице', false);
                    }
                    defer.resolve();
                }, function () {
                    defer.reject();
                });
            }
            return defer.promise;
        }

        this.getLotsCurrentPlan = function (id, force, cons) {

            var defer = $q.defer();

            if (hasLots && !force) {
                defer.resolve();
            } else {
                hasLots = true;
                var url;
                if (cons) {
                    url = apiService.lotsCurrentPlan + id + '/consolidated/lots';
                } else {
                    url = apiService.lotsCurrentPlan + id + '/lots'
                }
                selectRequest(url)
                    .then(function (response) {

                        if (response.data) {
                            self.startLots = [];
                            var currYear = new Date().getFullYear();
                            for (lot in response.data) {
                                //if (response.data[lot].financings && response.data[lot].financings[0].year === currYear) {
                                //    self.startLots.push(new LotFactory(response.data[lot]));
                                //}
                                self.startLots.push(new LotFactory(response.data[lot]));
                            }

                        } else {
                            toastService.show('Нет данных для отображения на странице', false);
                        }

                        defer.resolve();
                    }, function (response) {
                        toastService.errorResponseShow('Произошла ошибка при получении лотов плана.', response);
                        defer.reject();
                    })
                    .then(function () {
                        commonVariables.requestArr.pop();
                    });
            }

            return defer.promise;
        };

        this.forceSync = function () {

            var defer = $q.defer();

            commonVariables.isLoading = true;

            this.lots.length = 0;
            this.startLots.length = 0;
            this.getLots(true).then(function () {
                $location.path() == '/plans' ? self.separateByFcpAction() : self.separateByStatuses();
                commonVariables.isLoading = false;
                defer.resolve();
            }).catch(function () {
                commonVariables.isLoading = false;
                defer.reject();
            });

            return defer.promise;
        }
        this.updateOneLot = function(id){
            var defer = $q.defer();
            this.lots.length = 0;
            selectRequest(apiService.lotsRoute + '/' +id)
                .then(function (response) {
                    var flag=false;

                    // ищем в списке текущих лотов
                    for (var i=0;i<self.startLots.length;i++){
                        if (self.startLots[i].id===id) {
                            flag=true;
                            break;
                        }
                    }

                    // если нашли
                    if (flag) {
                        self.startLots.splice(i,1);
                        if (response.data) {
                            self.startLots.push(new LotFactory(response.data));
                        }
                    }

                    self.getLots(false).then(function () {
                        $location.path() == '/plans' ? self.separateByFcpAction() : self.separateByStatuses();
                        commonVariables.isLoading = false;
                        defer.resolve();
                    }).catch(function () {
                        commonVariables.isLoading = false;
                        defer.reject();
                    });
                }, function (response) {
                    toastService.errorResponseShow('Произошла ошибка при получении лотов', response);
                    defer.reject();
                })
                .then(function () {
                    commonVariables.requestArr.pop();
                });


            return defer.promise;
        }

        this.recreateLots = function () {
            self.lots.splice(0, self.lots.length);
            separateByStatuses(self.startLots);
        };

        function fillDeprtmentsFiltersArray(lots) {
            commonVariables.departments.length = 0;
            lots.forEach(function (lot) {
                if (lot.common != null && angular.isString(lot.common.shortName)) {
                    if (commonVariables.departments.indexOf(lot.common.shortName) == -1) {
                        commonVariables.departments.push(lot.common.shortName);
                    }
                }
            })
        }

        function fillFcpActionsArray(lots) {
            commonVariables.fcpActions.length = 0;
            var draftArr = lots.map(function (lot) {
                var action = {};
                if (lot.fcpAction && lot.fcpAction.id) {
                    action = lot.fcpAction;
                }
                if (lot.subProgramAction && lot.subProgramAction.id) {
                    action = lot.subProgramAction;
                }
                return action;
            });
            var pp = {};
            for (var i = 0; i < draftArr.length; i++) {
                var str = draftArr[i];
                pp[str.id] = str;
            }
            Object.keys(pp).forEach(function (act) {

                if (act === 'undefined') {
                    commonVariables.fcpActions.push({
                        id: '0',
                        title: 'Внепрограммное мероприятие',
                        shortTitle:'Внепрограммное мероприятие'
                    });
                } else {
                    if (pp[act].title.length>97) {
                        pp[act].shortTitle=pp[act].title.slice(0,94)+'...';
                    } else {
                        pp[act].shortTitle=pp[act].title;
                    }
                    commonVariables.fcpActions.push(pp[act]);
                }
            });

            commonVariables.fcpActions.sort(function (a, b) {
                return a.title.localeCompare(b.title);
            })
        }

        this.separateByStatuses = function () {
            self.lots.length = 0;
            var lots = self.startLots;
            var obj;
            commonVariables.expertsStatuses.forEach(function (status) {
                obj = {
                    statusId: status.machineName,
                    title: status.title,
                    lotsByStatus: lots.filter(function (lot) {
                        return lot.statusId === status.machineName
                    })
                };
                if (obj.lotsByStatus.length) {
                    obj.hasFilteredLots = true;
                    self.lots.push(obj);
                }
            });
        };

        this.separateByFcpAction = function () {
            self.lots.length = 0;
            var lots = this.startLots;
            var obj;
            lots.forEach(function (lot) {
                if (!lot.fcpAction) {
                    lot.fcpAction = {
                        title: 'Внепрограммное мероприятие'
                    }
                }
            });
            commonVariables.fcpActions.forEach(function (action) {
                obj = {
                    fcpAction: action,
                    lotsByFcpAction: lots.filter(function (lot) {
                        return lot.fcpAction.title == action.title;
                    }).sort(function (a, b) {

                        var aName = commonVariables.expertsStatuses.filter(function (status) {
                            return status.machineName === a.statusId;
                        });
                        var bName = commonVariables.expertsStatuses.filter(function (status) {
                            return status.machineName === b.statusId;
                        });
                        if (!aName[0]) {
                            console.log(a.statusId);
                        }
                        if (!bName[0]) {
                            console.log(b.statusId);
                        }
                        return aName[0].title.localeCompare(bName[0].title);
                    })
                };

                if (obj.lotsByFcpAction.length) {
                    obj.hasFilteredLots = true;
                    self.lots.push(obj);
                }
            });
        };

        this.getMyLots = function () {
            self.lots.splice(0);
            //self.startLots.splice( 0 );
            var lots = self.startLots.filter(function (lot) {
                return commonVariables.myDepartments.indexOf(lot.common.id) != -1;
            });
            var obj;
            commonVariables.expertsStatuses.forEach(function (status) {
                obj = {
                    statusId: status.machineName,
                    title: status.title,
                    lotsByStatus: lots.filter(function (lot) {
                        return lot.statusId === status.machineName
                    })
                };
                if (obj.lotsByStatus.length) {
                    obj.hasFilteredLots = true;
                    self.lots.push(obj);
                }
            });
        };

        this.getMyLotsByStatus= function(statusId){
            self.lots.splice(0);
            var lots = self.startLots.filter(function (lot) {
                return lot.statusId==statusId;
            });

            if (lots.length) {
                var obj;
                commonVariables.expertsStatuses.forEach(function (status) {
                    obj = {
                        statusId: status.machineName,
                        title: status.title,
                        lotsByStatus: lots.filter(function (lot) {
                            return lot.statusId === status.machineName
                        })
                    };
                    if (obj.lotsByStatus.length) {
                        obj.hasFilteredLots = true;
                        self.lots.push(obj);
                    }
                });
            } else {
                toastService.show('Лотов не найдено',false);
            }
        }

        this.getNewLot = function () {
            return new LotFactory({requirement3044: 'Нет'});
        }

        this.getCurrentById = function (lotId) {
            for (var i = 0; i < self.startLots.length; i++) {
                if (self.startLots[i].id == lotId) {
                    commonVariables.currentLot = self.startLots[i];
                    break;
                }
            }
        }
        this.getCurrentByIdNew = function (lotId) {
            var defer = $q.defer();
            this.getExpertStatuses().then(function () {
                commonVariables.currentLot = new LotFactory({id: lotId});
                defer.resolve();
            }, function () {
                defer.reject()
            });
            return defer.promise;
        }
        this.cleanLots = function () {
            self.lots.splice(0);
            self.startLots.splice(0);
        }
        
        this.getUserLots = function (userid) {
            var self=this,
                defer = $q.defer();
            // this.cleanLots();
            $q.all([self.getExpertStatuses(), getUserLotsRequest(userid)]).then(function (arguments) {
                self.startLots.splice(0);
                if (arguments[1].length > 0) {
                    for (var i = 0; i < arguments[1].length; i++) {
                        self.startLots.push(new LotFactory(arguments[1][i]));
                    }
                    // fillDeprtmentsFiltersArray(self.startLots)
                    // fillFcpActionsArray(self.startLots);
                } else {
                    toastService.show('Нет данных для отображения на странице', false);
                }
                defer.resolve();
            }, function () {
                defer.reject();
            });
            return defer.promise;
        }

        function selectRequest(url) {

            function reqWrapper() {
                var defer = $q.defer();
                $http({
                    method: 'GET',
                    headers: appsecurity.getSecurityHeaders(),
                    url: url
                }).then(function (response) {
                      

                        defer.resolve(response);
                    }, function (response) {
                       defer.reject(response);

                    }
                )
                return defer.promise;
                
            }
            var req=reqWrapper;
            commonVariables.requestArr.push(req);
            return req();
        }
    }]);