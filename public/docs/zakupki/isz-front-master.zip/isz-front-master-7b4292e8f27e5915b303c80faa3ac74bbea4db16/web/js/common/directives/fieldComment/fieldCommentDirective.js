﻿angular.module( 'isz' )
.directive( 'fieldComment', ['$mdDialog', 'commonVariables','appsecurity', function ( $mdDialog, commonVariables ,appsecurity) {

    return {
        replace: true,
        templateUrl: '/js/common/directives/fieldComment/fieldCommentTemplate.html',
        scope: {
            fieldId: '@fieldComment',
            titleRu: '@',
            noShow:'@'
        },
        controller: 'commentsController',
        link: function ( scope ) {
            var counterIncrased = false;
            scope.hasComments = false;
            scope.youLast=false;

            scope.$on( 'commentsUpdates', updateHasComments );

            function updateHasComments( event, fieldId ) {
                if ( !scope.hasComments && ( !fieldId || fieldId == scope.fieldId ) ) {
                    scope.hasComments = scope.show && Boolean( angular.isArray( scope.commentControl.comments )
                        && scope.commentControl.comments.length );
                    scope.yourLast=scope.hasComments
                        &&Boolean( angular.isArray( scope.commentControl.comments )
                            && scope.commentControl.comments.length
                        && (scope.commentControl.comments[0].author.userId===appsecurity.userInfo.id
                            ||scope.commentControl.comments[0].author.id===appsecurity.userInfo.id)
                        &&(scope.commentControl.comments[0].author.userRole===appsecurity.currentRole.code));

                    if ( !counterIncrased && scope.hasComments ) {
                        scope.$emit( 'commentsCounterChanged', 1 );
                        counterIncrased = true;
                    }
                }
                if (scope.hasComments && ( fieldId == scope.fieldId )) {
                    scope.yourLast=scope.hasComments
                        &&Boolean( angular.isArray( scope.commentControl.comments )
                            && scope.commentControl.comments.length
                            && (scope.commentControl.comments[0].author.userId===appsecurity.userInfo.id
                            ||scope.commentControl.comments[scope.commentControl.comments.length-1].author.id===appsecurity.userInfo.id)
                            &&(scope.commentControl.comments[0].author.userRole===appsecurity.currentRole.code));

                }
            }
        }
    };
}] );

angular.module( 'isz' ).controller( 'commentsController', ['$scope', '$mdDialog','$timeout', 'commonVariables',function ( $scope, $mdDialog, $timeout, commonVariables ) {

    $scope.$on( 'lotCommentControlsAdded', getCommentControl );

    $scope.openCommentsModal = function () {
        $mdDialog.show( {
            templateUrl: '/js/common/templates/commentsModal.html',
            controller: 'commentsModal',
            locals: {
                'fieldId': $scope.fieldId,
                'titleRu': $scope.titleRu
            }
        } ).then( function () {
            $scope.$parent.$broadcast( 'commentsUpdates', $scope.fieldId );
            //$scope.$emit( 'commentsUpdates', $scope.fieldId );
        } )
    }

    function getCommentControl() {
        if ( commonVariables.currentLot ) {
            $timeout(function () {
                $scope.commentControl = commonVariables.currentLot.commentControls[$scope.fieldId];
                $scope.show = !!$scope.commentControl;
                $scope.$broadcast( 'commentsUpdates', $scope.fieldId );

            },0);
        } else {
            setTimeout( getCommentControl, 100 );
        }
    }

    getCommentControl();
} ]);

angular.module( 'isz' )
.directive( 'commentsCount', [function () {

    return function ( scope, element ) {
        var commentsCoutner = 0;

        element.text( commentsCoutner );

        scope.$on( 'commentsCounterChanged', function ( event, shift ) {
            element.text( commentsCoutner += shift );
        } );
    }
}] )