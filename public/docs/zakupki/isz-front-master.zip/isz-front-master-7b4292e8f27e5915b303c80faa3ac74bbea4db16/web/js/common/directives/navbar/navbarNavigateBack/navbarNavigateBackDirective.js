﻿angular.module( 'isz' ).directive( 'navbarNavigateBack', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/navbarNavigateBack/navbarNavigateBackTemplate.html',
        controller: ['$scope', '$location', 'navigationService','commonVariables', function ( $scope, $location, navigationService,commonVariables ) {
            $scope.navigateBack = function () {
                if ( $location.path()==='/profile' ) {
                    $location.path( '/' + commonVariables.currentSubSystem );
                } else {
                    $location.path( navigationService.getPreviousUrl() );
                }
                
            };
        }]
    }
}] );