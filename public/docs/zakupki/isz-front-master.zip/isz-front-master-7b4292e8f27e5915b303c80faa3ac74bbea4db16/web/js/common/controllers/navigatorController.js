/**
 * Created by pol on 10.11.2015.
 */
angular.module('isz')
    .controller('navigatorController', ['$scope', '$mdDialog', '$timeout', 'commonVariables',
        function ($scope, $mdDialog, $timeout, commonVariables) {
            var prevIndex = 0;
            var beginRangePos = 0;
            var endRangePos = 0;
            var itemsInList = 0;
            var itemWidth = 0;
            var slideWidth = 0;
            var elem;
            var actSl;
            var nextSl;
            var prevSl;

            $scope.slides = [
                {
                    subsystem: {
                        name: "plans",
                        title: "Планирование"
                    },
                    etaps: [
                        {
                            title: "Формирование лота",
                            status: [{
                                name: "draft",
                                title: "Формирование лота",
                                dateBegin: "",
                                dateEnd: "",
                                visible: true
                            }
                            ],
                            number: 1,
                            state: "active"
                        },
                        {
                            title: "На согласовании у Руководителя Департамента",
                            status: [
                                {
                                    name: "on_approvement",
                                    title: "Cогласован Руководителем Департамента",
                                    dateBegin: "12.03.15",
                                    dateEnd: "",
                                    visible: true,

                                },
                                {
                                    name: "on_completion",
                                    title: "На доработке",
                                    dateBegin: "",
                                    dateEnd: "",
                                    visible: false
                                }
                            ],
                            number: 2,
                            state: "complete"
                        },
                        {
                            title: "Включен в план закупок департамента",
                            status: [
                                {
                                    name: "planning",
                                    title: "Включен в план закупок департамента",
                                    dateBegin: "19.03.15",
                                    dateEnd: "",
                                    visible: true,

                                }
                            ],
                            number: 3,
                            state: "complete"
                        },
                        {
                            title: "На согласовании у Координатора",
                            status: [
                                {
                                    name: "on_approvement",
                                    title: "Согласован Координатором",
                                    dateBegin: "27.03.2015",
                                    dateEnd: "",
                                    visible: true,

                                },
                                {
                                    name: "on_completion",
                                    title: "На доработке",
                                    dateBegin: "",
                                    dateEnd: "",
                                    visible: false
                                }
                            ],
                            number: 4,
                            state: "failed"
                        },
                        {
                            title: "Включен в план-график закупок",
                            status: [
                                {
                                    name: "on_approvement",
                                    title: "Включен в план-график закупок",
                                    dateBegin: "",
                                    dateEnd: "",
                                    visible: true

                                }

                            ],

                            number: 5,
                            state: "none"
                        }

                    ]
                },{
                    subsystem: {
                        name: "docs",
                        title: "Документы"
                    },
                    etaps: [
                        {
                            title: "Формирование госзаказа",
                            status: [{
                                name: "draft",
                                title: "Формирование лота",
                                dateBegin: "",
                                dateEnd: "",
                                visible: true
                            }
                            ],
                            number: 1,
                            state: "active"
                        },
                        {
                            title: "На согласовании у Руководителя Департамента",
                            status: [
                                {
                                    name: "on_approvement",
                                    title: "Cогласован Руководителем Департамента",
                                    dateBegin: "12.04.15",
                                    dateEnd: "",
                                    visible: true,

                                },
                                {
                                    name: "on_completion",
                                    title: "На доработке",
                                    dateBegin: "",
                                    dateEnd: "",
                                    visible: false
                                }
                            ],
                            number: 2,
                            state: "complete"
                        },
                        {
                            title: "На согласовании в Организации-Мониторе",
                            status: [
                                {
                                    name: "planning",
                                    title: "Включен в план закупок департамента",
                                    dateBegin: "19.04.15",
                                    dateEnd: "",
                                    visible: true,

                                }
                            ],
                            number: 3,
                            state: "complete"
                        },
                        {
                            title: "На согласовании у Координатора",
                            status: [
                                {
                                    name: "on_approvement",
                                    title: "Согласован Координатором",
                                    dateBegin: "25.04.15",
                                    dateEnd: "",
                                    visible: true,

                                },
                                {
                                    name: "on_completion",
                                    title: "На доработке",
                                    dateBegin: "",
                                    dateEnd: "",
                                    visible: false
                                }
                            ],
                            number: 4,
                            state: "failed"
                        },
                        {
                            title: "Госзаказ утвержден",
                            status: [
                                {
                                    name: "on_approvement",
                                    title: "Включен в план-график закупок",
                                    dateBegin: "",
                                    dateEnd: "",
                                    visible: true

                                }

                            ],

                            number: 5,
                            state: "none"
                        }

                    ]
                }
            ];

            $scope.currentIndex = 0;
            $timeout(function(){

                elem=angular.element(document.querySelector('.navigator-modal'));
                actSl = angular.element( document.querySelector('.slide-active'));
                nextSl = angular.element(document.querySelector('.slide-next'));
                prevSl = angular.element( document.querySelector('.slide-prev'));


                setLefts();
                $scope.$watch('currentIndex',function(){
                    Array.prototype.forEach.call( $scope.slides, function ( sl ) {
                        sl.visible = false;
                    } );
                    $scope.slides[$scope.currentIndex].visible = true;
                    setSlides();

                })

            },0)
            function setSlides() {
                if ( $scope.currentIndex === 0 ) {
                    $scope.prevSubsystem = $scope.slides[$scope.slides.length - 1];
                } else {
                    $scope.prevSubsystem = $scope.slides[$scope.currentIndex - 1];
                }
                if ( $scope.currentIndex === ( $scope.slides.length - 1 ) ) {
                    $scope.nextSubsystem = $scope.slides[0];
                } else {
                    $scope.nextSubsystem = $scope.slides[$scope.currentIndex + 1];
                }
                $scope.activeSubsystem = $scope.slides[$scope.currentIndex];
                prevIndex = $scope.currentIndex;
            }


            function setLefts() {

                //slideWidth =  angular.element( document.querySelector('.slide')).css( 'width' );
                var slideCss=window.getComputedStyle(document.querySelector('.slide'))
                slideWidth=parseInt(slideCss.width);
                prevSl.css( 'left', '-' + slideWidth +'px');
                nextSl.css( 'left', slideWidth +'px');
            }

            $scope.next = function () {

                movement( actSl, nextSl, true, 500 );

                $timeout( function () {
                    if ( $scope.currentIndex < ( $scope.slides.length - 1 ) ) {
                        $scope.currentIndex++;
                    } else {
                        $scope.currentIndex = 0;
                    }

                    clearTransition( actSl, nextSl );
                }, 500 );

            };
            $scope.prev = function () {
                movement( actSl, prevSl, false, 500 );

                $timeout( function () {
                    if ( $scope.currentIndex > 0 ) {
                        $scope.currentIndex--;
                    } else {
                        $scope.currentIndex = $scope.slides.length - 1;
                    }

                    clearTransition( actSl, prevSl );
                }, 500 );

            };

            function movement( fEl, sEl, isNext, duration ) {
                var s = isNext?'-':'';

                fEl.css( 'transition-duration', duration+'ms' );
                fEl.css( 'transition-property', 'transform' );
                fEl.css( 'transition-timing-function', 'cubic-bezier(0.42,0,0.58,1)' );
                fEl.css( 'transition-delay', '0s' );

                sEl.css( 'transition-duration', duration + 'ms' );
                sEl.css( 'transition-property', 'transform' );
                sEl.css( 'transition-timing-function', ' cubic-bezier(0.42,0,0.58,1)' );
                sEl.css( 'transition-delay', '0s' );


                fEl.css( 'transform', 'translateX('+s + slideWidth +'px)' );
                sEl.css( 'transform', 'translateX('+s + slideWidth + 'px)' );
            }

            function clearTransition( fEl, sEl ) {
                fEl.css( 'transition-duration', '0ms' );
                fEl.css( 'transition-property', '' );
                fEl.css( 'transition-timing-function', '' );
                fEl.css( 'transition-delay', '0s' );

                sEl.css( 'transition-duration', '0ms' );
                sEl.css( 'transition-property', '' );
                sEl.css( 'transition-timing-function', '' );
                sEl.css( 'transition-delay', '0s' );

                sEl.css( 'transform', 'translateX(0)' );
                fEl.css( 'transform', 'translateX(0)' );
            }

        }]);
