/**
 * Created by pol on 29.01.2016.
 */
angular.module( 'isz' ).directive( 'sideMessage', ['$timeout',function ($timeout) {

    var VERTICAL_SHIFT = 35,
        HORIZONTAL_SHIFT = 3;

    return {
        restrict: 'E',
        replace: true,
        templateUrl: '/js/common/directives/sideMessage/sideMessageTemplate.html',
        scope: {
            model: '='
        },


        link: function ( scope, element, attrs ) {
            setLot();

            function setLot(){
                var containerRect = document.querySelector( '.commentsInnerContainer' ).getBoundingClientRect();
                if (containerRect.width>0) {
                    var css = { left: containerRect.width - 50 + 'px' };
                    //css = {right: containerRect.width - 140 + 'px'};

                    if ( angular.isNumber( scope.$parent.commentsZIndexCounter ) ) {
                        css.zIndex = ++scope.$parent.commentsZIndexCounter;
                    }

                    if ( attrs.shift ) {
                        css.marginTop = attrs.shift * VERTICAL_SHIFT + 'px';
                        css.marginLeft = attrs.shift * HORIZONTAL_SHIFT + 'px';
                    }

                    element.css( css );
                } else {
                    setTimeout(setLot,100);
                }
            }
            //scope.setHasMessages=Boolean(model.length);
            //scope.$on( 'Updates', function ( event, fieldId ) {
            //    if ( !scope.hasComments && fieldId == scope.fieldId ) {
            //        scope.hasComments = scope.commentControl && Boolean( angular.isArray( scope.commentControl.comments )
            //                && scope.commentControl.comments.length );
            //    }
            //} );
        }
    };
}] )