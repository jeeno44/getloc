﻿angular.module( 'isz' ).directive( 'calendarNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/pagesDocs/calendar/calendarNavbarTemplate.html',
        controller: [function () {

        }]
    }

}] )