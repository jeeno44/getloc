﻿angular.module('isz').directive('lotItem', ['$mdDialog', 'toastService', 'appsecurity', 'roleChangedEventService', '$location', 'commonVariables',
    function ($mdDialog, toastService, appsecurity, roleChangedEventService, $location, commonVariables) {

        return {
            restrict: 'EA',
            replace: false,
            templateUrl: '/js/common/directives/lotItem/template/lotItemTemplate.html',
            controller: ['$scope', '$location', '$timeout','commonVariables', 'controlsService', 'appsecurity',
                function ($scope, $location, $timeout, commonVariables, controlsService, appsecurity) {

                    $scope.handle = function ( lot, control ) {

                        commonVariables.currentLot=lot;
                        if ( control.opName == 'delegate' ) {
                            $mdDialog.show( {
                                templateUrl: '/js/documents/templates/expertsModal.html',
                                controller: function ($scope, $http, $mdDialog,appsecurity, apiService,commonVariables,control, controlsService) {
                                    $scope.selectedExperts = [];
                                    $scope.lot=commonVariables.currentLot;

                                    $http({
                                        url: apiService.expertsRoute,
                                        headers: appsecurity.getSecurityHeaders(),
                                        method: 'GET'
                                    }).then(function (response) {
                                        $scope.experts = response.data;

                                    }, function (response) {
                                        var str = 'Возникла ошибка при получении данных с сервера. ';
                                        toastService.errorResponseShow(str, response);
                                    })

                                    $scope.send = function () {

                                        var body = {
                                            expertList: []
                                        };

                                        for (var i = 0; i < $scope.selectedExperts.length; i++) {
                                            body.expertList.push($scope.selectedExperts[i].users.id)
                                        }

                                        controlsService.executeCommand(control, $scope.lot.id, body);

                                        $mdDialog.hide();
                                    }

                                    $scope.exit = $mdDialog.hide;

                                    $scope.exists = function (expert) {
                                        return $scope.selectedExperts.indexOf(expert) > -1;
                                    }

                                    $scope.toggle = function (expert) {
                                        var idx = $scope.selectedExperts.indexOf(expert);
                                        if (idx > -1) $scope.selectedExperts.splice(idx, 1);
                                        else $scope.selectedExperts.push(expert);
                                    }
                                },
                                locals:{ 'control':control}
                            }).then(function () {

                            })
                        } else if (control.opName === 'make_data_notice' || control.opName === 'edit_data_notice') {
                            commonVariables.currentLot.fillAllInfo().then(function(){
                                commonVariables.canOpenNotice = true;
                            })
                        } else if ( control.opName == 'posted_coordinator' ) {
                            $mdDialog.show( {
                                templateUrl: '/js/documents/templates/zakupkiUploadModal.html',
                                controller: ['$scope', 'apiService', function ($scope, apiService) {
                                    $scope.control = control;
                                    $scope.ecpInitComplete = false;
                                    $scope.ecpCertSelected = null;
                                    $scope.ecpInitError = "";
                                    $scope.ecpStore = null;
                                    $scope.ecpCertUnsignedValue = "";
                                    $scope.remove = function () {
                                        $mdDialog.hide();
                                    }

                                    $scope.close = $mdDialog.hide;

                                    $scope.applyECP = function(){
                                        var foivId = appsecurity.currentExpertGroup.common.id;
                                        $http({
                                            method: 'GET',
                                            url: apiService.serverRoute + 'integrations/zakupki_binary/' + foivId,
                                            headers: appsecurity.getSecurityHeaders()
                                        }).then(function(result) {
                                            var hex = result.data.data;
                                            var userCert = $scope.ecpStore.Certificates.Find(CAPICOM_CERTIFICATE_FIND_SHA, $scope.ecpCertSelected.id).Item(1);
                                            $scope.ecpSigner.Certificate = userCert;
                                            $scope.ecpSignedData.ContentEncoding = CADESCOM_BASE64_TO_BINARY;
                                            $scope.ecpSignedData.Content = hex;

                                            try {
                                                $scope.ecpCertUnsignedValue = $scope.ecpSignedData.SignCades($scope.ecpSigner, CADESCOM_CADES_BES, true);
                                            } catch (err) {
                                                $scope.ecpInitError = "Ошибка создания подписи";
                                            }

                                            $scope.ecpStore.Close();
                                        });

                                    }

                                    $scope.initECP = function () {

                                        if (!$scope.ecpInitComplete) {
                                            $scope.ecpStore = ObjCreator("CAPICOM.Store");
                                            $scope.ecpSigner = ObjCreator("CAdESCOM.CPSigner");
                                            $scope.ecpSignedData = ObjCreator("CAdESCOM.CadesSignedData");

                                            if ($scope.ecpStore) {
                                                function formatDate(d) {
                                                    try {
                                                        d = new Date(d);
                                                        return ('0' + d.getDate()).slice(-2) + '.' + ('0' + (d.getMonth() + 1)).slice(-2) + '.' + d.getFullYear();
                                                    } catch (e) {
                                                        return '';
                                                    }
                                                }

                                                $scope.ecpStore.Open(CAPICOM_CURRENT_USER_STORE, CAPICOM_MY_STORE, CAPICOM_STORE_OPEN_MAXIMUM_ALLOWED);

                                                var certCnt = $scope.ecpStore.Certificates.Count;

                                                if (certCnt > 0) {
                                                    for (var i = 1; i <= certCnt; i++) {
                                                        var cert = $scope.ecpStore.Certificates.Item(i);
                                                        $scope.ecpCertList = [];
                                                        $scope.ecpCertList.push({'id' : cert.Thumbprint, 'name': cert.GetInfo(6) + ' (' + formatDate(cert.ValidFromDate) + ' - ' + formatDate(cert.ValidToDate) + ')'});
                                                    }
                                                } else {
                                                    $scope.ecpInitError = "На Вашем ПК неустановлена квалифицированная электронная подпись";
                                                }
                                            } else {
                                                $scope.ecpInitError = "Ваш броузер или устарел или неустановленн КриптоПро";
                                            }
                                        }

                                        return false;
                                    }

                                    $scope.send = function(control){
                                        controlsService.executeCommand(control, lot.id);
                                        $mdDialog.hide();
                                    }

                                    $scope.upload = function(){
                                        var url = apiService.baseUrl + "/api/integrations/zakupki_freshdoc/" + lot.id;
                                        var xhr = new XMLHttpRequest();
                                        xhr.open("GET", url, true);
                                        xhr.responseType = "blob";
                                        var headers = appsecurity.getSecurityHeaders();
                                        xhr.setRequestHeader('X-Access-Token', headers['X-Access-Token']);
                                        xhr.setRequestHeader('X-Common-Id', headers['X-Common-Id']);
                                        xhr.onreadystatechange = function () {
                                            if (xhr.readyState == 4) {
                                                var a = document.createElement("a");
                                                document.body.appendChild(a);
                                                a.style = "display: none";
                                                var url = window.URL.createObjectURL(xhr.response);
                                                a.href = url;
                                                a.download = "Извещение.zip";
                                                a.click();
                                                setTimeout(function(){
                                                    window.URL.revokeObjectURL(url);
                                                }, 100)
                                            }
                                        };
                                        xhr.send(null);
                                    }
                                }]
                            } )
                        } else {
                            commonVariables.currentLot = lot;
                            controlsService.executeCommand(control, lot.id);

                        }
                    }

                    $scope.handleCustom = function (lot, name) {
                        commonVariables.currentLot = lot;
                        if (name == 'download_documents') {
                            $mdDialog.show({
                                templateUrl: '/js/documents/templates/downloadDocumentsModal.html',
                                controller: 'DownloadDocuments',
                                locals: {
                                    lotId: lot.id
                                }
                            })
                        } else if (name == 'upload_documents') {
                            //по-моему это уже не используется
                            $mdDialog.show({
                                templateUrl: '/js/documents/templates/uploadDocumentsModal.html',
                                controller: 'UploadDocuments'
                            })
                        } else if (name = 'make_data_notice') {
                            commonVariables.canOpenNotice = true;
                        }


                    }

                    $scope.lotClicked = function (lot) {
                        if (appsecurity.currentRole.isAllowReadLot(lot.common)) {
                            commonVariables.currentLot = lot;
                            $location.path('/' + commonVariables.currentSubSystem + '/lot/' + lot.id);
                            commonVariables.lotTitleFilter.value('');
                        } else {
                            toastService.show('У Вас нет прав доступа для просмотра лота', false);
                        }
                    }
                    $scope.$on('$mdMenuOpen',function () {
                        $timeout(function () {
                            // var el=document.querySelector('.md-active.md-open-menu-container');
                            var $el=$('.md-active.md-open-menu-container');
                            var scrHeight=$(window).height();
                            var top=$el.offset().top;
                            var elHeight=$el.outerHeight(true);
                            var offset=scrHeight-top-elHeight;
                            if (offset<0) {
                                $el.css("top",top+offset-5);
                            }

                        },0)

                    })
                }],
            link: function (scope) {
                scope.canControlSection = appsecurity.currentRole.isAllowControlSections(scope.lot.common);
            }
        }
    }]);
