﻿angular.module( 'isz' ).directive( 'navbarSearch', ['$timeout', function ( $timeout ) {

    return {
        restrict: 'E',       
        templateUrl: '/js/common/directives/navbar/navbarSearch/navbarSearchTemplate.html',
        controller: ['$scope', '$location', 'commonVariables', function ( $scope, $location, commonVariables ) {
            $scope.searchChanged = function ( val ) {
                commonVariables.lotTitleFilter.value( val );
            };
            $scope.mainPage = ($location.path() != '/plans' || $location.path() != '/docs')? false : true;
            $scope.searchClick = function () {
                // if ( $location.path() != '/plans' && commonVariables.currentSubSystem === 'plans' ) {
                //     $location.path( '/plans' );
                // }
                // if ( $location.path() != '/docs' && commonVariables.currentSubSystem === 'docs' ) {
                //     $location.path( '/docs' );
                // }
                // if ( $location.path() != '/acceptance' && commonVariables.currentSubSystem === 'acceptance' ) {
                //     $location.path( '/acceptance' );
                // }

            };


        }],
      
        link:function ( scope, el) {
                el.on( 'click', function () {
                    el.find( 'input' ).focus();

                } );
                //$timeout( function () {
                //    el.find( 'input' ).focus();
                //}, 10 );
        } 
    }
}] )