﻿angular.module('isz').service('commonVariables', ['Observer','serverVariables',
    function (Observer,serverVariables) {

        var self = this;

        this.requestArr=[];
        this.currentLot;
        this.currentUserRole;
        this.currentExpertGroup;
        this.currentUserPlan;
        this.lotTitleFilter = new Observer('');

        this.yearsFilter = [];
        this.expenseTypesFilter = [];
        this.procurementTypesFilter = [];
        this.depertmentsFilter = [];
        this.statusFilter = [];
        this.myDepartments = [];
        // this.priceRange = {
        //     min: 0,
        //     max: Number.POSITIVE_INFINITY
        // };
        this.priceRange = {
            min: '',
            max: ''
        };

        this.departments = [];
        this.expertsStatuses = [];
        this.successStatuses = [];
        this.plansStatuses = [];
        this.fcpActions = [];
        this.fcpActionsFilter = [];
        this.canOpenNotice=false;
        this.canOpenAcceptanceDateComment=false;
        this.acceptanceDepartments=[];
        this.acceptanceStatuses=[];

        this.revertFilters = function () {
            self.priceRange.min = 0;
            self.priceRange.max = Number.POSITIVE_INFINITY;
            self.expenseTypesFilter.length = 0;
            self.procurementTypesFilter.length = 0;
            self.depertmentsFilter.length = 0;
            self.yearsFilter.length = 0;
            self.lotTitleFilter.value('');
            self.statusFilter.length = 0;
        };

        this.lotsInGroups = [];

        // For pagePreLoader directive
        this.isLoading = false;

        // Can be: docs, plans;
        this.currentSubSystem = 'plans';
        var currYear = new Date();
        this.planCurrentYear = currYear.getFullYear();

        this.enterInLotTimeStamp;

        serverVariables.getSettings().then(function(){

            for (var i= 0;i<self.subsystemArray.length;i++){
                if (self.subsystemArray[i].name==='pocedures') {
                    self.subsystemArray[i].url=serverVariables.serverSettings.procedureUrl;
                    break;
                }
            }
        })


            this.subsystemArray = [
                {
                    name: 'plans',
                    title: 'Планирование',
                    icon: 'dashboard',
                    url: '/plans',
                    active: true,
                    visible: true,
                    pages: [
                        {
                            name: 'plans',
                            title: 'Главная',
                            url: '/plans',
                            icon: 'dashboard',
                            visible: false,
                            active: true
                        },
                        {
                            name: 'my_lots_plans',
                            title: 'Мои лоты',
                            url: '/plans/my',
                            icon: 'dashboard',
                            visible: false,
                            active: false
                        },
                        {
                            name: 'current_plan',
                            title: 'Текущий план',
                            url: '/plans/current',
                            icon: 'dashboard',
                            visible: false,
                            active: false
                        },
                        {
                            name: 'next_plan',
                            title: 'Проектируемый план',
                            url: '/plans/next',
                            icon: 'dashboard',
                            visible: false,
                            active: false
                        },
                        {
                            name: 'archive_plan',
                            title: 'Архивный план',
                            url: '/plans/archive',
                            icon: 'dashboard',
                            visible: false,
                            active: false
                        },
                        {
                            name: 'limits',
                            title: 'Лимиты',
                            url: '/plans/limits',
                            icon: 'tune',
                            visible: false,
                            active: false
                        },
                    ]
                },
                {
                    name: 'docs',
                    title: 'Документы',
                    icon: 'description',
                    url: '/docs',
                    active: false,
                    visible: true,
                    pages: [
                        {
                            name: 'docs',
                            title: 'Главная',
                            icon: 'description',
                            url: '/docs',
                            active: false,
                            visible: false
                        },
                        {
                            name: 'my_lots_docs',
                            title: 'Мои лоты',
                            icon: 'description',
                            url: '/docs/my',
                            active: false,
                            visible: false

                        }
                    ]
                },
                {
                    name: 'pocedures',
                    title: 'Процедуры',
                    url: '',
                    icon: 'assignment',
                    visible: true,
                    active: false,
                    pages: []
                },
                {
                    name: 'acceptance',
                    title: 'Приемка',
                    url: '/acceptance',
                    icon: 'assignment_turned_in',
                    visible: true,
                    active: false,
                    pages: [
                        {
                            name: 'acceptance',
                            title: 'Главная',
                            icon: 'description',
                            url: '/acceptance',
                            active: false,
                            visible: true
                        }
                    ]
                },
                {
                    name: 'statistic',
                    title: 'Статистика',
                    url: 'http://arm.isz.gosbook.ru',
                    icon: 'insert_chart',
                    visible: true,
                    active: false,
                    pages: [
                        //{
                        //    name: 'statistic_svod',
                        //    title: 'Сводная статистика',
                        //    icon: 'description',
                        //    url: '#',
                        //    active: false,
                        //    visible: true
                        //},
                        //{
                        //    name: 'statistic_profile',
                        //    title: 'Профиль заказчика',
                        //    icon: 'description',
                        //    url: '/#',
                        //    active: false,
                        //    visible: true
                        //},
                        //{
                        //    name: 'statistic_profile',
                        //    title: 'Сообщения',
                        //    icon: 'description',
                        //    url: '/#',
                        //    active: false,
                        //    visible: true
                        //}
                    ]
                }];

            this.currentMenuItem = function (url) {
                var name = url.slice(1).split('/');

                this.subsystemArray.forEach(function (subsystem) {
                    if (name[0] === subsystem.name) {
                        subsystem.active = true;
                    } else {
                        subsystem.active = false;
                    }

                    subsystem.pages.forEach(function (page) {
                        if (page.url === url) {
                            page.active = true;
                        } else {
                            page.active = false;
                        }

                    })
                });

            };


        this.setMenuItemVisibility = function (role) {
            var mappedPermsPlan = role.perms.plans.map(function (pr) {
                return pr.code;
            });
            var mappedPermsDocs = role.perms.docs.map(function (pr) {
                return pr.code;
            });
            self.subsystemArray[0].pages[0].visible = mappedPermsPlan.indexOf('find_all_lots')>-1;
            self.subsystemArray[0].pages[1].visible = mappedPermsPlan.indexOf('read_my_lots')>-1;
            self.subsystemArray[0].pages[2].visible = mappedPermsPlan.indexOf('read_current_plan')>-1;
            self.subsystemArray[0].pages[3].visible = mappedPermsPlan.indexOf('read_projected_plan')>-1;
            self.subsystemArray[0].pages[4].visible = mappedPermsPlan.indexOf('read_archive_plans')>-1;
            self.subsystemArray[0].pages[5].visible = mappedPermsPlan.indexOf('read_limits')>-1;
            self.subsystemArray[1].pages[0].visible = mappedPermsDocs.indexOf('documents_read_section_all_documents_in_his_group')>-1
                ||mappedPermsDocs.indexOf('documents_read_section_documents')>-1;
            self.subsystemArray[1].pages[1].visible = mappedPermsDocs.indexOf('documents_read_section_documents_in_his_group')>-1
                ||mappedPermsDocs.indexOf('documents_read_section_documents')>-1;

            for ( var i=0;i<self.subsystemArray.length;i++){
                self.subsystemArray[i].visible=false;
                for (var j=0;j<self.subsystemArray[i].pages.length;j++){
                    if (self.subsystemArray[i].pages[j].visible) {
                        self.subsystemArray[i].visible=true;
                    }
                }
            }
            /**
             * todo:хардкод для 3 и 4 подсистем
             */
            self.subsystemArray[2].visible=self.subsystemArray[3].visible=self.subsystemArray[4].visible=true;
        }




        this.readOnlyFields ={
            dfcp:[
                //"title",
                //"number",
                //"goals",
                //"tasks",
                //"actualityJustification",
                //"practicalUsage",
                //"expectedResults",
                //"expenseType",
                //"procurementStartDate",
                //"prepaymentContractPercentage",
                //"nks",
                //"govProgram",
                //"fcpActionTask",
                //"fcpAction",
                //"fcpActionSubaction"
            ],
            sstp:[

            ]
        };
        this.versionsOfCurrentPlan=[];
        this.versionPlan={};
        this.plans=[];
        this.selectedPlan=this.plans[0];
        this.newLotsFilter=true;
        this.changedLotsFilter=true;

    }]);