﻿/**
 * контроллер wysiwyg редактора
 * @param {object} - объект редактируемой сущности (лот, этап, работа)
 * @param {field} - поле сущности
 */

angular.module( 'isz' ).controller( 'TextEditorModalController', ['$scope', 'object', 'field',
    function ( $scope, object, field ) {
        $scope.text = object[field];

        $scope.save = function () {
            object[field] = $scope.text;
            object.patch( field );
        }

    }] );