angular.module( 'isz' ).filter( 'lotsFilter', ['commonVariables', function ( commonVariables ) {

    function getRegularExpFromArray( arr ) {
        return new RegExp( arr.map( function ( str ) {
            return '(' + str + ')';
        } ).join( '|' ), 'i' );

    }

    return function ( items, lotGroup ) {
        var valueMatchPattern = new RegExp( commonVariables.lotTitleFilter.lastValue, 'i' );

        var itemsToReturn = commonVariables.lotTitleFilter.lastValue == ''
                ? items
                : items.filter( function ( item ) {
                    return angular.isString( item.title ) && valueMatchPattern.test( item.title );
                } );

        if ( itemsToReturn ) {
            if ( commonVariables.expenseTypesFilter.length > 0 ) {
                var expenseTypesPattern = getRegularExpFromArray( commonVariables.expenseTypesFilter );
                itemsToReturn = itemsToReturn.filter( function ( item ) {
                    return item.expenseType != null &&
                        expenseTypesPattern.test( item.expenseType.description );
                } );
            }

            if ( commonVariables.procurementTypesFilter.length > 0 ) {
                var procurementTypesPattern = getRegularExpFromArray( commonVariables.procurementTypesFilter );
                itemsToReturn = itemsToReturn.filter( function ( item ) {
                    return item.procurementType != null &&
                        procurementTypesPattern.test( item.procurementType.description );
                } );
            }

            if ( commonVariables.depertmentsFilter.length ) {
                var departmentsPattern = getRegularExpFromArray( commonVariables.depertmentsFilter );
                itemsToReturn = itemsToReturn.filter( function ( item ) {
                    return item.common != null && angular.isString( item.common.shortName ) &&
                        departmentsPattern.test( item.common.shortName );
                } );
            }

            if ( commonVariables.yearsFilter.length ) {
                itemsToReturn = itemsToReturn.filter( function ( item ) {
                    return commonVariables.yearsFilter.indexOf( item.id ) > -1;
                } )
            }
          

            itemsToReturn = itemsToReturn.filter( function ( item ) {
                var min=isNaN(parseFloat(commonVariables.priceRange.min))?0:parseFloat(commonVariables.priceRange.min);
                var max=isNaN(parseFloat(commonVariables.priceRange.max))?Number.POSITIVE_INFINITY:parseFloat(commonVariables.priceRange.max);
                if (min<=max) {
                    return item.pricing >= min*1000 &&
                        item.pricing <= max*1000;
                } else {
                    return item.pricing >= min*1000 &&
                        item.pricing <= Number.POSITIVE_INFINITY;
                }

            } );
            if (lotGroup&&lotGroup.hasFilteredLots) {
                lotGroup.hasFilteredLots = itemsToReturn.length > 0;
            }

        }

        return itemsToReturn;
    }
}] );

angular.module( 'isz' ).filter( 'lotsCategoriesFilter', ['commonVariables', 'appsecurity', function ( commonVariables, appsecurity ) {

    return function ( categories ) {
        var valueMatchPattern = new RegExp( commonVariables.lotTitleFilter.lastValue, 'i' );

        if ( angular.isUndefined( appsecurity.currentRole ) ) {
            return [];
        }

        var categoriesToReturn = appsecurity.currentRole.isAllowReadAllSections() && commonVariables.lotTitleFilter.lastValue == ''
            ? categories
            : categories.filter( function ( category ) {
                for ( var i = 0; i < category.lotsByStatus.length; i++ ) {
                    if ( appsecurity.currentRole.isAllowReadSectionByGroup( category.lotsByStatus[i].common )
                        && hasValueMatch( category.lotsByStatus[i] ) ) {
                        return true;
                    }
                }
            } );

        return categories;

        function hasValueMatch( item ) {
            return angular.isString( item.title ) && valueMatchPattern.test( item.title );
        }
    }
}] );