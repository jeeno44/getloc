/**
 * Created by pol on 24.08.2015.
 */

angular.module( 'isz' ).directive( 'togglePlanType', [function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: '/js/common/directives/navbar/togglePlanType/template/togglePlanTypeTemplate.html',
        controller: ['$scope', '$rootScope', 'plansService', function ( $scope, $rootScope, plansService ) {


            $scope.$watch( 'currPlan', function () {
                plansService.planType = $scope.currPlan;
                $rootScope.$broadcast( 'planTypeChange' );
            } );
            $scope.currPlan = 'current';
            $scope.planTypes =
            {
                current: 'Текущий план',
                next: 'Проектируемый план'
            };
            $scope.showFlag = false;
            $scope.showButton = function () {
                $scope.showFlag = true;
            }
            $scope.hideButton = function () {
                $scope.showFlag = false;
            }

        }]
    };
}] );
