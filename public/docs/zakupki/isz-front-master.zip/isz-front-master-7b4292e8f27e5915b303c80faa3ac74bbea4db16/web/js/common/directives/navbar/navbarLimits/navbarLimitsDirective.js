﻿angular.module( 'isz' ).directive( 'navbarLimits', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/navbarLimits/navbarLimitsTemplate.html',
        controller: ['$scope', 'roleChangedEventService', 'appsecurity','$location',
            function ( $scope, roleChangedEventService, appsecurity, $location ) {
                roleChangedEventService.listen( function () {
                    $scope.permissions = appsecurity.currentRole.permissions;
                } );
                $scope.buttLimitsClick = function () {
                    $location.path( '/plans/limits' );
                };
            }]
    }
}] )