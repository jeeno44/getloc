angular.module( 'isz' ).directive( 'mdExpando', function () {

    function getSiblings( $node ) {
        var $childs = $node.parent().children();
        var nodeIndex = [].indexOf.call( $childs, $node[0] );

        $childs.splice( nodeIndex, 1 );
        return $childs;
    }

    return {
        restrict: 'A',
        replace: false,
        scope: true,
        link: function ( scope, $element,attr ) {
            if (!attr.mdExpando){
                scope.icon = 'expand_more';
            } else {
                scope.icon=attr.mdExpando;
            }

            //scope.icon = 'expand_more';


            scope.changeIcon = function () {
                var $toExpand = getSiblings( $element.parent() );

                if ( scope.icon === 'expand_more' ) {
                    scope.icon = 'expand_less';
                    $toExpand.removeClass( 'expand-detailed' ).addClass( 'expand-minimized' );
                } else {
                    scope.icon = 'expand_more';
                    $toExpand.removeClass( 'expand-minimized' ).addClass( 'expand-detailed' );
                }
            }

            scope.$on( '$destroy', function () {
                scope.changeIcon = null;
                scope.icon = null;
            } );
        }
    }
} );