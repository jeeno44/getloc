﻿angular.module( 'isz' ).directive( 'plansNextPlanNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/pagesPlans/nextPlan/nextPlanNavbarTemplate.html',
        controller: ['$scope', '$location', 'roleChangedEventService', 'appsecurity','commonVariables',
          function ( $scope, $location, roleChangedEventService, appsecurity,commonVariables ) {
              if ( !appsecurity.hasOwnProperty( 'currentRole' ) ) {
                  appsecurity.getUserInfo().then( function () {
                      $scope.permissions = appsecurity.currentRole.permissions;
                      $scope.expertGroup = appsecurity.currentExpertGroup;
                  } );
              } else {
                  $scope.permissions = appsecurity.currentRole.permissions;
                  $scope.expertGroup = appsecurity.currentExpertGroup;
              }
              $scope.commonVariables=commonVariables;
          }]
    }
}] )