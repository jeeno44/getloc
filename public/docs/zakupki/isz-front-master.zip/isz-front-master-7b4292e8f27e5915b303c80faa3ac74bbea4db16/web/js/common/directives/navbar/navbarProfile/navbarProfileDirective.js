﻿angular.module( 'isz' ).directive( 'navbarProfile', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/navbarProfile/navbarProfileTemplate.html',
        controller: ['$scope', 'roleChangedEventService', 'appsecurity','$location',
    function ( $scope, roleChangedEventService, appsecurity, $location) {
                roleChangedEventService.listen( function () {
                    $scope.permissions = appsecurity.currentRole.permissions;
                } );
                $scope.buttClick = function () {
                    $location.path( '/profile' )
                }
            }]
    }

}] )