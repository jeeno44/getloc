/**
 * Created by pol on 09.03.2016.
 */
angular.module('isz').directive('acceptanceLotsNavbar',[function(){
    return {
        restrict:'E',
        templateUrl:'/js/common/directives/navbar/pagesAcceptance/lots/acceptanceLotsNavbarTemplate.html',
        controller:['$scope','appsecurity',function($scope,appsecurity){
            if ( !appsecurity.hasOwnProperty( 'currentRole' ) ) {
                appsecurity.getUserInfo().then( function () {
                    $scope.permissions = appsecurity.currentRole.permissions;
                } );
            } else {
                $scope.permissions = appsecurity.currentRole.permissions;
            }
        }]
    }
}]);
