﻿angular.module( 'isz' ).factory( 'WorkTypeFactory', ['$http', '$q', 'apiService', 'appsecurity', 'WorkKindFactory', 'toastService',
    function ( $http, $q, apiService, appsecurity, WorkKindFactory, toastService ) {

        function WorkTypeFactory( opts ) {

            this.id = opts.id;
            this.title = opts.title;
            this.type = opts.type || null;
            this.workKinds = [];
            this.financing = opts.financing || 0;
            this.executionDate = opts.executionDate;
            this.executionTerm = opts.executionTerm || null
            this.executionDateTerm = opts.executionDateTerm||0;
            this.startingDate = opts.startingDate;
            this.startDate = opts.startDate || null;
            this.executionType = opts.executionType;
            this.result = opts.result || null;
            this.qualitativeChar = opts.qualitativeChar || null;
            this.quantativeChar = opts.quantativeChar || null;
            this.pricePerUnit = opts.pricePerUnit || 0;
            this.volume = opts.volume || 0;
            this.specRequirements=opts.specRequirements||null;
            this.warranty=opts.warranty||null;
            this.gosAccred=opts.gosAccred||null;
            this.nameOis=opts.nameOis||null;
            this.volumeOis=opts.volumeOis||null;
            this.nmckJustification=opts.nmckJustification||null;

            if ( opts.workKinds ) {
                for ( var i = 0; i < opts.workKinds.length; i++ ) {
                    var workKind = new WorkKindFactory( opts.workKinds[i], this.id );
                    this.workKinds.push( workKind );
                }
            }
        }

        WorkTypeFactory.prototype = {
            update: function () {
                var workType = this;
                var defer = $q.defer();

                $http( {
                    method: 'PUT',
                    url: apiService.workTypesRoute + '/' + workType.id,
                    data: workType,
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {
                    toastService.show( 'Тип работ/услуг успешно обновлен', false );
                    defer.resolve();
                }, function ( response ) {
                    var str='Возникла ошибка при обновлении Типа работ/услуг. ';
                    toastService.errorResponseShow(str,response);
                    defer.reject();
                } )

                return defer.promise;
            },
            create: function () {
                var workType = this;
                var defer = $q.defer();

                $http( {
                    method: 'POST',
                    url: apiService.workTypesRoute,
                    data: workType,
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {
                    workType.id = response.data.id;
                    toastService.show( 'Тип работ/услуг успешно добавлен', false );
                    defer.resolve();
                }, function ( response ) {
                    var str='Возникла ошибка при добавлении Типа работ/услуг. ';
                    toastService.errorResponseShow(str,response);
                    defer.reject();
                } )

                return defer.promise;
            },
            remove: function () {

                var workType = this;
                var defer = $q.defer();

                $http( {
                    method: 'DELETE',
                    url: apiService.workTypesRoute + '/' + workType.id,
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {
                    toastService.show( 'Тип работ/услуг успешно удален', false );
                    defer.resolve();
                }, function ( response ) {
                    var str='Возникла ошибка при удалении Типа работ/услуг. ';
                    toastService.errorResponseShow(str,response);
                    defer.reject();
                } );

                return defer.promise;
            },
            save: function(){
                var defer = $q.defer();
                var workType=this;
                $http({
                    method:'PUT',
                    url: apiService.workTypesRoute+'/'+workType.id,
                    data:workType,
                    headers:appsecurity.getSecurityHeaders()
                }).then(function(response){
                    defer.resolve();
                },function(response){
                    toastService.errorResponseShow('Ошибка при сохранении ТР(У).',response);
                    defer.reject()
                });
                return defer.promise;
            },
            patch: function () {
                var workType = this,
                    objToSave = {};

                [].forEach.call( arguments, function ( key ) {
                    if ( angular.isString( key ) && key in workType &&
                        ( !angular.isObject( workType[key] ) || angular.isDate( workType[key] ) ) ) {
                        objToSave[key] = workType[key];
                    }
                } );

                if ( Object.keys( objToSave ).length ) {
                    $http( {
                        method: 'PATCH',
                        data: objToSave,
                        url: apiService.workTypesRoute + '/' + workType.id,
                        headers: appsecurity.getSecurityHeaders()
                    } ).then( function ( response ) {

                    }, function ( response ) {
                        toastService.show( 'Произошла ошибка при обновлении типа работ/услуг', true );
                    } );
                }
            },
            financingChanged: function ( patch, stage ) {
                stage.financing = stage.getWorkTypeFinancingSumm();
                if ( patch ) {
                    //this.patch( 'financing' );
                    //stage.patch( 'financing' );
                }
            }
        }
        return WorkTypeFactory;
    }] )