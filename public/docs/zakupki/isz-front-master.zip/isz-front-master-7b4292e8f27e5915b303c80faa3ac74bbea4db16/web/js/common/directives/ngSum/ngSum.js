angular.module( 'isz' ).directive( 'ngSum', function () {

    function getCallProperties( scope, pathInstruction ) {
        var paths = pathInstruction.split( /\.|(\[[0-9]+\])/ )
                                   .filter( function ( path ) { return Boolean( path ); } )
                                   .map( function ( path ) { return path.replace( /\[|\]/g, '' ) } ),
            length = paths.length,
            i = 0,
            callProperties = {
                destination: scope,
                context: this
            };

        for ( ; i < length && callProperties.destination[paths[i]]; i++ ) {
            if ( i === length - 1 && length > 1 ) {
                callProperties.context = callProperties.destination;
            }
            callProperties.destination = callProperties.destination[paths[i]];
        }

        return callProperties;
    }

    return {
        restrict: 'A',
        replace: false,
        link: function ( scope, $element, attrs ) {
            var instructions = attrs.ngSum.split( /\s+in\s+/ );

            scope.$watch(
                function ( scope ) {
                    return getCallProperties( scope, instructions[0] ).destination;
                },
                function ( value ) {
                    var callProps = getCallProperties( scope, instructions[1] );
                    if ( angular.isFunction( callProps.destination ) ) {
                        callProps.destination.call( callProps.context, value );
                    }
                } );
        }
    }
} );