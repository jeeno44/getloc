angular.module( 'isz' ).filter( 'calendarStatuses', ['translate', function ( translate ) {

    return function ( calendarLots, statusesRu ) {
        var statusesEn = statusesRu.map( function ( statusRu ) {
            return translate.status( 'en', statusRu );
        } );

        return statusesEn.length == 0
            ? calendarLots
            : calendarLots.filter( function ( calendarLot ) {
                return statusesEn.indexOf( calendarLot.statusId ) != -1;
            } );
    }
}] );

angular.module( 'isz' ).filter( 'calendar_year_statuses', ['translate', function ( translate ) {

    return function ( item, statusesRu ) {
        var keys, statusesEn;

        keys = Object.keys( item );
        statusesEn = statusesRu.map( function ( statusRu ) {
            return translate.status( 'en', statusRu );
        } );

        if ( statusesEn.length == 0 ) {
            return keys.reduce( function ( count, key ) {
                return count + item[key];
            }, 0 );
        }

        return keys.reduce( function ( count, key ) {
            return count + ( statusesEn.indexOf( key ) == -1
                        ? 0
                        : item[key] );
        }, 0 );
    }
}] );

angular.module( 'isz' ).filter( 'calendar_year_events', ['translate', function () {

    return function ( items, eventNamesRu ) {
        return eventNamesRu.length
                    ? items.filter( function ( item ) {
                        return eventNamesRu.indexOf( item.title ) > -1;
                    } )
                    : items;
    }
}] );

angular.module( 'isz' ).filter( 'calendar_details_statuses', ['translate', function () {

    return function ( items, statusesRu ) {
        return statusesRu.length
                    ? items.filter( function ( item ) {
                        return statusesRu.indexOf( item.statusRu ) > -1;
                    } )
                    : items;
    }
}] );

angular.module( 'isz' ).filter( 'calendar_details_events', ['translate', function ( translate ) {

    return function ( items, eventNamesRu ) {
        return eventNamesRu.length
                    ? items.filter( function ( item ) {
                        return eventNamesRu.indexOf( translate.calendar.events( 'ru', item ) ) > -1;
                    } )
                    : items;
    }
}] );

angular.module( 'isz' ).filter( 'calendar_gant_events', ['translate', function ( translate ) {

    return function ( items, eventNamesRu ) {
        return eventNamesRu.length
                    ? items.filter( function ( item ) {
                        return eventNamesRu.indexOf( translate.calendar.events( 'ru', item.type ) ) > -1;
                    } )
                    : items;
    }
}] );
