﻿angular.module( 'isz' ).directive( 'numberOnlyInput', ['toastService','counterService', function ( toastService, counterService ) {
    return {
        restrict: 'EA',

        template: '<input style="width:100%;"  min="{{inputMin}}" max="{{inputMax}}" name="{{inputName}}" ng-model="inputValue" ng-change="inputChange" ng-disabled="locked" ng-blur="inputBlur()" aria-label="input"/>',
        scope: {
            inputValue: '=',
            inputName: '=',
            inputChange: '=',
            locked: '=',


            inputBlur: '&',
            inputMin: '=',
            inputMax: '='
        },
        link: function ( scope, elm, attrs ) {
            //if ( 'required' in attrs ) {
            //    counterService.notify( 1, scope.$parent.name );
            //    counterIncrased = true;
            //
            //    scope.$on( 'remainingRequiredFields', function ( event, count ) {
            //        if ( counterIncrased ) {
            //            count.blank++;
            //            count.emptyFields.push($element[0].attributes['model'].value );
            //        }
            //    } );
            //
            //}

            scope.$watch( 'inputValue', function ( newValue, oldValue ) {
                var arr = String( newValue ).split( "" );

                if ( arr.length ) {
                    oldValue = oldValue || '';

                    if ( arr.length === 1 && ( arr[0] == '-' || arr[0] === '.' ) ) {
                        scope.inputValue = oldValue;
                    }

                    if ( arr.length === 2 && newValue === '-.' ) {
                        scope.inputValue = oldValue;
                    }
                    if ( isNaN( newValue ) ) {
                        scope.inputValue = oldValue;
                    }

                }
            } );

            elm.on( 'change', function () {
                var val = scope.inputValue * 1
                if ( val < scope.inputMin ) {
                    scope.inputValue = scope.inputMin;
                    toastService.show( 'Установленное значение не может быть меньше ' + scope.inputMin, true );
                }

                if ( val > scope.inputMax ) {
                    scope.inputValue = scope.inputMax;
                    toastService.show( 'Установленное значение не может быть больше ' + scope.inputMax, true );
                }
            } );
        }
    };
}] );