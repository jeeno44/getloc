/**
 * Created by pol on 15.12.2015.
 */
angular.module('isz').controller('BlockingCtrl',['$scope','serverVariables',function($scope,serverVariables){

    $scope.goBack = function () {
        localStorage.clear();
        var settings=serverVariables.serverSettings;
        window.location=settings.authServer+'/logout?redirect_uri='+settings.productServer+'/oauth2/authorize&client_id='+settings.clientId+'&response_type=token';
    };
}])
