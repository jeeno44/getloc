﻿angular.module('isz')
    .controller('HomeCtrl', ['$scope', '$location', 'appsecurity', 'commonVariables', 'roleChangedEventService', 'serverVariables',
        function ($scope, $location, appsecurity, commonVariables, roleChangedEventService, serverVariables) {
            $scope.userRoles = appsecurity.userRoles;
            $scope.currentSystem = commonVariables.currentSubSystem;
            commonVariables.enterInLotTimeStamp = null;
            appsecurity.getUserInfo().then(function () {
                $scope.userInfo = appsecurity.userInfo;
                $scope.userGroups = appsecurity.expertGroups;
                $scope.currentGroup = appsecurity.currentExpertGroup;
                if ($scope.currentGroup) {
                    $scope.currentGroupChanged();
                }
                $scope.editProfile = appsecurity.currentRole.permissions.editProfile;


            });
            $scope.goBack = function () {
                localStorage.clear();

                var settings = serverVariables.serverSettings;
                window.location = settings.authServer + '/logout?redirect_uri=' + settings.productServer + '/oauth2/authorize&client_id=' + settings.clientId + '&response_type=token';
            };

            $scope.login = function () {

                if ($scope.personalData) {
                    //Переход на подсистему процедур
                    if ($scope.currentSystem === 'procs') {
                        window.location = serverVariables.serverSettings.procedureUrl;
                    } else {
                        $location.path('/' + $scope.currentSystem);
                    }

                }

            };
            $scope.subsystemChange = function () {
                commonVariables.currentSubSystem = $scope.currentSystem;
                appsecurity.currentRole.subsystemChanged();
            }
            $scope.currentRoleChanged = function () {
                if ($scope.currentRole) {
                    appsecurity.currentExpertGroup=$scope.currentGroup;
                    localStorage["expertGroup"] = appsecurity.currentExpertGroup.id;
                    appsecurity.changeCommon();
                    commonVariables.revertFilters();

                    appsecurity.currentRole = $scope.currentRole;
                    localStorage['role'] = $scope.currentRole.code;
                    appsecurity.currentRole.subsystemChanged();
                    roleChangedEventService.roleChangeTrigger($scope.currentRole);
                }

               
            }
            $scope.currentGroupChanged = function () {

                var groupRoles = $scope.userInfo.groupRoles.filter(function (gr) {
                    return gr.expertGroup.id===$scope.currentGroup.id;
                }).map(function (ob) {
                    return ob.expertRole.name;
                });
                $scope.userRoles=appsecurity.userRoles.filter(function (role) {
                    return groupRoles.indexOf(role.code)>-1;
                })
            }

        }]);