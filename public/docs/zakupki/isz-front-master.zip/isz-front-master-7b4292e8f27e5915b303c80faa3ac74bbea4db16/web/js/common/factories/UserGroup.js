﻿angular.module( 'isz' ).factory( 'UserGroup', [function () {

    function UserGroup( opts ) {
        this.name = opts.expertGroup.title || 'Группа без имени';
        this.common = opts.expertGroup.common;
        this.id = opts.expertGroup.id;
        this.type = opts.expertGroup.type;
        this.weight=this.getWeight(opts.expertGroup.type);
        if (opts.expertRole&&opts.expertRole.name) {
            this.expertRoleName=opts.expertRole.name;
        } else {
            this.expertRoleName=null;
        }

    }

    UserGroup.prototype = {
        getWeight:function (type){
            var weight;
            if (type) {
                switch (type){
                    case 'common':
                        weight=3;
                        break;
                    case 'expert':
                        weight=2;
                        break
                    default :
                        weight=1;
                        break;
                }
            } else {
                weight=0;
            }
            return weight;
        }
    };

    return UserGroup;
}] );