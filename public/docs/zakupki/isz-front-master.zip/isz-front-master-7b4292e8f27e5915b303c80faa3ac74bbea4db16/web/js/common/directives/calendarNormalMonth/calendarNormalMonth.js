angular.module( 'isz' ).directive( 'calendarNormalMonth', ['$compile', 'translate', function ( $compile, translate ) {

    function getEventsMarkup( day, types, amountToShow, allowedStatuses ) {
        var markup = '<div class="calendar_events">' +
                        '<div class="day_panel" layout="row">' +
                            '<div class="calendar_date">' + day.day + '</div>' +
                        '</div>';

        if ( types.length && amountToShow ) {
            var i, event, references;

            for ( i = 0; i < amountToShow && i < types.length; i++ ) {
                event = day.events[types[i]];

                references = allowedStatuses.length
                            ? event.references.filter( function ( refer ) {
                                return allowedStatuses.indexOf( refer.statusRu ) > -1;
                            } )
                            : event.references;

                markup += '<div class="calendar_event">' +
                               '<div class="event_name dotdotdot">' + event.nameRu + '</div>' +
                               '<div class="event_count">: ' + references.length + '</div>' +
                           '</div>';
            }
        }

        return markup + '</div>';
    }

    function getAmountToshow() {
        var maxHeight = parseFloat( getComputedStyle( document.querySelector( '.calendar_days' ) ).width );
        return Math.floor(( maxHeight / 7 - 20 ) / 20 );
    }

    return {
        restrict: 'EA',
        replace: false,
        link: function ( scope, $element, attrs ) {
            scope.$on( 'forceRedraw', forceRedraw );
            scope.container = $element;

            function forceRedraw() {
                var types = scope.day.existedTypes || [],
                    amountToShow = getAmountToshow();

                if ( scope.selectedEvents.length ) {
                    types = types.filter( function ( type ) {
                        return scope.selectedEvents.indexOf( translate.calendar.events( 'ru', type ) ) > -1;
                    } );
                }

                $element.toggleClass( 'calendar_today', scope.day.date.isSame( moment(), 'day' ) )
                        .toggleClass( 'out_of_month', scope.day.outOfMonth )
                        .html( getEventsMarkup( scope.day, types, amountToShow, scope.selectedStatuses ) );

                if ( types.length ) {
                    var diff = amountToShow - types.length,
                        dateiledBtn = $compile(
                                    '<div class="day_details">' +
                                    ( diff < 0 ? '<span class="not_fit_count">+ еще ' + -diff + '</span>' : '' ) +
                                    '<md-button aria-label="Развернуть" class="md-icon-button aqua">' +
                                        '<ng-md-icon icon="info_outline" size="18"></ng-md-icon>' +
                                    '</md-button>' +
                                    '</div>'
                                    )( scope );

                    dateiledBtn.on( 'click', function ( ev ) {
                        angular.element( document.querySelector( '#month_view' ) )
                            .append( $compile( '<div calendar-details day="day" container="container" ordinal="$index % 7 + 1" view="dateViewIndex" allowedevents="selectedEvents"  allowedstatuses="selectedStatuses"></div>' )( scope ) );
                    } );
                    $element[0].querySelector( '.day_panel' ).appendChild( dateiledBtn[0] );
                }
            }

        }
    }
}] );