﻿angular.module( 'isz' ).directive( 'plansCurrentPlanNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/pagesPlans/currentPlan/currentPlanNavbarTemplate.html',
        controller: ['$scope', '$location', 'roleChangedEventService', 'appsecurity','commonVariables',
          function ( $scope, $location, roleChangedEventService, appsecurity,commonVariables ) {
              if ( !appsecurity.hasOwnProperty( 'currentRole' ) ) {
                  appsecurity.getUserInfo().then( function () {
                      $scope.permissions = appsecurity.currentRole.permissions;
                      $scope.expertGroup = appsecurity.currentExpertGroup;


                  } );
              } else {
                  $scope.permissions = appsecurity.currentRole.permissions;
                  $scope.expertGroup = appsecurity.currentExpertGroup;
              }
              $scope.commonVariables=commonVariables;
          }]
    }
}] )