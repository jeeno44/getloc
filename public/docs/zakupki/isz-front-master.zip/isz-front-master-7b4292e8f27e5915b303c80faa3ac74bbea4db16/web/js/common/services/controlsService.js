angular.module( 'isz' ).service( 'controlsService', ['$http', 'appsecurity', 'apiService', 'lotsService', 'toastService', '$q','commonVariables',
    function ( $http, appsecurity, apiService, lotsService, toastService, $q, commonVariables ) {

        this.executeCommand = function ( control, id, body, forceFlag ) {

            var defer = $q.defer();
            //var id = control.url.slice(control.url.lastIndexOf('/')+1);

            var controlUrl = [];
            for (var i in control) {
                controlUrl.push(i + '=' + control[i]);
            }

            $http( {
                method: control.method,
                url: apiService.baseUrl + control.url + '?' + controlUrl.join('&') + '&userId=' + appsecurity.userInfo.id,
                headers: appsecurity.getSecurityHeaders(),
                data: body ? body : {}
            } ).then( function ( response ) {
                if (!forceFlag && id){
                    lotsService.updateOneLot(id).then(function(){
                        defer.resolve();
                    });
                } else {
                    defer.resolve();
                }


            }, function ( response ) {
                toastService.errorResponseShow('Произошла ошибка при выполнении команды.',response);
                defer.reject();
            } );

            return defer.promise;
        }
    }] );