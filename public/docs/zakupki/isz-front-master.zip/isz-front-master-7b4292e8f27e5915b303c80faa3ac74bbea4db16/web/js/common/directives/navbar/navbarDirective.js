﻿angular.module('isz').directive('navbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/navbarTemplate.html',
        controller: ['$scope', '$location', '$route', 'commonVariables', 'appsecurity', 'roleChangedEventService',
            function ( $scope, $location, $route, commonVariables, appsecurity, roleChangedEventService ) {
                appsecurity.getUserInfo().then( function () {
                    //$scope.permissions = appsecurity.currentRole.permissions;
                    //$scope.depZakFlag = appsecurity.currentRole.code.indexOf( 'Rukovoditel_depzak' ) !== -1;
                } );
                $scope.$on('$routeChangeSuccess', function () {
                    $scope.currentRoute = $route.current.$$route;
                    $scope.show = $location.path() !== '/';
                    //componentHandler.upgradeElements(document.querySelector('body'));
                });
            }]
    };

}])