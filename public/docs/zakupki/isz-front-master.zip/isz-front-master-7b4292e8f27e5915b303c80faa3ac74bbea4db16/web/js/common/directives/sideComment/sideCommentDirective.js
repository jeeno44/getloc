﻿angular.module( 'isz' ).directive( 'sideComment', ['$timeout','$window',function ($timeout,$window) {

    var VERTICAL_SHIFT = 35,
        HORIZONTAL_SHIFT = 3;

    return {
        restrict: 'E',
        replace: true,
        templateUrl: '/js/common/directives/sideComment/sideCommentTemplate.html',
        scope: {
            fieldId: '@',
            titleRu: '@'
        },
        controller: 'commentsController',
        link: function ( scope, element, attrs ) {
            setLot();

            function setLot(){
                var elem=document.querySelector( '.commentsInnerContainer' );
                if (elem&&elem.getBoundingClientRect) {
                    var containerRect = elem.getBoundingClientRect();
                    if (containerRect.width>0) {
                        var css = { left: containerRect.width - 50 + 'px' };
                        //css = {right: containerRect.width - 140 + 'px'};

                        if ( angular.isNumber( scope.$parent.commentsZIndexCounter ) ) {
                            css.zIndex = ++scope.$parent.commentsZIndexCounter;
                        }

                        if ( attrs.shift ) {
                            css.marginTop = attrs.shift * VERTICAL_SHIFT + 'px';
                            css.marginLeft = attrs.shift * HORIZONTAL_SHIFT + 'px';
                        }

                        element.css( css );
                    } else {
                        setTimeout(setLot,100);
                    }
                }


            }

            scope.$on( 'commentsUpdates', function ( event, fieldId ) {
                if ( !scope.hasComments && fieldId == scope.fieldId ) {
                    scope.hasComments = scope.commentControl && Boolean( angular.isArray( scope.commentControl.comments )
                        && scope.commentControl.comments.length );
                }
            } );
           angular.element(window).on('resize',setLot);
        }
    };
}] )