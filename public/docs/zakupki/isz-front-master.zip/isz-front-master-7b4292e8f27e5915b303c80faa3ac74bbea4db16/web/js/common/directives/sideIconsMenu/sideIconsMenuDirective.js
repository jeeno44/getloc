/**
 * Created by pol on 04.04.2016.
 */
angular.module('isz').directive('sideIconsMenu',function () {
    return {
        restrict:'E',
        templateUrl:'/js/common/directives/sideIconsMenu/sideIconsMenuTemplate.html',
        replace:true,
        controller:['$scope','commonVariables',function ($scope,commonVariables) {
            $scope.menuArray = commonVariables.subsystemArray;
        }]
    }
})
