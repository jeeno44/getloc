/**
 * Created by pol on 25.01.2016.
 */
angular.module('isz').directive('navbarSmallMenu',function(){
    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/navbarSmallMenu/navbarSmallMenuTemplate.html',
        controller: ['$scope','$mdSidenav', 'appsecurity','$location',
            function ( $scope, $mdSidenav, appsecurity, $location) {
                $scope.openSideNav = function(){
                    $mdSidenav('left-sidenav').toggle();
                }
            }]
    }
});