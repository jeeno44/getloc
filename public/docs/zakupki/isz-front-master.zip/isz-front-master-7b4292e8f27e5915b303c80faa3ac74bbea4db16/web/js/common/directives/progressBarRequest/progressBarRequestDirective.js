/**
 * Created by pol on 14.04.2016.
 */
angular.module('isz').directive('progressBarRequest',[function () {
    return {
        restrict:'E',
        templateUrl:'/js/common/directives/progressBarRequest/progressBarRequestTemplate.html',
        replace:false,
        controller:['$scope','commonVariables',function ($scope,commonVariables) {
            $scope.reqArr=commonVariables.requestArr;
            $scope.determinateValue=0;

            var step=0;
            $scope.$watch('reqArr.length',function (new_val,old_val) {
                // var defer=$q.defer();
                if ($scope.reqArr.length) {
                    if (old_val<new_val||step===0) {

                        step=100/new_val;
                    }

                    $scope.determinateValue=100-Math.round(new_val*step);
                    $scope.isLoading=true;
                } else {
                    $scope.isLoading=false;
                }
            })

        }]
    }
}])