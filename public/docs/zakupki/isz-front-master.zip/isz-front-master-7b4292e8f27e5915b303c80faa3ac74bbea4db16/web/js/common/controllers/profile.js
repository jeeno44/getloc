﻿angular.module('isz').controller('profile', ['$scope', '$http', '$location', 'appsecurity', 'roleChangedEventService', 'lotsService', 'commonVariables', 'apiService', 'toastService', 'serverVariables',
    function ($scope, $http, $location, appsecurity, roleChangedEventService, lotsService, commonVariables, apiService, toastService, serverVariables) {

        $scope.userRoles = appsecurity.userRoles;
        $scope.expertGroups = appsecurity.expertGroups;
        commonVariables.enterInLotTimeStamp = null;

        appsecurity.getUserInfo().then(function () {

            if (!appsecurity.currentRole.permissions.readProfile) {
                toastService.show('У Вас нет прав для просмотра данной страницы');
                $location.path('/');
            }

            $scope.userInfo = appsecurity.userInfo;

            $scope.currentRole = appsecurity.currentRole;
            $scope.editProfile = appsecurity.currentRole.permissions.editProfile;

            $scope.currentExpertGroup = appsecurity.currentExpertGroup;
            $scope.currentExpertGroupChanged()
        });
        
        /**
         * функция изменения пароля
         */
        $scope.changePassword = function () {
            if ($scope.changePasswordForm.$valid) {
                var data = {
                    oldPassword: $scope.oldPassword,
                    newPassword: $scope.newPassword,
                    confirmPassword: $scope.confirmPassword
                }
                $http({
                    method: 'POST',
                    headers: appsecurity.getSecurityHeaders(),
                    url: apiService.serverRoute + 'users/passwords',
                    data: data
                }).then(function () {
                    toastService.show('Пароль успешно обновлен', false);
                }, function (response) {
                    var str = 'Возникла ошибка при смене пароля. ';
                    toastService.errorResponseShow(str, response);
                });
            }
        }
        
        /**
         * функция выхода
         * -очищаем localStorage и перенаправляем на страницу авторизации
         * 
         */
        $scope.Logout = function () {
            localStorage.clear();

            var settings = serverVariables.serverSettings;
            window.location = settings.authServer + '/logout?redirect_uri=' + settings.productServer + '/oauth2/authorize&client_id=' + settings.clientId + '&response_type=token';
        }

        $scope.currentRoleChanged = function () {
            if ($scope.currentRole){
                appsecurity.currentExpertGroup = $scope.currentExpertGroup;
                localStorage["expertGroup"] = appsecurity.currentExpertGroup.id;
                appsecurity.changeCommon();
                commonVariables.revertFilters();

                appsecurity.currentRole = $scope.currentRole;
                //commonVariables.currentUserRole=$scope.currentRole;
                localStorage['role'] = $scope.currentRole.code;
                appsecurity.currentRole.subsystemChanged();
                roleChangedEventService.roleChangeTrigger($scope.currentRole);

            }
        }

        $scope.currentExpertGroupChanged = function () {


            var groupRoles = appsecurity.userInfo.groupRoles.filter(function (gr) {
                return gr.expertGroup.id===$scope.currentExpertGroup.id;
            }).map(function (ob) {
                return ob.expertRole.name;
            });
            $scope.userRoles=appsecurity.userRoles.filter(function (role) {
                return groupRoles.indexOf(role.code)>-1;
            })
            // if ($scope.currentRole) {
            //
            //     appsecurity.currentRole.subsystemChanged();
            // }
        }

        $scope.$watch(function ($scope) {
            return $scope.newPassword;
        }, makeValidIfPasswordsMatched);

        $scope.$watch(function ($scope) {
            return $scope.confirmPassword;
        }, makeValidIfPasswordsMatched);

        function makeValidIfPasswordsMatched() {
            var isMatched = $scope.newPassword === $scope.confirmPassword;
            $scope.changePasswordForm.confirmPassword.$setValidity('isMatch', isMatched);
        }
    }]);