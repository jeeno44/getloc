﻿angular.module('isz').directive('plansLotsNavbar', [function () {

    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/navbar/pagesPlans/lots/lotsPlansNavbarTemplate.html',
        controller: ['$scope', '$location','$mdSidenav', 'roleChangedEventService', 'appsecurity',
            function ( $scope, $location,$mdSidenav, roleChangedEventService, appsecurity ) {

                if ( !appsecurity.hasOwnProperty( 'currentRole' ) ) {
                    appsecurity.getUserInfo().then( function () {
                        $scope.permissions = appsecurity.currentRole.permissions;
                        $scope.depZakFlag = appsecurity.currentRole.code.indexOf( 'Rukovoditel_depzak' ) !== -1;
                        $scope.expertGroup = appsecurity.currentExpertGroup;
                    } );

                } else {
                    $scope.permissions = appsecurity.currentRole.permissions;
                    $scope.depZakFlag = appsecurity.currentRole.code.indexOf( 'Rukovoditel_depzak' ) !== -1;
                    $scope.expertGroup = appsecurity.currentExpertGroup;
                }
                $scope.openSideNav = function(){
                    $mdSidenav('left-sidenav').toggle();
                }
            }]
    }
}])