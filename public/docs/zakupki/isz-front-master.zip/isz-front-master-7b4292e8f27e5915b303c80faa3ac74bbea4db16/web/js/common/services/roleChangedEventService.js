angular.module( 'isz' ).service( 'roleChangedEventService', ['$rootScope','commonVariables', function ( $rootScope,commonVariables ) {

    this.roleChangeTrigger = function (role) {
        $rootScope.$broadcast( "roleChanged" );
        commonVariables.setMenuItemVisibility(role);
    }

    this.listen = function ( callback ) {
        $rootScope.$on( "roleChanged", callback );
    }

}] );