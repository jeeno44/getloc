﻿angular.module('isz').directive('filters', [function () {


    return {
        restrict: 'E',
        templateUrl: '/js/common/directives/filters/filters.html',
        controller: ['$scope', '$route', '$location', 'commonVariables', '$http',  'apiService','$q', 'appsecurity','toastService',
            function ($scope, $route, $location, commonVariables, $http, apiService, $q, appsecurity,toastService) {

                var lastReaquestYears;

                function isLastRequest(time) {
                    return lastReaquestYears === time;
                }

                function getFilters() {
                    return $scope.selectedItem3.map(function (year) {
                        return 'filters[financings.year.start][0]=' + year;
                    }).join('&');
                }

                $scope.$on('$routeChangeSuccess', function () {
                    if ($route.current.$$route) {
                        $scope.currentPageName = $route.current.$$route.controller;
                        if ($location.path() == '/profile' && !(appsecurity.currentRole&&appsecurity.currentRole.permissions&&appsecurity.currentRole.permissions.readProfile)) {
                            $location.path('/');
                        }
                    }
                });

                $scope.arrayItems = ['Прочие нужды', 'НИОКР'];
                $scope.arrayItems2 = ['Открытый конкурс', 'Электронный аукцион', 'Запрос котировок'];
                $scope.arrayItems3 = ['2015', '2016', '2017', '2018'];
                $scope.selectedItem3 = commonVariables.selectedItem3;
                $scope.arrayItems4 = commonVariables.fcpActions;

                $scope.commonVariables = commonVariables;

                $scope.yearChanged = function () {
                    if ($scope.selectedItem3.length) {
                        (function (time) {
                            lastReaquestYears = time;
                            selectRequest(apiService.lotsRoute + '?limit=999999&' + getFilters())
                                .then(function (response) {
                                        if (response.status===204){
                                            toastService.show('Нет данных по запросу', false);
                                        }
                                    if (isLastRequest(time)) {
                                        lastReaquestYears = undefined;
                                        if (angular.isArray(response.data)) {
                                            commonVariables.yearsFilter = response.data.map(function (lot) {
                                                return lot.id;
                                            });
                                        } else {
                                            commonVariables.yearsFilter = [null];
                                        }
                                    }
                                },
                                function (response) {
                                    var str = 'Возникла ошибка при получении лотов. ';
                                    toastService.errorResponseShow(str, response);
                                });

                        })(new Date().getTime());
                    } else {
                        lastReaquestYears = undefined;
                        commonVariables.yearsFilter = [];
                    }
                }
                $scope.removeFilters = function () {
                    if  (commonVariables.expenseTypesFilter&&commonVariables.expenseTypesFilter.length){
                        commonVariables.expenseTypesFilter=[];
                    }
                    if (commonVariables.procurementTypesFilter&&commonVariables.procurementTypesFilter.length){
                        commonVariables.procurementTypesFilter=[];
                    }
                    if ($scope.selectedItem3&&$scope.selectedItem3.length) {
                        $scope.selectedItem3=[];
                        $scope.yearChanged();
                    }
                    if  (commonVariables.depertmentsFilter&&commonVariables.depertmentsFilter.length){
                        commonVariables.depertmentsFilter=[];
                    }
                    if (commonVariables.statusFilter&&commonVariables.statusFilter.length){
                        commonVariables.statusFilter=[];
                    }
                    if (commonVariables.priceRange.min!==''||commonVariables.priceRange.max!='') {

                        commonVariables.priceRange.min='';
                        commonVariables.priceRange.max= '';
                    }
                    if (commonVariables.fcpActionsFilter&&commonVariables.fcpActionsFilter.length) {
                        commonVariables.fcpActionsFilter=[];
                    }
                }
                function selectRequest(url) {
                    var defer = $q.defer();
                    $http({
                        method: 'GET',
                        headers: appsecurity.getSecurityHeaders(),
                        url: url
                    }).then(function (response) {
                            defer.resolve(response);
                        }, function () {
                            defer.reject();
                        }
                    )
                    return defer.promise;
                }

            }]
    }

}])