﻿angular.module( 'isz' ).service( 'commentsService', ['$rootScope', 'CommentControl', 'CommentFactory',
    function ( $rootScope, CommentControl, CommentFactory ) {

        this.fillCommentControls = function ( lot, responseData ) {
            var commentsExists = responseData.comments && responseData.comments !== null;
            if ( responseData.controls && responseData.controls.fields ) {
                for ( var comContr in responseData.controls.fields ) {
                    lot.commentControls[comContr] = new CommentControl( responseData.controls.fields[comContr] );
                    if ( commentsExists ) {
                        lot.commentControls[comContr].addComments( getCommentsByTitle( responseData, comContr ) );
                    }
                }
            }
            lot.canAddComments = (responseData.controls && responseData.controls.fieldsCredentials && responseData.controls.fieldsCredentials.length
                &&responseData.controls.fieldsCredentials.indexOf('add')>-1);



            $rootScope.$broadcast( 'lotCommentControlsAdded' );
        }

        function getCommentsByTitle( responseData, fieldId ) {
            var comments = [];

            for ( var i = 0; i < responseData.comments.length; i++ ) {
                // if ( responseData.comments[i].fieldId == fieldId ) {
                //     comments.push( responseData.comments[i] );
                // }
                if ( responseData.comments[i].field_id == fieldId ) {
                    comments.push( responseData.comments[i] );
                }
            }
            return comments;
        }

        this.getEmptyComment = function () {
            return new CommentFactory( {} );
        }
    }] )