/**
 * Created by pol on 29.09.2015.
 */
angular.module('isz').service('serverVariables',['$http','$q',function($http,$q){
    this.serverSettings;
    var self=this;
    this.getSettings = function(){
        var defer = $q.defer();
        if (angular.isDefined(this.serverSettings)){
            defer.resolve();
        } else {
            $http({
                method: 'GET',
                url: '/serverSettings.json'
            }).then(function (response) {
                self.serverSettings = response.data;
                defer.resolve();
            }, function (response) {
                toastService.show('��������� ������ ��� ������� �������� �������', true);
                defer.reject();
            });

        }
        return defer.promise;
    }
}]);
