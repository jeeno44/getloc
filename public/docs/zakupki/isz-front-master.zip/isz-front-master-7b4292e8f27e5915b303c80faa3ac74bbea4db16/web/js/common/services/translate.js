angular.module( 'isz' ).service( 'translate', [function () {

    function getTranlateFromObject( object, value, lang ) {
        if ( angular.isString( value ) && angular.isString( lang ) ) {
            switch ( lang.toLowerCase() ) {
                case 'ru': return object[value];
                case 'en':
                    for ( var keys = Object.keys( object ), i = keys.length ; i--; ) {
                        if ( object[keys[i]] == value ) {
                            return keys[i];
                        }
                    }
            }
        }
    }

    this.status = function ( lang, status ) {
        if ( angular.isString( status ) ) {
            var statuses = {
                'planning': 'Формирование',
                'approved': 'Утвержден',
                'draft': 'Черновик',
                'on_agreement': 'На согласовании',
                'on_completion': 'На доработке',
                'on_expertise': 'На экспертизе',
                'agreed': 'Согласован'
            };

            return getTranlateFromObject( statuses, status, lang );
        }
    };

    this.calendar = {
        events: function ( lang, event ) {
            var events = {
                'creationDate': 'Дата создания',
                'creation': 'Создание',

                'contractExecution': 'Дата контракта',
                'contract': 'Контракт',

                'procurement': 'Закупки',
                'procurementStartDate': 'Начальная дата закупок',
                'procurementStart': 'Начало закупок',
                'procurementEndDate': 'Конечная дата закупок',
                'procurementEnd': 'Конец закупок',

                'expertise': 'Экспертиза',
                'expertiseStart': 'Начало экспертизы',
                'expertiseEnd': 'Окончание экспертизы'
            };

            return getTranlateFromObject( events, event, lang );
        },
        timeRange: function ( lang, timeRange ) {
            var timeRanges = {
                'day': 'День',
                'week': 'Неделя',
                'month': 'Месяц',
                'year': 'Год'
            };

            return getTranlateFromObject( timeRanges, timeRange, lang );
        }
    };

    this.dates = function ( lang, date ) {
        var dates = {
            'today': 'сегодня',
            'lot.creationDate': 'дата создания',
            'lot.procurementStartDate': 'начало закупок',
            'lot.procurementEndDate': 'конец закупок',
            'lot.orderPublication': 'срок размещения извещения об осуществлении закупки',
            'stage.startDate':'дата начала этапа',
            'stage.executionDate':'дата окончания этапа',
            'workType.startDate':'дата начала работы',
            'workType.executionDate':'дата окончания работы',
            'lot.applicationDateTimeEnd':'дата и время окончания приема заявок',
            'lot.applicationDateTimeStart':'дата и время начала приема заявок',
            'lot.applicationVskrDateTime':'дата и время вскрытия заявок',
            'lot.kdDateTimeStartProvision':'дата и время начала предоставления (по местному времени)',
            'lot.kdDateTimeEndProvision':'дата и время окончания предоставления (по местному времени)',
            'lot.docClarificationEndDate':'Время и Дата окончания приема заявок на разъяснение положений КД',
            'lot.docClarificationStartDate':'Время и Дата начала приема заявок на разъяснение положений КД',
            'lot.applicationVskrDateTimeStart':'6 дней  окончания приема заявок на разъяснение положений КД',

        };

        return getTranlateFromObject( dates, date, lang );
    };

    this.requiredFieldName = function ( lang, field ) {
        if ( angular.isString( field ) ) {
            var fields = {
                'lot.title': 'Наименование лота',
                'lot.number': 'Номер (шифр) лота',
                'lot.expenseType': 'Направление расходов',
                'foundationOptions.govProgramBuffer.govProgram': 'Государственная программа',
                'foundationOptions.govProgramBuffer.fcp.fcp': 'Федеральная целевая программа',
                'foundationOptions.govProgramBuffer.fcp.fcpActionTask': 'Задача Федеральной целевой программы',
                'foundationOptions.govProgramBuffer.fcp.fcpAction': 'Мероприятие федеральной целевой программы',
                'foundationOptions.govProgramBuffer.fcp.fcpActionSubaction': 'Подмероприятие федеральной целевой программы',
                'foundationOptions.govProgramBuffer.subprogram.subProgram': 'Подпрограмма государственной программы',
                'foundationOptions.govProgramBuffer.subprogram.subProgramMainAction': 'Основное мероприятие подпрограммы',
                'foundationOptions.govProgramBuffer.subprogram.subProgramAction': 'Мероприятие подпрограммы',
                'foundationOptions.nonProgramBuffer.orderTitle': 'Наименование документа основания',
                'foundationOptions.nonProgramBuffer.orderNumber': 'Номер документа',
                'foundationOptions.nonProgramBuffer.orderDate': 'Дата подписания документа',
                'lot.nmckType': 'Метод определения и обоснования НМЦК',
                'lot.procurementType': 'Способ определения поставщика',
                'lot.procurementEndDate': 'Окончание проведения закупки',
                'stage.startDate':'Начало этапа',
                'stage.title': 'Наименование этапа',
                'workType.title': 'Наименование работы / услуги',
                'stage.executionType':'Окончание этапа',
                'workType.executionDate':'Окончания работы',
                'lot.okpd.length':'ОКПД2',
                'stage.executionTerm':'Срок окончания этапа',
                'stage.executionDate':'Дата окончания этапа',
                'lot.applicationPostAddress':'Адрес доставки заявок почтой',
                'lot.applicationDateTimeStart':'Дата и время начала приема заявок',
                'lot.applicationDateTimeEnd':'Дата и время окончания приема заявок',
                'lot.applicationVskrAddress':'Адрес проведения конкурса',
                'lot.applicationVskrDateTime':'Дата и время проведения конкурса',
                'lot.applicationRassmotrDateTime':'Дата рассмотрения и оценки заявок на участие в конкурсе (по местному времени)',
                'lot.applicationRassmotrAddress':'Место рассмотрения и оценки заявок на участие в конкурсе',
                'lot.kdMethodProvision':'Способы предоставления',
                'lot.kdDateTimeStartProvision':'Дата и время начала предоставления (по местному времени)',
                'lot.kdDateTimeEndProvision':'Дата и время окончания предоставления (по местному времени)',
                'lot.kdPlaceProvision':'Место предоставления',
                'lot.kdOrderProvision':'Порядок предоставления',
                'maxReportingDocDate':'Дата сдачи отчетной документации',
                'foundationOptions.govProgramBuffer.kbk.kbkExpenseType':'Вид расходов КБК',
                'lot.procurementStartDate': 'начало закупок',
                'lot.procurementEndDate': 'конец закупок',

            };
            return getTranlateFromObject( fields, field, lang );
        }
    }



}] );