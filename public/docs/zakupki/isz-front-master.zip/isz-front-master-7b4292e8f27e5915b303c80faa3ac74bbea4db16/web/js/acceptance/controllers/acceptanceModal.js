/**
 * Created by pol on 11.03.16.
 */
angular.module('isz').controller('acceptanceModal',['$scope','$mdDialog','$http','commonVariables',
    function($scope,$mdDialog,$http,commonVariables){
        $scope.close = $mdDialog.hide;
        $scope.lot=commonVariables.currentLot;
        $scope.lightArray=[
            {
                id:1,
                title:'Соответствует',
                name:'accept'
            },
            {
                id:2,
                title:'Соответствует не в полном объеме',
                name:'offer'
            },
            {
                id:3,
                title:'Не соответствует',
                name:'reject'
            }
        ]
}]);
