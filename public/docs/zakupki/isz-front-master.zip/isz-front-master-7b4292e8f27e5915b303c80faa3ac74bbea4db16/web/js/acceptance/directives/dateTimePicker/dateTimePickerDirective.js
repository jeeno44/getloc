/**
 * Created by pol on 12.03.2016.
 */
angular.module('isz').directive('iszDateTimePicker',function(){
   return {
       restrict: 'E',
       scope: {
           model: '=',
           label: '@',
           locked: '=',
           chooseFn: '&',
       },
       templateUrl:'/js/acceptance/directives/dateTimePicker/dateTimePickerTemplate.html',
       //controller: 'mdcDatePickerInputController',
       controller:['$scope', '$attrs', '$mdDialog',function($scope,$attrs,$mdDialog){
           $scope.timeShow=$attrs.hasOwnProperty('time');
           var formatt='LL';
           if ( $scope.model != null ) {

               if ($scope.timeShow) {
                   formatt='LLL';

               }
               $scope.selected = {
                   model: moment( $scope.model ).format( formatt ),
                   date: $scope.model
               };
           }
           else {
               $scope.selected = {
                   model: 'Дата не указана',
                   date: new Date(),
               };
           }

           $scope.openPicker = function ( ev ) {

               if ( $attrs.disabled == 'true' ) {
                   return;
               }

               $scope.yearSelection = false;

               $mdDialog.show( {
                   targetEvent: ev,
                   templateUrl: '/js/acceptance/directives/dateTimePicker/pickerModal/pickerModalTemplate.html',
                   controller: 'pickerModalController',
                   locals: { model: $scope.model, locale: $attrs.locale, mdTheme: $attrs.dialogMdTheme,timeShow:$scope.timeShow }
               } ).then( function ( selected ) {

                   $scope.dialName=$attrs.name;
                   if ( selected ) {


                           $scope.hasDate = true;
                           $scope.selected = selected;
                           $scope.model = selected.date;
                           $scope.hours=moment(selected.date).format('HH');

                           $scope.$$postDigest( function () {
                               var objectPaths = $attrs.model.split( '.' ),
                                   objectName = objectPaths[0],
                                   objectKeyName = objectPaths[1];

                               if ( 'saveOnChoose' in $attrs  ) {
                                   //$scope.$parent[objectName].patch( objectKeyName );
                                   $scope.$parent.$parent[objectName]=$scope.model;
                               }

                               if ( 'chooseFn' in $attrs ) $scope.chooseFn();
                           } )

                   }
               } );
           };
       }]

   };
});
