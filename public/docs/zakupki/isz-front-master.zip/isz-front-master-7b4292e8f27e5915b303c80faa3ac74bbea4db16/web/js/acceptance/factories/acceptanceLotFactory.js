/**
 * Created by pol on 10.03.2016.
 */
angular.module('isz').factory('AcceptanceLotFactory',[function(){
    function AcceptanceLotFactory(opts){
        this.title = opts.title;
        this.number = opts.number || '';
        this.contract = opts.contract||null;
        this.common = opts.common;
        this.stage = opts.stage||null;
        this.statusId=opts.statusId;
        this.iszNumber = opts.iszNumber;
        this.getFinYears(opts.financings);
        this.controls = [];
        this.configreControls(opts.controls || {});
        this.acceptanceDateMenu=[];
        this.isActive=false;
    }
    AcceptanceLotFactory.prototype ={
        getFinYears: function (finnacings) {
            this.finYears = '';
            if (angular.isArray(finnacings)) {
                var yearArrs = finnacings.map(function (fin) {
                    return fin.year * 1;
                });
                var min = yearArrs.reduce(function (x, y) {
                    return (x < y) ? x : y;
                }, yearArrs[0]);
                var max = yearArrs.reduce(function (x, y) {
                    return (x > y) ? x : y;
                }, 0);

                if (max == min) {
                    this.finYears = max;
                } else {
                    this.finYears = min + '-' + max;
                }
            }
        },
        configreControls: function (controls) {
            this.controls.length = 0;
            this.canEdit = false;


            if (!controls.entity) {
                return;
            }

            for (var i = 0; i < controls.entity.length; i++) {
                if (controls.entity[i].opName == 'edit') {
                    this.canEdit = true;
                } else {
                    controls.entity[i].icon = 'keyboard_arrow_right';
                    switch (controls.entity[i].opName) {
                        case 'send_to_completion':
                            controls.entity[i].icon = 'keyboard_arrow_left';
                            break;
                        case 'confirm':
                            controls.entity[i].icon = 'done';
                            break;
                        case 'delete':
                            controls.entity[i].icon = 'delete';
                            break;
                        case 'send_to_approve':
                            controls.entity[i].icon = 'keyboard_arrow_right';
                            break;
                        case 'send_to_monitor':
                            controls.entity[i].icon = 'keyboard_arrow_right';
                            break;
                        case 'send_to_coordinator':
                            controls.entity[i].icon = 'keyboard_arrow_right';
                            break;
                        case 'delegate':
                            controls.entity[i].icon = 'person';
                            break;
                        case 'posted_coordinator':
                            controls.entity[i].icon = 'publish';
                            controls.entity[i].value = 'Разместить в ЕИС';
                            break;
                        case 'make_data_notice':
                            controls.entity[i].icon = 'note_add';
                            controls.entity[i].value = 'Внести данные по извещению';
                            break;
                        case 'edit_data_notice':
                            controls.entity[i].icon = 'note_add';
                            controls.entity[i].value = 'Изменить данные по извещению';
                            break;
                        default:
                            controls.entity[i].icon = 'keyboard_arrow_left';
                            break;
                    }
                    this.controls.unshift(controls.entity[i]);
                }
            }
        },
    }

    return AcceptanceLotFactory;
}]);