/**
 * Created by pol on 10.03.2016.
 */
angular.module('isz').controller('acceptanceDateHistory',['$scope','$mdDialog','$http','appsecurity',
    function($scope,$mdDialog,$http,appsecurity){
        $scope.close=$mdDialog.hide;
        $scope.currentUser=appsecurity.userInfo.id;
        $scope.history=[];
        $http({
            method: 'GET',
            url: '/js/acceptance/moc_objects/moc_acceptanceDateHistory.json'
        }).then(function (response) {
            if (angular.isArray(response.data)) {
                for (var i=0;i<response.data.length;i++){
                    response.data[i].entityTitle=getTitleEntity(response.data[i]);
                }
                $scope.history = response.data.sort(function(a,b){
                    if (a.currDate> b.currDate) {
                        return -1;
                    }
                    if (a.currDate< b.currDate) {
                        return 1;
                    } else return 0;
                });
            }


        }, function (response) {
            toastService.show('Ошибка получения истории', true);

        });
        function getTitleEntity(entity){
            var resp;
            switch (entity.statusId) {
                case 'accept':
                    if (entity.userId===$scope.currentUser){
                        resp='Вы подтвердили дату';
                    } else {
                        resp='Участник комиссии подтвердил дату';
                    }
                    break;
                case 'offer':
                    if (entity.userId===$scope.currentUser){
                        resp='Вы предложили новую дату';
                    } else {
                        resp='Участник комиссии предложил новую дату';
                    }
                    break;
                case 'reject':
                    if (entity.userId===$scope.currentUser){
                        resp='Вы отказали в изменении';
                    } else {
                        resp='Участник комиссии отказал в изменении';
                    }
                    break;
                default:
                    if (entity.userId===$scope.currentUser){
                        resp='Вы установили дату';
                    } else {
                        resp='Участник комиссии установил дату';
                    }
                    break;
            }
            return resp;
        }
    }])