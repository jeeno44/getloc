/**
 * Created by pol on 10.03.2016.
 */
angular.module('isz').service('acceptanceLotsService',['$http', '$q','AcceptanceLotFactory','commonVariables',
    function($http,$q,AcceptanceLotFactory,commonVariables){
        this.acceptanceDateMenu=[];
        this.startLots=[];
        this.lots=[];
        var self= this;
        this.getAcceptanceDateMenu = function(){
            var defer = $q.defer();
            if (self.acceptanceDateMenu.length) {
                defer.resolve;
            } else {
                $http({
                    method: 'GET',
                    url: '/js/acceptance/moc_objects/moc_acceptanceDateMenu.json'
                }).then(function (response) {
                    if (angular.isArray(response.data)) {
                        self.acceptanceDateMenu = response.data;
                    }

                    defer.resolve();
                }, function (response) {
                    toastService.show('Ошибка получения данных меню', true);
                    defer.reject();
                });
            }
            return defer.promise;
        }
        this.getAcceptanceLots = function(){
            var defer = $q.defer();
            self.startLots.splice(0);
            self.lots.splice(0);
            var departments={};
            var statuses={}
            $http({
                method: 'GET',
                url: '/js/acceptance/moc_objects/moc_acceptanceLots.json'
            }).then(function (response) {
                if (angular.isArray(response.data)) {
                    self.startLots = response.data;
                }
                for (var i=0;i<self.startLots.length;i++){
                    var lot=new AcceptanceLotFactory(self.startLots[i]);
                    //self.lots.push(lot);

                        for (var j=0;j<self.acceptanceDateMenu.length;j++){
                            lot.acceptanceDateMenu.push(self.acceptanceDateMenu[j]);
                        }
                        lot.stage.acceptanceDateStatus.entityTitle=self.getTitleEntity(lot.stage.acceptanceDateStatus);
                        self.lots.push(lot);
                        departments[lot.common.shortName]=1;
                        statuses[lot.statusId]=1;

                }
                if (!commonVariables.acceptanceDepartments.length) {
                    Object.keys(departments).forEach(function(key){
                       commonVariables.acceptanceDepartments.push(key);
                    });
                }
                if (!commonVariables.acceptanceStatuses.length) {
                    Object.keys(statuses).forEach(function(key){
                        commonVariables.acceptanceStatuses.push(key);
                    });
                }
                defer.resolve();
            }, function (response) {
                toastService.show('Ошибка получения данных лотов', true);
                defer.reject();
            });
            return defer.promise;
        }
        this.getTitleEntity=function(entity){
            var resp;
            switch (entity.statusId) {
                case 'accept':
                   resp = 'Утверджена дата';
                    break;
                case 'offer':
                    resp= 'Предложена дата';
                    break;
                case 'reject':
                    resp='Отклонена дата';
                    break;
                default:

                    break;
            }
            return resp;
        }
}]);
