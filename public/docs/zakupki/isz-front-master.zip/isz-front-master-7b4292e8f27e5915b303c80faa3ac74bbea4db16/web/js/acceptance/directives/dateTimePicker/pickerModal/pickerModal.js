/**
 * Created by pol on 13.03.2016.
 */
angular.module('isz').controller('pickerModalController',['$scope','$mdDialog','$timeout',  '$document', 'model', 'locale', 'mdTheme','timeShow', function($scope,$mdDialog, $timeout,  $document, model, locale, mdTheme,timeShow ){
    $scope.currentDate = new Date();
    $scope.exit=$mdDialog.hide;
    function checkLocale( locale ) {
        if ( !locale ) {
            return ( navigator.language !== null ? navigator.language : navigator.browserLanguage ).split( '_' )[0].split( '-' )[0] || 'en';
        }
        return locale;
    }

    $scope.model = model;
    $scope.timeShow=timeShow;

    $scope.mdTheme = mdTheme ? mdTheme : 'default';

    var activeLocale;

    this.build = function ( locale ) {
        activeLocale = locale;

        moment.locale( activeLocale );
        var formatt;
        if ($scope.timeShow) {
            formatt='LLL';
        }

        if ( $scope.model != null ) {
            $scope.selected = {
                model: angular.isDate( $scope.model ) ? moment( $scope.model ).format(formatt) : $scope.model,
                date: $scope.model,
                hours:moment($scope.model).format('HH')*1,
                minutes:moment($scope.model).format('mm')*1
            };

            $scope.activeDate = moment( $scope.model );
        }
        else {
            $scope.selected = {
                model: undefined,
                date: new Date(),
                hours:0,
                minutes:0
            };
            $scope.activeDate = moment().minutes(0);
        }
        //$scope.hours=moment($scope.selected.date).format('HH')*1;
        //$scope.minutes=moment($scope.selected.date).format('mm')*1;
        $scope.moment = moment;

        $scope.days = [];
        //TODO: Use moment locale to set first day of week properly.
        $scope.daysOfWeek = [moment.weekdaysMin( 1 ), moment.weekdaysMin( 2 ), moment.weekdaysMin( 3 ), moment.weekdaysMin( 4 ), moment.weekdaysMin( 5 ), moment.weekdaysMin( 6 ), moment.weekdaysMin( 0 )];

        $scope.years = [];

        for ( var y = moment().year() - 100; y <= moment().year() + 100; y++ ) {
            $scope.years.push( y );
        }

        generateCalendar();
        generateTimes();
    };
    this.build( checkLocale( locale ) );

    $scope.previousMonth = function () {
        $scope.activeDate = $scope.activeDate.subtract( 1, 'month' );
        generateCalendar();
        $scope.select($scope.activeDate);
    };

    $scope.nextMonth = function () {
        $scope.activeDate = $scope.activeDate.add( 1, 'month' );
        generateCalendar();
        $scope.select($scope.activeDate);

    };
    $scope.addTime=function(){
        var formatt='LLL';
        $scope.activeDate = $scope.activeDate.add( 30, 'minutes' );
        for (var i=0;i<$scope.days.length;i++){
            if ( angular.isDefined( $scope.selected.model ) && $scope.days[i].isSame( $scope.selected.date, 'day' )) {
                $scope.days[i]=$scope.days[i].add(30,'minutes');
                break;
            }

        }

        var dat=$scope.activeDate;

        dat=moment(dat).minutes(dat.minutes());
        dat=moment(dat).hours(dat.hours());
        $scope.selected = {
            model: dat.format( formatt ),
            date: dat.toDate(),
            hours:moment(dat).format('HH')*1,
            minutes:moment(dat).format('mm')*1
        };
        selectDate();
        selectTime();
    }
    $scope.delTime = function(){
        var formatt='LLL';
        $scope.activeDate = $scope.activeDate.add( -30, 'minutes' );
        for (var i=0;i<$scope.days.length;i++){
            if ( angular.isDefined( $scope.selected.model ) && $scope.days[i].isSame( $scope.selected.date, 'day' )) {
                $scope.days[i]=$scope.days[i].add(-30,'minutes');
                break;
            }

        }

        var dat=$scope.activeDate;

        dat=moment(dat).minutes(dat.minutes());
        dat=moment(dat).hours(dat.hours());
        $scope.selected = {
            model: dat.format( formatt ),
            date: dat.toDate(),
            hours:moment(dat).format('HH')*1,
            minutes:moment(dat).format('mm')*1
        };
        selectDate();
        selectTime();
    }

    $scope.select = function ( day ) {
        var formatt;
        if ($scope.timeShow) {
            formatt='LLL';
            var dat=$scope.activeDate;
            dat=moment(dat).minutes(dat.minutes());
            dat=moment(dat).hours(dat.hours());
            day=day.minutes(dat.minutes());
            day=day.hours(dat.hours());
            $scope.selected = {
                model: day.format( formatt ),
                date: day.toDate(),
                hours:moment(dat).format('HH')*1,
                minutes:moment(dat).format('mm')*1
            };

        } else {
            formatt='LL';
            $scope.selected = {
                model: day.format( formatt ),
                date: day.toDate(),

            };

        }

        $scope.model = day.toDate();
        $scope.activeDate = moment( $scope.model );
        //generateCalendar();
        selectDate();
    };
    $scope.hourSelect=function(time){
        var formatt;
        formatt='LLL';
        var dat=$scope.activeDate;
        dat=moment(dat).minutes(dat.minutes());
        dat=moment(dat).hours(time.hour);
        $scope.selected = {
            model: dat.format( formatt ),
            date:  dat.toDate(),
            hours:time.hour,
            minutes:moment(dat).format('mm')*1
        };
        $scope.model=dat.toDate();
        $scope.activeDate = moment( $scope.model );
        selectTime();
    }

    $scope.selectYear = function ( year ) {
        $scope.yearSelection = false;

        $scope.selected.model = moment( $scope.selected.date ).year( year ).format( 'LL' );
        $scope.selected.date = moment( $scope.selected.date ).year( year ).toDate();
        $scope.model = moment( $scope.selected.date ).toDate();
        $scope.activeDate = $scope.activeDate.add( year - $scope.activeDate.year(), 'year' );

        generateCalendar();
    };
    $scope.displayYearSelection = function () {
        var calendarHeight = $document[0].getElementsByClassName( 'mdc-date-picker__calendar' )[0].offsetHeight;
        var yearSelectorElement = $document[0].getElementsByClassName( 'mdc-date-picker__year-selector' )[0];
        yearSelectorElement.style.height = calendarHeight + 'px';

        $scope.yearSelection = true;

        $timeout( function () {
            var activeYearElement = $document[0].getElementsByClassName( 'mdc-date-picker__year--is-active' )[0];
            yearSelectorElement.scrollTop = yearSelectorElement.scrollTop + activeYearElement.offsetTop - yearSelectorElement.offsetHeight / 2 + activeYearElement.offsetHeight / 2;
        } );
    };
    function selectDate(){
        for (var i=0;i<$scope.days.length;i++){
            $scope.days[i].selected = angular.isDefined( $scope.selected.model ) && $scope.days[i].isSame( $scope.selected.date, 'day' );
        }
    }
    function selectTime(){
        for (var i=0;i<24;i++){
            $scope.pickerTimes[i].selected=  angular.isDefined( $scope.selected.model ) && $scope.pickerTimes[i].hour=== $scope.selected.hours;
        }
    }
    function generateTimes(){
        var times=[];
        $scope.pickerTimes=[];
        for (var i =0; i<24;i++){
            var time={
                hour:i
            };
            time.selected = angular.isDefined( $scope.selected.model ) && time.hour=== $scope.selected.hours;
            time.now = time.hour==moment().hour();
            $scope.pickerTimes.push(time);
        }

    }
    function generateCalendar() {
        var days = [],
            previousDay = angular.copy( $scope.activeDate ).date( 0 ),
            firstDayOfMonth = angular.copy( $scope.activeDate ).date( 1 ),
            lastDayOfMonth = angular.copy( firstDayOfMonth ).endOf( 'month' ),
            maxDays = angular.copy( lastDayOfMonth ).date();

        $scope.emptyFirstDays = [];

        for ( var i = firstDayOfMonth.day() === 0 ? 6 : firstDayOfMonth.day() - 1; i > 0; i-- ) {
            $scope.emptyFirstDays.push( {} );
        }

        for ( var j = 0; j < maxDays; j++ ) {
            var date = angular.copy( previousDay.add( 1, 'days' ) );

            date.selected = angular.isDefined( $scope.selected.model ) && date.isSame( $scope.selected.date, 'day' );
            date.today = date.isSame( moment(), 'day' );

            days.push( date );
        }

        $scope.emptyLastDays = [];

        for ( var k = 7 - ( lastDayOfMonth.day() === 0 ? 7 : lastDayOfMonth.day() ) ; k > 0; k-- ) {
            $scope.emptyLastDays.push( {} );
        }

        $scope.days = days;
    }

    $scope.cancel = function () {
        $mdDialog.hide();
    };

    $scope.closePicker = function () {
        if ($scope.timeShow) {

              var  formatt='LLL';


            var dat=moment($scope.selected.date).hours($scope.selected.hours);
            dat=moment(dat).minutes($scope.selected.minutes);
            $scope.selected.date = dat.toDate();
            $scope.selected.model=dat.format( formatt );
        }
        $mdDialog.hide( $scope.selected );
    };
}]);