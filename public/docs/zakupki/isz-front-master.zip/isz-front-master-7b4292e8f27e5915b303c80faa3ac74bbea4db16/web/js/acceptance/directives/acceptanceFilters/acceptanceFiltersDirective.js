/**
 * Created by pol on 09.03.2016.
 */
angular.module('isz').directive('acceptanceFilters',[function(){
    return {
        restrict: 'E',
        templateUrl:'/js/acceptance/directives/acceptanceFilters/acceptanceFiltersTemplate.html',
        controller: ['$scope',function($scope){

        }]
    }
}]);
