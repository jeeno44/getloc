/**
 * Created by pol on 13.03.2016.
 */
angular.module('isz').directive('acceptanceDateComment',function(){
    return {
        restrict:'E',
        scope:{
            type:'='
        },
        templateUrl:'/js/acceptance/directives/acceptanceDateComment/acceptanceDateCommentTemplate.html',
        controller:['$scope','$attrs','commonVariables','appsecurity','acceptanceLotsService',function($scope,$attrs,commonVariables,appsecurity,acceptanceLotsService){
            $scope.lot=commonVariables.currentLot;
            $scope.commentTitle='';
            $scope.commentText='';
            $scope.selectedDate=null;
            $scope.showDatePicker=false;
            $scope.saveButtonText='';
            var type=$scope.type;
            var icon='';
            switch (type) {
                case 'accept':
                    $scope.commentType='Вы утвердили предложенное время';
                    $scope.saveButtonText='Утвердить';
                    icon='done';
                    break;
                case 'offer':
                    $scope.commentType='Вы предлагаете время: ';
                    $scope.showDatePicker=true;
                    $scope.saveButtonText='Предложить';
                    icon='event';
                    break;
                case 'reject':
                    $scope.commentType='Вы отклонили предложенное время';
                    $scope.saveButtonText='Отклонить';
                    icon='event_busy';
                    break;
            }
            $scope.exit=function(){
                commonVariables.canOpenAcceptanceDateComment=false;
            }
            $scope.close = function(){
                if ($scope.selectedDate) {
                   $scope.lot.stage.acceptanceDateStatus.workDate=$scope.selectedDate;

                }
                if (type==='accept') {
                    $scope.lot.stage.acceptanceDate=$scope.lot.stage.acceptanceDateStatus.workDate;
                }
                $scope.lot.stage.acceptanceDateStatus.statusId=type;
                $scope.lot.stage.acceptanceDateStatus.icon=icon;
                $scope.lot.stage.acceptanceDateStatus.comment=$scope.commentText;
                $scope.lot.stage.acceptanceDateStatus.currDate=(new Date());
                $scope.lot.stage.acceptanceDateStatus.userid=appsecurity.userInfo.id;
                $scope.lot.stage.acceptanceDateStatus.entityTitle=acceptanceLotsService.getTitleEntity($scope.lot.stage.acceptanceDateStatus);
                commonVariables.canOpenAcceptanceDateComment=false;
            }
        }]
    }
})