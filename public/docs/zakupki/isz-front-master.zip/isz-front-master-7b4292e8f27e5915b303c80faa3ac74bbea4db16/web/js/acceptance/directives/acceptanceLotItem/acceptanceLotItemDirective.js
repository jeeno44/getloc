/**
 * Created by pol on 09.03.16.
 */
angular.module('isz').directive('acceptanceLotItem',function(){
    return {
        restrict:'E',
        replace: false,
        templateUrl:'/js/acceptance/directives/acceptanceLotItem/acceptanceLotItemTemplate.html',
        controller:['$scope','commonVariables',function($scope,commonVariables){
            $scope.menuHidden=false;
            $scope.getStatus = function ( id ) {
                if ( id ) {
                    var stat = commonVariables.expertsStatuses.filter( function ( st ) {
                        return st.machineName === id;
                    } );
                    return stat[0].title;
                }
                return null;
            };
            $scope.showTooltip = function(){
                $scope.menuHidden=true;
            }
            $scope.hideTooltip = function(){
                $scope.menuHidden=false;
            }
        }]
    }
})