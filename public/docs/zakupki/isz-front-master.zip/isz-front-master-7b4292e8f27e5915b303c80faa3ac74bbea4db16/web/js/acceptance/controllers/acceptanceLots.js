/**
 * Created by pol on 09.03.2016.
 */
angular.module('isz').controller('acceptanceLots',['$scope','$mdDialog','appsecurity','commonVariables','acceptanceLotsService',
    function($scope,$mdDialog,appsecurity,commonVariables,acceptanceLotsService){
        $scope.commonVariables=commonVariables;
        commonVariables.isLoading = true;
        $scope.lots=acceptanceLotsService.lots;
        $scope.menuArray = commonVariables.subsystemArray;
        $scope.commentType='';


        commonVariables.currentMenuItem('/acceptance');

        appsecurity.getUserInfo().then(function(){
            acceptanceLotsService.getAcceptanceDateMenu().then(function(){
                acceptanceLotsService.getAcceptanceLots().then(function(){
                    commonVariables.isLoading=false;
                },function(){
                    commonVariables.isLoading=false;
                })
            })
        },function(){
            commonVariables.isLoading=false;
        })

        $scope.handle = function(lot,control){
            if (control.opName==='acceptance'){
                $scope.acceptanceDialogShow(lot);
            }

        }

        $scope.acceptanceDateMenuHandle = function(lot,item){
            commonVariables.currentLot=lot;
            $scope.commentType=item.statusId;
            $scope.commonVariables.canOpenAcceptanceDateComment=true;

        }
        $scope.acceptanceDialogShow = function(lot){
            commonVariables.currentLot=lot;
            $mdDialog.show({
                templateUrl:'/js/acceptance/templates/acceptanceModalTemplate.html',
                controller:'acceptanceModal'
            });
        }

        $scope.showAcceptanceDateHistory = function(lot){
            $mdDialog.show({
                templateUrl:'/js/acceptance/templates/acceptanceDateHistoryModal.html',
                controller:'acceptanceDateHistory'
            });
        }
        $scope.lotClicked = function(lot){
            for (var i=0;i<$scope.lots.length;i++){
                $scope.lots[i].isActive=false;
            }
            lot.isActive=true;
        }


}]);