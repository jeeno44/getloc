﻿angular.module( 'isz' ).controller( 'docsLots', ['$scope', 'appsecurity', 'lotsService', 'commonVariables', 'toastService','stagesService','workTypeService',
    function ( $scope, appsecurity, lotsService, commonVaribales, toastService,stagesService,workTypeService ) {
        $scope.statusedLots = lotsService.lots;
        $scope.commonVariables=commonVaribales;
        commonVaribales.isLoading = true;
        commonVaribales.enterInLotTimeStamp=null;
        commonVaribales.currentMenuItem('/docs');

        stagesService.creatingStage = false;
        workTypeService.creatingWorkType=false;

        $scope.liftCategory = function ( to, from ) {
            if ( to === from ) {
                return;
            }

            var categoryToLift = $scope.statusedLots.splice( from, 1 ),
                categoriesEnding = $scope.statusedLots.splice( to, $scope.statusedLots.length - to );

            categoriesEnding.unshift( categoryToLift[0] );

            [].push.apply( $scope.statusedLots, categoriesEnding );
        }


        $scope.allert =function(){
            alert('Clicked!');
        }
        $scope.updateLotsList = function(){
            appsecurity.getUserInfo().then( function () {
                if (commonVaribales.currentSubSystem!=='docs'){
                    commonVaribales.currentSubSystem='docs';
                    appsecurity.currentRole.subsystemChanged();
                }
                var role=appsecurity.currentRole.code;
                var expertizeShowArr = ['Rukovoditel_koordinator','Specialist_koordinator','Head_OM'];
                var authorShowArr = ['Rukovoditel_koordinator','Specialist_koordinator','Head_OM'];
                var expertShowArr=['Rukovoditel_koordinator','Specialist_koordinator','Rukovoditel_depzak','Specialist_depzak'];
                $scope.expertizeShow=expertizeShowArr.indexOf(role)!==-1;
                $scope.authorShow=authorShowArr.indexOf(role)!==-1;
                $scope.expertShow=expertShowArr.indexOf(role)!==-1;
                $scope.readLot = appsecurity.currentRole.permissions.readLot;
                $scope.readSections = appsecurity.currentRole.permissions.readSections;
                $scope.controlSections = appsecurity.currentRole.permissions.controlSections;
                $scope.readSectionsAll = appsecurity.currentRole.permissions.readSectionsAll;

                $scope.readSectionsByGroup = appsecurity.currentRole.permissions.readSectionsByGroup;
                if ( !$scope.readSections && !$scope.readSectionsByGroup ) {
                    commonVaribales.isLoading = false;
                    toastService.show( 'У Вас нет прав доступа для просмотра этой страницы', false );
                } else {
                    lotsService.forceSync().then(function(){

                        commonVaribales.isLoading = false;

                    });
                }



            } , function () {
                commonVaribales.isLoading = false;
            } );
        }
        $scope.updateLotsList();
    }] );