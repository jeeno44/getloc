angular.module( 'isz' ).factory( 'CriteriaIndicatorFactory', ['$http', '$q', 'apiService', 'appsecurity', 'toastService',
    function ( $http, $q, apiService, appsecurity, toastService ) {

        function CriteriaIndicator( indicator, ratingId ) {
            this.id = indicator.id;
            this.criteriaRating = indicator.criteriaRating;
            this.indicator = indicator.indicator;
            //this.indicatorContent = indicator.indicatorContent;
            this.indicatorContent = indicator.content;
            this.indicatorTitle = indicator.title;
            this.indicatorValue = indicator.indicatorValue;
            this.criteriaRating = ratingId;

            //this.versionEndAt = indicator.versionEndAt;
            //this.versionOwnerId = indicator.versionOwnerId;
            //this.versionStartAt = indicator.versionStartAt;
        }

        CriteriaIndicator.prototype = {
            create: function () {
                var defer = $q.defer(),
                    indicator = this;

                $http( {
                    method: 'POST',
                    url: apiService.criteriaIndicatorsRoute,
                    data: this,
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {
                    indicator.id = response.data.id;
                    defer.resolve( indicator );
                }, function ( response ) {
                    toastService.errorResponseShow('��������� ������ ��� �������� �������� ����������',response);
                    defer.reject( response );
                } )

                return defer.promise;
            },
            update: function () {
                var defer = $q.defer(),
                    indicator = this;

                $http( {
                    method: 'PUT',
                    url: apiService.criteriaIndicatorsRoute + '/' + this.id,
                    data: this,
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {
                    indicator.id = response.data.id;
                    defer.resolve( indicator );
                }, function ( response ) {
                    toastService.errorResponseShow('��������� ������ ��� ���������� �������� ����������', response);
                    defer.reject( response );
                } )

                return defer.promise;
            },
            remove: function () {
                $http( {
                    method: 'DELETE',
                    url: apiService.criteriaIndicatorsRoute + '/' + this.id,
                    data: this,
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {

                }, function ( response ) {
                    toastService.errorResponseShow('��������� ������ ��� �������� �������� ����������', response);
                } )
            }
        }

        return CriteriaIndicator;
    }] );