angular.module( 'isz' ).controller( 'DownloadDocuments', ['$scope', '$mdDialog', 'commonVariables','apiService', 'lotId',
    function ( $scope, $mdDialog, commonVariables, apiService, lotId, $http, $q, appsecurity, toastService ) {
        $scope.documentFormats = ['docx', 'pdf'];
        $scope.docUrl=apiService.baseUrl+'/doc/download/';

        //for ( var i = 0; i < lotsService.startLots.length; i++ ) {
        //    if ( lotsService.startLots[i].id == lotId )
        //    {
        //        $scope.lot = lotsService.startLots[i];
        //    }
        //}
        $scope.lot=commonVariables.currentLot;
        $scope.shape = function ( document ) {
            document.shape( lotId );
        }

        $scope.downloadFile = function ( document ) {
            window.open( document.uploadedUrl, '_blank' );
        }

        $scope.exit = function () {
            $mdDialog.hide();
        }


    }] );