angular.module( 'isz' ).factory( 'CriteriaRatingFactory', ['CriteriaIndicatorFactory', '$q', '$http', 'apiService', 'appsecurity', 'criteriaHelperService', 'toastService',
    function ( CriteriaIndicatorFactory, $q, $http, apiService, appsecurity, criteriaHelperService, toastService ) {

        function CriteriaRating( rating ) {
            var self = this;

            this.id = rating.id;
            this.lot = rating.lot_id;
            this.value = rating.value;
            this.title = rating.title;
            this.criteriaType=rating.criteriaType;

            this.criteriaIndicators = ( rating.criteriaIndicators || [] ).map( function ( indicator ) {
                return new CriteriaIndicatorFactory( indicator, self.id );
            } );

            this.totalPercents = this.getArraySumm( this.criteriaIndicators, 'indicatorValue' );
            this.criteriaErrors = [];
            this.indicatorsToRemove = [];
        }

        CriteriaRating.prototype = {
            updateIndicators: function () {
                this.criteriaIndicators.forEach( function ( indicator ) {
                    if ( angular.isDefined( indicator.id ) ) {
                        indicator.update();
                    } else {
                        indicator.create();
                    }
                } );

                this.indicatorsToRemove.forEach( function ( indicator ) {
                    indicator.remove();
                } );
                this.indicatorsToRemove.length = 0;
            },
            update: function () {
                var defer = $q.defer();

                $http( {
                    method: 'PUT',
                    url: apiService.criteriaRatingsRoute + '/' + this.id,
                    data: this,
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {
                    defer.resolve();
                }, function ( response ) {

                    toastService.errorResponseShow( '��������� ������ ��� ���������� �������� ��������', response );
                    defer.reject();
                } )

                return defer.promise;
            },

            create: function () {
                var defer = $q.defer();

                $http( {
                    method: 'POST',
                    url: apiService.criteriaRatingsRoute,
                    data: {'lot_id': this.lot, 'title': this.title, 'value': this.value},
                    headers: appsecurity.getSecurityHeaders()
                } ).then( function ( response ) {
                    defer.resolve();
                }, function ( response ) {
                    toastService.errorResponseShow( 'Критерии оценки заявок сохранен', response );
                    defer.reject();
                } )

                return defer.promise;
            },

            createIndicator: function () {
                var indicator = new CriteriaIndicatorFactory( {}, this.id )
                this.criteriaIndicators.push( indicator );
            },
            removeIndicator: function ( indicator ) {
                var indicatorIndex = this.criteriaIndicators.indexOf( indicator );
                this.indicatorsToRemove.push( this.criteriaIndicators.splice( indicatorIndex, 1 )[0] );
                this.recalculate();
            },
            recalculate: function () {
                this.totalPercents = this.getArraySumm( this.criteriaIndicators, 'indicatorValue' );
                criteriaHelperService.validateCriteriaIndicators( this );
            },
            getArraySumm: function ( arr, key ) {
                var mappedPrice = arr.map( function ( object ) {
                    return key in object
                        ? parseFloat( object[key] ) || 0
                        : 0;
                } );

                return mappedPrice.reduce( function ( fullSum, price ) {
                    return fullSum += price;
                }, 0 );
            }
        }

        return CriteriaRating;
    }] );