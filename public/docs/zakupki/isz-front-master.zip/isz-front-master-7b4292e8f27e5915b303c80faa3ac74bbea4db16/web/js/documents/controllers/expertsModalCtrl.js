/**
 * Created by pol on 28.04.2016.
 */
angular.module('isz').controller('expertsModalCtrl',['$scope', '$http', '$mdDialog','appsecurity', 'apiService','commonVariables','control',
    function ($scope, $http, $mdDialog,appsecurity, apiService,commonVariables,control, controlsService) {

        $scope.selectedExperts = [];
        $scope.lot=commonVariables.currentLot;

        $http({
            url: apiService.expertsRoute,
            headers: appsecurity.getSecurityHeaders(),
            method: 'GET'
        }).then(function (response) {
            $scope.experts = response.data;

        }, function (response) {
            var str = 'Возникла ошибка при получении данных с сервера. ';
            toastService.errorResponseShow(str, response);
        })

        $scope.send = function () {

            var body = {
                expertList: []
            };

            for (var i = 0; i < $scope.selectedExperts.length; i++) {
                body.expertList.push($scope.selectedExperts[i].users.id)
            }

            controlsService.executeCommand(control, $scope.lot.id, body);

            $mdDialog.hide();
        }

        $scope.exit = $mdDialog.hide;

        $scope.exists = function (expert) {
            return $scope.selectedExperts.indexOf(expert) > -1;
        }

        $scope.toggle = function (expert) {
            var idx = $scope.selectedExperts.indexOf(expert);
            if (idx > -1) $scope.selectedExperts.splice(idx, 1);
            else $scope.selectedExperts.push(expert);
        }
    }]);