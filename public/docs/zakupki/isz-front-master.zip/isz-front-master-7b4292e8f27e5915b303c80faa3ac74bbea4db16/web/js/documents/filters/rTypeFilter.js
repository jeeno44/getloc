﻿angular.module( 'isz' ).filter( 'rType', function () {

    var types = {
        good: 'Товар',
        labour: 'Работа/Услуга'
    }


    return function ( item ) {
        return types[item];
    }
} );
