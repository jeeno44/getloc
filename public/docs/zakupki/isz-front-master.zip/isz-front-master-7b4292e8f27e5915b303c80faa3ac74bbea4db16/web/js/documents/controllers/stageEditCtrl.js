/**
 * Created by pol on 26.04.2016.
 */
angular.module('isz').controller('stageEditCtrl',['$scope','$mdDialog', 'stagesService', 'commonVariables', 'toastService', 'Stage','hotkeys',
    function ($scope,$mdDialog, stagesService, commonVariables, toastService, Stage,hotkeys) {

        hotkeys.bindTo($scope).add({
            combo: 'ctrl+enter',
            description: 'Сохранить этап',
            allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
            callback: function () {
                $scope.stageSave($scope.stage);
            }
        });


        $scope.lot=commonVariables.currentLot;
        $scope.stage = stagesService.getNewStage();
        $scope.startingDates = stagesService.startingDates;
        $scope.executionTypes = stagesService.executionTypes;
        $scope.isEditing=stagesService.editFlag;

        // $scope.isView=stagesService.isView||false;


        $scope.stagesBuff = [];
        $scope.lot.stages.forEach(function (st) {
            var obj = {}, stage;
            angular.copy(st, obj);
            stage = new Stage(obj);
            //stageValidate( st );
            $scope.stagesBuff.push(stage);

        });
        $scope.stagesBuff.push($scope.stage);

        $scope.close = function () {
            stagesService.editFlag=false;
            stagesService.creatingStage = false;
            $mdDialog.hide();
        }
        function stageValidate(stage, stageInd) {
            var toastStr = "Ошибка при проверке этапа "+(stageInd+1)+": ";
            var toastList=[];
            stage.canSave = false;
            var valid = true;
            //title validate
            if (!stage.title) {
                toastList.push("не заполнено название этапа");
                toastService.showList(toastStr,toastList,false);
                return false;
            }
            if (!$scope.lot.procurementEndDate) {
                toastList.push("не указана дата окончания закупок лота");
                toastService.showList(toastStr,toastList,false);
                return false;
            } else {
                var procurementEndDate = moment($scope.lot.procurementEndDate);
            }
            var startDate;

            //startYear
            if (( stage.startYear * 1 ) > 1) {
                if (stage.startingDate == 1) {
                    toastList.push("несоответствие года выполнения дате начала этапа");
                    toastService.showList(toastStr,toastList,false);
                    return false;
                }
                var arr = $scope.lot.stages.filter(function (st) {
                    return ( st.startYear * 1 ) == ( stage.startYear * 1 ) - 1;
                })
                if (angular.isDefined(arr) && arr.length) {
                    if (stage.startingDate == 2) {

                        var draft = [];
                        draft = $scope.stagesBuff.filter(function (st) {
                            return st !== stage;
                        });
                        //draft.splice(draft.indexOf(stage),1);
                        var arrCurr = draft.filter(function (st) {
                            return ( st.startYear * 1 ) === ( stage.startYear * 1 );
                        });

                        if (angular.isDefined(arrCurr) && arrCurr.length) {
                            var maxPrevSatgeDateEl;
                            maxPrevSatgeDateEl = arrCurr.reduce(function (x, y) {
                                var xDate, yDate;
                                if (x.executionDateTerm) {
                                    xDate = moment(x.startDate).add(x.executionTerm, 'days');
                                } else {
                                    xDate = moment(x.executionDate);
                                }
                                if (x.executionDateTerm) {
                                    yDate = moment(y.startDate).add(y.executionTerm, 'days');
                                } else {
                                    yDate = moment(y.executionDate);
                                }
                                return ( xDate > yDate ) ? x : y;
                            });
                            if (maxPrevSatgeDateEl.executionDateTerm) {
                                startDate = moment(maxPrevSatgeDateEl.startDate).add(maxPrevSatgeDateEl.executionTerm, 'days');
                            } else {
                                startDate = moment(maxPrevSatgeDateEl.executionDate);
                            }

                        } else {
                            toastList.push("нет предыдущего этапа");
                            toastService.showList(toastStr,toastList,false);

                            return false;
                        }

                    }

                    if (stage.startingDate == 3) {
                        startDate = new Date(procurementEndDate.year() + ( stage.startYear * 1 ) - 1, 0, 1);
                        startDate = moment(startDate);
                    }

                    if (stage.startingDate == 4) {
                        if (!stage.startDate) {
                            toastList.push("не указана дата начала этапа");
                            toastService.showList(toastStr,toastList,false);
                            return false;
                        } else {
                            startDate = stage.startDate;
                            var dd1 = new Date(procurementEndDate.year() + ( stage.startYear * 1 ) - 1, 0, 1);
                            var dd2 = new Date(procurementEndDate.year() + ( stage.startYear * 1 ), 0, 1);
                            if (!( moment(stage.startDate) >= dd1 && moment(stage.startDate) < dd2 )) {
                                toastList.push("несоответствие года выполнения дате начала этапа");
                                toastService.showList(toastStr,toastList,false);
                                return false;
                            }
                        }
                        startDate = moment(stage.startDate);
                    }

                } else {
                    toastList.push("нет предыдущего этапа");
                    toastService.showList(toastStr,toastList,false);
                    return false;
                }


            } else {
                if (stage.startingDate === 1) {
                    startDate = procurementEndDate;
                }
                if (stage.startingDate === 2) {
                    var draft = [];
                    draft = $scope.stagesBuff.filter(function (st) {
                        return st !== stage;
                    });
                    var arrCurr = draft.filter(function (st) {
                        return ( st.startYear * 1 ) === ( stage.startYear * 1 );
                    });

                    if (angular.isDefined(arrCurr) && arrCurr.length) {
                        var maxPrevSatgeDateEl;
                        maxPrevSatgeDateEl = arrCurr.reduce(function (x, y) {
                            var xDate, yDate;
                            if (x.executionDateTerm) {
                                xDate = moment(x.startDate).add(x.executionTerm, 'days');
                            } else {
                                xDate = moment(x.executionDate);
                            }
                            if (x.executionDateTerm) {
                                yDate = moment(y.startDate).add(y.executionTerm, 'days');
                            } else {
                                yDate = moment(y.executionDate);
                            }
                            return ( xDate > yDate ) ? x : y;
                        });
                        if (maxPrevSatgeDateEl.executionDateTerm) {
                            startDate = moment(maxPrevSatgeDateEl.startDate).add(maxPrevSatgeDateEl.executionTerm, 'days');
                        } else {
                            startDate = moment(maxPrevSatgeDateEl.executionDate);
                        }

                    } else {
                        toastList.push("нет предыдущего этапа");
                        toastService.showList(toastStr,toastList,false);
                        return false;
                    }
                }
                if (stage.startingDate === 3) {
                    toastList.push("несоответствие года выполнения дате начала этапа");
                    toastService.showList(toastStr,toastList,false);
                    return false;
                }
                if (stage.startingDate === 4) {
                    if (!stage.startDate) {
                        toastList.push("не указана дата начала этапа");
                        toastService.showList(toastStr,toastList,false);
                        return false;
                    } else {
                        if (moment(stage.startDate) < procurementEndDate) {
                            toastList.push("дата начала этапа должна быть позже даты окончания закупок");
                            toastService.showList(toastStr,toastList,false);
                            return false;
                        } else {
                            var dd = new Date(procurementEndDate.year() + 1, 0, 1);
                            if (!( moment(stage.startDate) >= procurementEndDate && moment(stage.startDate) < dd )) {
                                toastList.push("несоответствие года выполнения дате начала этапа");
                                toastService.showList(toastStr,toastList,false);
                                return false;
                            }
                        }
                    }
                    startDate = moment(stage.startDate);
                }
            }
            if (!stage.startDate) {
                stage.startDate = startDate.toDate();
            }

            if (!stage.executionType) {
                toastList.push("не указан тип окончания этапа");
                toastService.showList(toastStr,toastList,false);
                return false;
            } else {
                switch (stage.executionType) {
                    case 1:
                        if (!stage.executionDate) {
                            toastList.push("не указана дата окончания этапа");
                            toastService.showList(toastStr,toastList,false);
                            return false;
                        } else {
                            if (moment(stage.executionDate) < startDate) {
                                toastList.push("дата окончания этапа должна быть позже даты начала этапа");
                                toastService.showList(toastStr,toastList,false);
                                return false;
                            }
                        }

                        break;
                    case 2:
                        if (!stage.executionTerm) {
                            toastList.push("не указан срок окончания этапа");
                            toastService.showList(toastStr,toastList,false);
                            return false;
                        } else {

                            var dd = new Date(procurementEndDate.year() + ( stage.startYear * 1 ), 0, 1);
                            if (moment(stage.startDate).add(stage.executionTerm, 'days') >= dd) {
                                toastList.push("дата окончания этапа должна быть позже даты начала этапа");
                                toastService.showList(toastStr,toastList,false);
                                return false;
                            }
                            var dat = moment(stage.startDate).add(stage.executionTerm, 'days');
                            stage.executionDate = dat.toDate();
                        }
                        break;
                }
            }

            stage.canSave = true;
            return true;
        }

        $scope.stageFieldChange = function (stage, field, pickerFlag) {

            if (field === 'executionTerm') {
                var dat = moment(stage.startDate).add(stage.executionTerm, 'days');
                stage.executionDate = dat.toDate();
            }
            if (field==='financing' &&stage.workTypes&&stage.workTypes.length&&(stage.financing!=stage.getWorkTypeFinancingSumm())){
                toastService.show('Цена по этапу не равна сумме стоимостей работ этапа',false)
            }

        };
        $scope.stageSave = function (stage) {

            var flag = true;

            for (var i = 0; i < $scope.stagesBuff.length; i++) {
                if (!stageValidate($scope.stagesBuff[i],i)) {
                    flag = false;

                }
            }
            if (flag) {
                if (stage.id) {
                    stage.save().then(function () {
                        toastService.show('Этап успешно сохранен', false);
                        commonVariables.currentLot.recalculateTotalPrice();
                    });

                } else {
                    stage.create($scope.lot).then(function () {
                        $scope.lot.stages.push(stage);
                        toastService.show('Этап успешно добавлен', false);
                        commonVariables.currentLot.recalculateTotalPrice();
                    });

                }


                $scope.close();
            }
        };
    }]);

