﻿angular.module( 'isz' ).service( 'criteriaHelperService', ['$timeout','toastService', function ( $timeout,toastService ) {

    var listOfCriteriaErrors = {
        noLimitValues: 'Вы должны определить предельные величины значимости критериев',
        not100Percents: 'Сумма значимости критериев должна быть 100%',
        lowMinValue: 'Минимальное значение первого критерия не должно быть меньше ',
        costLimitValues:'Сумма значений стоимостных критериев вне допустимого диапазона',
        noncostLimitValues:'Сумма значений нестоимостных критериев вне допустимого диапазона'
    };

    function addCriteriaError( msg, obj ) {
        if ( obj.criteriaErrors.indexOf( msg ) === -1 ) {
            obj.criteriaErrors.push( msg );
            //toastService.show(msg,false);
        }

    }

    function removeCriteriaError( msg, obj ) {
        var msgIndex = obj.criteriaErrors.indexOf( msg );
        if ( msgIndex !== -1 ) {
            obj.criteriaErrors.splice( msgIndex, 1 )
        }
    }

    this.validateCriteriaRatings = function ( lot ) {
        $timeout( function () {
            if ( angular.isDefined( lot.criteriaCostMinValue) ||  angular.isDefined( lot.criteriaNonCostMaxValue)) {
                removeCriteriaError( listOfCriteriaErrors.noLimitValues, lot );

                if ( lot.criteriaRatingsTotalPercents === 100 ) {
                    removeCriteriaError( listOfCriteriaErrors.not100Percents, lot );
                } else {
                    addCriteriaError( listOfCriteriaErrors.not100Percents, lot );
                }
                if (angular.isDefined(lot.costCriteria && lot.costCriteria.length)) {
                    var sum = lot.costCriteria.reduce(function(a,b){
                        return a+ (b.value?(b.value*1):0);
                    },0);
                    if (sum<lot.criteriaCostMinValue || sum>lot.criteriaCostMaxValue) {
                        addCriteriaError(listOfCriteriaErrors.costLimitValues, lot)
                    } else {
                        removeCriteriaError( listOfCriteriaErrors.costLimitValues, lot );
                    }
                } else {
                    removeCriteriaError( listOfCriteriaErrors.costLimitValues, lot );
                }
                if (angular.isDefined(lot.noncostCriteria && lot.noncostCriteria.length)) {
                    var sum1 = lot.noncostCriteria.reduce(function(a,b){
                        return a+ (b.value?(b.value*1):0);
                    },0);
                    if (sum1<lot.criteriaNonCostMinValue || sum1>lot.criteriaNonCostMaxValue) {
                        addCriteriaError(listOfCriteriaErrors.noncostLimitValues, lot)
                    } else {
                        removeCriteriaError( listOfCriteriaErrors.noncostLimitValues, lot );
                    }
                } else {
                    removeCriteriaError( listOfCriteriaErrors.noncostLimitValues, lot );
                }
            } else {
                addCriteriaError( listOfCriteriaErrors.noLimitValues, lot );
            }
        }, 0 );
    }

    this.validateCriteriaIndicators = function ( rating ) {
        if ( rating.totalPercents === 100 ) {
            removeCriteriaError( listOfCriteriaErrors.not100Percents, rating );
        } else {
            addCriteriaError( listOfCriteriaErrors.not100Percents, rating );
        }

    }
} ]);