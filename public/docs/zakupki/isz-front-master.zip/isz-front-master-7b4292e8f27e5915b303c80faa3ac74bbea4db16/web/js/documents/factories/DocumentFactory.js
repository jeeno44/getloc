﻿angular.module('isz').factory('Document', ['$http', '$q', 'appsecurity', 'toastService','apiService', function ($http, $q, appsecurity, toastService,apiService) {

    //var url = apiService.baseUrl+'/';

    function Document(docCategory, nameR, docs) {
        this.nameR = nameR;
        this.docType = 'docx';
        this.docCategory = docCategory;
        this.uploadedUrl = '';
        this.files = docs;
        this.activeFileDoc = null;
        this.activeFilePdf = null;
        this.url= apiService.baseUrl+'/';


        for (var i in docs) {
            docs[i].order = moment(docs[i].created).unix();
            docs[i].created = moment(docs[i].created).format('DD.MM.YY HH:mm');
        }

        var DocsDoc = docs,
            DocsPdf = docs;

        DocsDoc = DocsDoc.filter(function (doc) {
            return ((doc.status == 1) && (doc.type == "docx"));
        });

        DocsPdf = DocsPdf.filter(function (doc) {
            return ((doc.status == 1) && (doc.type == "pdf"));
        });

        DocsDoc.sort(function(a, b) {
            if (a.order > b.order)
                return -1;
            else if (a.order < b.order)
                return 1;
            else
                return 0;
        });

        DocsPdf.sort(function(a, b) {
            if (a.order > b.order)
                return -1;
            else if (a.order < b.order)
                return 1;
            else
                return 0;
        });

        this.activeFileDoc = (DocsDoc[0] !== undefined) ? DocsDoc[0] : null;
        this.activeFilePdf = (DocsPdf[0] !== undefined) ? DocsPdf[0] : null;

    }

    Document.prototype = {
        shape: function (lotId) {
            var apiUrl = this.url + 'doc/' + this.docCategory + '/' + lotId + '/generate?format=' + this.docType;
            var document = this;
            document.isDownloading = true;
            selectRequest(apiUrl)
                .then(function (response) {
                    document.isDownloading = false;
                    toastService.show('Задача на формирование документа ' + document.nameR + ' успешно отправленна. По завершению Вы будете оповещены', false);
                }, function (response) {
                    document.isDownloading = false;
                    toastService.errorResponseShow('Произошел сбой при формировании документа' + document.nameR + ' на сервере', response);
                });
        }
    };
    function selectRequest(url) {
        var defer = $q.defer();
        $http({
            method: 'GET',
            headers: appsecurity.getSecurityHeaders(),
            url: url
        }).then(function (response) {
            defer.resolve(response);
        })
        return defer.promise;
    }

    return Document;
}]);