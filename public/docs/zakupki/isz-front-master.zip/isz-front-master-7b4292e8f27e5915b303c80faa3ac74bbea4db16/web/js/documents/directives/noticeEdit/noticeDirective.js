angular.module('isz').directive('noticeEdit',[function(){
    return {
        restrict: 'E',
        templateUrl: '/js/documents/directives/noticeEdit/noticeEditModal.html',
        replace: false,
        controller: ['$scope','commonVariables','toastService','translate','hotkeys',function($scope,commonVariables,toastService,translate,hotkeys){
            hotkeys.bindTo($scope).add({
                combo: 'ctrl+enter',
                description: 'Сохранить',
                allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
                callback: function () {
                    $scope.saveNotice();
                }
            });
            $scope.lot = commonVariables.currentLot;
            if ($scope.lot.docClarificationEndDate) {
                $scope.lot.applicationVskrDateTimeStart=moment($scope.lot.docClarificationEndDate).add(6,'days').toDate()
            }
            if ($scope.lot.docClarificationStartDate&&!$scope.lot.docClarificationEndDate) {
                $scope.lot.applicationVskrDateTimeStart=moment($scope.lot.docClarificationStartDate).add(7,'days').toDate()
            }

            $scope.needPatchStage=false;
            $scope.maxReportingDocDate=null;
            $scope.departments = commonVariables.departments;

            $scope.close=function(){
                commonVariables.canOpenNotice=false;
            }
            $scope.saveNotice =function(){
                var count = {
                    blank: 0,
                    emptyFields: []
                };

                $scope.$broadcast('remainingRequiredFields', count);
                if (count.blank) {
                    var title = 'Необходимо заполнить обязательные поля:',
                        fieldArr = [];
                    for (var i = 0; i < count.emptyFields.length; i++) {
                        fieldArr.push(translate.requiredFieldName('ru', count.emptyFields[i]));
                    }

                    toastService.showList(title, fieldArr, true);
                } else {
                    if (!$scope.lot.docClarificationEndDate){
                        $scope.lot.docClarificationEndDate=moment($scope.lot.applicationVskrDateTime).subtract(6,'days').toDate()
                    }
                    $scope.lot.noticeSave();
                    if ( $scope.needPatchStage&&$scope.lot.stages.length) {
                        var stage=$scope.lot.stages.reduce(function(a,b){
                            return (a.executionDate> b.executionDate)? a:b;
                        },$scope.lot.stages[0]);
                        stage.reportingDocsDate=$scope.maxReportingDocDate;
                        if (stage) stage.patch('reportingDocsDate');
                    }
                    $scope.close();
                }
            }
            $scope.saveMaxReportingDocDate = function(ee){
                if (ee) {
                    $scope.maxReportingDocDate=ee;
                    $scope.needPatchStage=true
                }

            }

            setMaxReportingDocDate();
            function setMaxReportingDocDate(){

                for (var i=0;i<$scope.lot.stages.length;i++){
                    if ($scope.lot.stages[i].reportingDocsDate) {
                        if (!$scope.maxReportingDocDate) {
                            $scope.maxReportingDocDate=$scope.lot.stages[i].reportingDocsDate;
                        } else if ($scope.lot.stages[i].reportingDocsDate>$scope.maxReportingDocDate) {
                            $scope.maxReportingDocDate=$scope.lot.stages[i].reportingDocsDate;
                        }
                    }
                }
            }
        }]
    }
}]);