/**
 * Created by pol on 21.03.2016.
 */
angular.module('isz').directive('nmckJustification', function () {
    return {
        restrict: 'E',
        templateUrl: '/js/documents/directives/nmckJustification/nmckJustificationTemplate.html',
        replace: true,
        controller: ['$scope','commonVariables', function ($scope,commonVariables) {
            $scope.entityType = 'lots';
            // $scope.lot=commonVariables.currentLot;
            $scope.entityTypes = [
                {
                    label: 'Лот',
                    value: 'lots',
                    enable:true
                },
                {
                    label: 'Этапы',
                    value: 'stages',
                    enable:true
                },
                {
                    label: 'Работы',
                    value: 'works',
                    enable:true
                }
            ];
            $scope.setPages = function () {
                $scope.entityTypes.forEach(function (en) {
                    en.enable=true;
                })
                if ($scope.lot.nmckJustification&&$scope.lot.nmckJustification!=='') {
                    $scope.entityTypes[0].enable=true;
                    $scope.entityTypes[1].enable=false;
                    $scope.entityTypes[2].enable=false;
                    $scope.entityType = 'lots';
                    return;
                }
                var flStages=false;
                var flWorks=false;
                for (var i=0;i<$scope.lot.stages.length;i++){
                    if ($scope.lot.stages[i].nmckJustification&&$scope.lot.stages[i].nmckJustification!=='') {
                        flStages=true;
                        break;
                    } else {
                        for (var j=0;j<$scope.lot.stages[i].workTypes.length;j++){
                            if ($scope.lot.stages[i].workTypes[j].nmckJustification&&$scope.lot.stages[i].workTypes[j].nmckJustification!=='') {
                                flWorks=true;
                                break;
                            }
                        }

                    }
                }
                if (flStages) {
                    $scope.entityTypes[0].enable=false;
                    $scope.entityTypes[1].enable=true;
                    $scope.entityTypes[2].enable=false;
                    $scope.entityType = 'stages';
                    return;
                }
                if (flWorks) {
                    $scope.entityTypes[0].enable=false;
                    $scope.entityTypes[1].enable=false;
                    $scope.entityTypes[2].enable=true;
                    $scope.entityType = 'works';
                    return;
                }

            }
            $scope.changeWorkNmck = function (work) {
                $scope.setPages();
                work.patch('nmckJustification');
            }
            setLot();
            function setLot() {
                if (commonVariables.currentLot&&commonVariables.currentLot.hasAllInfo) {
                    $scope.lot = commonVariables.currentLot;
                    $scope.setPages();
                    // $scope.$$phase || $scope.$apply();
                } else {
                    setTimeout(setLot, 100);
                }
            }

        }]
    }
})