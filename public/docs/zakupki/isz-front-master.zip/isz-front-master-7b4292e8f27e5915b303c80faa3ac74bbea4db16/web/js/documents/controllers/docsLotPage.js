angular.module('isz').controller('docsLotPage', ['$location', '$scope', '$mdDialog', '$location', '$http', '$q', 'commonVariables', 'WorkKindFactory', 'WorkTypeFactory', 'lotsService', 'appsecurity', 'controlsService', 'commonVariables', 'workTypeService', 'stagesService', 'apiService','toastService','$document',
    function ($location, $scope, $mdDialog, $location, $http, $q, commonVariables, WorkKindFactory, WorkTypeFactory, lotsService, appsecurity, controlsService, commonVariables, workTypeService, stagesService, apiService,toastService,$document) {

        commonVariables.isLoading = true;
        $scope.dealOpen = false;
       
        var content = angular.element(document.querySelector('.doc-lot-page'));
        content.addClass('view_mode');
        /*
        * @todo: поставить canEditStage =false
        * */
        $scope.canEditStage=false;
     

        $scope.workTypeService = workTypeService;
        $scope.stagesService = stagesService;
        $scope.commonVariables=commonVariables;
        $scope.inShowComments = false;
        $scope.inShowRootComment = true;
        $scope.stageYears=[];

        $scope.toggleEditMode = function () {
            content.toggleClass('view_mode').toggleClass('edit_mode');
            $scope.lot.toggleEditMode();
        }

        $scope.toggleShowComments = function () {
            $scope.inShowComments = !$scope.inShowComments;
            content.toggleClass('show_comments');
        }
        $scope.commentRoot = function () {
            $mdDialog.show({
                templateUrl: '/js/common/templates/commentsModal.html',
                controller: 'commentsModal',
                locals: {
                    'fieldId': 'root',
                    'titleRu': 'Комментарий к лоту'
                }
            }).then(function () {
                $scope.$broadcast('commentsUpdates', 'root');
            });
        }

        $scope.executeControlCommand = function (control) {


            var lot = $scope.lot;

            if ( control.opName == 'delegate' ) {
                $mdDialog.show( {
                    templateUrl: '/js/documents/templates/expertsModal.html',
                    controller: 'expertsModalCtrl',
                    locals:{ 'control':control}
                } ).then( function () {

                } )
            }  else if (control.opName === 'make_data_notice' || control.opName === 'edit_data_notice') {
                commonVariables.canOpenNotice = true;

            }
            else {
                commonVariables.isLoading = true;
                controlsService.executeCommand(control,$scope.lot.id).then(function () {
                    $location.path('/docs');
                    commonVariables.isLoading = false;
                }, function () {
                    commonVariables.isLoading = false;
                });
            }
        }

        appsecurity.getUserInfo().then(function () {
            if (commonVariables.currentSubSystem!=='docs'){
                commonVariables.currentSubSystem='docs';
                appsecurity.currentRole.subsystemChanged();
            }

            if (!commonVariables.currentLot) {
                var pathArr = $location.$$path.split('/'),
                    curId = pathArr[pathArr.length - 1];
                lotsService.getCurrentByIdNew(curId).then(afterSetCurrentLot, function () {
                    commonVariables.isLoading = false;
                });
            } else {
                afterSetCurrentLot();
                $(document).scrollTop((-1)*$(document).scrollTop());
            }
            selectRequest(apiService.marketplaceSelect).then(function (response) {

                $scope.marketplaceSelect = response.data;
            }, function (response) {
                toastService.errorResponseShow('Ошибка получения данных справочника ЦСР КБК', response);
            })
                .then(function () {
                    commonVariables.requestArr.pop();
                });


            //
            //lotsService.getLots().then( function () {
            //
            //    if ( !commonVariables.currentLot ) {
            //        var pathArr = $location.$$path.split( '/' ),
            //            curId = pathArr[pathArr.length - 1];
            //
            //        commonVariables.currentLot = lotsService.getCurrentById( curId );
            //    }
            //
            //    var q1 = commonVariables.currentLot.fillAllInfo();
            //    var q2 = commonVariables.currentLot.getFormsSettings();
            //    var q3 = commonVariables.currentLot.getCriteriaIndicators();
            //    var q4 = commonVariables.currentLot.getCriteriaMaxValues();
            //
            //    $q.all( [q1, q2, q3, q4] ).then( function () {
            //        $scope.lot = commonVariables.currentLot;
            //        commonVariables.enterInLotTimeStamp = new Date();
            //        $scope.isEditable = appsecurity.currentRole.isAllowEditLot( commonVariables.currentLot.common )
            //                                && commonVariables.currentLot.canEdit;
            //        commonVariables.isLoading = false;
            //        if (!($scope.lot.stages && $scope.lot.stages.length) && $scope.lot.procurementEndDate) {
            //            $scope.canAddStage=true;
            //        } else {
            //            $scope.canAddStage=false;
            //        }
            //    }, function () {
            //        commonVariables.isLoading = false;
            //    } );
            //}, function () {
            //    commonVariables.isLoading = false;
            //} );

        }, function () {
            commonVariables.isLoading = false;
        });

        function afterSetCurrentLot() {
            var q1 = commonVariables.currentLot.fillAllInfo();
            var q2 = commonVariables.currentLot.getFormsSettings();
            //var q3 = commonVariables.currentLot.getCriteriaIndicators();
            var q4 = commonVariables.currentLot.getCriteriaMaxValues();

            $q.all([q1, q2, q4]).then(function () {
                $scope.lot = commonVariables.currentLot;
                //$scope.noticePartShow =(function(){
                //
                //    if ($scope.lot.applicationPostAddress) return true;
                //    if ($scope.lot.applicationcourrieraddress) return true;
                //    if ($scope.lot.applicationDateTimeEnd) return true;
                //    if ($scope.lot.applicationVskrAddress) return true;
                //    if ($scope.lot.applicationVskrDateTime) return true;
                //    if ($scope.lot.applicationRassmotrDateTime) return true;
                //    if ($scope.lot.applicationRassmotrAddress) return true;
                //
                //
                //    return false;
                //})();
                commonVariables.enterInLotTimeStamp = new Date();
                $scope.showCommentControl = Boolean(Object.keys($scope.lot.commentControls).length);
                //$scope.isEditable = appsecurity.currentRole.isAllowEditLot(commonVariables.currentLot.common);
                /*
                @todo: убрать возможность редактирования
                * */
                $scope.isEditable = appsecurity.currentRole.isAllowEditLot(commonVariables.currentLot.common)
                    && commonVariables.currentLot.canEdit;

                if ($scope.lot.common.id===appsecurity.currentExpertGroup.common.id) {
                    $scope.canEditStage=true;
                }

                commonVariables.isLoading = false;

                // в подсистеме документов эти условия ненужны и мы можем добавлять этапы спокойно
                //$scope.canAddStage = true;
                if ($scope.lot.procurementEndDate) {
                    $scope.canAddStage = true;
                } else {
                    $scope.canAddStage = false;
                }
                $scope.$watch('lot.stages.length',fillStageYears);
            }, function () {
                commonVariables.isLoading = false;
            });
        }

        $scope.tableView = true;

        $scope.addWorkKind = function (work) {
            work.workKinds.push({
                title: '',
                qualitiveChar: '',
                result: '',
                nameOis: '',
                volumeOis: '',
                license: '',
                gosAccred: '',
                rightsOis: '',
                npa: '',
                warranty: '',
                specRequirements: ''
            });
        }

        $scope.removeWorkKind = function (work, workKind) {
            var workKindIndex = work.workKinds.indexOf(workKind);
            work.workKinds.splice(workKindIndex, 1);
        }

        $scope.openWorkKindEditModal = function (workKind, workType) {
            $mdDialog.show({
                templateUrl: '/js/documents/templates/workKindModal.html',
                controller: ['$scope', function ($scope) {
                    $scope.workKind = new WorkKindFactory(workKind || {});
                    $scope.workKindSettings = commonVariables.currentLot.settings.workKindSettings;

                    $scope.close = function () {
                        $mdDialog.hide();
                    }

                    $scope.saveWorkKind = function () {
                        if ($scope.workKindForm.$valid) {
                            if (angular.isDefined(workKind)) {
                                angular.extend(workKind, $scope.workKind);
                                workKind.update();
                                $mdDialog.hide();
                            } else {
                                $scope.workKind.workType = workType.id;
                                $scope.workKind.create().then(function () {
                                    $mdDialog.hide();
                                    workType.workKinds.push($scope.workKind);
                                });
                            }
                        }
                    }
                }]
            });
        }

        $scope.openDeleteModal = function (workKind, workType) {
            $mdDialog.show({
                templateUrl: '/js/documents/templates/deleteWorkKindModal.html',
                controller: ['$scope', function ($scope) {
                    $scope.exit = function () {
                        $mdDialog.hide();
                    }

                    $scope.remove = function () {
                        workKind.remove().then(function () {
                            var index = workType.workKinds.indexOf(workKind);
                            workType.workKinds.splice(index, 1);
                            $mdDialog.hide();
                        });
                    }
                }]
            })
        }

        $scope.openWorkTypeEditModal = function (stage) {
            workTypeService.stage = stage;
            // workTypeService.creatingWorkType = true;
            $mdDialog.show({
                templateUrl:'/js/documents/templates/modal/workTypeCreateEditTemplate.html',
                controller:'workTypeEditCtrl',
            });
        }
        $scope.viewWorkType = function (work,stage) {
            workTypeService.editFlag=true;
            workTypeService.currentWork=work;
            workTypeService.stage=stage;
            // workTypeService.creatingWorkType = true;
            $mdDialog.show({
                templateUrl:'/js/documents/templates/modal/workTypeCreateEditTemplate.html',
                controller:'workTypeEditCtrl',
            });
        }
        $scope.openStageCreateModal = function () {
          $mdDialog.show({
              templateUrl:'/js/documents/templates/modal/stageCreateTemplate.html',
              controller:'stageEditCtrl',
          });
        }
        $scope.viewStage = function (stage) {
            stagesService.editFlag=true;
            stagesService.currentStage=stage;
            $mdDialog.show({
                templateUrl:'/js/documents/templates/modal/stageCreateTemplate.html',
                controller:'stageEditCtrl',
            });
            // stagesService.creatingStage = true;

        }

        $scope.openWorkTypeDeleteModal = function (workType, stage) {
            $mdDialog.show({
                templateUrl: '/js/documents/templates/deleteWorkTypeModal.html',
                controller: ['$scope', function ($scope) {
                    $scope.exit = function () {
                        $mdDialog.hide();
                    }

                    $scope.remove = function () {
                        workType.remove().then(function () {
                            var index = stage.workTypes.indexOf(workType);
                            stage.workTypes.splice(index, 1);
                            workType.financingChanged(true, stage);
                            $mdDialog.hide();
                        })
                    }
                }]
            })
        }

        $scope.informCardFormSubmit = function () {
            commonVariables.currentLot.informCardSave();
        }

        $scope.openWorkKindCreateSmallModal = function (workType) {

            $mdDialog.show({
                templateUrl: '/js/documents/templates/workKindCreateSmallModal.html',
                controller: ['$scope', function ($scope) {
                    $scope.workKind = new WorkKindFactory({});

                    $scope.close = function () {
                        $mdDialog.hide();
                    }

                    $scope.createWorkKind = function () {
                        if ($scope.workKindCreateForm.$valid) {
                            $scope.workKind.workType = workType.id;
                            $scope.workKind.create().then(function () {
                                $mdDialog.hide();
                                workType.workKinds.push($scope.workKind);
                            });
                        }
                    }
                }]
            })
        }

        $scope.openTextEditorModal = function (object, field,parent,parent_field) {
            $mdDialog.show({
                templateUrl: '/js/documents/templates/textEditorModal.html',
                controller: ['$scope', function ($scope) {
                    $scope.text = object[field];

                    $scope.save = function () {
                        object[field] = $scope.text;
                        if (parent){
                            for (var i=0;i<parent[parent_field].length;i++){
                                if (parent[parent_field][i].id===object.id) {
                                    parent[parent_field][i][field]=object[field];
                                    if ( typeof parent[parent_field][i].id==='number') {
                                        delete parent[parent_field][i].id;
                                    }

                                    break;
                                }
                            }
                            var obj={};
                            obj[parent_field]=parent[parent_field];
                            parent.patch(obj).then(function(response){
                                if (response.data && response.data[parent_field]) {
                                    parent[parent_field]=response.data[parent_field];
                                }
                            })


                        } else {

                            object.patch(field);
                        }
                        $mdDialog.hide();
                    }
                    $scope.exit = $mdDialog.hide;
                }]
            })
        }
        //$scope.openComplexObjTextEditorModal = function (object, field) {
        //    $mdDialog.show({
        //        templateUrl: '/js/documents/templates/textEditorModal.html',
        //        controller: ['$scope', function ($scope) {
        //            $scope.text = object[field];
        //
        //            $scope.save = function () {
        //                object[field] = $scope.text;
        //                object.patch(field);
        //                $mdDialog.hide();
        //            }
        //            $scope.exit = $mdDialog.hide;
        //        }]
        //    })
        //}

        $scope.openHtmlPreviewModal = function (object, field) {
            $mdDialog.show({
                templateUrl: '/js/documents/templates/htmlPreviewModal.html',
                controller: ['$scope', function ($scope) {
                    $scope.text = object[field];

                    $scope.exit = $mdDialog.hide;
                }]
            })
        }
        $scope.downloadFile = function (document) {
            //window.open( 'http://isz.gosbook.ru' + document.file, '_blank' );
            window.open(document.file, '_blank');
        }
        $scope.saveMarketplace = function () {
            $scope.lot.patch({marketplace: {id: $scope.lot.marketplace.id}});
        }
        $scope.docReqRadioClick = function(){
            if ($scope.lot.inEditMode && $scope.lot.docRequirementsRadio) {
                $scope.lot.docRequirements=null;
            }
        }

        $scope.gzAgreementExtraRadioClick = function () {
            if ($scope.lot.inEditMode && $scope.lot.gzAgreementExtraRadio) {
                $scope.lot.gz[0].gzAgreementExtraName=null;
                $scope.lot.gz[0].gzAgreementExtraPosition=null;
            }
        }
        $scope.setDocClarificationEndDate = function () {
            $scope.lot.docClarificationEndDate = moment($scope.lot.applicationVskrDateTime).subtract(6,'days').toDate();
            $scope.$$phase||$scope.$apply();
        }
        $scope.setApplicationVskrDateTimeStart=function () {
            if (!$scope.lot.applicationVskrDateTimeStart) {
                if ($scope.lot.docClarificationEndDate) {
                    $scope.lot.applicationVskrDateTimeStart=moment($scope.lot.docClarificationEndDate).add(6,'days').toDate()
                } else {
                    $scope.lot.applicationVskrDateTimeStart=moment($scope.lot.docClarificationStartDate).add(7,'days').toDate()
                }

            }
        }
        $scope.saveRate = function(){
            $scope.lot.patch( { rateIndicator: $scope.lot.rateIndicator } );
        }
        $scope.okeiSearch = function (query) {
            var result = [], defer = $q.defer();
            if (query) {
                query = encodeURIComponent(query.replace("%20", "+"));
                selectRequest(apiService.okeisSelect + '&filters[title]=' + query + '&limit=10000').then(function (response) {
                    if (angular.isArray(response.data)) {
                        for (var i = 0; i < response.data.length; i++) {
                            result.push(response.data[i]);
                        }
                    }
                    defer.resolve(result);
                }, function (response) {
                    toastService.errorResponseShow('Ошибка получения данных справочника ОКЕИ', response);
                    defer.reject();
                })
                    .then(function () {
                        commonVariables.requestArr.pop();
                    });
            }

            return defer.promise;
        };
        function selectRequest(url) {
            //return $http({
            //    method: 'GET',
            //    headers: appsecurity.getSecurityHeaders(),
            //    url: url
            //})
            // var defer = $q.defer();
            // $http({
            //     method: 'GET',
            //     headers: appsecurity.getSecurityHeaders(),
            //     url: url
            // }).then(function (response) {
            //         defer.resolve(response);
            //     }, function () {
            //         $http({
            //             method: 'GET',
            //             headers: appsecurity.getSecurityHeaders(),
            //             url: url
            //         }).then(function (response) {
            //             defer.resolve(response);
            //         }, function (response) {
            //             defer.reject(response);
            //         })
            //     }
            // )
            // return defer.promise;
            function reqWrapper() {
                var defer = $q.defer();
                $http({
                    method: 'GET',
                    headers: appsecurity.getSecurityHeaders(),
                    url: url
                }).then(function (response) {
                        defer.resolve(response);
                    }, function (response) {
                        defer.reject(response);

                    }
                )
                return defer.promise;

            }
            var req=reqWrapper;
            commonVariables.requestArr.push(req);
            return req();
        }

        $scope.openDeal = function () {
            $scope.$$childTail.dealOpen = true;
            $scope.dealOpen = true;
        }
        $scope.closeDeal = function () {
            $scope.$$childTail.dealOpen = false;
            $scope.dealOpen = false;
        }

        $scope.editStage = function(stage){
            stagesService.editFlag=true;
            stagesService.currentStage=stage;
            // stagesService.creatingStage = true;
            $mdDialog.show({
                templateUrl:'/js/documents/templates/modal/stageCreateTemplate.html',
                controller:'stageEditCtrl',
            });
        }
        $scope.deleteStage = function(stage){
            $mdDialog.show({
                templateUrl: '/js/plans/templates/deleteStageModal.html',
                controller: ['$scope','commonVariables', function ($scope,commonVariables) {
                    $scope.remove = function () {
                        stagesService.removeStage(stage).then(function () {
                            commonVariables.currentLot.recalculateTotalPrice();
                        });

                        $mdDialog.hide();

                    }

                    $scope.close = $mdDialog.hide;
                }]
            });
        }
        $scope.editWorkType = function(work,stage){
            workTypeService.editFlag=true;
            workTypeService.currentWork=work;
            workTypeService.stage=stage;
            // workTypeService.creatingWorkType = true;
            $mdDialog.show({
                templateUrl:'/js/documents/templates/modal/workTypeCreateEditTemplate.html',
                controller:'workTypeEditCtrl',
            });
        }

        $scope.addRia = function(){
            $scope.lot.ria.push({id:$scope.lot.ria.length,name:null,volume:null});
        }
        $scope.removeRia = function(ria){
            for (var i=0;i<$scope.lot.ria.length;i++){
                if (ria.id===$scope.lot.ria[i].id) {
                    $scope.lot.ria.splice(i,1);
                    break;
                }
            }
            if (typeof ria.id!=='number') {
                $scope.lot.patch({ria:$scope.lot.ria}).then(function(response){
                    if (response.data&&response.data.ria){
                        $scope.lot.ria=response.data.ria;
                    }
                });
            }

        }
        function fillStageYears(){
            var obj={};
            if (angular.isArray($scope.lot.stages)) {
                for (var i=0; i<$scope.lot.stages.length;i++){
                    var year=moment($scope.lot.stages[i].executionDate).year();
                    obj[year]=1;
                }
                $scope.stageYears.splice(0);
                for (key in obj){
                    $scope.stageYears.push(key*1);
                }
                $scope.stageYears.sort();
                if (angular.isArray($scope.lot.rateIndicator)) {
                    for (var i=0;i<$scope.lot.rateIndicator.length;i++){
                        var rate=$scope.lot.rateIndicator[i];
                        var valuesBuff=[];

                        for (var j=0;j<$scope.stageYears.length;j++){
                            var flag=false;
                            for (var k=0;k<rate.value.length;k++){
                                if (rate.value[k].year===$scope.stageYears[j]) {
                                    flag=true;
                                    valuesBuff.push(rate.value[k]);
                                    break;
                                }
                            }
                            if (!flag) {
                                valuesBuff.push({
                                    year:$scope.stageYears[j],
                                    weight:null
                                })
                            }
                        }
                        rate.value=valuesBuff;
                    }
                }
            }
        }
        $scope.saveRateIndicator=function(){
            var objArr=[];
            $scope.lot.rateIndicator.forEach(function (rate) {
                var ob={
                    rateIndicator:rate.rateIndicator.id,
                    value:rate.value,
                    weight:rate.weight
                }
                if (rate.id){
                    ob.id=rate.id;
                }
                objArr.push(ob);
            })
            $scope.lot.patch({rateIndicator:objArr});
        }

      
    }]);

