/**
 * Created by pol on 13.01.2016.
 */
angular.module('isz').directive('noticeView',[function(){
    return {
        restrict:'E',
        templateUrl:'/js/documents/directives/noticeView/noticeViewDirectiveTemplate.html',
        replace:true,
        controller: ['$scope','commonVariables',function($scope,commonVariables){
            setMaxReportingDocDate();
            function setMaxReportingDocDate(){

                for (var i=0;i<$scope.lot.stages.length;i++){
                    if ($scope.lot.stages[i].reportingDocsDate) {
                        if (!$scope.maxReportingDocDate) {
                            $scope.maxReportingDocDate=$scope.lot.stages[i].reportingDocsDate;
                        } else if ($scope.lot.stages[i].reportingDocsDate>$scope.maxReportingDocDate) {
                            $scope.maxReportingDocDate=$scope.lot.stages[i].reportingDocsDate;
                        }
                    }
                }
            }
        }]
    }
}])
