/**
 * Created by pol on 19.04.2016.
 */
angular.module('isz').directive('infoCards',function () {
    return {
        restrict:'E',
        templateUrl:'/js/documents/directives/infoCards/infoCardsTemplate.html',
        replace:true,
        controller: ['$scope',function($scope){
          
        }]
    }
});
