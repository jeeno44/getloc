/**
 * Created by pol on 26.04.2016.
 */
angular.module('isz').controller('workTypeEditCtrl', ['$scope', '$mdDialog', 'workTypeService', 'commonVariables', 'toastService', 'hotkeys',
    function ($scope, $mdDialog, workTypeService, commonVariables, toastService, hotkeys) {

        hotkeys.bindTo($scope).add({
            combo: 'ctrl+enter',
            description: 'Сохранить',
            allowIn: ['INPUT', 'SELECT', 'TEXTAREA'],
            callback: function () {
                $scope.save();
            }
        });

        $scope.workType = workTypeService.getNewWorkType();
        $scope.lot=commonVariables.currentLot;

        // var stage = workTypeService.stage;
        $scope.stage = workTypeService.stage;

        $scope.types = ['good', 'labour'];
        // $scope.temp = $scope.workType.type;
        $scope.workTypeSettings = commonVariables.currentLot.settings.workTypeSettings;
        $scope.startingWorkDates = workTypeService.startingWorkDates;
        $scope.executionWorkTypes = workTypeService.executionTypes;
        $scope.workTypeFieldChange = function (field) {
            if (field === 'executionTerm') {
                var dat = moment($scope.workType.startDate).add($scope.workType.executionTerm, 'days');
                $scope.workType.executionDate = dat.toDate();
            }
            if (field === 'financing' && $scope.stage.workTypes && $scope.stage.workTypes.length && ( $scope.stage.financing != $scope.stage.getWorkTypeFinancingSumm())) {
                toastService.show('Цена по этапу не равна сумме стоимостей работ этапа', false)
            }
            $scope.workType.canSave = true;
        };
        $scope.save = function () {
            if ($scope.workTypeForm.$valid) {
                //$scope.workType.stage = stage;
                // $scope.workType.type = $scope.temp;
                if ($scope.workType.id) {
                    $scope.workType.save().then(function () {
                        //$scope.workType.financingChanged( true, stage );
                        toastService.show('Тип работ успешно сохранен', false);
                    });

                    $scope.close()

                } else {
                    $scope.workType.create().then(function () {
                        workTypeService.creatingWorkType = false;
                        //$scope.workType.financingChanged( true, stage );
                        $scope.stage.workTypes.push($scope.workType);
                    });
                }

            } else {
                toastService.show('Заполните обязательные поля', false)
            }
        }

        $scope.close = function () {
            workTypeService.editFlag = false;
            workTypeService.creatingWorkType = false;
            $mdDialog.hide();
        }
    }]);
