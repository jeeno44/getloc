angular.module( 'isz' ).directive( 'workKind', ['commonVariables', function ( commonVariables ) {

    return {
        restrict: 'E',
        replace: true,
        templateUrl: '/js/documents/directives/workKindDirective/template/workKindTemplate.html',
        controller: ['$scope', function ( $scope ) {

        }],
        link: function ( scope, element, attr ) {
            scope.currentLot = commonVariables.currentLot;
            scope.type = attr.type;
        }
    }
}] );