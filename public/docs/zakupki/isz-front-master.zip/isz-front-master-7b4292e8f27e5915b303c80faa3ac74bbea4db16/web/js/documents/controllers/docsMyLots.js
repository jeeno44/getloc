/**
 * Created by pol on 10.11.2015.
 */
angular.module( 'isz' ).controller( 'docsMyLots', ['$scope', 'appsecurity', 'lotsService', 'commonVariables', 'toastService',
    function ( $scope, appsecurity, lotsService, commonVaribales, toastService ) {
        $scope.statusedLots = lotsService.lots;
        commonVaribales.isLoading = true;
        commonVaribales.enterInLotTimeStamp=null;
        commonVaribales.currentMenuItem('/docs/my');

        $scope.commonVariables=commonVaribales;
        $scope.liftCategory = function ( to, from ) {
            if ( to === from ) {
                return;
            }

            var categoryToLift = $scope.statusedLots.splice( from, 1 ),
                categoriesEnding = $scope.statusedLots.splice( to, $scope.statusedLots.length - to );

            categoriesEnding.unshift( categoryToLift[0] );

            [].push.apply( $scope.statusedLots, categoriesEnding );
        }

        $scope.updateLotsList = function(){
            appsecurity.getUserInfo().then( function () {
                if (commonVaribales.currentSubSystem!=='docs'){
                    commonVaribales.currentSubSystem='docs';
                    appsecurity.currentRole.subsystemChanged();
                }
                lotsService.cleanLots();

                var role=appsecurity.currentRole.code;
                var expertizeShowArr = ['Rukovoditel_koordinator','Specialist_koordinator','Head_OM','Specialist_OM'];
                var authorShowArr = ['Rukovoditel_koordinator','Specialist_koordinator','Head_OM'];
                var expertShowArr=['Rukovoditel_koordinator','Specialist_koordinator','Rukovoditel_depzak','Specialist_depzak'];
                var depZakRoleArr=['Rukovoditel_depzak','Specialist_depzak'];
                var koordRoleArr=['Rukovoditel_koordinator','Specialist_koordinator'];
                var monitorRoleArr=['Head_OM','Specialist_OM'];

                var depZakRole=depZakRoleArr.indexOf(role)!==-1;
                var koordRole = koordRoleArr.indexOf(role)!==-1;
                var monitorRole = monitorRoleArr.indexOf(role)!==-1;


                $scope.expertizeShow=expertizeShowArr.indexOf(role)!==-1;
                $scope.authorShow=authorShowArr.indexOf(role)!==-1;
                $scope.expertShow=expertShowArr.indexOf(role)!==-1;
                $scope.readLot = appsecurity.currentRole.permissions.readLot;
                $scope.readSections = appsecurity.currentRole.permissions.readSections;
                $scope.controlSections = appsecurity.currentRole.permissions.controlSections;
                $scope.readSectionsAll = appsecurity.currentRole.permissions.readSectionsAll;

                $scope.readSectionsByGroup = appsecurity.currentRole.permissions.readSectionsByGroup;

                if ( !$scope.readSections && !$scope.readSectionsByGroup ) {
                    commonVaribales.isLoading = false;
                    toastService.show( 'У Вас нет прав доступа для просмотра этой страницы', false );
                } else {

                    // if (depZakRole){
                    //     commonVaribales.myDepartments = appsecurity.expertGroups.map( function ( gr ) {
                    //         return gr.common.id;
                    //     } );
                    //     lotsService.forceSync().then( function () {
                    //         lotsService.getMyLots();
                    //         commonVaribales.isLoading = false;
                    //     } , function () {
                    //         commonVaribales.isLoading = false;
                    //     } );
                    // } else {
                        lotsService.getUserLots(appsecurity.userInfo.id).then(function () {
                            // lotsService.getMyLots();
                            lotsService.separateByStatuses();
                            commonVaribales.isLoading = false;
                        },function () {
                            commonVaribales.isLoading = false;
                        })
                    // }
                    // if (koordRole){
                    //     lotsService.forceSync().then(function(){
                    //         lotsService.getMyLotsByStatus('on_agreement_coordinator');
                    //         commonVaribales.isLoading = false;
                    //     }, function () {
                    //         commonVaribales.isLoading = false;
                    //     });
                    // }
                    // if (monitorRole){
                    //     lotsService.forceSync().then(function(){
                    //         lotsService.getMyLotsByStatus('on_agreement_monitor');
                    //         commonVaribales.isLoading = false;
                    //     }, function () {
                    //         commonVaribales.isLoading = false;
                    //     });
                    // }
                    
                }
            } , function () {
                commonVaribales.isLoading = false;
            } );
        }
        $scope.updateLotsList();

    }] );