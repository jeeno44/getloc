// Declare app level module which depends on views, and components
angular.module('isz', [
    'ngRoute',
    'ngAria',
    'ngAnimate',
    'ngMaterial',
    'ngMdIcons',
    'ngMaterial.components.templates',
    'ngMaterial.components.datePicker',
    'flow',
    'ngTinyScrollbar',
    'mdlInit',
    'md.data.table',
    'as.sortable',
    'cfp.hotkeys'


], function () {
    //primitive implementation of jQuery.prototype.is
    angular.element.prototype.is = function (comparison) {
        var match = false;
        if (this.length == 1) {
            if (angular.isString(comparison)) {
                switch (comparison.slice(0, 1)) {
                    case '#':
                        match = this[0].id && this[0].id.toLowerCase() == comparison.slice(1).toLowerCase();
                        break;
                    case '.':
                        match = this.hasClass(comparison.slice(1));
                        break;
                    default:
                        match = this[0].nodeName.toLowerCase() == comparison.toLowerCase();
                }
            } else {
                match = this[0].isSameNode(comparison instanceof angular.element ? comparison[0] : comparison);
            }
        }
        return match;
    };




    <!-- Initialize material-scrolltop with (minimal) -->
    $('body').materialScrollTop({
        padding: 0,
        revealElement: 'body',
        revealPosition: 'bottom',
        duration: 600,
        easing: 'swing',
        onScrollEnd: function() {  }
    });
}).controller('topNavbar', ['$scope', '$route', '$location','$q', 'appsecurity', 'commonVariables', 'navigationService', 'serverVariables', 'toastService',
    function ($scope, $route, $location, $q, appsecurity, commonVariables, navigationService, serverVariables, toastService) {

        navigationService.clearAll();

        serverVariables.getSettings().then( function(){
            var settings = serverVariables.serverSettings;

            //krecu
            // localStorage.setItem('__at__','MTVlY2Q2MDYwNGNmNTFmOTMyZjg5MTMzN2ViZDAxN2JmNjgxNjIyZDVhOTlhZGE0ZGNiNzhiZjIxMTU5NjM3Mg');
            //t.rukvoditel
            //a.malov
            // localStorage.setItem('__at__','NDA1MTMwMmJhNzEzYTU3ZTRiZWQwOWYyNzRmMWNiYThmZTEzOGIzOTRjMGExZTdlZGJhMWMyNzExMGYwYjBiMw');
            if (appsecurity.getAccessToken() == undefined && $location.$$hash.indexOf('access_token') == -1) {
                window.location=settings.authServer+'/oauth/v2/auth?redirect_uri='+settings.productServer+'/oauth2/authorize&client_id='+settings.clientId+'&response_type=token';
                localStorage.navUrl = $location.$$path;
            }

            /**
             * browser detect
             */
            function getBrowser() {
                var ua = navigator.userAgent;

                var bName = function () {
                    if (ua.search(/Edge/) > -1) return "edge";
                    if (ua.search(/MSIE/) > -1) return "ie";
                    if (ua.search(/Trident/) > -1) return "ie11";
                    if (ua.search(/Firefox/) > -1) return "firefox";
                    if (ua.search(/Opera/) > -1) return "opera";
                    if (ua.search(/OPR/) > -1) return "operaWebkit";
                    if (ua.search(/YaBrowser/) > -1) return "yabrowser";
                    if (ua.search(/Chrome/) > -1) return "chrome";
                    if (ua.search(/Safari/) > -1) return "safari";
                    if (ua.search(/Maxthon/) > -1) return "maxthon";
                }();

                var version;
                switch (bName) {
                    case "edge":
                        version = (ua.split("Edge")[1]).split("/")[1];
                        break;
                    case "ie":
                        version = (ua.split("MSIE ")[1]).split(";")[0];
                        break;
                    case "ie11":
                        bName = "ie";
                        version = (ua.split("; rv:")[1]).split(")")[0];
                        break;
                    case "firefox":
                        version = ua.split("Firefox/")[1];
                        break;
                    case "opera":
                        version = ua.split("Version/")[1];
                        break;
                    case "operaWebkit":
                        bName = "opera";
                        version = ua.split("OPR/")[1];
                        break;
                    case "yabrowser":
                        version = (ua.split("YaBrowser/")[1]).split(" ")[0];
                        break;
                    case "chrome":
                        version = (ua.split("Chrome/")[1]).split(" ")[0];
                        break;
                    case "safari":
                        version = (ua.split("Version/")[1]).split(" ")[0];
                        break;
                    case "maxthon":
                        version = ua.split("Maxthon/")[1];
                        break;
                }

                var platform = 'desktop';
                if (/iphone|ipad|ipod|android|blackberry|mini|windows\sce|palm/i.test(navigator.userAgent.toLowerCase())) platform = 'mobile';

                var browsrObj;

                try {
                    browsrObj = {
                        platform: platform,
                        browser: bName,
                        versionFull: version,
                        versionShort: version.split(".")[0]
                    };
                } catch (err) {
                    browsrObj = {
                        platform: platform,
                        browser: 'unknown',
                        versionFull: 'unknown',
                        versionShort: 'unknown'
                    };
                }

                return browsrObj;
            }
            var browser = getBrowser();
            if ((browser.browser==='ie' && (browser.versionShort*1)<11)||
                (browser.browser==='firefox' && (browser.versionShort*1)<45)||
                (browser.browser==='opera' && (browser.versionShort*1)<32)||
                (browser.browser==='yabrowser' && (browser.versionShort*1)<16)||
                (browser.browser==='chrome' && (browser.versionShort*1)<50)||
                (browser.browser==='edge' && (browser.versionShort*1)<25)) {
                toastService.show('Вы используете устаревшую версию браузера '+browser.browser+' v.'+browser.versionShort+'. Это может привести к некорректному отображению страниц и работе системы в целом',false);
            }
            // toastService.show('Браузер '+browser.browser+' v.'+browser.versionShort,false);

            /**
             * Implement websocket messages
             */
            $.getScript(settings.socketUrl + "/socket.io/socket.io.js", function() {
                var socket = io.connect(settings.socketUrl);
                socket.on("messenger:display", function (data) {
                    toastService.showList(data.message, data.type);
                });
            });
        });

        

        $scope.$on('$routeChangeSuccess', function () {
            navigationService.rememberUrl($location.path());
            if ($route.current.$$route) {
                $scope.$root.currentPageName = $route.current.$$route.controller;
                if ($location.path() == '/profile' && !(appsecurity.currentRole&&appsecurity.currentRole.permissions&&appsecurity.currentRole.permissions.readProfile)) {
                    $location.path('/');
                }
            }

            if ($location.path().indexOf('/docs') !== -1) {
                commonVariables.currentSubSystem = 'docs';
            } else if ($location.path().indexOf('/plans') !== -1) {
                commonVariables.currentSubSystem = 'plans';
            } else if ($location.path().indexOf('/acceptance') !== -1) {
                commonVariables.currentSubSystem = 'acceptance';
            }
        });

    }]).
    controller('ListenerSocket', function ($scope) {
        var socket = io.connect("http://localhost");
        console.log(socket);
        socket.on("messenger:display", function(data){
            console.log(data);
        });

        socket.emit("test:test", data, function(){

        });
    }).
    directive('mdlTabs', [function () {

    return {
        restrict: 'A',
        compile: function (tElement, attrs) {
            new window.MaterialTabs(tElement[0]);

            if ('stretch' in attrs) {
                var tabs = tElement[0].querySelectorAll('.mdl-tabs__tab'),
                    i = tabs.length,
                    width = ( 100 / i ).toFixed(3) + '%';

                for (; i--; tabs[i].style.width = width); //empty
            }

            return function (scope) {

            }
        }
    };
}]);