--
-- PostgreSQL database dump
--

-- Dumped from database version 9.4.6
-- Dumped by pg_dump version 9.4.6
-- Started on 2016-03-23 08:40:18 MSK

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 1 (class 3079 OID 12776)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2980 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- TOC entry 2 (class 3079 OID 246231)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 2981 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 174 (class 1259 OID 246242)
-- Name: expertise_field; Type: TABLE; Schema: public; Owner: iszgosbookru; Tablespace: 
--

CREATE TABLE expertise_field (
    id uuid NOT NULL,
    expertise_user_id uuid NOT NULL,
    field_id character varying(255) DEFAULT NULL::character varying,
    comment text DEFAULT NULL::character varying,
    time_created timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    value boolean,
    entity_id uuid
);


ALTER TABLE expertise_field OWNER TO iszgosbookru;

--
-- TOC entry 175 (class 1259 OID 246251)
-- Name: expertise_group; Type: TABLE; Schema: public; Owner: iszgosbookru; Tablespace: 
--

CREATE TABLE expertise_group (
    id uuid NOT NULL,
    status_id uuid,
    group_id uuid,
    entity_id uuid NOT NULL,
    entity_type character varying(255) DEFAULT NULL::character varying NOT NULL,
    time_start timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    time_end timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    subsystem character varying(16) DEFAULT NULL::character varying
);


ALTER TABLE expertise_group OWNER TO iszgosbookru;

--
-- TOC entry 176 (class 1259 OID 246258)
-- Name: expertise_status; Type: TABLE; Schema: public; Owner: iszgosbookru; Tablespace: 
--

CREATE TABLE expertise_status (
    id uuid NOT NULL,
    title character varying(255) DEFAULT NULL::character varying,
    machine_name character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE expertise_status OWNER TO iszgosbookru;

--
-- TOC entry 177 (class 1259 OID 246266)
-- Name: expertise_user; Type: TABLE; Schema: public; Owner: iszgosbookru; Tablespace: 
--

CREATE TABLE expertise_user (
    id uuid NOT NULL,
    expertise_group_id uuid,
    status_id uuid,
    user_id uuid,
    time_start timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    time_end timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    role_name character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE expertise_user OWNER TO iszgosbookru;

--
-- TOC entry 178 (class 1259 OID 246272)
-- Name: work_flow; Type: TABLE; Schema: public; Owner: iszgosbookru; Tablespace: 
--

CREATE TABLE work_flow (
    id uuid NOT NULL,
    subsystem character varying(32) NOT NULL,
    entity_type character varying(32) NOT NULL,
    common_type character varying(32),
    govprogram_title character varying(255),
    specorg_full_name character varying(255),
    workflow_schema_yml text NOT NULL,
    workflow_schema text NOT NULL,
    name character varying(64) NOT NULL
);


ALTER TABLE work_flow OWNER TO iszgosbookru;

--
-- TOC entry 2968 (class 0 OID 246242)
-- Dependencies: 174
-- Data for Name: expertise_field; Type: TABLE DATA; Schema: public; Owner: iszgosbookru
--

COPY expertise_field (id, expertise_user_id, field_id, comment, time_created, value, entity_id) FROM stdin;
620d3ef7-bb42-4b15-8d94-83e757c65264	016d471c-59f0-473c-97f9-998cd7717bdb	number	Проверить корректность шифра лота	2016-03-18 09:41:46	t	\N
bac6d730-d25d-492a-8276-7b8cf00d0a18	1d86e908-1523-4889-bdcc-2570e6543ef4	root	Комментарий	2016-03-21 12:36:07	t	\N
\.


--
-- TOC entry 2969 (class 0 OID 246251)
-- Dependencies: 175
-- Data for Name: expertise_group; Type: TABLE DATA; Schema: public; Owner: iszgosbookru
--

COPY expertise_group (id, status_id, group_id, entity_id, entity_type, time_start, time_end, subsystem) FROM stdin;
a9266f23-e3dc-4a4c-856b-c7c848c1e450	fd49266f-2d82-4f22-87e2-e5e3148e38cd	465caf09-96f9-4b25-a827-3a926d310231	eb851ee4-58e4-40d7-952d-914f9c7fb849	lot	2016-01-21 10:43:21	\N	fp_planirovanie
1c8656b3-6d7a-4bbd-b7a2-17cae0d1d022	fd49266f-2d82-4f22-87e2-e5e3148e38cd	465caf09-96f9-4b25-a827-3a926d310231	71a4c9be-347c-447b-9f2c-5d571692572e	lot	2016-01-21 10:08:51	\N	fp_planirovanie
3375170c-178c-49fd-9091-05d0b37fba36	fd49266f-2d82-4f22-87e2-e5e3148e38cd	465caf09-96f9-4b25-a827-3a926d310231	e3403a17-1c9c-4ddc-bcee-909722d53f0b	lot	2016-01-21 10:41:00	\N	fp_planirovanie
92c92282-aa60-41bb-9bd6-9f0b64970e94	fd49266f-2d82-4f22-87e2-e5e3148e38cd	465caf09-96f9-4b25-a827-3a926d310231	f0441fb3-dde0-4d06-a5b2-4fcf25a1a2a6	lot	2016-01-21 10:46:30	\N	fp_planirovanie
1a42a643-2d19-44ac-9161-0124ee3c0356	4ffc614f-353d-4753-bc27-299925e2276a	465caf09-96f9-4b25-a827-3a926d310231	b8070eb1-36a9-4ad9-902c-7ce5df84d82e	lot	2016-01-14 19:31:12	\N	fp_planirovanie
f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	f54b128d-0bba-4c12-b22b-bd9e32e137b4	27446dec-c610-4fec-9b2d-0e64d358c666	add914d2-1f47-42b0-9650-10a03e003dce	plan	2016-01-14 19:44:30	\N	fp_planirovanie
1ddaf231-cdc7-420d-b42c-c14d84d33db3	b4dff173-81c7-47ab-956c-c8e7fb3615d7	27446dec-c610-4fec-9b2d-0e64d358c666	6e5d4f7d-ef2a-47a3-a7c2-7cc4e71b7bc0	plan	2016-01-14 19:47:43	\N	fp_planirovanie
3bb0433b-e5e7-4638-a88d-8d69e588aae3	f54b128d-0bba-4c12-b22b-bd9e32e137b4	465caf09-96f9-4b25-a827-3a926d310231	296ae6ed-4579-47f5-9364-9c520a9803bb	lot	2016-01-18 13:07:06	\N	fp_planirovanie
45120458-8eec-4ef6-9a39-791e042857ac	f54b128d-0bba-4c12-b22b-bd9e32e137b4	465caf09-96f9-4b25-a827-3a926d310231	8dd3063a-a58d-46fb-ba63-ca0681a582f0	lot	2016-01-18 13:07:52	\N	fp_planirovanie
885b86e1-0f97-4a9d-9a38-2d62043fe4f6	b4dff173-81c7-47ab-956c-c8e7fb3615d7	27446dec-c610-4fec-9b2d-0e64d358c666	9221e200-7f75-4b6b-b634-7b4c98385130	lot	2016-01-19 09:49:31	\N	fp_planirovanie
a12228a9-2b5a-4130-bc32-0b7a01a3dd37	b4dff173-81c7-47ab-956c-c8e7fb3615d7	f5bee918-4a0f-40e7-bab7-3a7f248c775c	03271472-3ecc-4e52-9fe3-f2d24e0a6364	lot	2016-01-27 16:48:16	\N	fp_planirovanie
9fe93b69-a35d-4b2f-959a-836efd76fe71	fd49266f-2d82-4f22-87e2-e5e3148e38cd	f5bee918-4a0f-40e7-bab7-3a7f248c775c	dc4404a8-d7ed-483c-bc46-b405e1ac42b8	lot	2016-02-26 15:13:36	\N	fp_planirovanie
1dd67bf0-7641-4717-a9a5-8a6969461243	f54b128d-0bba-4c12-b22b-bd9e32e137b4	27446dec-c610-4fec-9b2d-0e64d358c666	89d1aeef-6a9d-412d-84e6-b6744a3ab4ac	lot	2016-03-18 09:40:29	\N	fp_planirovanie
35e703d6-1818-452e-b309-cda807dcdf8d	b4dff173-81c7-47ab-956c-c8e7fb3615d7	27446dec-c610-4fec-9b2d-0e64d358c666	b8325d00-dfc2-48b6-bcc5-d656bb027aff	lot	2016-01-19 15:38:46	\N	fp_planirovanie
67494a8e-cfc4-4d98-95a3-75ceda99ee0b	fd49266f-2d82-4f22-87e2-e5e3148e38cd	465caf09-96f9-4b25-a827-3a926d310231	c6843edf-31c6-4130-bd64-47d6ba34d3ed	lot	2016-01-21 10:27:17	\N	fp_planirovanie
3a70b0f0-6c2e-445c-86fd-af7f4c08e2f3	fd49266f-2d82-4f22-87e2-e5e3148e38cd	465caf09-96f9-4b25-a827-3a926d310231	cee796f7-5969-4118-8742-f06893522d47	lot	2016-01-21 16:02:56	\N	fp_planirovanie
9a7989f0-038c-4fae-8bcc-d44e5ae72ea5	fd49266f-2d82-4f22-87e2-e5e3148e38cd	465caf09-96f9-4b25-a827-3a926d310231	2a1cb94e-3e4b-41b1-a201-63fcb3e1ffbc	lot	2016-01-21 10:50:34	\N	fp_planirovanie
30f348d2-fe3d-458a-b7dc-9de8ff1bcb91	fd49266f-2d82-4f22-87e2-e5e3148e38cd	465caf09-96f9-4b25-a827-3a926d310231	4ed26c6a-9695-40ad-88b2-089188586bb6	lot	2016-01-21 15:18:24	\N	fp_planirovanie
5db7f507-9905-461b-a3dc-d60048110343	fd49266f-2d82-4f22-87e2-e5e3148e38cd	465caf09-96f9-4b25-a827-3a926d310231	2f0f35be-97a8-4889-8824-c03a4b4b8598	lot	2016-01-21 11:45:45	\N	fp_planirovanie
\.


--
-- TOC entry 2970 (class 0 OID 246258)
-- Dependencies: 176
-- Data for Name: expertise_status; Type: TABLE DATA; Schema: public; Owner: iszgosbookru
--

COPY expertise_status (id, title, machine_name) FROM stdin;
4afa41e6-5ded-4b04-a92b-bd2efa6b9747	Черновик	draft
b4dff173-81c7-47ab-956c-c8e7fb3615d7	Согласован	approved
fd49266f-2d82-4f22-87e2-e5e3148e38cd	На доработке	on_completion
49742445-edab-4467-9297-596432e871f4	На согласовании ОМ	on_agreement_monitor
5958b67c-cfcd-4a63-be2c-48b32974d772	На согласовании К	on_agreement_coordinator
f54b128d-0bba-4c12-b22b-bd9e32e137b4	На согласовании РДЗ	on_agreement
5cc7bbe9-0f73-4786-af13-7ddccd26d1f0	На согласовании экспертов	on_delegation
4ffc614f-353d-4753-bc27-299925e2276a	На планировании	planning
07e82356-165a-4c5b-bbae-7de55391769f	На доработке	on_completion_dzp
75b6bbfd-cec4-4460-8dd4-fda2d8ee403e	Согласован РДЗ Подвед	approved_dzp
af82443e-184e-422a-8233-af89cdec51d2	На согласовании Руководителем Куратором	on_agreement_curator
5990a810-55cc-4b70-9da4-c8b9297fd71c	На доработке Руководителем ДЗП	on_completion_curator
\.


--
-- TOC entry 2971 (class 0 OID 246266)
-- Dependencies: 177
-- Data for Name: expertise_user; Type: TABLE DATA; Schema: public; Owner: iszgosbookru
--

COPY expertise_user (id, expertise_group_id, status_id, user_id, time_start, time_end, role_name) FROM stdin;
9db0ca14-1035-42e5-af9e-3fed54d23d6d	1a42a643-2d19-44ac-9161-0124ee3c0356	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-14 19:31:12	\N	author
ca196706-59be-4744-b18b-7b17c66b3558	1a42a643-2d19-44ac-9161-0124ee3c0356	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-14 19:31:12	\N	author
8cb0de8f-1102-4b25-a6fb-5230d88967c3	1a42a643-2d19-44ac-9161-0124ee3c0356	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-14 19:31:12	\N	author
5cf37f14-7d76-4f4e-af69-a872cb5cc0a6	1a42a643-2d19-44ac-9161-0124ee3c0356	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-14 19:31:12	\N	author
4f40b173-2543-4a5b-ac0a-eaa8633481eb	1a42a643-2d19-44ac-9161-0124ee3c0356	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-14 19:31:12	\N	author
58994b03-8c3c-4223-9ab9-99a2cc50510c	1a42a643-2d19-44ac-9161-0124ee3c0356	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-14 19:31:12	\N	author
a16f9a91-85b5-4bfc-999a-dd25ff1f53c3	1a42a643-2d19-44ac-9161-0124ee3c0356	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-14 19:31:12	\N	author
1084c496-6e05-4e1b-b762-a5fc90afb095	1a42a643-2d19-44ac-9161-0124ee3c0356	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-14 19:31:12	\N	author
aada9cd3-7a50-4ab8-8526-bf9fc4c44354	1a42a643-2d19-44ac-9161-0124ee3c0356	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-14 19:31:12	\N	author
01da4bec-ce57-473c-840e-7e06cabda40e	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	1d03f765-fdaa-4b64-9f88-a772eba12e51	2016-01-14 19:44:30	\N	coordinator
d05abd09-ebdb-4a0f-b3d3-af8d05db33ce	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	3ef14eae-7965-4400-a4f1-b5b713869622	2016-01-14 19:44:30	\N	director_dz
91d80c4b-be3e-4410-8204-8dad6c4725d3	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-14 19:44:30	\N	director_dz
45ac61ce-1572-4383-86fb-287a87e395de	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-14 19:44:30	\N	director_dz
a5ea6c4b-b013-4add-976a-cb5cc3768945	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-14 19:44:30	\N	director_dz
a0eb87ad-7285-418f-97fe-85af11f45b7d	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-14 19:44:30	\N	director_dz
5d2956db-5e4d-411a-bc44-97a1f713d02c	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-14 19:44:30	\N	director_dz
ec944605-eb80-4727-86fb-1e35d9a528a7	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	dd822929-f6a0-42e6-9b9c-4e6c3844cc4f	2016-01-14 19:44:31	\N	coordinator
fce9fea4-0592-40ea-826c-598b84b4f52f	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-14 19:44:31	\N	director_dz
33741ba3-8a92-41c2-8a54-45de7aedbd36	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-14 19:44:31	\N	director_dz
317cd6c1-e0f7-4f01-8506-0c89e9328740	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-14 19:44:31	\N	director_dz
040d15db-e1db-4531-8f1e-6021a3c2743a	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	68bb5eec-19eb-4a12-9954-8035581540ed	2016-01-14 19:44:31	\N	coordinator
5c5b17dc-4a3b-48ec-8246-df6809c3baba	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	9fedf471-0a97-451c-894d-03e157f0db94	2016-01-14 19:44:31	\N	coordinator
16a0c42d-1c3b-4c09-8399-b4755782cdb5	f2abb013-f56d-41b4-95dd-6cd9cc3c93c6	\N	6502e4a5-5a8f-4758-bf9f-e7d60f6aaa30	2016-01-14 19:44:31	\N	director_dz
555e01ea-a516-44a3-9560-fed5db455fc2	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	1d03f765-fdaa-4b64-9f88-a772eba12e51	2016-01-14 19:47:43	\N	coordinator
3dcc9038-7f3f-4fbe-9e2e-19804a165e8e	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	3ef14eae-7965-4400-a4f1-b5b713869622	2016-01-14 19:47:43	\N	director_dz
a576fdc5-cd6f-487a-a55b-bc287da1d4b7	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-14 19:47:43	\N	director_dz
b5df4ace-f5d9-43dd-9d47-b6eb2c379612	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-14 19:47:43	\N	director_dz
e3cfec92-5d89-44c4-a2a1-0607c55f1a57	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-14 19:47:43	\N	director_dz
657d315f-b6f5-49bf-a0df-9e757dc12a83	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-14 19:47:43	\N	director_dz
5e0c501f-28d4-4785-89b4-244f9af2c396	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-14 19:47:43	\N	director_dz
3460ccf6-8a74-45da-9a05-5cd46bde554c	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	dd822929-f6a0-42e6-9b9c-4e6c3844cc4f	2016-01-14 19:47:43	\N	coordinator
73ab9cda-ee7e-4c40-b020-a90556c100a0	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-14 19:47:43	\N	director_dz
293b5749-0325-4e05-b761-239f4cfc75b0	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-14 19:47:43	\N	director_dz
df3345cc-1f67-4573-886a-43b33c7ef291	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-14 19:47:43	\N	director_dz
20649ea6-c349-4a70-9ca3-71264b92dda3	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	68bb5eec-19eb-4a12-9954-8035581540ed	2016-01-14 19:47:43	\N	coordinator
20e4504c-c3a9-47ab-a0ce-675de1d7ee95	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	9fedf471-0a97-451c-894d-03e157f0db94	2016-01-14 19:47:43	\N	coordinator
b1b6ba1b-1dcb-4394-82cb-1339e6185ecb	1ddaf231-cdc7-420d-b42c-c14d84d33db3	\N	6502e4a5-5a8f-4758-bf9f-e7d60f6aaa30	2016-01-14 19:47:43	\N	director_dz
5c375c55-7588-48de-9d18-af0537b9ac5d	3bb0433b-e5e7-4638-a88d-8d69e588aae3	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-18 13:07:06	\N	author
d1150cbc-bd67-4c21-be72-20ad8759eb00	3bb0433b-e5e7-4638-a88d-8d69e588aae3	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-18 13:07:06	\N	author
8a8829f7-914b-4cb2-8d01-38227a89c3e9	3bb0433b-e5e7-4638-a88d-8d69e588aae3	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-18 13:07:06	\N	author
e0383163-fb66-440d-995c-5b7abda50e97	3bb0433b-e5e7-4638-a88d-8d69e588aae3	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-18 13:07:06	\N	author
1d86e908-1523-4889-bdcc-2570e6543ef4	3bb0433b-e5e7-4638-a88d-8d69e588aae3	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-18 13:07:06	\N	author
7d99f101-e473-449e-b224-382958ce8258	3bb0433b-e5e7-4638-a88d-8d69e588aae3	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-18 13:07:06	\N	author
651022ce-9ce8-45e5-9881-47d342696966	3bb0433b-e5e7-4638-a88d-8d69e588aae3	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-18 13:07:06	\N	author
dd631996-c46b-4d01-bf91-bb66460142d3	3bb0433b-e5e7-4638-a88d-8d69e588aae3	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-18 13:07:06	\N	author
eeb6d906-0d3c-42af-a840-ced45fc099a6	3bb0433b-e5e7-4638-a88d-8d69e588aae3	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-18 13:07:06	\N	author
89241755-eab6-4e77-93f9-4d55ca176973	45120458-8eec-4ef6-9a39-791e042857ac	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-18 13:07:52	\N	author
c5601b4b-959d-4b85-b23f-25b2e0b0d109	45120458-8eec-4ef6-9a39-791e042857ac	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-18 13:07:52	\N	author
d6d1c67e-6100-49e4-9d22-31a8e79298ed	45120458-8eec-4ef6-9a39-791e042857ac	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-18 13:07:52	\N	author
0963d81a-5f0b-4384-880b-45cd1cb4c67c	45120458-8eec-4ef6-9a39-791e042857ac	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-18 13:07:52	\N	author
099fb6f7-68be-40f4-bb91-be7fa6dadeb0	45120458-8eec-4ef6-9a39-791e042857ac	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-18 13:07:52	\N	author
df10630d-f328-4b24-910b-04e7f003b636	45120458-8eec-4ef6-9a39-791e042857ac	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-18 13:07:52	\N	author
8c46aae1-7399-42bf-ae6f-d7ee5c87ba2e	45120458-8eec-4ef6-9a39-791e042857ac	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-18 13:07:52	\N	author
4aea26f7-74fa-4782-af23-e28aeb05d5a4	45120458-8eec-4ef6-9a39-791e042857ac	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-18 13:07:52	\N	author
333ce4c2-3c93-4ca9-b377-5585e0efaf85	45120458-8eec-4ef6-9a39-791e042857ac	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-18 13:07:52	\N	author
dbca17ee-a52e-44e0-a5a0-5eacd05ecd70	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	1d03f765-fdaa-4b64-9f88-a772eba12e51	2016-01-19 09:49:32	\N	coordinator
6a2a7fb8-780b-4ac0-a8c1-1a71f3959bf8	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	3ef14eae-7965-4400-a4f1-b5b713869622	2016-01-19 09:49:32	\N	director_dz
67f19669-25f1-4900-8a3f-3ee99426ddb6	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-19 09:49:32	\N	director_dz
72702287-6a53-49b5-b692-d07556386733	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-19 09:49:32	\N	director_dz
17c070ae-8226-4a23-bf00-45adb5fd97a9	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-19 09:49:32	\N	director_dz
a85d0905-23fb-4505-8dee-3f841ebf7cbc	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-19 09:49:32	\N	director_dz
c288e335-5f7d-42cc-b43e-1f688af888a9	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-19 09:49:32	\N	director_dz
bc199998-58c4-46fa-b1da-f81242e48507	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	dd822929-f6a0-42e6-9b9c-4e6c3844cc4f	2016-01-19 09:49:32	\N	coordinator
c0fc09f2-76f2-4c68-a539-8499a914605c	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-19 09:49:32	\N	director_dz
a76e98dc-f35a-43b7-9403-ed8fe416aac5	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-19 09:49:32	\N	director_dz
53f9d2d9-794e-4f5e-aa34-8964866e0dbb	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-19 09:49:32	\N	director_dz
6398cdd9-84c6-4abc-9309-547b765831df	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	68bb5eec-19eb-4a12-9954-8035581540ed	2016-01-19 09:49:32	\N	coordinator
1429b656-bf07-4c57-ad70-3221b685c138	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	9fedf471-0a97-451c-894d-03e157f0db94	2016-01-19 09:49:32	\N	coordinator
a120db98-af16-4035-83d5-348f55a4fb90	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	6502e4a5-5a8f-4758-bf9f-e7d60f6aaa30	2016-01-19 09:49:32	\N	director_dz
158a0ad5-dd5c-48fa-8f45-1a0ff98faa31	885b86e1-0f97-4a9d-9a38-2d62043fe4f6	\N	5a992837-6622-45b0-b4c3-3ff8774aa004	2016-01-19 09:49:32	\N	coordinator
fdb45dc9-32ff-447b-8ad9-7a582b6a918d	35e703d6-1818-452e-b309-cda807dcdf8d	\N	1d03f765-fdaa-4b64-9f88-a772eba12e51	2016-01-19 15:38:46	\N	coordinator
93fe832c-4225-4273-a45d-eec4334958ac	35e703d6-1818-452e-b309-cda807dcdf8d	\N	3ef14eae-7965-4400-a4f1-b5b713869622	2016-01-19 15:38:46	\N	director_dz
8a04b06c-e4fa-4421-95fb-f34a3cc3463a	35e703d6-1818-452e-b309-cda807dcdf8d	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-19 15:38:46	\N	director_dz
41f575e4-aada-4690-bda7-3fe744497bda	35e703d6-1818-452e-b309-cda807dcdf8d	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-19 15:38:46	\N	director_dz
38d6eb99-1798-4bdb-a00b-11e13a844dd3	35e703d6-1818-452e-b309-cda807dcdf8d	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-19 15:38:46	\N	director_dz
a2a27d60-6342-4114-a212-89ea3df37f83	35e703d6-1818-452e-b309-cda807dcdf8d	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-19 15:38:46	\N	director_dz
c3fb6784-8ae0-4314-a8f6-1c2d46ded8a7	35e703d6-1818-452e-b309-cda807dcdf8d	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-19 15:38:46	\N	director_dz
7395fbcf-8388-4beb-a427-c9aed661b71f	35e703d6-1818-452e-b309-cda807dcdf8d	\N	dd822929-f6a0-42e6-9b9c-4e6c3844cc4f	2016-01-19 15:38:46	\N	coordinator
b5f8cd2f-b13d-4736-b294-a4cc4d9a1128	35e703d6-1818-452e-b309-cda807dcdf8d	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-19 15:38:46	\N	director_dz
c9189f9d-7cec-4c30-85e1-d0ed3022f26d	35e703d6-1818-452e-b309-cda807dcdf8d	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-19 15:38:46	\N	director_dz
3f1e62b6-e9c9-4645-a828-d715a4e338b5	35e703d6-1818-452e-b309-cda807dcdf8d	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-19 15:38:46	\N	director_dz
fb4f93f2-8209-484e-9aeb-0a664ed51a93	35e703d6-1818-452e-b309-cda807dcdf8d	\N	68bb5eec-19eb-4a12-9954-8035581540ed	2016-01-19 15:38:46	\N	coordinator
cd077d50-fee5-46c8-9b1e-131c87c700e7	35e703d6-1818-452e-b309-cda807dcdf8d	\N	9fedf471-0a97-451c-894d-03e157f0db94	2016-01-19 15:38:46	\N	coordinator
b3b3cf52-f481-44e7-a9ab-35e111f9dd84	35e703d6-1818-452e-b309-cda807dcdf8d	\N	6502e4a5-5a8f-4758-bf9f-e7d60f6aaa30	2016-01-19 15:38:46	\N	director_dz
39fe0584-714b-404d-8c0a-91ac40f1ff6e	35e703d6-1818-452e-b309-cda807dcdf8d	\N	5a992837-6622-45b0-b4c3-3ff8774aa004	2016-01-19 15:38:46	\N	coordinator
273262ef-4711-4046-b0e5-91abe7067246	35e703d6-1818-452e-b309-cda807dcdf8d	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-19 15:38:46	\N	director_dz
35f9e832-613f-482d-8aa0-c7b76c57e084	1c8656b3-6d7a-4bbd-b7a2-17cae0d1d022	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-21 10:08:51	\N	author
ce4216bd-3990-43ab-9e1d-ca7a0e327721	1c8656b3-6d7a-4bbd-b7a2-17cae0d1d022	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-21 10:08:51	\N	author
9359696c-8c50-4425-aa99-96e66e545a14	1c8656b3-6d7a-4bbd-b7a2-17cae0d1d022	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-21 10:08:51	\N	author
452496f5-d75d-44a1-baee-3b555cf72949	1c8656b3-6d7a-4bbd-b7a2-17cae0d1d022	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-21 10:08:51	\N	author
e2eea1b6-136e-4fb9-94d4-6e2d03ea9803	1c8656b3-6d7a-4bbd-b7a2-17cae0d1d022	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-21 10:08:51	\N	author
d86209bf-04d3-4801-9e15-d30e546372f4	1c8656b3-6d7a-4bbd-b7a2-17cae0d1d022	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-21 10:08:51	\N	author
034698c8-4fd3-4b52-9036-5af880241e2b	1c8656b3-6d7a-4bbd-b7a2-17cae0d1d022	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-21 10:08:51	\N	author
ff4edca6-7254-4b6c-b379-4bd79291d892	1c8656b3-6d7a-4bbd-b7a2-17cae0d1d022	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-21 10:08:51	\N	author
25236046-2a42-41af-8f29-2197382cabae	1c8656b3-6d7a-4bbd-b7a2-17cae0d1d022	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-21 10:08:51	\N	author
f1d007a2-14c8-49a7-abaa-290509de3ea2	67494a8e-cfc4-4d98-95a3-75ceda99ee0b	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-21 10:27:17	\N	author
643e8a0d-52da-4ef6-8199-eef67f0ab87b	67494a8e-cfc4-4d98-95a3-75ceda99ee0b	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-21 10:27:17	\N	author
e19624b7-c1e2-4c93-8b81-37ee36148f78	67494a8e-cfc4-4d98-95a3-75ceda99ee0b	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-21 10:27:17	\N	author
4012eb97-f1dd-4de1-897a-ae8025a3779b	67494a8e-cfc4-4d98-95a3-75ceda99ee0b	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-21 10:27:17	\N	author
1544b767-7cbf-446b-b19b-542d949d5b89	67494a8e-cfc4-4d98-95a3-75ceda99ee0b	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-21 10:27:17	\N	author
506eabad-198f-4d18-a2a2-c90f54cdb624	67494a8e-cfc4-4d98-95a3-75ceda99ee0b	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-21 10:27:17	\N	author
fad6d074-9c48-426b-a460-49820311ec25	67494a8e-cfc4-4d98-95a3-75ceda99ee0b	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-21 10:27:17	\N	author
f232f771-293f-41e0-9063-66ca048db891	67494a8e-cfc4-4d98-95a3-75ceda99ee0b	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-21 10:27:17	\N	author
85b77a63-357f-46f9-8c74-679b485e293d	67494a8e-cfc4-4d98-95a3-75ceda99ee0b	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-21 10:27:17	\N	author
454b2301-76e5-40db-852d-51f459e486b0	3375170c-178c-49fd-9091-05d0b37fba36	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-21 10:41:00	\N	author
eeacb561-7aa8-4eb9-8a31-7830107019a6	3375170c-178c-49fd-9091-05d0b37fba36	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-21 10:41:00	\N	author
83cb0f77-7491-4368-911f-970c04c3d06b	3375170c-178c-49fd-9091-05d0b37fba36	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-21 10:41:00	\N	author
a8c3c6d0-cdf7-421e-a31a-6440a27a27ee	3375170c-178c-49fd-9091-05d0b37fba36	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-21 10:41:00	\N	author
d10cf694-295c-4a95-aa30-ee4bba541463	3375170c-178c-49fd-9091-05d0b37fba36	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-21 10:41:00	\N	author
d64eb26b-da5b-4b64-b095-1511065da64b	3375170c-178c-49fd-9091-05d0b37fba36	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-21 10:41:00	\N	author
e899dfd5-f2d4-4df6-8e5a-c99402a6407b	3375170c-178c-49fd-9091-05d0b37fba36	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-21 10:41:00	\N	author
b4fa5095-3086-4c42-bb7f-20c3294b0053	3375170c-178c-49fd-9091-05d0b37fba36	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-21 10:41:00	\N	author
09573709-9a5d-4d05-a6c1-ce768b14412c	3375170c-178c-49fd-9091-05d0b37fba36	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-21 10:41:00	\N	author
af9d622c-10fa-429d-9db4-997b3507bf53	a9266f23-e3dc-4a4c-856b-c7c848c1e450	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-21 10:43:21	\N	author
9e1a4ff2-cbce-4a72-867e-a217cc079dcd	a9266f23-e3dc-4a4c-856b-c7c848c1e450	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-21 10:43:21	\N	author
b6e98249-73cf-4a06-a024-fa1d054fccec	a9266f23-e3dc-4a4c-856b-c7c848c1e450	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-21 10:43:21	\N	author
3c7523aa-39ff-4f83-8740-efd583903897	a9266f23-e3dc-4a4c-856b-c7c848c1e450	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-21 10:43:21	\N	author
192dfb5b-361a-4be3-9204-00c7138bcb52	a9266f23-e3dc-4a4c-856b-c7c848c1e450	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-21 10:43:21	\N	author
c7e33ddc-366a-4247-b6e3-0669ba4a9748	a9266f23-e3dc-4a4c-856b-c7c848c1e450	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-21 10:43:21	\N	author
02d2460a-a878-4477-b61b-106e43a30e01	a9266f23-e3dc-4a4c-856b-c7c848c1e450	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-21 10:43:21	\N	author
68e316e3-ce18-4805-8784-f77f416db4fb	a9266f23-e3dc-4a4c-856b-c7c848c1e450	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-21 10:43:21	\N	author
84d4e954-89f5-44c9-96de-fc30c85c9879	a9266f23-e3dc-4a4c-856b-c7c848c1e450	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-21 10:43:21	\N	author
b00d0192-02ef-41da-9ebd-554ffe0b894e	92c92282-aa60-41bb-9bd6-9f0b64970e94	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-21 10:46:30	\N	author
57f765dc-4089-4104-b8df-22d5cd86bbab	92c92282-aa60-41bb-9bd6-9f0b64970e94	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-21 10:46:30	\N	author
da370583-5aa4-4186-850e-c0b5ee2fbe22	92c92282-aa60-41bb-9bd6-9f0b64970e94	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-21 10:46:30	\N	author
91e8be4c-4b4a-4c17-9a61-3a4524f3a5b0	92c92282-aa60-41bb-9bd6-9f0b64970e94	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-21 10:46:30	\N	author
889b232c-68cb-484f-bf52-801251ee676e	92c92282-aa60-41bb-9bd6-9f0b64970e94	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-21 10:46:30	\N	author
99263fa2-fa36-4dd1-80b4-8c6b5bd70e06	92c92282-aa60-41bb-9bd6-9f0b64970e94	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-21 10:46:30	\N	author
4f5035c0-72dd-4302-84b5-9cdb60cc5841	92c92282-aa60-41bb-9bd6-9f0b64970e94	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-21 10:46:30	\N	author
3d8ddd33-e6e3-4431-99bf-ea96ac19e0ff	92c92282-aa60-41bb-9bd6-9f0b64970e94	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-21 10:46:30	\N	author
976743c2-c495-4ada-a479-d6060340bf89	92c92282-aa60-41bb-9bd6-9f0b64970e94	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-21 10:46:30	\N	author
0271d4e6-5767-4be4-8877-c7047dbec55f	9a7989f0-038c-4fae-8bcc-d44e5ae72ea5	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-21 10:50:34	\N	author
de1d9d48-9b52-4ea9-a3d7-525a527c0952	9a7989f0-038c-4fae-8bcc-d44e5ae72ea5	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-21 10:50:34	\N	author
d8eae994-def2-4843-ba9e-31e17d1c4fea	9a7989f0-038c-4fae-8bcc-d44e5ae72ea5	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-21 10:50:34	\N	author
abee73f0-1a86-4240-bc16-d3b4c4864919	9a7989f0-038c-4fae-8bcc-d44e5ae72ea5	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-21 10:50:34	\N	author
256c435a-5554-43ce-b5eb-be09027654a9	9a7989f0-038c-4fae-8bcc-d44e5ae72ea5	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-21 10:50:34	\N	author
88c76861-b507-4868-af1e-9fadf335c993	9a7989f0-038c-4fae-8bcc-d44e5ae72ea5	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-21 10:50:34	\N	author
a2faa7ee-4201-4c33-8529-99d82cdec513	9a7989f0-038c-4fae-8bcc-d44e5ae72ea5	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-21 10:50:34	\N	author
024f3093-105a-4ec5-a9ef-87ae1af342d1	9a7989f0-038c-4fae-8bcc-d44e5ae72ea5	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-21 10:50:34	\N	author
bd752149-e447-4d67-ae08-d9c85ec33ff8	9a7989f0-038c-4fae-8bcc-d44e5ae72ea5	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-21 10:50:34	\N	author
683c4862-e622-4cc7-b741-493ee067d001	5db7f507-9905-461b-a3dc-d60048110343	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-21 11:45:45	\N	author
ab4304a6-a7d0-48ba-80a1-28124b8be2a1	5db7f507-9905-461b-a3dc-d60048110343	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-21 11:45:45	\N	author
b64748e6-700c-44bb-b15b-d43e0c198bec	5db7f507-9905-461b-a3dc-d60048110343	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-21 11:45:45	\N	author
255a5c94-b180-44c4-91b6-d69c75bbf3b9	5db7f507-9905-461b-a3dc-d60048110343	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-21 11:45:45	\N	author
d44fe9ff-2d73-413b-b287-7d2ca062ca92	5db7f507-9905-461b-a3dc-d60048110343	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-21 11:45:45	\N	author
50151c19-bcf3-446c-9035-5ab7ddde8884	5db7f507-9905-461b-a3dc-d60048110343	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-21 11:45:45	\N	author
127d1b56-6067-4f9c-8d36-aa0921615642	5db7f507-9905-461b-a3dc-d60048110343	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-21 11:45:45	\N	author
b0e428e6-0c86-47fd-8ec2-83634aa61c38	5db7f507-9905-461b-a3dc-d60048110343	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-21 11:45:45	\N	author
1ad764e2-6688-433e-a77e-49ffa8f9c58b	5db7f507-9905-461b-a3dc-d60048110343	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-21 11:45:45	\N	author
d58b31d0-9a6b-473d-8d22-57cf5ac8f927	30f348d2-fe3d-458a-b7dc-9de8ff1bcb91	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-21 15:18:24	\N	author
759a65e5-0159-45a9-8c78-63257e4d4684	30f348d2-fe3d-458a-b7dc-9de8ff1bcb91	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-21 15:18:24	\N	author
c956b392-c43d-413d-bdc1-f6a4f147c280	30f348d2-fe3d-458a-b7dc-9de8ff1bcb91	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-21 15:18:24	\N	author
149604d3-d315-404b-929d-75a623f59fc7	30f348d2-fe3d-458a-b7dc-9de8ff1bcb91	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-21 15:18:24	\N	author
a0f006e5-ef7a-48c8-91bc-66b2568b4386	30f348d2-fe3d-458a-b7dc-9de8ff1bcb91	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-21 15:18:24	\N	author
b0e26bc6-b664-4434-a188-92497e3ee1f7	30f348d2-fe3d-458a-b7dc-9de8ff1bcb91	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-21 15:18:24	\N	author
2cdd87d0-b51e-4968-beeb-091ca68f3b65	30f348d2-fe3d-458a-b7dc-9de8ff1bcb91	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-21 15:18:24	\N	author
1c20f1d5-367a-4ddf-98e2-2e2cb58e47f9	30f348d2-fe3d-458a-b7dc-9de8ff1bcb91	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-21 15:18:24	\N	author
b3cf0568-c6a9-4b63-8d6c-02b6b57c08e0	30f348d2-fe3d-458a-b7dc-9de8ff1bcb91	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-21 15:18:24	\N	author
7b6bb5d9-e68d-429c-9be8-88e7183edb65	3a70b0f0-6c2e-445c-86fd-af7f4c08e2f3	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-01-21 16:02:57	\N	author
5ecb29df-335b-49c8-a179-08bdf673ed87	3a70b0f0-6c2e-445c-86fd-af7f4c08e2f3	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-01-21 16:02:57	\N	author
bfd6e1d6-b691-4698-b429-8f02dc0be4a0	3a70b0f0-6c2e-445c-86fd-af7f4c08e2f3	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-01-21 16:02:57	\N	author
1c189ce2-2e3e-4c29-95c0-362990f2acca	3a70b0f0-6c2e-445c-86fd-af7f4c08e2f3	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-01-21 16:02:57	\N	author
dbc514f2-8774-4f0c-941c-0b531923862d	3a70b0f0-6c2e-445c-86fd-af7f4c08e2f3	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-01-21 16:02:57	\N	author
de608215-215e-4323-8218-5f3d98669392	3a70b0f0-6c2e-445c-86fd-af7f4c08e2f3	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-01-21 16:02:57	\N	author
b08468b7-4044-41bb-9721-3b94d315a0d9	3a70b0f0-6c2e-445c-86fd-af7f4c08e2f3	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-01-21 16:02:57	\N	author
17abd25a-ef1e-4188-b145-0abc660e7d3a	3a70b0f0-6c2e-445c-86fd-af7f4c08e2f3	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-01-21 16:02:57	\N	author
2c1af695-429a-4169-a270-4143e3e52fb5	3a70b0f0-6c2e-445c-86fd-af7f4c08e2f3	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-01-21 16:02:57	\N	author
d4e6e477-b222-4610-be74-7ff397fbfdaf	a12228a9-2b5a-4130-bc32-0b7a01a3dd37	\N	1d03f765-fdaa-4b64-9f88-a772eba12e51	2016-01-27 16:48:16	\N	coordinator
58d29f4d-7c55-47c9-9e48-b59442cbc1aa	a12228a9-2b5a-4130-bc32-0b7a01a3dd37	\N	3ef14eae-7965-4400-a4f1-b5b713869622	2016-01-27 16:48:16	\N	director_dz
e762967c-6e95-49e7-843c-49bc83b8e3e8	a12228a9-2b5a-4130-bc32-0b7a01a3dd37	\N	2ae5db5a-da91-40b9-8ba7-a63a60b22676	2016-01-27 16:48:16	\N	director_dz
f0bf0f0b-4a80-446e-8ed5-d3b21f0a9416	a12228a9-2b5a-4130-bc32-0b7a01a3dd37	\N	da4f97e8-730d-4212-bde6-c259e9928a5e	2016-01-27 16:48:16	\N	coordinator
94ce556a-639f-42fd-baf6-ca684e90f372	a12228a9-2b5a-4130-bc32-0b7a01a3dd37	\N	6d7ef785-bffc-4b93-b565-1dcec4632fe0	2016-01-27 16:48:16	\N	expert
e8ba6bcc-cc78-456c-bb93-ef873cb69161	a12228a9-2b5a-4130-bc32-0b7a01a3dd37	\N	45250f65-4218-41a4-aadb-3d29e2fa4796	2016-01-27 16:48:16	\N	expert
25ce516c-eca9-4a49-8aa5-62b8f40a09b1	a12228a9-2b5a-4130-bc32-0b7a01a3dd37	\N	4281471b-abda-4452-a341-0e416dbd2ecd	2016-01-27 16:48:16	\N	monitor
cba5e96b-a169-4fd3-805f-e3fff86f55a0	a12228a9-2b5a-4130-bc32-0b7a01a3dd37	\N	21b30592-e308-4efe-af8f-63b1a72346a5	2016-01-27 16:48:16	\N	coordinator
1682e246-170b-4cfa-8926-a5175a4fa2de	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	5ce7b9cb-b70b-4090-b7a3-a0d9d1642162	2016-02-26 15:13:36	\N	autor
7257c21f-cbd3-43c7-b7a8-d8a3d42d6f32	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	1d03f765-fdaa-4b64-9f88-a772eba12e51	2016-02-26 15:13:36	\N	coordinator
506bbf97-544a-4df0-ab9b-5d6c344491fe	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	3ef14eae-7965-4400-a4f1-b5b713869622	2016-02-26 15:13:36	\N	director_dz
50dfd85b-0920-4de0-ada6-9824568d0dd8	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	2ae5db5a-da91-40b9-8ba7-a63a60b22676	2016-02-26 15:13:36	\N	director_dz
c7bf02b7-525c-43b2-94b7-f79e97569d9c	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	da4f97e8-730d-4212-bde6-c259e9928a5e	2016-02-26 15:13:36	\N	coordinator
9258f58c-f2e7-4442-a844-1e7ceec5f142	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	6d7ef785-bffc-4b93-b565-1dcec4632fe0	2016-02-26 15:13:36	\N	expert
7525ff07-92f8-4327-b19d-ab3a42304741	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	45250f65-4218-41a4-aadb-3d29e2fa4796	2016-02-26 15:13:36	\N	expert
75f70449-53f0-4cc8-92ca-db1a92c0f40d	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	4281471b-abda-4452-a341-0e416dbd2ecd	2016-02-26 15:13:36	\N	monitor
55c04750-bc57-423d-9681-f1a66e2a98b3	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	21b30592-e308-4efe-af8f-63b1a72346a5	2016-02-26 15:13:36	\N	coordinator
fbe4423c-6ad2-4a2f-857b-ecb4cf359d51	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	b81be4cf-2de7-4f12-bfed-0c57b5b49167	2016-02-26 15:13:36	\N	sekretar_kk
38062ebb-a587-489d-9740-935afa21bb3d	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	59f1b916-f4de-4368-a3b4-bcab9bb82b70	2016-02-26 15:13:36	\N	chlen_kk
56f9b3d0-10ed-4d12-91ae-b58a4760eb7b	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	0559b61f-279b-4015-a2e5-d8ac93d2505e	2016-02-26 15:13:36	\N	predsedatel_kk
ee6c29e9-e819-40c6-8cbe-0a508263fda0	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	a8f3dba8-716e-4bfa-b98d-dcbefa0ed4ec	2016-02-26 15:13:36	\N	zamestitel_pkk
3c839239-7593-4e6f-ab9c-00f9146ac1ce	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	df94ccca-6003-44ff-a54a-9a6e973ade8f	2016-02-26 15:13:36	\N	rukovoditel_co
aa3c10b2-04ba-48b4-be6e-6b2390c59ba8	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	411696d4-bc93-4b44-beca-27146449757e	2016-02-26 15:13:36	\N	specialist_co
63864f57-4d06-4eac-9245-d0907f8656f0	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	fea089a9-4927-4c08-805e-984492bd2191	2016-02-26 15:13:36	\N	rukovoditel_ispolnitel
b59a0efa-8b42-4c62-9be0-5b93fd65fac5	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	d5e31352-d81b-42e5-b378-30a8753d03be	2016-02-26 15:13:36	\N	specialist_ispolnitel
abd55d72-e4b9-4df5-9dd3-4cc4733b865c	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	08390255-6036-4f2a-ba91-67cdd4c6fd83	2016-02-26 15:13:36	\N	director_dz
e825bd07-f68c-4d1f-809b-5a0bb11004be	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	255d0f23-1a7c-4964-bf17-e9e9cdac4eea	2016-02-26 15:13:36	\N	monitor
4d12384c-96de-4f62-b44f-30967cf56264	9fe93b69-a35d-4b2f-959a-836efd76fe71	\N	5cd5fe26-a2a1-4537-aa75-c2bf2c3815b8	2016-02-26 15:13:36	\N	expert
016d471c-59f0-473c-97f9-998cd7717bdb	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-03-18 09:40:29	\N	autor
35bfcfc3-35a8-4a66-ba79-dd65d64ad690	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	1d03f765-fdaa-4b64-9f88-a772eba12e51	2016-03-18 09:40:29	\N	coordinator
26c85405-7b6c-4299-ab59-66d2375000e6	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	3ef14eae-7965-4400-a4f1-b5b713869622	2016-03-18 09:40:29	\N	director_dz
197eb1b2-c95e-427e-93f4-86739dad28ee	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	f0a51e92-a9f7-4fdd-938d-b5e20955d1e6	2016-03-18 09:40:29	\N	director_dz
7f2d3ce5-9119-4975-b189-1639f3087f09	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	08de2f58-424b-46a0-8cc2-5307df024ad8	2016-03-18 09:40:29	\N	director_dz
9f1cbc3d-8dde-4770-a518-5552fb31b1e7	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	5b942b2c-25c6-405a-a683-312c76b1fb34	2016-03-18 09:40:29	\N	director_dz
6611af74-2098-40dc-99a8-e356fbc3f0cc	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	78e8e7a7-96c8-48fa-9f73-22dd314dcf99	2016-03-18 09:40:29	\N	director_dz
8d609aed-bab1-4454-b0ce-5db28e415b9a	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	dd822929-f6a0-42e6-9b9c-4e6c3844cc4f	2016-03-18 09:40:29	\N	coordinator
86508350-5289-4486-93b8-d91192a6c250	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	dabd5f28-fd1b-4b58-bfd6-a1545be3ce02	2016-03-18 09:40:29	\N	director_dz
8f205502-3efa-471c-b548-2a6143939b6d	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	8bc90a07-558f-4523-9142-dec37446414e	2016-03-18 09:40:29	\N	director_dz
c8aa2c32-e1f3-4b87-9df6-495a0563e5e6	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	68bb5eec-19eb-4a12-9954-8035581540ed	2016-03-18 09:40:29	\N	coordinator
3ec06e5b-7f6c-4539-9898-b654649d71b3	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	9fedf471-0a97-451c-894d-03e157f0db94	2016-03-18 09:40:29	\N	coordinator
0c2945f7-9f85-46aa-966c-1ea59a32bb7e	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	6502e4a5-5a8f-4758-bf9f-e7d60f6aaa30	2016-03-18 09:40:29	\N	director_dz
661c06aa-159a-4c90-af78-2b4e276c1d79	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	5a992837-6622-45b0-b4c3-3ff8774aa004	2016-03-18 09:40:29	\N	coordinator
6a3d8ac3-a370-4f81-b940-1871b090c5c7	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	e53ebb16-4a8e-4ec2-b19f-3bcc39754e41	2016-03-18 09:40:29	\N	director_dz
035128a5-dfc2-4916-a16a-1074dfcd5d5f	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	3a380dc8-43c8-4560-9ebe-3d21fa1cad44	2016-03-18 09:40:29	\N	director_dz
efc64812-30a7-4c2b-803d-0d7a3a3dfd28	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	d107a138-3725-4eb7-91a3-8dd88f7d7656	2016-03-18 09:40:29	\N	director_dz
e56a47d4-6ebb-4437-a5c8-a3a989a0a330	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	1d0a7bca-531a-4af2-8db9-f26bb716ba41	2016-03-18 09:40:29	\N	director_dz
6f1bff8a-1ce0-4694-8a1c-ef43b4f2e048	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	70ad62ff-dab7-4efa-9f70-89c2ea0c3da9	2016-03-18 09:40:29	\N	coordinator
cdb15b29-d6ad-4c04-922e-a35ebc46ff5a	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	2a81efe8-47b1-42a1-bb44-ae3fd5d2716d	2016-03-18 09:40:29	\N	director_dz
19e4f64e-5fe9-4532-ba3f-a97946d70cf9	1dd67bf0-7641-4717-a9a5-8a6969461243	\N	9147779d-e8e0-47aa-9a2d-5e4a3be16920	2016-03-18 09:40:29	\N	director_dz
\.


--
-- TOC entry 2972 (class 0 OID 246272)
-- Dependencies: 178
-- Data for Name: work_flow; Type: TABLE DATA; Schema: public; Owner: iszgosbookru
--

COPY work_flow (id, subsystem, entity_type, common_type, govprogram_title, specorg_full_name, workflow_schema_yml, workflow_schema, name) FROM stdin;
a432cbc6-10ae-4b17-865f-32a34408aa58	fp_planirovanie	plan	\N	\N	\N	#plan_on_agreement:\r\nstart: draft\r\nend:   [ approved ]\r\nsteps:\r\n                        draft:\r\n                            label: Черновик\r\n                            allow_comments: []\r\n                            next_states:\r\n                                send_to_approve:\r\n                                    control: send_to_approve\r\n                                    roles: [ director_dz, coordinator, author ]\r\n                        on_agreement:\r\n                            label: На согласовании\r\n                            allow_comments: [ coordinator ]\r\n                            next_states:\r\n                                on_completion:\r\n                                    control: send_to_completion\r\n                                    roles: [ coordinator ]\r\n                                confirm:\r\n                                    control: confirm\r\n                                    roles: [ coordinator ]\r\n                        on_completion:\r\n                            label: На доработке\r\n                            allow_comments: []\r\n                            next_states:\r\n                                send_to_approve:\r\n                                    control: send_to_approve\r\n                                    roles: [ director_dz ]\r\n                        approved:\r\n                            label: Согласован\r\n                            allow_comments: []\r\n                            next_states:\r\n                                on_completion:\r\n                                    control: send_to_completion\r\n                                    roles: [ director_dz ]\r\n                        confirmed:\r\n                            allow_comments: []\r\n                            label: Планируется\r\n                            next_states: ~	{"start":"draft","end":["approved"],"steps":{"draft":{"label":"\\u0427\\u0435\\u0440\\u043d\\u043e\\u0432\\u0438\\u043a","allow_comments":[],"next_states":{"send_to_approve":{"control":"send_to_approve","roles":["director_dz","coordinator","author"]}}},"on_agreement":{"label":"\\u041d\\u0430 \\u0441\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d\\u0438\\u0438","allow_comments":["coordinator"],"next_states":{"on_completion":{"control":"send_to_completion","roles":["coordinator"]},"confirm":{"control":"confirm","roles":["coordinator"]}}},"on_completion":{"label":"\\u041d\\u0430 \\u0434\\u043e\\u0440\\u0430\\u0431\\u043e\\u0442\\u043a\\u0435","allow_comments":[],"next_states":{"send_to_approve":{"control":"send_to_approve","roles":["director_dz"]}}},"approved":{"label":"\\u0421\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d","allow_comments":[],"next_states":{"on_completion":{"control":"send_to_completion","roles":["director_dz"]}}},"confirmed":{"allow_comments":[],"label":"\\u041f\\u043b\\u0430\\u043d\\u0438\\u0440\\u0443\\u0435\\u0442\\u0441\\u044f","next_states":null}}}	default
0563421d-5230-41ae-b152-7dd62935e562	fp_planirovanie	lot	\N	\N	\N	start: draft\r\nend: [planned]\r\nsteps:\r\n                        draft:\r\n                            label: Черновик\r\n                            allow_comments: [ author, coordinator ]\r\n                            next_states:\r\n                                send_to_approve:\r\n                                    control: send_to_approve\r\n                                    roles: [ author ]\r\n                                delete:\r\n                                    control: delete\r\n                                    roles: [ author ]\r\n                                edit:\r\n                                    control: edit\r\n                                    roles: [ author, director_dz, coordinator ]\r\n                        on_agreement:\r\n                            label: На согласовании\r\n                            allow_comments: [ director_dz, coordinator ]\r\n                            next_states:\r\n                                on_completion:\r\n                                    control: send_to_completion\r\n                                    roles: [ director_dz ]\r\n                                approved:\r\n                                    control: confirm\r\n                                    roles: [ director_dz ]\r\n                        on_completion:\r\n                            label: На доработке\r\n                            allow_comments: [ author, coordinator ]\r\n                            next_states:\r\n                                send_to_approve:\r\n                                    control: send_to_approve\r\n                                    roles: [ author ]\r\n                                edit:\r\n                                    control: edit\r\n                                    roles: [ author, director_dz, coordinator ]\r\n                        approved:\r\n                            label: Согласован\r\n                            view_comments: [ author, coordinator ]\r\n                            next_states:\r\n                                send_to_plan:\r\n                                    control: send_to_plan\r\n                                    roles: [ director_dz, coordinator ]\r\n                        planning:\r\n                            label: Запланирован\r\n                            view_comments: [ author, coordinator ]\r\n                            next_states:\r\n                                remove_from_plan:\r\n                                    control: remove_from_plan\r\n                                    roles: [ director_dz, coordinator ]\r\n                        planned:\r\n                            allow_comments: ~\r\n                            label: В плане\r\n                            next_states: ~	{"start":"draft","end":["planned"],"steps":{"draft":{"label":"\\u0427\\u0435\\u0440\\u043d\\u043e\\u0432\\u0438\\u043a","allow_comments":["author","coordinator"],"next_states":{"send_to_approve":{"control":"send_to_approve","roles":["author"]},"delete":{"control":"delete","roles":["author"]},"edit":{"control":"edit","roles":["author","director_dz","coordinator"]}}},"on_agreement":{"label":"\\u041d\\u0430 \\u0441\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d\\u0438\\u0438","allow_comments":["director_dz","coordinator"],"next_states":{"on_completion":{"control":"send_to_completion","roles":["director_dz"]},"approved":{"control":"confirm","roles":["director_dz"]}}},"on_completion":{"label":"\\u041d\\u0430 \\u0434\\u043e\\u0440\\u0430\\u0431\\u043e\\u0442\\u043a\\u0435","allow_comments":["author","coordinator"],"next_states":{"send_to_approve":{"control":"send_to_approve","roles":["author"]},"edit":{"control":"edit","roles":["author","director_dz","coordinator"]}}},"approved":{"label":"\\u0421\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d","view_comments":["author","coordinator"],"next_states":{"send_to_plan":{"control":"send_to_plan","roles":["director_dz","coordinator"]}}},"planning":{"label":"\\u0417\\u0430\\u043f\\u043b\\u0430\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d","view_comments":["author","coordinator"],"next_states":{"remove_from_plan":{"control":"remove_from_plan","roles":["director_dz","coordinator"]}}},"planned":{"allow_comments":null,"label":"\\u0412 \\u043f\\u043b\\u0430\\u043d\\u0435","next_states":null}}}	default
28048549-5982-4bb2-acc5-f2087e4516bd	fp_planirovanie	lot	\N	\N	\N	start: draft\r\nend:   [ approved ]\r\nsteps:\r\n                        draft:\r\n                            label: Черновик\r\n                            allow_comments: ~\r\n                            next_states:\r\n                                send_to_approve:\r\n                                    control: send_to_approve_dzp\r\n                                    roles: [ specialist_dzp ]\r\n                                delete:\r\n                                    control: delete\r\n                                    roles: [ specialist_dzp ]\r\n                                edit:\r\n                                    control: edit\r\n                                    roles: [ specialist_dzp, director_dz, coordinator ]\r\n                        on_agreement:\r\n                            label: На согласовании\r\n                            allow_comments: [ rukovoditel_dzp ]\r\n                            next_states:\r\n                                on_completion_dzp:\r\n                                    control: send_to_completion_dzp\r\n                                    roles: [ rukovoditel_dzp ]\r\n                                approved_dzp:\r\n                                    control: confirm_dzp\r\n                                    roles: [ rukovoditel_dzp ]\r\n                        on_completion_dzp:\r\n                            label: На доработке\r\n                            allow_comments: [ rukovoditel_dzp, specialist_dzp ]\r\n                            next_states:\r\n                                send_to_approve:\r\n                                    control: send_to_approve_dzp\r\n                                    roles: [ specialist_dzp ]\r\n                                edit:\r\n                                    control: edit\r\n                                    roles: [ specialist_dzp, director_dz, coordinator ]\r\n                        approved_dzp:\r\n                            label: Согласован РДЗ Подвед\r\n                            allow_comments: [ rukovoditel_dzp ]\r\n                            next_states:\r\n                                on_agreement_curator:\r\n                                    control: on_agreement_curator\r\n                                    roles: [ rukovoditel_dzp ]\r\n                        on_agreement_curator:\r\n                            label: На согласовании Руководителем Куратором\r\n                            allow_comments: [ rukovoditel_curator ]\r\n                            next_states:\r\n                                on_completion:\r\n                                    control: send_to_completion\r\n                                    roles: [ rukovoditel_curator ]\r\n                                approved:\r\n                                    control: confirm\r\n                                    roles: [ rukovoditel_curator ]\r\n                        on_completion_curator:\r\n                            label: На доработке Руководителем ДЗП\r\n                            allow_comments: [ rukovoditel_curator, rukovoditel_dzp ]\r\n                            next_states:\r\n                                send_to_approve:\r\n                                    control: send_to_approve_curator\r\n                                    roles: [ rukovoditel_dzp ]\r\n                                edit:\r\n                                    control: edit\r\n                                    roles: [ rukovoditel_dzp, director_dz, coordinator ]\r\n                                on_completion:\r\n                                    control: send_to_completion\r\n                                    roles: [ rukovoditel_dzp ]\r\n                        approved:\r\n                            allow_comments: ~\r\n                            label: Согласован\r\n                            next_states: ~	{"start":"draft","end":["approved"],"steps":{"draft":{"label":"\\u0427\\u0435\\u0440\\u043d\\u043e\\u0432\\u0438\\u043a","allow_comments":null,"next_states":{"send_to_approve":{"control":"send_to_approve_dzp","roles":["specialist_dzp"]},"delete":{"control":"delete","roles":["specialist_dzp"]},"edit":{"control":"edit","roles":["specialist_dzp","director_dz","coordinator"]}}},"on_agreement":{"label":"\\u041d\\u0430 \\u0441\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d\\u0438\\u0438","allow_comments":["rukovoditel_dzp"],"next_states":{"on_completion_dzp":{"control":"send_to_completion_dzp","roles":["rukovoditel_dzp"]},"approved_dzp":{"control":"confirm_dzp","roles":["rukovoditel_dzp"]}}},"on_completion_dzp":{"label":"\\u041d\\u0430 \\u0434\\u043e\\u0440\\u0430\\u0431\\u043e\\u0442\\u043a\\u0435","allow_comments":["rukovoditel_dzp","specialist_dzp"],"next_states":{"send_to_approve":{"control":"send_to_approve_dzp","roles":["specialist_dzp"]},"edit":{"control":"edit","roles":["specialist_dzp","director_dz","coordinator"]}}},"approved_dzp":{"label":"\\u0421\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d \\u0420\\u0414\\u0417 \\u041f\\u043e\\u0434\\u0432\\u0435\\u0434","allow_comments":["rukovoditel_dzp"],"next_states":{"on_agreement_curator":{"control":"on_agreement_curator","roles":["rukovoditel_dzp"]}}},"on_agreement_curator":{"label":"\\u041d\\u0430 \\u0441\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d\\u0438\\u0438 \\u0420\\u0443\\u043a\\u043e\\u0432\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u0435\\u043c \\u041a\\u0443\\u0440\\u0430\\u0442\\u043e\\u0440\\u043e\\u043c","allow_comments":["rukovoditel_curator"],"next_states":{"on_completion":{"control":"send_to_completion","roles":["rukovoditel_curator"]},"approved":{"control":"confirm","roles":["rukovoditel_curator"]}}},"on_completion_curator":{"label":"\\u041d\\u0430 \\u0434\\u043e\\u0440\\u0430\\u0431\\u043e\\u0442\\u043a\\u0435 \\u0420\\u0443\\u043a\\u043e\\u0432\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u0435\\u043c \\u0414\\u0417\\u041f","allow_comments":["rukovoditel_curator","rukovoditel_dzp"],"next_states":{"send_to_approve":{"control":"send_to_approve_curator","roles":["rukovoditel_dzp"]},"edit":{"control":"edit","roles":["rukovoditel_dzp","director_dz","coordinator"]},"on_completion":{"control":"send_to_completion","roles":["rukovoditel_dzp"]}}},"approved":{"allow_comments":null,"label":"\\u0421\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d","next_states":null}}}	workflow2
c655da4f-57bb-4a06-acbf-b9477f39fe90	fp_documents	lot	\N	\N	\N	start: draft\r\nend:   [ approved ]\r\nsteps:\r\n                draft:\r\n                    label: Черновик\r\n                    allow_comments: [ author ]\r\n                    next_states:\r\n                        send_to_approve:\r\n                            control: send_to_approve\r\n                            roles: [ author ]\r\n                        edit:\r\n                            control: edit\r\n                            roles: [ author, director_dz, coordinator ]\r\n                on_completion:\r\n                    label: На доработке\r\n                    allow_comments: [ author, director_dz ]\r\n                    next_states:\r\n                        send_to_approve:\r\n                            control: send_to_approve\r\n                            roles: [ author ]\r\n                        edit:\r\n                            control: edit\r\n                            roles: [ author, director_dz, coordinator ]\r\n                on_agreement:\r\n                    label: На согласовании РДЗ\r\n                    allow_comments: [ director_dz ]\r\n                    next_states:\r\n                        on_completion:\r\n                            control: send_to_completion\r\n                            roles: [ director_dz ]\r\n                        on_agreement_monitor:\r\n                            control: send_to_monitor\r\n                            roles: [ director_dz ]\r\n                on_agreement_monitor:\r\n                    label: На согласование ОМ\r\n                    allow_comments: [ monitor ]\r\n                    next_states:\r\n                        on_completion:\r\n                            control: send_to_completion\r\n                            roles: [ monitor ]\r\n                        on_delegation:\r\n                            control: delegate\r\n                            roles: [ monitor ]\r\n                        on_agreement_coordinator:\r\n                            control: send_to_coordinator\r\n                            roles: [ monitor ]\r\n                on_agreement_coordinator:\r\n                    label: На согласование К\r\n                    allow_comments: [ coordinator ]\r\n                    next_states:\r\n                        on_completion:\r\n                            control: send_to_completion\r\n                            roles: [ coordinator ]\r\n                        approved:\r\n                            control: confirm\r\n                            roles: [ coordinator ]\r\n                on_delegation:\r\n                    allow_comments: [ expert ]\r\n                    label: Делегирован Эксперту\r\n                    next_states:\r\n                        on_agreement_monitor:\r\n                            control: form_conclusion\r\n                            roles: [ expert ]\r\n                approved:\r\n                    label: Согласован\r\n                    allow_comments: ~\r\n                    next_states:\r\n                        edit:\r\n                            control: edit\r\n                            roles: [ author, director_dz, coordinator ]\r\n                        posted:\r\n                            control: posted_coordinator\r\n                            roles: [ coordinator ]	{"start":"draft","end":["approved"],"steps":{"draft":{"label":"\\u0427\\u0435\\u0440\\u043d\\u043e\\u0432\\u0438\\u043a","allow_comments":["author"],"next_states":{"send_to_approve":{"control":"send_to_approve","roles":["author"]},"edit":{"control":"edit","roles":["author","director_dz","coordinator"]}}},"on_completion":{"label":"\\u041d\\u0430 \\u0434\\u043e\\u0440\\u0430\\u0431\\u043e\\u0442\\u043a\\u0435","allow_comments":["author","director_dz"],"next_states":{"send_to_approve":{"control":"send_to_approve","roles":["author"]},"edit":{"control":"edit","roles":["author","director_dz","coordinator"]}}},"on_agreement":{"label":"\\u041d\\u0430 \\u0441\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d\\u0438\\u0438 \\u0420\\u0414\\u0417","allow_comments":["director_dz"],"next_states":{"on_completion":{"control":"send_to_completion","roles":["director_dz"]},"on_agreement_monitor":{"control":"send_to_monitor","roles":["director_dz"]}}},"on_agreement_monitor":{"label":"\\u041d\\u0430 \\u0441\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d\\u0438\\u0435 \\u041e\\u041c","allow_comments":["monitor"],"next_states":{"on_completion":{"control":"send_to_completion","roles":["monitor"]},"on_delegation":{"control":"delegate","roles":["monitor"]},"on_agreement_coordinator":{"control":"send_to_coordinator","roles":["monitor"]}}},"on_agreement_coordinator":{"label":"\\u041d\\u0430 \\u0441\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d\\u0438\\u0435 \\u041a","allow_comments":["coordinator"],"next_states":{"on_completion":{"control":"send_to_completion","roles":["coordinator"]},"approved":{"control":"confirm","roles":["coordinator"]}}},"on_delegation":{"allow_comments":["expert"],"label":"\\u0414\\u0435\\u043b\\u0435\\u0433\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d \\u042d\\u043a\\u0441\\u043f\\u0435\\u0440\\u0442\\u0443","next_states":{"on_agreement_monitor":{"control":"form_conclusion","roles":["expert"]}}},"approved":{"label":"\\u0421\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d","allow_comments":null,"next_states":{"edit":{"control":"edit","roles":["author","director_dz","coordinator"]},"posted":{"control":"posted_coordinator","roles":["coordinator"]}}}}}	default
1d9a797f-1c0a-469f-864c-4658118c3984	fp_planirovanie	plan	\N	\N	\N	start: draft\nend:   [ confirmed ]\nsteps:\n                        draft:\n                            label: Архивный\n                            allow_comments: []\n                            next_states: ~	{"start":"draft","end":["confirmed"],"steps":{"draft":{"label":"\\u0410\\u0440\\u0445\\u0438\\u0432\\u043d\\u044b\\u0439","allow_comments":[],"next_states":null}}}	plan_archived
8324b0ff-c80e-4de6-94f0-6c2dfb2d883c	fp_planirovanie	lot	\N	\N	\N	start: draft\r\nend:   [ planned ]\r\nsteps:\r\n                        draft:\r\n                            label: Черновик\r\n                            allow_comments: [ author, coordinator ]\r\n                            next_states:\r\n                                send_to_approve:\r\n                                    control: send_to_approve\r\n                                    roles: [ author ]\r\n                                delete:\r\n                                    control: delete\r\n                                    roles: [ author ]\r\n                                edit:\r\n                                    control: edit\r\n                                    roles: [ author, director_dz, coordinator ]\r\n                        on_agreement:\r\n                            label: На согласовании\r\n                            allow_comments: [ director_dz, coordinator ]\r\n                            next_states:\r\n                                on_completion:\r\n                                    control: send_to_completion\r\n                                    roles: [ director_dz ]\r\n                                approved:\r\n                                    control: confirm_coordinator\r\n                                    roles: [ director_dz ]\r\n                        on_completion:\r\n                            label: На доработке\r\n                            allow_comments: [ author, coordinator ]\r\n                            next_states:\r\n                                send_to_approve:\r\n                                    control: send_to_approve\r\n                                    roles: [ author ]\r\n                                edit:\r\n                                    control: edit\r\n                                    roles: [ author, director_dz, coordinator ]\r\n                        approved:\r\n                            label: Согласован\r\n                            view_comments: [ author, coordinator ]\r\n                            next_states:\r\n                                send_to_plan:\r\n                                    control: send_to_plan\r\n                                    roles: [ coordinator ]\r\n                                on_completion:\r\n                                    control: send_to_completion\r\n                                    roles: [ coordinator ]\r\n                                on_agreement:\r\n                                    control: send_to_approve_rdz\r\n                                    roles: [ director_dz ]\r\n                        planning:\r\n                            label: Запланирован\r\n                            view_comments: [ author, coordinator ]\r\n                            next_states:\r\n                                remove_from_plan:\r\n                                    control: remove_from_plan\r\n                                    roles: [ coordinator ]\r\n                        planned:\r\n                            allow_comments: ~\r\n                            label: В плане\r\n                            next_states: ~	{"start":"draft","end":["planned"],"steps":{"draft":{"label":"\\u0427\\u0435\\u0440\\u043d\\u043e\\u0432\\u0438\\u043a","allow_comments":["author","coordinator"],"next_states":{"send_to_approve":{"control":"send_to_approve","roles":["author"]},"delete":{"control":"delete","roles":["author"]},"edit":{"control":"edit","roles":["author","director_dz","coordinator"]}}},"on_agreement":{"label":"\\u041d\\u0430 \\u0441\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d\\u0438\\u0438","allow_comments":["director_dz","coordinator"],"next_states":{"on_completion":{"control":"send_to_completion","roles":["director_dz"]},"approved":{"control":"confirm_coordinator","roles":["director_dz"]}}},"on_completion":{"label":"\\u041d\\u0430 \\u0434\\u043e\\u0440\\u0430\\u0431\\u043e\\u0442\\u043a\\u0435","allow_comments":["author","coordinator"],"next_states":{"send_to_approve":{"control":"send_to_approve","roles":["author"]},"edit":{"control":"edit","roles":["author","director_dz","coordinator"]}}},"approved":{"label":"\\u0421\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d","view_comments":["author","coordinator"],"next_states":{"send_to_plan":{"control":"send_to_plan","roles":["coordinator"]},"on_completion":{"control":"send_to_completion","roles":["coordinator"]},"on_agreement":{"control":"send_to_approve_rdz","roles":["director_dz"]}}},"planning":{"label":"\\u0417\\u0430\\u043f\\u043b\\u0430\\u043d\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d","view_comments":["author","coordinator"],"next_states":{"remove_from_plan":{"control":"remove_from_plan","roles":["coordinator"]}}},"planned":{"allow_comments":null,"label":"\\u0412 \\u043f\\u043b\\u0430\\u043d\\u0435","next_states":null}}}	pgd_on_agreement
04be3001-1061-4acc-871e-bc8449bfa55c	fp_planirovanie	plan	\N	\N	\N	start: draft\r\nend:   [ confirmed ]\r\nsteps:\r\n                        draft:\r\n                            label: Черновик\r\n                            allow_comments: []\r\n                            next_states:\r\n                                #send_to_approve:\r\n                                #    control: send_to_approve\r\n                                #    roles: [ director_dz, coordinator ]\r\n                                #on_completion:\r\n                                #    control: send_to_completion\r\n                                #    roles: [ coordinator ]\r\n                                confirm:\r\n                                    control: confirm\r\n                                    roles: [ coordinator ]\r\n                                plan_consolidate_download_xml:\r\n                                    control: plan_consolidate_download_xml\r\n                                    roles: [ coordinator ]\r\n                                plan_send_zakupki:\r\n                                    control: plan_send_zakupki\r\n                                    roles: [ coordinator ]\r\n                        on_agreement:\r\n                            label: На согласовании\r\n                            allow_comments: [ coordinator ]\r\n                            next_states:\r\n                                on_completion:\r\n                                    control: send_to_completion\r\n                                    roles: [ coordinator ]\r\n                                confirm:\r\n                                    control: confirm\r\n                                    roles: [ coordinator ]\r\n                                plan_consolidate_download_xml:\r\n                                    control: plan_consolidate_download_xml\r\n                                    roles: [ coordinator ]\r\n                                plan_send_zakupki:\r\n                                    control: plan_send_zakupki\r\n                                    roles: [ coordinator ]\r\n                        on_completion:\r\n                            label: На доработке\r\n                            allow_comments: []\r\n                            next_states:\r\n                                send_to_approve:\r\n                                    control: send_to_approve\r\n                                    roles: [ director_dz ]\r\n                                plan_consolidate_download_xml:\r\n                                    control: plan_consolidate_download_xml\r\n                                    roles: [ coordinator ]\r\n                                plan_send_zakupki:\r\n                                    control: plan_send_zakupki\r\n                                    roles: [ coordinator ]\r\n                        approved:\r\n                            label: Согласован\r\n                            allow_comments: []\r\n                            next_states:\r\n                                on_completion:\r\n                                    control: send_to_completion\r\n                                    roles: [ director_dz ]\r\n                                plan_consolidate_download_xml:\r\n                                    control: plan_consolidate_download_xml\r\n                                    roles: [ coordinator ]\r\n                                plan_send_zakupki:\r\n                                    control: plan_send_zakupki\r\n                                    roles: [ coordinator ]\r\n                        confirmed:\r\n                            allow_comments: []\r\n                            label: Zakupki.gov.ru\r\n                            next_states:\r\n                                plan_consolidate_download_xml:\r\n                                    control: plan_consolidate_download_xml\r\n                                    roles: [ coordinator ]\r\n                                plan_send_zakupki:\r\n                                    control: plan_send_zakupki\r\n                                    roles: [ coordinator ]	{"start":"draft","end":["confirmed"],"steps":{"draft":{"label":"\\u0427\\u0435\\u0440\\u043d\\u043e\\u0432\\u0438\\u043a","allow_comments":[],"next_states":{"confirm":{"control":"confirm","roles":["coordinator"]},"plan_consolidate_download_xml":{"control":"plan_consolidate_download_xml","roles":["coordinator"]},"plan_send_zakupki":{"control":"plan_send_zakupki","roles":["coordinator"]}}},"on_agreement":{"label":"\\u041d\\u0430 \\u0441\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d\\u0438\\u0438","allow_comments":["coordinator"],"next_states":{"on_completion":{"control":"send_to_completion","roles":["coordinator"]},"confirm":{"control":"confirm","roles":["coordinator"]},"plan_consolidate_download_xml":{"control":"plan_consolidate_download_xml","roles":["coordinator"]},"plan_send_zakupki":{"control":"plan_send_zakupki","roles":["coordinator"]}}},"on_completion":{"label":"\\u041d\\u0430 \\u0434\\u043e\\u0440\\u0430\\u0431\\u043e\\u0442\\u043a\\u0435","allow_comments":[],"next_states":{"send_to_approve":{"control":"send_to_approve","roles":["director_dz"]},"plan_consolidate_download_xml":{"control":"plan_consolidate_download_xml","roles":["coordinator"]},"plan_send_zakupki":{"control":"plan_send_zakupki","roles":["coordinator"]}}},"approved":{"label":"\\u0421\\u043e\\u0433\\u043b\\u0430\\u0441\\u043e\\u0432\\u0430\\u043d","allow_comments":[],"next_states":{"on_completion":{"control":"send_to_completion","roles":["director_dz"]},"plan_consolidate_download_xml":{"control":"plan_consolidate_download_xml","roles":["coordinator"]},"plan_send_zakupki":{"control":"plan_send_zakupki","roles":["coordinator"]}}},"confirmed":{"allow_comments":[],"label":"Zakupki.gov.ru","next_states":{"plan_consolidate_download_xml":{"control":"plan_consolidate_download_xml","roles":["coordinator"]},"plan_send_zakupki":{"control":"plan_send_zakupki","roles":["coordinator"]}}}}}	plan_consolidated
\.


--
-- TOC entry 2841 (class 2606 OID 246279)
-- Name: expertise_field_pkey; Type: CONSTRAINT; Schema: public; Owner: iszgosbookru; Tablespace: 
--

ALTER TABLE ONLY expertise_field
    ADD CONSTRAINT expertise_field_pkey PRIMARY KEY (id);


--
-- TOC entry 2844 (class 2606 OID 246281)
-- Name: expertise_group_pkey; Type: CONSTRAINT; Schema: public; Owner: iszgosbookru; Tablespace: 
--

ALTER TABLE ONLY expertise_group
    ADD CONSTRAINT expertise_group_pkey PRIMARY KEY (id);


--
-- TOC entry 2847 (class 2606 OID 246283)
-- Name: expertise_status_pkey; Type: CONSTRAINT; Schema: public; Owner: iszgosbookru; Tablespace: 
--

ALTER TABLE ONLY expertise_status
    ADD CONSTRAINT expertise_status_pkey PRIMARY KEY (id);


--
-- TOC entry 2849 (class 2606 OID 246285)
-- Name: expertise_user_pkey; Type: CONSTRAINT; Schema: public; Owner: iszgosbookru; Tablespace: 
--

ALTER TABLE ONLY expertise_user
    ADD CONSTRAINT expertise_user_pkey PRIMARY KEY (id);


--
-- TOC entry 2853 (class 2606 OID 246287)
-- Name: work_flow_pkey; Type: CONSTRAINT; Schema: public; Owner: iszgosbookru; Tablespace: 
--

ALTER TABLE ONLY work_flow
    ADD CONSTRAINT work_flow_pkey PRIMARY KEY (id);


--
-- TOC entry 2850 (class 1259 OID 246288)
-- Name: idx_3f81f5186bf700bd; Type: INDEX; Schema: public; Owner: iszgosbookru; Tablespace: 
--

CREATE INDEX idx_3f81f5186bf700bd ON expertise_user USING btree (status_id);


--
-- TOC entry 2851 (class 1259 OID 246289)
-- Name: idx_3f81f518ea75eb4a; Type: INDEX; Schema: public; Owner: iszgosbookru; Tablespace: 
--

CREATE INDEX idx_3f81f518ea75eb4a ON expertise_user USING btree (expertise_group_id);


--
-- TOC entry 2842 (class 1259 OID 246290)
-- Name: idx_472b361987009189; Type: INDEX; Schema: public; Owner: iszgosbookru; Tablespace: 
--

CREATE INDEX idx_472b361987009189 ON expertise_field USING btree (expertise_user_id);


--
-- TOC entry 2845 (class 1259 OID 246291)
-- Name: idx_711e37846bf700bd; Type: INDEX; Schema: public; Owner: iszgosbookru; Tablespace: 
--

CREATE INDEX idx_711e37846bf700bd ON expertise_group USING btree (status_id);


--
-- TOC entry 2854 (class 1259 OID 262425)
-- Name: work_flow_subsystem_entity_type_name; Type: INDEX; Schema: public; Owner: iszgosbookru; Tablespace: 
--

CREATE UNIQUE INDEX work_flow_subsystem_entity_type_name ON work_flow USING btree (subsystem, entity_type, name);


--
-- TOC entry 2857 (class 2606 OID 246292)
-- Name: fk_3f81f5186bf700bd; Type: FK CONSTRAINT; Schema: public; Owner: iszgosbookru
--

ALTER TABLE ONLY expertise_user
    ADD CONSTRAINT fk_3f81f5186bf700bd FOREIGN KEY (status_id) REFERENCES expertise_status(id);


--
-- TOC entry 2858 (class 2606 OID 246297)
-- Name: fk_3f81f518ea75eb4a; Type: FK CONSTRAINT; Schema: public; Owner: iszgosbookru
--

ALTER TABLE ONLY expertise_user
    ADD CONSTRAINT fk_3f81f518ea75eb4a FOREIGN KEY (expertise_group_id) REFERENCES expertise_group(id);


--
-- TOC entry 2855 (class 2606 OID 246302)
-- Name: fk_472b361987009189; Type: FK CONSTRAINT; Schema: public; Owner: iszgosbookru
--

ALTER TABLE ONLY expertise_field
    ADD CONSTRAINT fk_472b361987009189 FOREIGN KEY (expertise_user_id) REFERENCES expertise_user(id);


--
-- TOC entry 2856 (class 2606 OID 246307)
-- Name: fk_711e37846bf700bd; Type: FK CONSTRAINT; Schema: public; Owner: iszgosbookru
--

ALTER TABLE ONLY expertise_group
    ADD CONSTRAINT fk_711e37846bf700bd FOREIGN KEY (status_id) REFERENCES expertise_status(id);


--
-- TOC entry 2979 (class 0 OID 0)
-- Dependencies: 8
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2016-03-23 08:40:18 MSK

--
-- PostgreSQL database dump complete
--

